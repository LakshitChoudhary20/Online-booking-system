(function(_) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    var ba, da, fa, ia, la, qa, sa, wa, va, xa, ya, Aa, Ba, Ca, Ea, Fa, Ja, Ka, La, Ma, Oa, Xa, db, fb, hb, jb, pb, sb, vb, wb, Ab, Db, Fb, Hb, Ib, Nb, Pb, Ob, Qb, Rb, Jb, Sb, Wb, Xb, Zb, $b, bc, cc, dc, ec, gc, hc, nc, oc, pc, rc, sc, uc, yc, tc, Ac, Cc, Dc, Fc, Ic, Jc, Kc, Lc, Mc, Oc, Tc, Rc, Vc, Qc, Pc, Wc, Xc, Yc, Zc, $c, ad, bd, ed, dd, gd, hd, jd, md, od, pd, qd, sd, rd, Ad, Cd, Bd, Ed, Dd, Fd, Hd, nd, Ld, Pd, Rd, Sd, Td, Wd, Xd, Yd, Zd, de, ee, Qd, fe, ge, ie, je, ke, oe, pe, qe, me, we, ne, xe, Be, De, Fe, Ie, Je, Ke, Ne, Qe, Re, We, Xe, Ye, Ze, $e, bf, df, ef, hf, jf, kf, nf, pf, qf, sf, uf, vf, wf, xf, yf, Af, Bf, Df, Ef, Hf, Jf, Nf, Of, Pf, Sf, Wf, Yf, bg, $f, fg, gg, hg, dg, eg, ig, jg, kg, ng, og, sg, tg, Ag, Bg, Gg, Kg, Og, Rg, Tg, Vg, Wg, Xg, Yg, Zg, $g, bh, eh, fh, lh, sh, vh, xh, K, yh, Eh, Ch, Vh, Xh, Zh, $h, ei, hi, li, oi, vi, pi, Ci, Di, Ei, Fi, wi, Gi, xi, Ii, Ji, Li, Mi, Oi, Ni, Qi, Vi, Ti, Wi, ej, hj, $i, aj, ij, lj, jj, oj, pj, qj, tj, uj, zj, Aj, Lj, Rj, Pj, Qj, Wj, ak, ck, dk, ek, gk, kk, uk, nk, hk, Dk, Bk, Ck, Fk, Hk, Kk, O, Mk, Nk, Ok, Qk, Sk, Tk, $k, al, cl, dl, jl, ll, ml, ql, ul, vl, wl, yl, Cl, Hl, Jl, Kl, Ml, Nl, Rl, Sl, Tl, $l, Ql, bm, cm, dm, fm, im, km, lm, mm, nm, pm, qm, sm, um, vm, tm, zm, Am, Em, Fm, Hm, Pm, Rm, Tm, Wm, Vm, Um, dn, gn, hn, jn, kn, on, qn, un, yn, zn, An, Dn, Gn, Fn, Jn, Pn, Qn, Sn, ao, Zn, eo, ho, Tn, so, to, wo, vo, yo, Ao, Co, Eo, Go, Mo, Ro, So, Vo, Yo, Wo, Xo, $o, ap, bp, ep, fp, gp, hp, jp, np, op, pp, qp, tp, up, vp, wp, xp, zp, Ap, Bp, Fp, Pp, Ip, Rp, Sp, Yp, Vp, Wp, Xp, bq, cq, Up, kq, mq, nq, pq, vq, yq, Aq, Bq, Gq, Iq, Kq, Nq, ra, Oq, Pq, Rq, Qq, Sq, Tq, Vq, Xq, Yq, $q, br, fr, cr, gr, hr, jr, kr, lr, mr, nr, or, wr, xr, yr, zr, Fr, Ir, Kr, Lr, Mr, Pr, os, vs, ws, As, Bs, jt, mt, ut, pt, rt, xt, wt, zt, Bt, At, Dt, Lt, Pt, Vt, $t, bu, cu, du, fu, gu, hu, iu, ku, lu, mu, tu, uu, vu, ob, xu, Au, yu, zu, Bu, Cu;
    ba = function(a) {
        return function() {
            return _.aa[a].apply(this, arguments)
        }
    };
    da = function(a) {
        return a ? a.passive && ca() ? a : a.capture || !1 : !1
    };
    fa = function(a, b) {
        b = _.ea(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    };
    _.ha = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    ia = function(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    };
    la = function(a) {
        for (var b = 0, c = 0, d = {}; c < a.length;) {
            var e = a[c++],
                f = _.ja(e) ? "o" + _.ka(e) : (typeof e).charAt(0) + e;
            Object.prototype.hasOwnProperty.call(d, f) || (d[f] = !0, a[b++] = e)
        }
        a.length = b
    };
    qa = function(a, b) {
        a.sort(b || _.oa)
    };
    sa = function(a) {
        for (var b = ra, c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
            index: d,
            value: a[d]
        };
        var e = b || _.oa;
        qa(c, function(f, g) {
            return e(f.value, g.value) || f.index - g.index
        });
        for (b = 0; b < a.length; b++) a[b] = c[b].value
    };
    wa = function(a, b) {
        if (!_.ta(a) || !_.ta(b) || a.length != b.length) return !1;
        for (var c = a.length, d = va, e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    };
    _.oa = function(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    };
    va = function(a, b) {
        return a === b
    };
    xa = function(a, b) {
        for (var c = {}, d = 0; d < a.length; d++) {
            var e = a[d],
                f = b.call(void 0, e, d, a);
            void 0 !== f && (c[f] || (c[f] = [])).push(e)
        }
        return c
    };
    ya = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192)
                    for (var f = ya.apply(null, ia(d, e, e + 8192)), g = 0; g < f.length; g++) b.push(f[g]);
            else b.push(d)
        }
        return b
    };
    Aa = function(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    Ba = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    Ca = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return c
    };
    Ea = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Da.length; f++) c = Da[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    Fa = function() {
        var a = _.t.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    Ja = function(a) {
        return Ga ? Ha ? Ha.brands.some(function(b) {
            return (b = b.brand) && _.Ia(b, a)
        }) : !1 : !1
    };
    Ka = function(a) {
        return _.Ia(Fa(), a)
    };
    La = function() {
        return Ga ? !!Ha && 0 < Ha.brands.length : !1
    };
    Ma = function() {
        return La() ? Ja("Chromium") : (Ka("Chrome") || Ka("CriOS")) && !(La() ? 0 : Ka("Edge")) || Ka("Silk")
    };
    Oa = function(a) {
        return new Na(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    };
    _.Va = function(a) {
        var b = void 0 === b ? Qa : b;
        a: if (b = void 0 === b ? Qa : b, !(a instanceof _.Ra)) {
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof Na && d.Ok(a)) {
                    a = Sa(a);
                    break a
                }
            }
            a = void 0
        }
        return a || _.Ua
    };
    Xa = function(a) {
        for (var b = _.Wa.apply(1, arguments), c = [a[0]], d = 0; d < b.length; d++) c.push(String(b[d])), c.push(a[d + 1]);
        return Sa(c.join(""))
    };
    _.Za = function(a) {
        a: if (Ya) {
            try {
                var b = new URL(a)
            } catch (c) {
                b = "https:";
                break a
            }
            b = b.protocol
        } else b: {
            b = document.createElement("a");
            try {
                b.href = a
            } catch (c) {
                b = void 0;
                break b
            }
            b = b.protocol;b = ":" === b || "" === b ? "https:" : b
        }
        if ("javascript:" !== b) return a
    };
    _.bb = function(a) {
        return a instanceof _.Ra ? _.$a(a) : _.Za(a)
    };
    _.cb = function(a) {
        throw Error("unexpected value " + a + "!");
    };
    db = function(a) {
        var b, c, d = null == (c = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : c.call(b, "script[nonce]");
        (b = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };
    fb = function(a, b) {
        a.textContent = _.eb(b);
        db(a)
    };
    hb = function(a, b) {
        a.src = _.gb(b);
        db(a)
    };
    jb = function(a) {
        var b = window,
            c = !0;
        c = void 0 === c ? !1 : c;
        new _.v.Promise(function(d, e) {
            function f() {
                g.onload = null;
                g.onerror = null;
                var h;
                null == (h = g.parentElement) || h.removeChild(g)
            }
            var g = b.document.createElement("script");
            g.onload = function() {
                f();
                d()
            };
            g.onerror = function() {
                f();
                e(void 0)
            };
            g.type = "text/javascript";
            hb(g, a);
            c && "complete" !== b.document.readyState ? _.ib(b, "load", function() {
                b.document.body.appendChild(g)
            }) : b.document.body.appendChild(g)
        })
    };
    pb = function(a) {
        var b, c, d, e, f, g;
        return _.kb(function(h) {
            switch (h.j) {
                case 1:
                    return b = "https://pagead2.googlesyndication.com/getconfig/sodar?sv=200&tid=" + a.j + ("&tv=" + a.o + "&st=") + a.Xc, c = void 0, h.m = 2, h.yield(nb(b), 4);
                case 4:
                    c = h.o;
                    h.j = 3;
                    h.m = 0;
                    break;
                case 2:
                    ob(h);
                case 3:
                    if (!c) return h.return(void 0);
                    d = a.Ed || c.sodar_query_id;
                    e = void 0 !== c.rc_enable && a.m ? c.rc_enable : "n";
                    f = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms;
                    g = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
                    return d && c.bg_hash_basename && c.bg_binary ? h.return({
                        context: a.A,
                        zj: c.bg_hash_basename,
                        yj: c.bg_binary,
                        Tk: a.j + "_" + a.o,
                        Ed: d,
                        Xc: a.Xc,
                        Je: e,
                        jf: f,
                        He: g
                    }) : h.return(void 0)
            }
        })
    };
    sb = function(a) {
        var b;
        return _.kb(function(c) {
            if (1 == c.j) return c.yield(pb(a), 2);
            if (b = c.o) {
                var d = "sodar2";
                d = void 0 === d ? "sodar2" : d;
                var e = window,
                    f = e.GoogleGcLKhOms;
                f && "function" === typeof f.push || (f = e.GoogleGcLKhOms = []);
                var g = {};
                f.push((g._ctx_ = b.context, g._bgv_ = b.zj, g._bgp_ = b.yj, g._li_ = b.Tk, g._jk_ = b.Ed, g._st_ = b.Xc, g._rc_ = b.Je, g._dl_ = b.jf, g._g2_ = b.He, g));
                if (f = e.GoogleDX5YKUSk) e.GoogleDX5YKUSk = void 0, f[1]();
                d = _.qb(rb, {
                    basename: d
                });
                jb(d)
            }
            return c.return(b)
        })
    };
    vb = function(a) {
        var b = !1;
        b = void 0 === b ? !1 : b;
        if (tb) {
            if (b && /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a)) throw Error("Found an unpaired surrogate");
            a = (ub || (ub = new TextEncoder)).encode(a)
        } else {
            for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                var f = a.charCodeAt(e);
                if (128 > f) d[c++] = f;
                else {
                    if (2048 > f) d[c++] = f >> 6 | 192;
                    else {
                        if (55296 <= f && 57343 >= f) {
                            if (56319 >= f && e < a.length) {
                                var g = a.charCodeAt(++e);
                                if (56320 <= g && 57343 >= g) {
                                    f = 1024 * (f - 55296) + g - 56320 + 65536;
                                    d[c++] = f >> 18 | 240;
                                    d[c++] = f >> 12 & 63 | 128;
                                    d[c++] = f >> 6 & 63 | 128;
                                    d[c++] = f & 63 | 128;
                                    continue
                                } else e--
                            }
                            if (b) throw Error("Found an unpaired surrogate");
                            f = 65533
                        }
                        d[c++] = f >> 12 | 224;
                        d[c++] = f >> 6 & 63 | 128
                    }
                    d[c++] = f & 63 | 128
                }
            }
            a = c === d.length ? d : d.subarray(0, c)
        }
        return a
    };
    wb = function(a) {
        _.t.setTimeout(function() {
            throw a;
        }, 0)
    };
    Ab = function(a) {
        if (!yb) return zb(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    };
    Db = function(a) {
        return Cb[a] || ""
    };
    Fb = function(a) {
        return Eb && null != a && a instanceof Uint8Array
    };
    Hb = function(a) {
        if (a !== Gb) throw Error("illegal external caller");
    };
    Ib = function() {
        return "function" === typeof BigInt
    };
    Nb = function(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = _.z(Jb(c, a)), b = c.next().value, a = c.next().value, c = b);
        Kb = c >>> 0;
        Lb = a >>> 0
    };
    Pb = function(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (2097151 >= b) var c = "" + (4294967296 * b + a);
        else Ib() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + 6777216 * c + 6710656 * b, c += 8147497 * b, b *= 2, 1E7 <= a && (c += Math.floor(a / 1E7), a %= 1E7), 1E7 <= c && (b += Math.floor(c / 1E7), c %= 1E7), c = b + Ob(c) + Ob(a));
        return c
    };
    Ob = function(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    };
    Qb = function() {
        var a = Kb,
            b = Lb;
        b & 2147483648 ? Ib() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = _.z(Jb(a, b)), a = b.next().value, b = b.next().value, a = "-" + Pb(a, b)) : a = Pb(a, b);
        return a
    };
    Rb = function(a) {
        if (16 > a.length) Nb(Number(a));
        else if (Ib()) a = BigInt(a), Kb = Number(a & BigInt(4294967295)) >>> 0, Lb = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +("-" === a[0]);
            Lb = Kb = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), Lb *= 1E6, Kb = 1E6 * Kb + d, 4294967296 <= Kb && (Lb += _.A(Math, "trunc").call(Math, Kb / 4294967296), Lb >>>= 0, Kb >>>= 0);
            b && (b = _.z(Jb(Kb, Lb)), a = b.next().value, b = b.next().value, Kb = a, Lb = b)
        }
    };
    Jb = function(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    Sb = function(a) {
        return Array.prototype.slice.call(a)
    };
    Wb = function(a) {
        var b = Ub(a);
        1 !== (b & 1) && (Object.isFrozen(a) && (a = Sb(a)), Vb(a, b | 1))
    };
    Xb = function(a, b, c) {
        return c ? a | b : a & ~b
    };
    Zb = function() {
        var a = [];
        Yb(a, 1);
        return a
    };
    $b = function(a) {
        Yb(a, 34);
        return a
    };
    bc = function(a) {
        Yb(a, 32);
        return a
    };
    cc = function(a, b) {
        Vb(b, (a | 0) & -14591)
    };
    dc = function(a, b) {
        Vb(b, (a | 34) & -14557)
    };
    ec = function(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    gc = function(a) {
        return !(!a || "object" !== typeof a || a.Vk !== fc)
    };
    hc = function(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    };
    nc = function(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new lc(a, Gb) : mc();
            else if (a.constructor !== lc)
            if (Fb(a)) {
                var d;
                c ? d = 0 == a.length ? mc() : new lc(a, Gb) : d = a.length ? new lc(new Uint8Array(a), Gb) : mc();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    };
    oc = function(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        var d = Ub(a);
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? _.A(b, "includes").call(b, c) : b.has(c)))) return !1;
        Vb(a, d | 1);
        return !0
    };
    pc = function(a) {
        if (a & 2) throw Error();
    };
    rc = function(a) {
        if (qc) throw Error("");
        qc = a
    };
    sc = function(a) {
        if (qc) try {
            qc(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    };
    uc = function() {
        var a = tc();
        qc ? _.t.setTimeout(function() {
            sc(a)
        }, 0) : wb(a)
    };
    yc = function(a) {
        a = Error(a);
        vc(a, "warning");
        sc(a);
        return a
    };
    tc = function() {
        var a = Error();
        vc(a, "incident");
        return a
    };
    _.zc = function(a) {
        if (null != a && "number" !== typeof a) throw Error("Value of float/double field must be a number, found " + typeof a + ": " + a);
        return a
    };
    Ac = function(a) {
        if (null == a) return a;
        if ("number" === typeof a || "NaN" === a || "Infinity" === a || "-Infinity" === a) return Number(a)
    };
    Cc = function(a) {
        if ("boolean" !== typeof a) throw Error("Expected boolean but got " + Bc(a) + ": " + a);
        return a
    };
    Dc = function(a) {
        if (null == a || "boolean" === typeof a) return a;
        if ("number" === typeof a) return !!a
    };
    Fc = function(a) {
        var b = typeof a;
        return "number" === b ? _.A(Number, "isFinite").call(Number, a) : "string" !== b ? !1 : Ec.test(a)
    };
    Ic = function(a) {
        _.A(Number, "isFinite").call(Number, a) || uc();
        return a
    };
    Jc = function(a) {
        return a
    };
    Kc = function(a) {
        if ("number" !== typeof a) throw yc("int32");
        _.A(Number, "isFinite").call(Number, a) || uc();
        return a
    };
    Lc = function(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    };
    Mc = function(a) {
        if ("number" !== typeof a) throw yc("uint32");
        _.A(Number, "isFinite").call(Number, a) || uc();
        return a
    };
    _.Nc = function(a) {
        return null == a ? a : Mc(a)
    };
    Oc = function(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return a
    };
    _.Sc = function(a, b) {
        b = !!b;
        if (!Fc(a)) throw yc("int64");
        return "string" === typeof a ? Pc(a, b) : b ? Qc(a, b) : Rc(a, !1)
    };
    Tc = function(a) {
        return null == a ? a : _.Sc(a)
    };
    Rc = function(a, b) {
        a = _.A(Math, "trunc").call(Math, a);
        if (b && !_.A(Number, "isSafeInteger").call(Number, a)) {
            Nb(a);
            b = Kb;
            var c = Lb;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, 0 == b && (c = c + 1 >>> 0);
            b = 4294967296 * c + (b >>> 0);
            a = a ? -b : b
        }
        return a
    };
    Vc = function(a) {
        return a = _.A(Math, "trunc").call(Math, a)
    };
    Qc = function(a, b) {
        a = _.A(Math, "trunc").call(Math, a);
        !b || _.A(Number, "isSafeInteger").call(Number, a) ? a = String(a) : (Nb(a), a = Qb());
        return a
    };
    Pc = function(a, b) {
        var c = _.A(Math, "trunc").call(Math, Number(a));
        if (_.A(Number, "isSafeInteger").call(Number, c)) return String(c);
        c = a.indexOf("."); - 1 !== c && (a = a.substring(0, c));
        b && (Rb(a), a = Qb());
        return a
    };
    Wc = function(a, b) {
        var c = _.A(Math, "trunc").call(Math, Number(a));
        if (_.A(Number, "isSafeInteger").call(Number, c) && (!b || 0 <= c)) return String(c);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        Rb(a);
        return Pb(Kb, Lb)
    };
    Xc = function(a) {
        if (null == a) return a;
        if (Fc(a)) {
            var b;
            "number" === typeof a ? b = Rc(a, !1) : b = Pc(a, !1);
            return b
        }
    };
    Yc = function(a, b) {
        b = void 0 === b ? !1 : b;
        if (null == a) return a;
        if (Fc(a)) return "string" === typeof a ? Pc(a, b) : b ? Qc(a, b) : Rc(a, b)
    };
    Zc = function(a) {
        var b = !!b;
        if (!Fc(a)) throw yc("uint64");
        "string" === typeof a ? b = Wc(a, b) : b ? (a = _.A(Math, "trunc").call(Math, a), b ? (Nb(a), b = Pb(Kb, Lb)) : b = String(a)) : b = Vc(a);
        return b
    };
    $c = function(a) {
        if ("string" !== typeof a) throw Error();
        return a
    };
    ad = function(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    };
    bd = function(a) {
        return null == a || "string" === typeof a ? a : void 0
    };
    ed = function(a, b, c, d) {
        if (null != a && "object" === typeof a && a.kg === cd) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? dd(b) : new b : void 0;
        var e = c = Ub(a);
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && Vb(a, e);
        return new b(a)
    };
    dd = function(a) {
        var b = a[fd];
        if (b) return b;
        b = new a;
        $b(b.D);
        return a[fd] = b
    };
    gd = function(a) {
        return a
    };
    hd = function(a, b, c) {
        if (b) return $c(a);
        var d;
        return null != (d = bd(a)) ? d : c ? "" : void 0
    };
    jd = function(a, b) {
        id = b;
        a = new a(b);
        id = void 0;
        return a
    };
    md = function(a) {
        switch (typeof a) {
            case "boolean":
                return kd || (kd = [0, void 0, !0]);
            case "number":
                return 0 < a ? void 0 : 0 === a ? ld || (ld = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    };
    _.B = function(a, b, c) {
        null == a && (a = id);
        id = void 0;
        if (null == a) {
            var d = 96;
            c ? (a = [c], d |= 512) : a = [];
            b && (d = d & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error();
            d = Ub(a);
            if (d & 64) return a;
            d |= 64;
            if (c && (d |= 512, c !== a[0])) throw Error();
            a: {
                c = d;
                if (d = a.length) {
                    var e = d - 1;
                    if (hc(a[e])) {
                        c |= 256;
                        b = e - (+!!(c & 512) - 1);
                        if (1024 <= b) throw Error();
                        d = c & -16760833 | (b & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    b = Math.max(b, d - (+!!(c & 512) - 1));
                    if (1024 < b) throw Error();
                    d = c & -16760833 | (b & 1023) << 14
                } else d = c
            }
        }
        Vb(a, d);
        return a
    };
    od = function(a, b, c, d, e, f) {
        a = ed(a, d, c, f);
        e && (a = nd(a));
        return a
    };
    pd = function(a) {
        return a
    };
    qd = function(a) {
        return [a, this.get(a)]
    };
    sd = function(a, b) {
        return rd(b)
    };
    rd = function(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return vd || !oc(a, void 0, 9999) ? a : void 0;
                    if (Fb(a)) return Ab(a);
                    if (a instanceof lc) return wd(a);
                    if (a instanceof xd) return a = yd(a), zd || 0 !== a.length ? a : void 0
                }
        }
        return a
    };
    Ad = function(a, b, c) {
        a = Sb(a);
        var d = a.length,
            e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    };
    Cd = function(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && Ub(a) & 1 ? void 0 : f && Ub(a) & 2 ? a : Bd(a, b, c, void 0 !== d, e, f);
            else if (hc(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Cd(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    };
    Bd = function(a, b, c, d, e, f) {
        var g = d || c ? Ub(a) : 0;
        d = d ? !!(g & 32) : void 0;
        a = Sb(a);
        for (var h = 0; h < a.length; h++) a[h] = Cd(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    };
    Ed = function(a) {
        return Cd(a, Dd, void 0, void 0, !1, !1)
    };
    Dd = function(a) {
        return a.kg === cd ? a.toJSON() : a instanceof xd ? yd(a, Ed) : rd(a)
    };
    Fd = function(a, b, c) {
        c = void 0 === c ? dc : c;
        if (null != a) {
            if (Eb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = Ub(a);
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (Vb(a, (d | 34) & -12293), a) : Bd(a, Fd, d & 4 ? dc : c, !0, !1, !0)
            }
            a.kg === cd ? (c = a.D, d = Gd(c), a = d & 2 ? a : jd(a.constructor, Hd(c, d, !0))) : a instanceof xd && (c = $b(Id(a, Fd)), a = new xd(c, a.sf, a.Fd, a.Ug));
            return a
        }
    };
    _.Jd = function(a) {
        var b = a.D;
        return jd(a.constructor, Hd(b, Gd(b), !1))
    };
    Hd = function(a, b, c) {
        var d = c || b & 2 ? dc : cc,
            e = !!(b & 32);
        a = Ad(a, b, function(f) {
            return Fd(f, e, d)
        });
        Yb(a, 32 | (c ? 2 : 0));
        return a
    };
    nd = function(a) {
        var b = a.D,
            c = Gd(b);
        return c & 2 ? jd(a.constructor, Hd(b, c, !1)) : a
    };
    _.Kd = function(a) {
        var b = a.D,
            c = Gd(b);
        return c & 2 ? a : jd(a.constructor, Hd(b, c, !0))
    };
    Ld = function(a, b, c, d, e) {
        var f = ec(b);
        if (c >= f || e) {
            e = b;
            if (b & 256) f = a[a.length - 1];
            else {
                if (null == d) return e;
                f = a[f + (+!!(b & 512) - 1)] = {};
                e |= 256
            }
            f[c] = d;
            e !== b && Vb(a, e);
            return e
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    };
    Pd = function(a, b, c, d, e) {
        var f = b & 2,
            g = Md(a, b, c, e);
        Array.isArray(g) || (g = Nd);
        var h = !(d & 2);
        d = !(d & 1);
        var k = !!(b & 32),
            l = Ub(g);
        0 !== l || !k || f || h ? l & 1 || (l |= 1, Vb(g, l)) : (l |= 33, Vb(g, l));
        f ? (a = !1, l & 2 || ($b(g), a = !!(4 & l)), (d || a) && Object.freeze(g)) : (f = !!(2 & l) || !!(2048 & l), d && f ? (g = Sb(g), d = 1, k && !h && (d |= 32), Vb(g, d), Ld(a, b, c, g, e)) : h && l & 32 && !f && Od(g, 32));
        return g
    };
    Rd = function(a, b, c, d, e, f, g) {
        e = void 0 === e ? 2 : e;
        a = a.D;
        var h = Gd(a);
        2 & h && (e = 1);
        f = !!f;
        var k = Pd(a, h, b, 1 | (f ? 2 : 0), d);
        h = Gd(a);
        var l = Ub(k),
            m = l,
            n = !!(2 & l),
            p = n && !!(4 & l);
        if (4 & l ? null == g || 0 === g ? 0 : !(g & l) : 1) {
            if (Object.isFrozen(k) || g && !(g & l)) k = Sb(k), m = 0, l = Qd(l, h, f), n = !!(2 & l), h = Ld(a, h, b, k, d);
            l = Xb(l, 4, !1);
            l = Xb(l, 4096, !1);
            l = Xb(l, 8192, !1);
            for (var r = 0, w = 0; r < k.length; r++) {
                var u = c(k[r]);
                null != u && (k[w++] = u)
            }
            w < r && (k.length = w);
            l = Xb(l, 20, !0);
            g && (l = Xb(l, g, !0))
        }
        p || ((c = 1 === e) && (l = Xb(l, 2, !0)), l !== m && Vb(k, l), (c || n) && Object.freeze(k));
        2 === e && n && (k = Sb(k), l = Qd(l, h, f), Vb(k, l), Ld(a, h, b, k, d));
        var y;
        f ? y = k : y = k;
        return y
    };
    Sd = function(a) {
        return nc(a, !0, !0)
    };
    Td = function(a) {
        return nc(a, !0, !1)
    };
    Wd = function() {
        var a;
        return null != (a = Ud) ? a : Ud = new xd($b([]), void 0, void 0, void 0, Vd)
    };
    Xd = function(a, b, c, d, e, f) {
        var g = b & 2;
        a: {
            var h = c,
                k = b & 2;c = !1;
            if (null == h) {
                if (k) {
                    a = Wd();
                    break a
                }
                h = []
            } else if (h.constructor === xd) {
                if (0 == (h.ee & 2) || k) {
                    a = h;
                    break a
                }
                h = Id(h)
            } else Array.isArray(h) ? c = !!(Ub(h) & 2) : h = [];
            if (k) {
                if (!h.length) {
                    a = Wd();
                    break a
                }
                c || (c = !0, $b(h))
            } else if (c) {
                c = !1;
                k = Sb(h);
                for (h = 0; h < k.length; h++) {
                    var l = k[h] = Sb(k[h]);
                    Array.isArray(l[1]) && (l[1] = $b(l[1]))
                }
                h = k
            }
            c || (Ub(h) & 64 ? Od(h, 32) : 32 & b && bc(h));f = new xd(h, e, hd, f);Ld(a, b, d, f, !1);a = f
        }
        if (null == a) return a;
        !g && e && (a.Ej = !0);
        return a
    };
    Yd = function(a, b) {
        a = a.D;
        var c = Gd(a);
        return Xd(a, c, Md(a, c, b), b, void 0, hd)
    };
    Zd = function(a, b, c) {
        a = a.D;
        var d = Gd(a);
        return Xd(a, d, Md(a, d, b), b, c)
    };
    _.be = function(a, b, c, d) {
        var e = a.D,
            f = Gd(e);
        pc(f);
        if (null == c) return Ld(e, f, b), a;
        var g = Ub(c),
            h = g,
            k = !!(2 & g) || Object.isFrozen(c),
            l = !k && !1;
        if (!(4 & g)) {
            g = 21;
            k && (c = Sb(c), h = 0, g = Qd(g, f, !0));
            k = !!(4 & g) && !!(4096 & g);
            for (var m = 0; m < c.length; m++) c[m] = d(c[m], k)
        }
        l && (g = Xb(g, 2, !0));
        g !== h && Vb(c, g);
        l && Object.freeze(c);
        Ld(e, f, b, c);
        return a
    };
    _.ce = function(a, b, c, d) {
        var e = a.D,
            f = Gd(e);
        pc(f);
        Ld(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    };
    de = function(a, b, c) {
        for (var d = 0, e = 0; e < c.length; e++) {
            var f = c[e];
            null != Md(a, b, f) && (0 !== d && (b = Ld(a, b, d)), d = f)
        }
        return d
    };
    ee = function(a, b, c, d, e, f, g) {
        var h = 1 === e;
        e = 2 === e;
        f = !!f;
        var k = !!(2 & b) && e,
            l = Pd(a, b, d, 3);
        b = Gd(a);
        var m = Ub(l),
            n = !!(2 & m),
            p = !!(4 & m),
            r = !!(32 & m),
            w = n && p || !!(2048 & m);
        if (!p) {
            var u = l,
                y = b,
                x = !!(2 & m);
            x && (y = Xb(y, 2, !0));
            for (var C = !x, I = !0, D = 0, J = 0; D < u.length; D++) {
                var Q = ed(u[D], c, !1, y);
                if (Q instanceof c) {
                    if (!x) {
                        var N = !!(Ub(Q.D) & 2);
                        C && (C = !N);
                        I && (I = N)
                    }
                    u[J++] = Q
                }
            }
            J < D && (u.length = J);
            m = Xb(m, 4, !0);
            m = Xb(m, 16, I);
            m = Xb(m, 8, C);
            Vb(u, m);
            n && !k && (Object.freeze(l), w = !0)
        }
        c = m;
        k = !!(8 & m) || h && !l.length;
        if (g && !k) {
            w && (l = Sb(l), w = !1, c = 0, m = Qd(m, b, f), b = Ld(a, b, d, l));
            g = l;
            k = m;
            for (n = 0; n < g.length; n++) u = g[n], m = nd(u), u !== m && (g[n] = m);
            k = Xb(k, 8, !0);
            m = k = Xb(k, 16, !g.length)
        }
        w || (h ? m = Xb(m, !l.length || 16 & m && (!p || r) ? 2 : 2048, !0) : f || (m = Xb(m, 32, !1)), m !== c && Vb(l, m), h && (Object.freeze(l), w = !0));
        e && w && (l = Sb(l), m = Qd(m, b, f), Vb(l, m), Ld(a, b, d, l));
        return l
    };
    Qd = function(a, b, c) {
        a = Xb(a, 2, !!(2 & b));
        a = Xb(a, 32, !!(32 & b) && c);
        return a = Xb(a, 2048, !1)
    };
    fe = function(a, b, c, d) {
        a = a.D;
        var e = Gd(a);
        pc(e);
        b = ee(a, e, c, b, 2);
        c = null != d ? d : new c;
        b.push(c);
        Ub(c.D) & 2 ? Od(b, 8) : Od(b, 16);
        return c
    };
    ge = function(a, b) {
        return null != a ? a : b
    };
    ie = function(a, b, c) {
        var d = a.constructor.ca,
            e = Gd(c ? a.D : b),
            f = ec(e),
            g = !1;
        if (d && vd) {
            if (!c) {
                b = Sb(b);
                var h;
                if (b.length && hc(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            _.A(Object, "assign").call(Object, b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = Gd(a.D);
            a = ec(h);
            h = +!!(h & 512) - 1;
            for (var k, l, m = 0; m < d.length; m++)
                if (l = d[m], l < a) {
                    l += h;
                    var n = f[l];
                    null == n ? f[l] = c ? Nd : Zb() : c && n !== Nd && Wb(n)
                } else k || (n = void 0, f.length && hc(n = f[f.length - 1]) ? k = n : f.push(k = {})), n = k[l], null == k[l] ? k[l] = c ? Nd : Zb() : c && n !== Nd && Wb(n)
        }
        k = b.length;
        if (!k) return b;
        var p;
        if (hc(f = b[k - 1])) {
            a: {
                var r = f;c = {};a = !1;
                for (var w in r)
                    if (Object.prototype.hasOwnProperty.call(r, w)) {
                        h = r[w];
                        if (Array.isArray(h)) {
                            m = h;
                            if (!he && oc(h, d, +w) || !zd && gc(h) && 0 === h.size) h = null;
                            h != m && (a = !0)
                        }
                        null != h ? c[w] = h : a = !0
                    }
                if (a) {
                    for (var u in c) {
                        r = c;
                        break a
                    }
                    r = null
                }
            }
            r != f && (p = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            w = k - 1;
            f = b[w];
            if (!(null == f || !he && oc(f, d, w - e) || !zd && gc(f) && 0 === f.size)) break;
            var y = !0
        }
        if (!p && !y) return b;
        var x;
        g ? x = b : x = Array.prototype.slice.call(b, 0, k);
        b = x;
        g && (b.length = k);
        r && b.push(r);
        return b
    };
    je = function(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        Yb(b, 128);
        return jd(a, bc(b))
    };
    ke = function(a, b, c) {
        a[b] = c
    };
    oe = function(a) {
        var b = a[le];
        if (!b) {
            var c = me(a);
            b = function(d, e) {
                return ne(d, e, c)
            };
            a[le] = b
        }
        return b
    };
    pe = function(a) {
        return a.j
    };
    qe = function(a, b) {
        var c, d, e = a.j;
        return function(f, g, h) {
            return e(f, g, h, d || (d = me(b).j), c || (c = oe(b)))
        }
    };
    me = function(a) {
        var b = a[re];
        if (b) return b;
        b = a[re] = {};
        var c = pe,
            d = qe;
        var e = void 0 === e ? ke : e;
        b.j = md(a[0]);
        var f = 0,
            g = a[++f];
        g && g.constructor === Object && (b.fk = g, g = a[++f], "function" === typeof g && (b.m = g, b.o = a[++f], g = a[++f]));
        for (var h = {}; Array.isArray(g) && "number" === typeof g[0] && 0 < g[0];) {
            for (var k = 0; k < g.length; k++) h[g[k]] = g;
            g = a[++f]
        }
        for (k = 1; void 0 !== g;) {
            "number" === typeof g && (k += g, g = a[++f]);
            var l = void 0;
            if (g instanceof se) var m = g;
            else m = te, f--;
            if (m.fj) {
                g = a[++f];
                l = a;
                var n = f;
                "function" == typeof g && (g = g(), l[n] = g);
                l = g
            }
            g = a[++f];
            n = k + 1;
            "number" === typeof g && 0 > g && (n -= g, g = a[++f]);
            for (; k < n; k++) {
                var p = h[k];
                e(b, k, l ? d(m, l, p) : c(m, p))
            }
        }
        ue in a && re in a && (a.length = 0);
        return b
    };
    we = function(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.fk)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof se ? c : [ve, c] : [c, void 0];
                var d = c[0].j;
                if (c = c[1]) {
                    var e = oe(c),
                        f = me(c).j;
                    c = (c = a.o) ? c(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };
    ne = function(a, b, c) {
        for (var d = Gd(a), e = +!!(d & 512) - 1, f = a.length, g = f + (d & 256 ? -1 : 0), h = d & 512 ? 1 : 0; h < g; h++) {
            var k = a[h];
            if (null != k) {
                var l = h - e,
                    m = we(c, l);
                m && m(b, k, l)
            }
        }
        if (d & 256) {
            a = a[f - 1];
            for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (d = +n, _.A(Number, "isNaN").call(Number, d) || (e = a[n], null != e && (f = we(c, d)) && f(b, e, d)))
        }
    };
    xe = function(a) {
        return new se(a, !1)
    };
    Be = function(a, b, c) {
        a: if (null != b) {
            if (Fc(b)) {
                if ("string" === typeof b) {
                    b = Pc(b, !1);
                    break a
                }
                if ("number" === typeof b) {
                    b = Rc(b, !1);
                    break a
                }
            }
            b = void 0
        }null != b && ("string" === typeof b && ye(b), null != b && (ze(a.j, 8 * c), "number" === typeof b ? (a = a.j, Nb(b), Ae(a, Kb, Lb)) : (c = ye(b), Ae(a.j, c.o, c.j))))
    };
    De = function(a, b, c, d, e) {
        b = b instanceof _.E ? b.D : Array.isArray(b) ? _.B(b, d[0], d[1]) : void 0;
        if (null != b) {
            ze(a.j, 8 * c + 2);
            c = a.j.end();
            Ce(a, c);
            c.push(a.o);
            e(b, a);
            e = c.pop();
            for (e = a.o + a.j.length() - e; 127 < e;) c.push(e & 127 | 128), e >>>= 7, a.o++;
            c.push(e);
            a.o++
        }
    };
    Fe = function(a) {
        var b = Ee;
        Ee = void 0;
        if (!a) throw Error(b && b() || String(a));
    };
    Ie = function(a) {
        return function() {
            var b = new He;
            ne(this.D, b, me(a));
            Ce(b, b.j.end());
            for (var c = new Uint8Array(b.o), d = b.m, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            b.m = [c];
            return c
        }
    };
    Je = function(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = jd(a, bc(b))
            }
            return b
        }
    };
    Ke = function(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    };
    _.Me = function(a) {
        var b = _.Wa.apply(1, arguments);
        if (0 === b.length) return Le(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Le(c)
    };
    Ne = function(a, b) {
        var c = _.gb(a).toString();
        if (/#/.test(c)) throw Error("");
        var d = /\?/.test(c) ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return Le(c)
    };
    Qe = function(a) {
        return new _.Oe(JSON.stringify(a).replace(/</g, "\\u003C"), Pe)
    };
    Re = function(a) {
        a = void 0 === a ? _.t : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return (null == (c = b) ? 0 : c.pageViewId) && (null == (d = b) ? 0 : d.canonicalUrl) ? b : null
    };
    We = function(a) {
        return Se(2 > (a.length + 3) % 4 ? a + "A" : a).map(function(b) {
            return (_.F = b.toString(2), _.A(_.F, "padStart")).call(_.F, 8, "0")
        }).join("")
    };
    Xe = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    };
    Ye = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };
    Ze = function(a, b) {
        var c = a.indexOf("11");
        if (-1 === c) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    $e = function(a, b) {
        var c = function(d) {
            var e = {};
            return [(e[d.Yc] = d.Oc, e)]
        };
        return JSON.stringify([a.filter(function(d) {
            return d.vc
        }).map(c), b.toJSON(), a.filter(function(d) {
            return !d.vc
        }).map(c)])
    };
    bf = function(a, b, c, d, e, f) {
        try {
            var g = a.j,
                h = _.af("SCRIPT", g);
            h.async = !0;
            hb(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", function() {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", function() {
                0 < c ? bf(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (k) {
            f()
        }
    };
    df = function(a, b, c, d) {
        c = void 0 === c ? function() {} : c;
        d = void 0 === d ? function() {} : d;
        bf(cf(a), b, 0, !1, c, d)
    };
    ef = function(a) {
        return a[_.A(_.v.Symbol, "iterator")]()
    };
    hf = function(a) {
        var b = ff(gf(a.location.href));
        a = b.get("fcconsent");
        b = b.get("fc");
        return "alwaysshow" === b ? b : "alwaysshow" === a ? a : null
    };
    jf = function(a) {
        var b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = ff(gf(a.location.href)).get("fctype")) && -1 !== b.indexOf(a) ? a : null
    };
    kf = function(a) {
        a && "function" == typeof a.xa && a.xa()
    };
    nf = function(a) {
        a = lf(a.data.__fciReturn);
        return {
            payload: a,
            Ag: _.mf(a, 1)
        }
    };
    pf = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = _.af("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                d && fa(a.google_image_requests, f);
                _.of(f, "load", g);
                _.of(f, "error", g)
            };
            _.ib(f, "load", g);
            _.ib(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    };
    qf = function(a) {
        return function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }
    };
    sf = function() {
        var a = rf;
        return function(b) {
            return b instanceof a
        }
    };
    uf = function(a) {
        return function(b) {
            if (!tf(b)) return !1;
            for (var c = _.z(_.A(Object, "entries").call(Object, a)), d = c.next(); !d.done; d = c.next()) {
                var e = _.z(d.value);
                d = e.next().value;
                e = e.next().value;
                if (!(d in b)) {
                    if (!0 === e.Gn) continue;
                    return !1
                }
                if (!e(b[d])) return !1
            }
            return !0
        }
    };
    vf = function(a) {
        return function(b) {
            return Array.isArray(b) ? b.every(function(c) {
                return a(c)
            }) : !1
        }
    };
    wf = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Ag: b.__uspapiReturn.callId
        }
    };
    xf = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Ag: b.__gppReturn.callId
        }
    };
    yf = function(a) {
        return !a || 1 === a.length && -1 === a[0]
    };
    Af = function(a, b) {
        b = void 0 === b ? window : b;
        if (zf(a)) try {
            return b.localStorage
        } catch (c) {}
        return null
    };
    Bf = function(a) {
        return "null" !== a.origin
    };
    Df = function(a, b, c) {
        b = zf(b) && Bf(c) ? c.document.cookie : null;
        return null === b ? null : (new Cf({
            cookie: b
        })).get(a) || ""
    };
    Ef = function(a, b, c) {
        return b[a] || c
    };
    Hf = function(a) {
        _.Ff(Gf).m(a)
    };
    _.If = function() {
        return _.Ff(Gf).A()
    };
    Jf = function(a, b) {
        b = void 0 === b ? document : b;
        var c;
        return !(null == (c = b.featurePolicy) || !(_.F = c.allowedFeatures(), _.A(_.F, "includes")).call(_.F, a))
    };
    Nf = function(a, b, c) {
        return !!(a && "runAdAuction" in b && b.runAdAuction instanceof Function && Jf("run-ad-auction", c))
    };
    Of = function(a, b) {
        return !!(a && "browsingTopics" in b && b.browsingTopics instanceof Function && Jf("browsing-topics", b))
    };
    Pf = function(a, b, c) {
        c = void 0 === c ? b.document : c;
        return !!(a && "sharedStorage" in b && b.sharedStorage && Jf("shared-storage", c))
    };
    Sf = function(a) {
        a = void 0 === a ? _.Qf() : a;
        return function(b) {
            return _.Rf(b + " + " + a) % 1E3
        }
    };
    _.G = function(a) {
        return _.Ff(Tf).o(a.j, a.defaultValue)
    };
    _.Uf = function(a) {
        return _.Ff(Tf).m(a.j, a.defaultValue)
    };
    _.Vf = function(a) {
        return _.Ff(Tf).A(a.j, a.defaultValue)
    };
    Wf = function(a) {
        return _.Ff(Tf).J(a.j, a.defaultValue)
    };
    Yf = function(a) {
        _.Ff(Xf).j(a)
    };
    bg = function() {
        if (void 0 === b) {
            var a = void 0 === a ? _.t : a;
            var b = a.ggeac || (a.ggeac = {})
        }
        a = b;
        Zf(_.Ff(Gf), a);
        $f(b);
        ag(_.Ff(Xf), b);
        _.Ff(Tf).j()
    };
    $f = function(a) {
        var b = _.Ff(Tf);
        b.o = function(c, d) {
            return Ef(5, a, function() {
                return !1
            })(c, d, 2)
        };
        b.m = function(c, d) {
            return Ef(6, a, function() {
                return 0
            })(c, d, 2)
        };
        b.A = function(c, d) {
            return Ef(7, a, function() {
                return ""
            })(c, d, 2)
        };
        b.J = function(c, d) {
            return Ef(8, a, function() {
                return []
            })(c, d, 2)
        };
        b.j = function() {
            Ef(15, a, function() {})(2)
        }
    };
    fg = function(a, b, c, d) {
        var e = new _.cg,
            f = "",
            g = function(k) {
                try {
                    var l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (_.of(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (m) {}
            },
            h = dg(a);
        return h ? (_.ib(a, "message", g), f = c(h), e.promise) : (c = eg(a)) ? (f = String(Math.floor(2147483647 * _.Qf())), _.ib(a, "message", g), b(c, f), e.promise) : null
    };
    gg = function(a) {
        return fg(a, function(b, c) {
            var d, e;
            return void(null == (d = null != (e = b.getGmaQueryInfo) ? e : b.getGmaSig) ? void 0 : d.postMessage(c))
        }, function(b) {
            return b.getQueryInfo()
        }, function(b) {
            return b.signal
        })
    };
    hg = function(a) {
        return !!dg(a) || !!eg(a)
    };
    dg = function(a) {
        var b;
        if ("function" === typeof(null == (b = a.gmaSdk) ? void 0 : b.getQueryInfo)) return a.gmaSdk
    };
    eg = function(a) {
        var b, c, d, e, f, g;
        if ("function" === typeof(null == (b = a.webkit) ? void 0 : null == (c = b.messageHandlers) ? void 0 : null == (d = c.getGmaQueryInfo) ? void 0 : d.postMessage) || "function" === typeof(null == (e = a.webkit) ? void 0 : null == (f = e.messageHandlers) ? void 0 : null == (g = f.getGmaSig) ? void 0 : g.postMessage)) return a.webkit.messageHandlers
    };
    ig = function(a) {
        var b, c;
        return null != (c = (_.F = ["pbjs"].concat(null != (b = a._pbjsGlobals) ? b : []).map(function(d) {
            return a[d]
        }), _.A(_.F, "find")).call(_.F, function(d) {
            return Array.isArray(null == d ? void 0 : d.que)
        })) ? c : null
    };
    jg = function(a) {
        var b = a.match(/\/?([0-9]+)(?:,[0-9]+)?((?:\/.+?)+?)(?:\/*)$/);
        return 3 !== (null == b ? void 0 : b.length) ? a : "/" + b[1] + b[2]
    };
    kg = function(a, b, c) {
        var d, e;
        return null != (e = null != (d = null == b ? void 0 : b.get((void 0 === c ? 0 : c) ? jg(a) : a)) ? d : null == b ? void 0 : b.get(_.Rf(a))) ? e : 0
    };
    ng = function(a, b, c) {
        var d, e, f, g, h;
        return _.kb(function(k) {
            if (1 == k.j) return d = c ? a.filter(function(l) {
                return !l.Yb
            }) : a, k.yield(_.v.Promise.all(d.map(function(l) {
                return l.Fb.promise
            })), 2);
            if (a.length === d.length) return k.return();
            e = a.filter(function(l) {
                return l.Yb
            });
            if (_.G(lg)) {
                f = _.z(b);
                for (g = f.next(); !g.done; g = f.next()) h = g.value, mg(h);
                return k.yield(_.v.Promise.all(e.map(function(l) {
                    return l.Fb.promise
                })), 0)
            }
            return k.yield(_.v.Promise.race([_.v.Promise.all(e.map(function(l) {
                return l.Fb.promise
            })), new _.v.Promise(function(l) {
                return void setTimeout(l, c)
            })]), 0)
        })
    };
    og = function(a, b, c, d) {
        try {
            if (a.setAttribute("data-google-query-id", c), !d) {
                null != b.googletag || (b.googletag = {
                    cmd: []
                });
                var e;
                b.googletag.queryIds = null != (e = b.googletag.queryIds) ? e : [];
                b.googletag.queryIds.push(c);
                500 < b.googletag.queryIds.length && b.googletag.queryIds.shift()
            }
        } catch (f) {}
    };
    _.pg = function(a) {
        return a.innerHeight >= a.innerWidth
    };
    _.rg = function(a) {
        var b = _.qg(a);
        a = a.innerWidth;
        return b && a ? b / a : 0
    };
    sg = function(a, b, c) {
        b = void 0 === b ? 420 : b;
        return (a = _.qg(a, void 0 === c ? !1 : c)) ? a > b ? 32768 : 320 > a ? 65536 : 0 : 16384
    };
    tg = function(a) {
        return (a = _.rg(a)) ? 1.05 < a ? 262144 : .95 > a ? 524288 : 0 : 131072
    };
    _.ug = function(a) {
        a = a.document;
        var b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };
    _.vg = function(a) {
        return _.ug(a).clientHeight
    };
    _.qg = function(a, b) {
        var c = _.ug(a).clientWidth;
        return (void 0 === b ? 0 : b) ? c * _.wg(a) : c
    };
    _.xg = function(a, b) {
        var c = _.ug(a);
        return b ? (a = _.vg(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    };
    _.yg = function(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    };
    _.zg = function(a) {
        var b = a.kf,
            c = a.ue,
            d = a.Re,
            e = a.lf,
            f = a.ve;
        a = a.Se;
        for (var g = [], h = 0; h < a; h++)
            for (var k = 0; k < d; k++) {
                var l = d - 1,
                    m = a - 1;
                g.push({
                    x: b + (0 === l ? 0 : k / l) * (c - b),
                    y: e + (0 === m ? 0 : h / m) * (f - e)
                })
            }
        return g
    };
    Ag = function(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };
    _.Ig = function(a) {
        var b = a.la,
            c = a.ng,
            d = a.Me,
            e = a.eh,
            f = a.Ja,
            g = a.Gj,
            h = a.im;
        a = 0;
        try {
            a |= b !== b.top ? 512 : 0;
            var k = Math.min(b.screen.width || 0, b.screen.height || 0);
            a |= k ? 320 > k ? 8192 : 0 : 2048;
            a |= b.navigator && Bg(b.navigator.userAgent) ? 1048576 : 0;
            if (c) {
                k = a;
                var l = b.innerHeight;
                var m = ((void 0 === h ? 0 : h) ? _.wg(b) * l : l) >= c;
                var n = k | (m ? 0 : 1024)
            } else n = a | (_.pg(b) ? 0 : 8);
            a = n;
            a |= sg(b, d, h);
            h || (a |= tg(b))
        } catch (p) {
            a |= 32
        }
        switch (e) {
            case 2:
                c = f;
                c = void 0 === c ? null : c;
                d = _.zg({
                    kf: 0,
                    ue: b.innerWidth,
                    Re: 3,
                    lf: 0,
                    ve: Math.min(Math.round(b.innerWidth / 320 * 50), Cg) + 15,
                    Se: 3
                });
                null != Dg(Gg(b, c), d) && (a |= 16777216);
                break;
            case 1:
                c = f, c = void 0 === c ? null : c, d = b.innerWidth, e = b.innerHeight, n = Math.min(Math.round(b.innerWidth / 320 * 50), Cg) + 15, m = _.zg({
                    kf: 0,
                    ue: d,
                    Re: 3,
                    lf: e - n,
                    ve: e,
                    Se: 3
                }), 25 < n && m.push({
                    x: d - 25,
                    y: e - 25
                }), null != Dg(Gg(b, c), m) && (a |= 16777216)
        }
        g && null != _.Hg(b, void 0 === f ? null : f) && (a |= 16777216);
        return a
    };
    Bg = function(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    };
    _.Hg = function(a, b) {
        b = void 0 === b ? null : b;
        var c = a.innerHeight;
        c = _.zg({
            kf: 0,
            ue: a.innerWidth,
            Re: 10,
            lf: c - 66,
            ve: c,
            Se: 10
        });
        return Dg(Gg(a, b), c)
    };
    Gg = function(a, b) {
        return new _.Jg(a, {
            Bh: Kg(a, void 0 === b ? null : b)
        })
    };
    Kg = function(a, b) {
        if (b = void 0 === b ? null : b) {
            var c = b;
            return function(d, e, f) {
                var g, h;
                _.Lg(c, "ach_evt", {
                    tn: d.tagName,
                    id: null != (g = d.getAttribute("id")) ? g : "",
                    cls: null != (h = d.getAttribute("class")) ? h : "",
                    ign: String(f),
                    pw: a.innerWidth,
                    ph: a.innerHeight,
                    x: e.x,
                    y: e.y
                }, !0, 1)
            }
        }
    };
    _.Mg = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    };
    _.Ng = function(a) {
        a = void 0 === a ? _.t : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    Og = function(a, b) {
        b = void 0 === b ? _.t : b;
        var c, d;
        return (null == (c = b.performance) ? void 0 : null == (d = c.timing) ? void 0 : d[a]) || 0
    };
    _.Pg = function(a) {
        a = void 0 === a ? _.t : a;
        var b = Math.min(Og("domLoading", a) || Infinity, Og("domInteractive", a) || Infinity);
        return Infinity === b ? Math.max(Og("responseEnd", a), Og("navigationStart", a)) : b
    };
    Rg = function(a, b) {
        b = void 0 === b ? [] : b;
        var c = Date.now();
        return _.Qg(b, function(d) {
            return c - d < 1E3 * a
        })
    };
    Tg = function(a, b) {
        try {
            var c = a.getItem("__lsv__");
            if (!c) return [];
            try {
                var d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || _.Sg(d, function(e) {
                    return !_.A(Number, "isInteger").call(Number, e)
                })) return a.removeItem("__lsv__"), [];
            d = Rg(b, d);
            d.length || null == a || a.removeItem("__lsv__");
            return d
        } catch (e) {
            return null
        }
    };
    Vg = function(a, b) {
        return null !== _.Ug(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && b.has(c)
        }, !0)
    };
    Wg = function(a, b) {
        return _.Ug(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && "fixed" === b.getComputedStyle(c, null).position
        }, !0)
    };
    Xg = function(a) {
        return Math.round(10 * Math.round(a / 10))
    };
    Yg = function(a) {
        return a.position + "-" + Xg(a.ia) + "x" + Xg(a.na) + "-" + Xg(a.scrollY + a.Sc) + "Y"
    };
    Zg = function(a) {
        return "f-" + Yg({
            position: a.position,
            Sc: a.Sc,
            scrollY: 0,
            ia: a.ia,
            na: a.na
        })
    };
    $g = function(a, b) {
        a = Math.min(null != a ? a : Infinity, null != b ? b : Infinity);
        return Infinity !== a ? a : 0
    };
    bh = function(a, b, c) {
        var d = _.ah(c.la).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.min(e.bottom + 10, c.na),
                    g = Math.max(e.left - 10, 0),
                    h = Math.min(e.right + 10, c.ia),
                    k = .3 * c.ia;
                for (e = Math.max(e.top - 10, 0); e <= f; e += 10) {
                    if (0 < h && g < k) {
                        var l = Zg({
                            position: "left",
                            Sc: e,
                            ia: c.ia,
                            na: c.na
                        });
                        b.set(l, $g(b.get(l), g))
                    }
                    if (g < c.ia && h > c.ia - k) {
                        l = Zg({
                            position: "right",
                            Sc: e,
                            ia: c.ia,
                            na: c.na
                        });
                        var m = c.ia - h;
                        b.set(l, $g(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    };
    _.dh = function(a) {
        if (1200 > a.ia || 650 > a.na) return null;
        var b = _.ah(a.la).sideRailAvailableSpace;
        if (!a.Rh) {
            var c = {
                    la: a.la,
                    ia: a.ia,
                    na: a.na,
                    kc: a.kc
                },
                d = "f-" + Xg(c.ia) + "x" + Xg(c.na);
            if (!b.has(d)) {
                b.set(d, 0);
                _.ah(c.la).sideRailProcessedFixedElements.clear();
                d = new _.v.Set([].concat(_.ch(_.A(Array, "from").call(Array, c.la.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]"))), _.ch(c.kc)));
                for (var e = c.la, f = [], g = _.z(e.document.querySelectorAll("*")), h = g.next(); !h.done; h = g.next()) {
                    h = h.value;
                    var k = e.getComputedStyle(h, null);
                    "fixed" === k.position && "none" !== k.display && "hidden" !== k.visibility && f.push(h)
                }
                e = _.z(f);
                for (f = e.next(); !f.done; f = e.next()) f = f.value, Vg(f, d) || bh(f, b, c)
            }
        }
        c = [];
        e = .9 * a.na;
        f = _.yg(a.la);
        g = d = (a.na - e) / 2;
        h = e / 7;
        for (k = 0; 8 > k; k++) {
            var l = c,
                m = l.push;
            var n = g;
            var p = a.position,
                r = {
                    la: a.la,
                    ia: a.ia,
                    na: a.na,
                    kc: a.kc
                },
                w = Zg({
                    position: p,
                    Sc: n,
                    ia: r.ia,
                    na: r.na
                }),
                u = Yg({
                    position: p,
                    Sc: n,
                    scrollY: f,
                    ia: r.ia,
                    na: r.na
                });
            if (!b.has(u)) {
                var y = "left" === p ? 20 : r.ia - 20,
                    x = y;
                p = .3 * r.ia / 5 * ("left" === p ? 1 : -1);
                for (var C = 0; 6 > C; C++) {
                    var I = Ag(r.la.document, {
                            x: Math.round(x),
                            y: Math.round(n)
                        }),
                        D = Vg(I, r.kc),
                        J = Wg(I, r.la);
                    if (!D && null !== J) {
                        bh(J, b, r);
                        b.delete(u);
                        break
                    }
                    D || (D = I.offsetHeight >= .25 * r.na, D = I.offsetWidth >= .9 * r.ia && D);
                    if (D) b.set(u, Math.round(Math.abs(x - y) + 20));
                    else if (x !== y) x -= p, p /= 2;
                    else {
                        b.set(u, 0);
                        break
                    }
                    x += p
                }
            }
            n = $g(b.get(w), b.get(u));
            m.call(l, n);
            g += h
        }
        b = a.Gi;
        f = a.position;
        e = Math.round(e / 8);
        d = Math.round(d);
        g = a.minWidth;
        a = a.minHeight;
        l = [];
        h = _.A(Array(c.length), "fill").call(Array(c.length), 0);
        for (k = 0; k < c.length; k++) {
            for (; 0 !== l.length && c[l[l.length - 1]] >= c[k];) l.pop();
            h[k] = 0 === l.length ? 0 : l[l.length - 1] + 1;
            l.push(k)
        }
        l = [];
        m = c.length - 1;
        k = _.A(Array(c.length), "fill").call(Array(c.length), 0);
        for (n = m; 0 <= n; n--) {
            for (; 0 !== l.length && c[l[l.length - 1]] >= c[n];) l.pop();
            k[n] = 0 === l.length ? m : l[l.length - 1] - 1;
            l.push(n)
        }
        l = null;
        for (m = 0; m < c.length; m++)
            if (n = {
                    position: f,
                    width: Math.round(c[m]),
                    height: Math.round((k[m] - h[m] + 1) * e),
                    offsetY: d + h[m] * e
                }, r = n.width >= g && n.height >= a, 0 === b && r) {
                l = n;
                break
            } else 1 === b && r && (!l || n.width * n.height > l.width * l.height) && (l = n);
        return l
    };
    eh = function(a) {
        var b = a.split("/");
        return "/" === a.charAt(0) && 2 <= b.length ? b[1] : "/" !== a.charAt(0) && 1 <= b.length ? b[0] : ""
    };
    fh = function() {
        var a = Date.now();
        return _.A(Number, "isFinite").call(Number, a) ? Math.round(a) : 0
    };
    lh = function(a) {
        var b = new gh;
        var c = fh();
        b = _.hh(b, 1, c);
        b = _.hh(b, 2, a.pvsid);
        b = _.ih(b, 3, a.zb || a.fb);
        c = _.If();
        b = _.be(b, 4, c, Kc);
        b = _.hh(b, 5, a.Wh);
        a = _.ih(b, 12, a.Lf);
        var d;
        if (b = null == (d = _.v.globalThis.performance) ? void 0 : d.memory) {
            d = new jh;
            try {
                _.hh(d, 1, b.jsHeapSizeLimit)
            } catch (e) {}
            try {
                _.hh(d, 2, b.totalJSHeapSize)
            } catch (e) {}
            try {
                _.hh(d, 3, b.usedJSHeapSize)
            } catch (e) {}
        } else d = void 0;
        d && _.kh(a, 10, d);
        return a
    };
    sh = function(a) {
        var b = _.Pg();
        if (a.Bc) {
            var c = a.Qa,
                d = c.Ac,
                e = lh(a),
                f = new mh;
            b = _.hh(f, 2, b);
            f = new nh;
            f = _.oh(f, 1, a.Bc);
            f = _.ph(f, 2, a.Wh);
            f = _.oh(f, 3, a.Ji);
            f = _.ph(f, 4, a.Vh);
            f = _.oh(f, 5, a.Ig);
            a = _.ph(f, 6, a.Pf);
            a = _.kh(b, 3, a);
            e = _.qh(e, 6, rh, a);
            d.call(c, e)
        }
    };
    vh = function(a) {
        if (!a.Bc) return function() {};
        var b = fh();
        a.Qa.Ac(th(lh(a)));
        return function() {
            var c = a.Qa,
                d = c.Ac,
                e = lh(a);
            var f = new uh;
            var g = fh() - b;
            f = _.hh(f, 1, g);
            e = _.qh(e, 14, rh, f);
            return void d.call(c, e)
        }
    };
    xh = function(a) {
        var b = void 0 === b ? _.Qf() : b;
        a.Ll && (.25 > b ? wh(a.Qa, {
            step: 1,
            tf: "ONE",
            Cb: 6
        }) : .5 > b ? wh(a.Qa, {
            step: 2,
            tf: "TWO",
            Cb: 3
        }) : .75 > b ? wh(a.Qa, {
            step: 3,
            tf: "THREE",
            Cb: 2
        }) : wh(a.Qa, {
            step: 6,
            tf: "SIX",
            Cb: 1
        }))
    };
    K = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        return function() {
            var e = _.Wa.apply(0, arguments),
                f = yh(a, b, c, d).apply(this, e);
            try {
                var g = e.length;
                if (a.Bc && a.Ji) {
                    var h = a.Qa,
                        k = h.Ac,
                        l = lh(a);
                    var m = _.hh(l, 5, a.Vh);
                    var n = new zh;
                    var p = _.H(n, 1, b);
                    var r = _.ph(p, 2, g);
                    var w = _.qh(m, 9, rh, r);
                    k.call(h, w)
                }
            } catch (u) {}
            return f
        }
    };
    yh = function(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return function() {
            var e = _.Wa.apply(0, arguments),
                f = void 0,
                g = !1,
                h = null,
                k = _.Ff(Ah);
            try {
                var l = _.G(Bh);
                l && k && (h = k.start(b.toString(), 3));
                f = c.apply(this, e);
                g = !0;
                l && k && k.end(h)
            } catch (m) {
                try {
                    if (g) Ch.call(this, a, 110, m);
                    else if (Ch.call(this, a, b, m), !d) throw m;
                } catch (n) {
                    if (_.Dh(h), !g && !d) throw m;
                }
            }
            return f
        }
    };
    Eh = function(a, b, c, d) {
        return yh(a, b, c, void 0 === d ? !1 : d)()
    };
    Ch = function(a, b, c) {
        if (a.Ig) {
            c = _.Fh(c) ? c.error : c;
            var d = new Gh,
                e = new Hh;
            try {
                var f = _.Ih(window);
                _.hh(e, 1, f)
            } catch (p) {}
            try {
                var g = _.If();
                _.be(e, 2, g, Kc)
            } catch (p) {}
            try {
                _.ih(e, 3, window.document.URL)
            } catch (p) {}
            f = _.kh(d, 2, e);
            g = new Jh;
            b = _.H(g, 1, b);
            try {
                var h = Kh(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                _.ih(b, 2, h)
            } catch (p) {}
            try {
                var k = Kh(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                _.ih(b, 3, k)
            } catch (p) {}
            try {
                var l = Kh(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && _.Lh(b, 4, l.split(/\n\s*/))
            } catch (p) {}
            h = _.kh(f, 1, b);
            k = new Mh;
            try {
                _.ih(k, 1, a.zb || a.fb)
            } catch (p) {}
            try {
                var m = Nh();
                _.ph(k, 2, m)
            } catch (p) {}
            try {
                var n = [].concat(_.ch(_.A(Oh, "keys").call(Oh)));
                _.Lh(k, 3, n)
            } catch (p) {}
            _.qh(h, 4, Ph, k);
            _.hh(h, 5, a.Pf);
            a.Qa.Hl(h)
        }
    };
    Vh = function(a, b, c) {
        var d, e;
        return null != (e = null == (d = _.A(a, "find").call(a, function(f) {
            f = _.Qh(f, Rh, 1);
            return Sh(f, 1) <= b && Sh(f, 2) <= c
        })) ? void 0 : Uh(d, Rh, 2)) ? e : null
    };
    Xh = function(a, b, c) {
        return "number" === typeof b && "number" === typeof c && Uh(a, Wh, 6).length ? Vh(Uh(a, Wh, 6), b, c) : Uh(a, Rh, 5)
    };
    Zh = function(a) {
        var b = void 0 === b ? window : b;
        var c = null;
        b.top === b && (b = Yh(!1, b), c = Xh(a, b.width, b.height));
        null != c || (c = Xh(a));
        return null == c ? [] : c.map(function(d) {
            return _.L(d, 3) ? "fluid" : [Sh(d, 1), Sh(d, 2)]
        })
    };
    $h = function(a) {
        var b = [],
            c = !1;
        a = _.z(Zh(a));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, Array.isArray(d) ? b.push(d.join("x")) : "fluid" === d ? c = !0 : b.push(d);
        c && b.unshift("320x50");
        return b.join("|")
    };
    _.ci = function(a) {
        _.Ff(ai).j = !0;
        return bi[a]
    };
    ei = function(a) {
        var b = a.document;
        return di(a) ? b.URL : b.referrer
    };
    hi = function(a) {
        try {
            return fi(a, window.top)
        } catch (b) {
            return new _.gi(-12245933, -12245933)
        }
    };
    li = function(a) {
        if (!a) return null;
        var b, c;
        a.getBoundingClientRect ? (a = _.ii(ji, a), a = new _.ki(a.right - a.left, a.bottom - a.top)) : a = null;
        return null != (c = null == (b = a) ? void 0 : b.floor()) ? c : null
    };
    oi = function(a, b) {
        for (var c = {}, d = _.z(_.A(Object, "keys").call(Object, b)), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = _.Jd(b[e]),
                g = _.Ff(mi),
                h = g.j.get(e);
            null == h ? h = ++_.Ff(Ah).m : g.j.delete(e);
            _.ni(f, 20, _.Nc(h));
            c[e] = f
        }
        return {
            Z: _.Jd(a),
            R: c
        }
    };
    vi = function() {
        for (var a = "", b = _.z(pi()), c = b.next(); !c.done; c = b.next()) c = c.value, 15 >= c && (a += "0"), a += c.toString(16);
        return a
    };
    pi = function() {
        var a;
        if ("function" === typeof(null == (a = window.crypto) ? void 0 : a.getRandomValues)) return a = new Uint8Array(16), window.crypto.getRandomValues(a), a;
        a = window;
        var b;
        if ("function" === typeof(null == (b = a.msCrypto) ? void 0 : b.getRandomValues)) return b = new Uint8Array(16), a.msCrypto.getRandomValues(b), b;
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(255 * Math.random());
        return a
    };
    Ci = function(a, b, c, d) {
        var e = wi(b, a) || xi(b, a);
        if (!e) return null;
        var f = hi(e),
            g = e === xi(b, a),
            h = yi(function() {
                var p = g ? xi(b, a) : e;
                return p && zi(p, window)
            }),
            k = function(p) {
                var r;
                return null == (r = h()) ? void 0 : r.getPropertyValue(p)
            };
        c = Zh(c)[0];
        var l = !1;
        Array.isArray(c) && (l = d ? g : 0 === f.x && "center" === k("text-align"));
        l && (f.x += Math.round(Math.max(0, (g ? e.clientWidth : e.parentElement.clientWidth) - Number(c[0])) / 2));
        if (g) {
            var m;
            f.y += Math.round(Math.min(null != (m = Ai(k("padding-top"))) ? m : 0, e.clientHeight));
            if (!l) {
                d = e.clientWidth;
                var n;
                f.x += Math.round(Math.min(null != (n = Ai(k("padding-left"))) ? n : 0, d))
            }
        }
        return f && Bi(e) ? f : new _.gi(-12245933, -12245933)
    };
    Di = function(a, b, c, d) {
        var e = xi(a, c),
            f = "none" === (null == e ? void 0 : e.style.display);
        f && (e.style.display = "block");
        a = Ci(c, a, b, d);
        f && (e.style.display = "none");
        return a
    };
    Ei = function(a) {
        return "google_ads_iframe_" + a.toString()
    };
    Fi = function(a) {
        return Ei(a) + "__container__"
    };
    wi = function(a, b) {
        var c;
        return (null == (c = xi(a, b)) ? void 0 : c.querySelector('[id="' + Fi(a) + '"]')) || null
    };
    Gi = function(a, b) {
        var c, d;
        return null != (d = null == (c = wi(a, b)) ? void 0 : c.querySelector('iframe[id="' + Ei(a) + '"]')) ? d : null
    };
    xi = function(a, b) {
        b = void 0 === b ? document : b;
        return Hi().m.get(a) || b.getElementById(a.getDomId())
    };
    Ii = function(a) {
        return Math.round(Number(Ai(a)))
    };
    Ji = function(a) {
        var b = a.parentElement;
        return !b || 1 >= b.children.length ? !1 : _.A(Array, "from").call(Array, b.children).some(function(c) {
            return c !== a && !(_.F = ["script", "style"], _.A(_.F, "includes")).call(_.F, c.tagName.toLowerCase())
        })
    };
    Li = function(a, b, c) {
        for (var d = 100; a && a !== b && --d;) _.Ki(a, c), a = a.parentElement
    };
    Mi = function(a, b, c, d, e) {
        _.Ki(a, {
            "margin-left": "0px",
            "margin-right": "0px"
        });
        var f = {},
            g = "rtl" === d.direction,
            h = ((e && -12245933 !== e.width ? e.width : b.innerWidth) - c) / 2;
        d = function() {
            var k = a.getBoundingClientRect().left;
            return g ? h - k : k - h
        };
        b = d();
        return 0 !== b ? (c = function(k) {
            g ? f["margin-right"] = k + "px" : f["margin-left"] = k + "px"
        }, c(-b), _.Ki(a, f), d = d(), 0 !== d && b !== d && (c(b / (d - b) * b), _.Ki(a, f)), !0) : !1
    };
    Oi = function(a, b, c, d, e, f, g, h, k, l) {
        window.setTimeout(function() {
            var m = $h(d);
            if (window.IntersectionObserver) {
                var n, p = null != (n = Gi(c, b)) ? n : xi(c, b);
                m = Ni(a, b, c, e, f, g, m, h, k, l, p);
                (new window.IntersectionObserver(m, {
                    threshold: .98
                })).observe(p)
            }
        }, 500)
    };
    Ni = function(a, b, c, d, e, f, g, h, k, l, m) {
        var n = window.location && "#flexibleAdSlotTest" === window.location.hash ? 1 : _.Uf(Pi);
        return yh(a, 459, function(p, r) {
            (p = null == p ? void 0 : p[0]) && Qi(a, b, c, d, e, f, g, h, k, l, r, m, p, n)
        })
    };
    Qi = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        var w = p.boundingClientRect,
            u = p.intersectionRatio,
            y = window.innerWidth,
            x = w.left,
            C = w.right,
            I = 0 > x + 2,
            D = 0 < C - (y + 2);
        (.98 <= u || I || D) && Ri(k, function(J) {
            m.unobserve(n);
            var Q = I || D;
            var N = new Si;
            Ti(n, Q) && N.set(10);
            if (void 0 !== h && Ji(n)) {
                var Y, ua = null == (Y = xi(c, b)) ? void 0 : Y.parentElement,
                    ma;
                Y = ua ? null == (ma = zi(ua, window)) ? void 0 : ma.width : void 0;
                h !== Y && N.set(16)
            }
            Q ? (N.set(8), Q = Ui(N)) : Q = Vi(b, c, u, N);
            ma = Wi(c, n, f);
            N = ma.Lk;
            ma = ma.Nk;
            Xi(J, a);
            Yi(J, "qid", l);
            Yi(J, "iu", c.getAdUnitPath());
            Yi(J, "e", String(Q));
            I && Yi(J, "ofl", String(x));
            D && Yi(J, "ofr", String(C - y));
            Yi(J, "ret", e + "x" + f);
            Yi(J, "req", g);
            Yi(J, "bm", String(d));
            Yi(J, "efh", Number(N));
            Yi(J, "stk", Number(ma));
            Yi(J, "ifi", Zi(window))
        }, r)
    };
    Vi = function(a, b, c, d) {
        var e = Gi(b, a) || xi(b, a);
        try {
            var f = e.getBoundingClientRect(),
                g = f.left,
                h = f.top,
                k = f.width,
                l = f.height,
                m = xi(b, a),
                n = zi(m, window);
            if ("hidden" === n.visibility || "none" === n.display) return Ui(d);
            var p = Ii(n.getPropertyValue("border-top-width") || 0) + 1;
            b = g + k;
            f = h + l;
            c = (1 - c) * l;
            var r = a.elementsFromPoint(g + p + 2, h + c + p);
            var w = a.elementsFromPoint(b - p - 2, h + c + p);
            var u = a.elementsFromPoint(b - p - 2, f - c - p);
            var y = a.elementsFromPoint(g + p + 2, f - c - p);
            var x = a.elementsFromPoint(b / 2, f - c - p)
        } catch (I) {
            return d.set(1), Ui(d)
        }
        if (!(r && r.length && w && w.length && u && u.length && y && y.length && x && x.length)) return d.set(7), Ui(d);
        a = function(I, D) {
            for (var J = !1, Q = 0; Q < I.length; Q++) {
                var N = I[Q];
                if (J) {
                    var Y = zi(N, window);
                    if ("hidden" !== Y.visibility && !$i(N) && !C(e, N)) {
                        d.set(D);
                        "absolute" === Y.position && d.set(11);
                        break
                    }
                } else e === N && (J = !0)
            }
        };
        aj(e) && d.set(9);
        var C = function(I, D) {
            return bj(I, D) || bj(D, I)
        };
        g = r[0];
        e === g || C(e, g) || $i(g) || d.set(2);
        g = w[0];
        e === g || C(e, g) || $i(g) || d.set(3);
        g = u[0];
        e === g || C(e, g) || $i(g) || d.set(4);
        g = y[0];
        e === g || C(e, g) || $i(g) || d.set(5);
        if ($i(e)) return Ui(d);
        a(r, 12);
        a(w, 13);
        a(u, 14);
        a(y, 15);
        a(x, 6);
        return Ui(d)
    };
    Ti = function(a, b) {
        var c = !1,
            d = !1;
        return cj(a, function(e, f) {
            d = d || "scroll" === e.overflowX || "auto" === e.overflowX;
            c = c || "flex" === e.display;
            return b && c && d || "listbox" === f.role
        })
    };
    Wi = function(a, b, c) {
        var d = (a = xi(a)) && zi(a, window),
            e = d ? "absolute" !== d.position : !0,
            f = !1,
            g = a && a.parentElement,
            h = !1;
        dj(b, function(k) {
            var l = k.style;
            if (e)
                if (h || (h = k === g)) e = ej(k, _.t, -1, -1);
                else {
                    l = l && l.height;
                    var m = (l && _.A(l, "endsWith").call(l, "px") ? Ii(l) : 0) >= c;
                    !l || m || "string" === typeof l && _.A(fj, "includes").call(fj, l) || (e = !1)
                }
            f || (k = zi(k, _.t), "sticky" !== k.position && "fixed" !== k.position) || (f = !0);
            return !(f && !e)
        }, 100);
        return {
            Lk: e,
            Nk: f
        }
    };
    ej = function(a, b, c, d) {
        var e = a.style;
        return (null == e ? 0 : e.height) && !_.A(fj, "includes").call(fj, e.height) || (null == e ? 0 : e.maxHeight) && !_.A(gj, "includes").call(gj, e.maxHeight) || hj(a, b.document, function(f) {
            var g = f.style.height;
            f = f.style.getPropertyValue("max-height");
            return !!g && !_.A(fj, "includes").call(fj, g) || !!f && !_.A(gj, "includes").call(gj, f)
        }, c, d) ? !1 : !0
    };
    hj = function(a, b, c, d, e) {
        b = b.styleSheets;
        if (!b) return !1;
        var f = a.matches || a.msMatchesSelector;
        d = -1 === d ? Infinity : d;
        e = -1 === e ? Infinity : e;
        for (var g = 0; g < Math.min(b.length, d); ++g) {
            var h = null;
            try {
                var k = b[g],
                    l = null;
                try {
                    l = k.cssRules || k.rules
                } catch (I) {
                    if (15 == I.code) throw I.styleSheet = k, I;
                }
                h = l
            } catch (I) {
                continue
            }
            l = void 0;
            if (null != (l = h) && l.length)
                for (l = 0; l < Math.min(h.length, e); ++l) try {
                    var m = h[l],
                        n, p = c;
                    if (!(n = f.call(a, m.selectorText) && p(m))) a: {
                        var r = void 0;p = a;
                        var w = c,
                            u = e,
                            y = null != (r = m.cssRules) ? r : [];
                        for (r = 0; r < Math.min(y.length, u); r++) {
                            var x = y[r],
                                C = w;
                            if (f.call(p, x.selectorText) && C(x)) {
                                n = !0;
                                break a
                            }
                        }
                        n = !1
                    }
                    if (n) return !0
                } catch (I) {}
        }
        return !1
    };
    $i = function(a) {
        return cj(a, function(b) {
            return "fixed" === b.position || "sticky" === b.position
        })
    };
    aj = function(a) {
        return cj(a, function(b) {
            var c;
            return (_.F = ["left", "right"], _.A(_.F, "includes")).call(_.F, null != (c = b["float"]) ? c : b.cssFloat)
        })
    };
    ij = function(a) {
        return "number" === typeof a || "string" === typeof a
    };
    lj = function(a) {
        a = jj(a);
        return _.kj(a)
    };
    jj = function(a) {
        return null === a ? "null" : void 0 === a ? "undefined" : a
    };
    oj = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? {} : d;
        var e = mj.j();
        0 === e.j && (e.j = .001 > Math.random() ? 2 : 1);
        2 === e.j && (e = {}, nj(_.A(Object, "assign").call(Object, {}, (e.c = String(a), e.pc = String(_.Ih(window)), e.em = c, e.lid = b, e.eids = _.If().join(), e), d), "esp"))
    };
    pj = function() {
        var a = window;
        var b = void 0 === b ? function() {} : b;
        return new _.v.Promise(function(c) {
            var d = function() {
                c(b());
                _.of(a, "load", d)
            };
            _.ib(a, "load", d)
        })
    };
    qj = function(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$");
        try {
            for (var d = 0; d < a.length; d++) {
                var e = (c.exec(a.key(d)) || [])[1];
                e && b.push(e)
            }
        } catch (f) {}
        return b
    };
    tj = function(a, b) {
        return Uh(a, rj, 2).some(function(c) {
            return _.sj(c, 1) === b && null != _.sj(c, 2)
        })
    };
    uj = function(a, b) {
        return Uh(a, rj, 2).some(function(c) {
            return _.sj(c, 1) === b && null != _.sj(c, 2)
        })
    };
    zj = function(a, b, c, d) {
        if (b)
            for (var e = _.z(qj(b)), f = e.next(), g = {}; !f.done; g = {
                    rc: g.rc
                }, f = e.next())
                if (g.rc = f.value, (f = vj().get(g.rc, b).Cc) && !uj(a, g.rc)) {
                    var h = wj(f);
                    if (2 !== h && 3 !== h) {
                        h = !1;
                        if (c) {
                            var k = /^(\d+)$/.exec(g.rc);
                            if (k && !(h = _.A(c.split(","), "includes").call(c.split(","), k[1]))) continue;
                            if (!h && !c.split(",").some(function(l) {
                                    return function(m) {
                                        var n;
                                        return null == d ? void 0 : null == (n = d.get(m)) ? void 0 : n.has(l.rc)
                                    }
                                }(g))) continue
                        }
                        xj(f, 9, h);
                        h = _.sj(f, 2);
                        yj(a, 2, rj, f);
                        f = {};
                        oj(19, g.rc, null, (f.hs = h ? "1" : "0", f))
                    }
                }
    };
    Aj = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    Lj = function(a, b, c, d, e) {
        var f, g, h, k, l, m, n, p, r, w, u, y, x;
        return _.kb(function(C) {
            return 1 == C.j ? (f = new Bj, g = new Cj(a, c, e), M(f, g), M(f, new Dj(g.v, void 0, d, e)), h = new Ej(g.l, e), M(f, h), k = new Fj(h.l, e), M(f, k), l = new Gj(b, k.l, e), M(f, l), M(f, new Dj(l.v, void 0, d, e)), m = new Hj(l.l, l.G, 300, 1E3, e), M(f, m), M(f, new Dj(m.l, void 0, d, e)), n = new Ij(e), M(f, n), p = new Jj(n.output, k.v, e), M(f, p), r = new Gj(b, p.l, e), M(f, r), w = new Dj(r.l, void 0, d, e), M(f, w), Kj(f), x = a, C.yield(m.l.promise, 2)) : C.return({
                id: x,
                collectorGeneratedData: null != (y = null == (u = C.o) ? void 0 : _.sj(u, 2)) ? y : null
            })
        })
    };
    Rj = function(a, b, c, d) {
        var e = {};
        e = void 0 === e ? Mj : e;
        Nj() !== Oj(window) ? oj(16, "") : Pj(a, "encryptedSignalProviders", c) && Pj(a, "secureSignalProviders", c) || (oj(38, ""), Qj(a, "encryptedSignalProviders", b, e, c, d), Qj(a, "secureSignalProviders", b, e, c, function() {}))
    };
    Pj = function(a, b, c) {
        if (void 0 === a[b] || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    };
    Qj = function(a, b, c, d, e, f) {
        var g, h = new Sj(null != (g = a[b]) ? g : [], c, "secureSignalProviders" === b, f, d);
        a[b] = new Tj(h);
        h.addErrorHandler(e)
    };
    Wj = function(a, b) {
        var c = new Bj,
            d = new Ij(b);
        a = new Uj(d.output, a, b);
        Vj(c, [d, a]);
        Kj(c)
    };
    ak = function(a, b, c, d, e) {
        var f = b.toString();
        if (Xj.has(f)) return null;
        Xj.add(f);
        f = new Bj;
        a = new Cj(a, c, e);
        var g = new Dj(a.v, c, d, e),
            h = new Yj(a.l, e),
            k = new Ej(h.l, e);
        b = new Zj(k.l, b, e);
        c = new Dj(b.l, c, d, e);
        Vj(f, [a, g, h, k, b, c]);
        Kj(f);
        return f
    };
    ck = function(a, b, c) {
        c = void 0 === c ? bk : c;
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? c(a, b) : _.ib(a, "load", function() {
            return void c(a, b)
        }))
    };
    dk = function(a) {
        try {
            var b, c;
            return (null != (c = null == (b = a.top) ? void 0 : b.frames) ? c : {}).google_ads_top_frame
        } catch (d) {}
        return null
    };
    ek = function(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    };
    gk = function(a) {
        if (a === a.top || _.fk(a.top)) return _.v.Promise.resolve({
            status: 4
        });
        var b = dk(a);
        if (!b) return _.v.Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && ek(a.document.referrer)) return _.v.Promise.resolve({
            status: 3
        });
        var c = new _.cg;
        a = new MessageChannel;
        a.port1.onmessage = function(d) {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                te: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    kk = function(a, b) {
        var c = hk(a);
        return c.messageChannelSendRequestFn ? _.v.Promise.resolve(c.messageChannelSendRequestFn) : new _.v.Promise(function(d) {
            function e(k) {
                return h.j(k).then(function(l) {
                    return l.data
                })
            }
            var f = _.af("IFRAME");
            f.style.display = "none";
            f.name = "goog_topics_frame";
            b && (f.credentialless = !0);
            f.src = _.gb(ik).toString();
            var g = (new URL(ik.toString())).origin,
                h = jk({
                    destination: a,
                    pb: f,
                    origin: g,
                    wb: "goog:gRpYw:doubleclick"
                });
            h.j("goog:topics:frame:handshake:ack").then(function(k) {
                "goog:topics:frame:handshake:ack" === k.data && d(e)
            });
            c.messageChannelSendRequestFn = e;
            a.document.documentElement.appendChild(f)
        })
    };
    uk = function(a, b, c, d) {
        var e = {
            skipTopicsObservation: _.G(lk),
            includeBuyerTopics: _.G(mk)
        };
        e = void 0 === e ? {} : e;
        var f = nk(d),
            g = f.ke,
            h = f.je;
        b = hk(b);
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e.skipTopicsObservation,
            includeBuyerTopics: e.includeBuyerTopics
        }).then(function(k) {
            var l = h;
            if (k instanceof Uint8Array) l || (l = !(g instanceof Uint8Array && wa(k, g)));
            else if (qf(ok)(k)) l || (l = k !== g);
            else return c.vb(989, Error(JSON.stringify(k))), 7;
            if (l && d) try {
                var m = new pk;
                var n = _.qk(m, 2, _.Mg());
                k instanceof Uint8Array ? rk(n, 1, sk, nc(k, !1, !1)) : rk(n, 3, sk, null == k ? k : Ic(k));
                d.setItem("goog:cached:topics", tk(n))
            } catch (p) {}
            return k
        }), b.getTopicsPromise = a);
        return g && !h ? _.v.Promise.resolve(g) : b.getTopicsPromise
    };
    nk = function(a) {
        if (!a) return {
            ke: null,
            je: !0
        };
        try {
            var b = a.getItem("goog:cached:topics");
            if (!b) return {
                ke: null,
                je: !0
            };
            var c = vk(b),
                d = wk(c, sk);
            switch (d) {
                case 0:
                    var e = null;
                    break;
                case 1:
                    e = xk(yk(c, zk(c, sk, 1)));
                    break;
                case 3:
                    e = _.Ak(c, zk(c, sk, 3), 0);
                    break;
                default:
                    _.cb(d)
            }
            var f = _.mf(c, 2) + 6048E5 < _.Mg();
            return {
                ke: e,
                je: f
            }
        } catch (g) {
            return {
                ke: null,
                je: !0
            }
        }
    };
    hk = function(a) {
        var b;
        return null != (b = a.google_tag_topics_state) ? b : a.google_tag_topics_state = {}
    };
    Dk = function(a) {
        if (Ma()) {
            var b = a.document.documentElement.lang;
            Bk(a) ? Ck(_.Ih(a), !0, "", b) : (new MutationObserver(function(c, d) {
                Bk(a) && (Ck(_.Ih(a), !1, b, a.document.documentElement.lang), d.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    };
    Bk = function(a) {
        var b, c;
        a = null == (b = a.document) ? void 0 : null == (c = b.documentElement) ? void 0 : c.classList;
        return !!((null == a ? 0 : a.contains("translated-rtl")) || (null == a ? 0 : a.contains("translated-ltr")))
    };
    Ck = function(a, b, c, d) {
        nj({
            ptt: "17",
            pvsid: "" + a,
            ibatl: String(b),
            pl: c,
            nl: d
        }, "translate-event")
    };
    Fk = function(a) {
        var b = "";
        Ek(function(c) {
            if (c === c.top) return !0;
            var d;
            if (null == (d = c.document) ? 0 : d.referrer) b = c.document.referrer;
            return !1
        }, !1, !1, a);
        return b
    };
    Hk = function(a) {
        var b = Gk(a, 500, 300);
        var c = a.navigator;
        var d = c.userAgent;
        var e = c.platform;
        c = c.product;
        !/Win|Mac|Linux|iPad|iPod|iPhone/.test(e) && /^Opera/.test(d) ? d = !1 : /Win/.test(e) && /Trident/.test(d) && 11 <= a.document.documentMode ? d = !0 : (a = (/WebKit\/(\d+)/.exec(d) || [0, 0])[1], e = (/rv:(\d+\.\d+)/.exec(d) || [0, 0])[1], d = !a && "Gecko" === c && 27 <= e && !/ rv: 1\.8([^.] |\.0) /.test(d) || 536 <= a ? !0 : !1);
        return d && !b
    };
    Kk = function(a, b) {
        var c = Ik.get(a);
        c || (b = c = b(), Jk.set(b, a), Ik.set(a, b));
        return c
    };
    O = function(a) {
        return function() {
            return new Lk(a, [].concat(_.ch(_.Wa.apply(0, arguments))))
        }
    };
    Mk = function(a) {
        return "[" + a.map(function(b) {
            return "string" === typeof b ? "'" + b + "'" : Array.isArray(b) ? Mk(b) : String(b)
        }).join(", ") + "]"
    };
    Nk = function(a, b) {
        b = Mk(b);
        b = b.substring(1, b.length - 1);
        return new Lk(96, [a, b])
    };
    Ok = function(a) {
        return (_.F = "rewardedSlotReady rewardedSlotGranted rewardedSlotClosed slotAdded slotRequested slotResponseReceived slotRenderEnded slotOnload slotVisibilityChanged impressionViewable gameManualInterstitialSlotReady gameManualInterstitialSlotClosed".split(" "), _.A(_.F, "includes")).call(_.F, a) ? a : null
    };
    Qk = function(a, b, c) {
        return Kk(c, function() {
            return new Pk(a, b, c)
        })
    };
    Sk = function(a, b, c) {
        return Kk(c, function() {
            return new Rk(a, b, c)
        })
    };
    Tk = function(a, b, c, d) {
        "string" === typeof a ? b.setClickUrl(a) : P(d, Nk("Slot.setClickUrl", [a]), c)
    };
    $k = function(a, b, c, d, e) {
        if ("string" !== typeof a || Uk(a)) P(e, Nk("Slot.setTargeting", [a, b]), c);
        else {
            var f = [];
            Array.isArray(b) ? f = b : _.ta(b) ? f = _.A(Array, "from").call(Array, b) : b && (f = [b]);
            f = f.map(String);
            (b = (_.F = Vk(d), _.A(_.F, "find")).call(_.F, function(g) {
                return _.sj(g, 1) === a
            })) ? Wk(b, f): (b = Wk(Xk(new Yk, a), f), yj(d, 9, Yk, b));
            e.info(Zk(a, f.join(), d.getAdUnitPath()), c)
        }
    };
    al = function(a, b, c, d) {
        if (null != a && "object" === typeof a)
            for (var e = _.z(_.A(Object, "keys").call(Object, a)), f = e.next(); !f.done; f = e.next()) f = f.value, $k(f, a[f], b, c, d);
        else d.error(Nk("Slot.updateTargetingFromMap", [a]), b)
    };
    cl = function(a, b, c, d) {
        return "string" !== typeof a ? (P(d, Nk("Slot.getTargeting", [a]), b), []) : (b = (_.F = Vk(c), _.A(_.F, "find")).call(_.F, function(e) {
            return _.sj(e, 1) === a
        })) ? _.bl(b, 2).slice() : []
    };
    dl = function(a) {
        return Vk(a).map(function(b) {
            return _.R(b, 1)
        })
    };
    jl = function(a, b, c, d) {
        if (void 0 === a) _.ni(c, 9), d.info(el(b.getAdUnitPath()), b);
        else {
            var e = Vk(c),
                f = _.A(e, "findIndex").call(e, function(g) {
                    return _.sj(g, 1) === a
                });
            0 > f ? P(d, fl(a, b.getAdUnitPath()), b) : (e.splice(f, 1), _.gl(c, 9, e), d.info(hl(a, b.getAdUnitPath()), b))
        }
    };
    ll = function(a, b, c) {
        return Kk(c, function() {
            return new kl(a, b, c, c.j)
        })
    };
    ml = function(a) {
        return _.A(Object, "assign").call(Object, {}, a, _.A(Object, "fromEntries").call(Object, _.A(Object, "entries").call(Object, a).map(function(b) {
            b = _.z(b);
            var c = b.next().value;
            return [b.next().value, c]
        })))
    };
    ql = function() {
        var a = {},
            b = ml(nl);
        a.OutOfPageFormat = b;
        b = ml(ol);
        a.TrafficSource = b;
        b = ml(pl);
        a.Taxonomy = b;
        return a
    };
    ul = function(a, b, c, d, e) {
        if ("string" === typeof a && a.length && void 0 !== rl()[a] && "string" === typeof b) {
            var f = (_.F = c.Na(), _.A(_.F, "find")).call(_.F, function(g) {
                return _.sj(g, 1) === a
            });
            f ? Wk(f, [b]) : (f = sl(Xk(new Yk, a), b), yj(c, 14, Yk, f));
            e.info(tl(a, String(b), d))
        } else P(e, Nk("PubAdsService.set", [a, b]))
    };
    vl = function(a, b, c) {
        return "string" !== typeof a ? (P(c, Nk("PubAdsService.get", [a])), null) : (b = (b = (_.F = b.Na(), _.A(_.F, "find")).call(_.F, function(d) {
            return _.sj(d, 1) === a
        })) && _.bl(b, 2)) ? b[0] : null
    };
    wl = function(a) {
        return a.Na().map(function(b) {
            return _.R(b, 1)
        })
    };
    yl = function() {
        for (var a = _.Vf(xl) || "0-0-0", b = a.split("-").map(function(e) {
                return Number(e)
            }), c = ["1", "0", "40"].map(function(e) {
                return Number(e)
            }), d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "1-0-40"
    };
    Cl = function() {
        if (zl) return zl;
        for (var a = Wf(Al), b = [], c = 0; c < a.length; c += 2) Bl(a[c], a[c + 1], b);
        return zl = b.join("&")
    };
    Hl = function(a, b) {
        if (!b || !_.ja(b)) return null;
        var c = !1,
            d = new Dl;
        _.El(b, function(e, f) {
            var g = !1;
            switch (f) {
                case "allowOverlayExpansion":
                    "boolean" === typeof e ? xj(d, 1, b.allowOverlayExpansion) : c = g = !0;
                    break;
                case "allowPushExpansion":
                    "boolean" === typeof e ? xj(d, 2, b.allowPushExpansion) : c = g = !0;
                    break;
                case "sandbox":
                    !0 === e ? xj(d, 3, b.sandbox) : c = g = !0;
                    break;
                default:
                    g = !0
            }
            g && a.error(Fl("setSafeFrameConfig", Gl(b), f, Gl(e)))
        });
        return c ? null : d
    };
    Jl = function(a) {
        var b = new Dl;
        a = _.z(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value) null != Il(c, 1) && xj(b, 1, _.L(c, 1)), null != Il(c, 2) && xj(b, 2, _.L(c, 2)), null != Il(c, 3) && xj(b, 3, _.L(c, 3));
        return b
    };
    Kl = function(a, b) {
        var c = {};
        b = (c[0] = Sf(b.pvsid), c);
        return _.Ff(Gf).o(a, b)
    };
    Ml = function(a, b) {
        var c;
        return null == (c = _.Ll(a, "__gads", b)) ? void 0 : _.A(c.split(":"), "find").call(c.split(":"), function(d) {
            return 0 === d.indexOf("ID=")
        })
    };
    Nl = function(a, b, c, d) {
        (c = Ml(c, d)) ? (d = {}, b = (d[0] = Sf(b.pvsid), d[1] = Sf(c), d), _.Ff(Gf).o(a, b)) : Kl(a, b)
    };
    Rl = function(a) {
        var b = a.key,
            c = a.value,
            d = a.Da,
            e = a.serviceName,
            f = a.Nl,
            g = a.bb,
            h = a.T;
        a = a.context;
        var k = null;
        "string" === typeof c ? k = [c] : Array.isArray(c) ? k = c : _.ta(c) && (k = _.A(Array, "from").call(Array, c));
        var l = "string" === typeof b && !Uk(b);
        k = k && ya(k);
        var m, n = null != (m = null == k ? void 0 : k.every(function(p) {
            return "string" === typeof p
        })) ? m : !1;
        if (l && n) {
            c = k;
            m = (_.F = Uh(d, Yk, 2), _.A(_.F, "find")).call(_.F, function(p) {
                return _.sj(p, 1) === b
            });
            if ("gpt-beta" === b) {
                if (f) {
                    P(h, Ol(c.join()));
                    return
                }
                if (m) {
                    P(h, Pl(c.join()));
                    return
                }
                c = Ql(c, g, a)
            }
            m ? Wk(m, c) : (f = Wk(Xk(new Yk, b), c), yj(d, 2, Yk, f));
            h.info(Zk(b, c.join(), e))
        } else P(h, Nk("PubAdsService.setTargeting", [b, c]))
    };
    Sl = function(a, b, c) {
        return "string" !== typeof a ? (P(c, Nk("PubAdsService.getTargeting", [a])), []) : (b = (_.F = Uh(b, Yk, 2), _.A(_.F, "find")).call(_.F, function(d) {
            return _.sj(d, 1) === a
        })) ? _.bl(b, 2).slice() : []
    };
    Tl = function(a) {
        return Uh(a, Yk, 2).map(function(b) {
            return _.R(b, 1)
        })
    };
    $l = function(a, b, c, d) {
        if (void 0 === a) _.ni(b, 2), d.info(Xl(c));
        else if ("gpt-beta" === a) P(d, Yl(a));
        else {
            var e = Uh(b, Yk, 2),
                f = _.A(e, "findIndex").call(e, function(g) {
                    return _.sj(g, 1) === a
                });
            0 > f ? P(d, fl(a, c)) : (e.splice(f, 1), _.gl(b, 2, e), d.info(Zl(a, c)))
        }
    };
    Ql = function(a, b, c) {
        var d = [];
        a = _.z(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            b.j = e;
            var f = Kl(9, c);
            1 === f.length && (d.push(e), d.push(e + "-" + f[0]))
        }
        return d
    };
    bm = function() {
        var a, b, c;
        return "pagead2.googlesyndication.com" === (null != (c = am.exec(null != (b = null == (a = _.ci(172)) ? void 0 : a.src) ? b : "")) ? c : [])[1]
    };
    cm = function(a) {
        return a + 'Correlator has been deprecated. Please see the Google Ad Manager help page on "Pageviews in GPT" for more information: https://support.google.com/admanager/answer/183281?hl=en'
    };
    dm = function(a, b) {
        var c = b.j;
        return a.map(function(d) {
            return _.A(c, "find").call(c, function(e) {
                return e.j === d
            })
        }).filter(sf())
    };
    fm = function() {
        Object.defineProperty(window, "google_DisableInitialLoad", {
            get: function() {
                em();
                return !0
            },
            set: function() {
                em()
            },
            configurable: !0
        })
    };
    im = function(a, b, c, d, e, f) {
        var g = gm(f, a, b, d, e, void 0, !0);
        f = g.slotId;
        g = g.Da;
        if (!f || !g) return P(b, Nk("PubAdsService.definePassback", [d, e])), null;
        xj(g, 17, !0);
        c.slotAdded(f, g);
        return {
            ni: ll(a, b, new hm(a, f, c)),
            Da: g
        }
    };
    km = function(a, b, c, d, e) {
        return Kk(c, function() {
            return new jm(a, b, c, d, e)
        })
    };
    lm = function(a, b, c, d, e) {
        "string" !== typeof a || "string" !== typeof b || void 0 === rl()[a] ? P(e, Nk("Slot.set", [a, b]), c) : (c = (_.F = d.Na(), _.A(_.F, "find")).call(_.F, function(f) {
            return _.sj(f, 1) === a
        })) ? Wk(c, [b]) : (b = sl(Xk(new Yk, a), b), yj(d, 3, Yk, b))
    };
    mm = function(a, b, c, d) {
        return "string" !== typeof a ? (P(d, Nk("Slot.get", [a]), b), null) : (b = (b = (_.F = c.Na(), _.A(_.F, "find")).call(_.F, function(e) {
            return _.sj(e, 1) === a
        })) && _.bl(b, 2)) ? b[0] : null
    };
    nm = function(a) {
        return a.Na().map(function(b) {
            return _.R(b, 1)
        })
    };
    pm = function(a) {
        return Array.isArray(a) && 2 === a.length ? a.every(om) : "fluid" === a
    };
    qm = function(a) {
        return Array.isArray(a) && 2 === a.length && om(a[0]) && om(a[1])
    };
    sm = function(a) {
        if (Array.isArray(a)) {
            var b = new Rh;
            b = _.ni(b, 1, _.Nc(a[0]));
            a = _.ni(b, 2, _.Nc(a[1]))
        } else a = rm();
        return a
    };
    um = function(a) {
        var b = [];
        if (tm(a)) b.push(sm(a));
        else if (Array.isArray(a)) {
            a = _.z(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, tm(c) ? b.push(sm(c)) : wa(c, ["fluid"]) && b.push(rm())
        }
        return b
    };
    vm = function(a) {
        var b = void 0 === b ? window : b;
        if (!a) return [];
        if (!a.length) {
            var c, d;
            null == (c = b.console) || null == (d = c.warn) || d.call(c, "Invalid GPT fixed size specification: " + JSON.stringify(a))
        }
        return um(a)
    };
    tm = function(a) {
        return _.G(wm) ? Array.isArray(a) && 2 === a.length ? a.every(xm) : "fluid" === a : Array.isArray(a) && 1 < a.length ? "number" === typeof a[0] && "number" === typeof a[1] : "fluid" === a
    };
    zm = function(a) {
        if (!Array.isArray(a) || 2 !== a.length) throw new ym("Each mapping entry must be an array of size 2");
        var b = a[0];
        if (!qm(b)) throw new ym("Size must be an array of two non-negative integers");
        var c = new Rh;
        c = _.ni(c, 1, _.Nc(b[0]));
        b = _.ni(c, 2, _.Nc(b[1]));
        if (Array.isArray(a[1]) && 0 === a[1].length) a = [];
        else if (a = um(a[1]), 0 === a.length) throw new ym("At least one slot size must be present");
        c = new Wh;
        b = _.kh(c, 1, b);
        return _.gl(b, 2, a)
    };
    Am = function() {
        var a;
        return null != (a = _.t.googletag) ? a : _.t.googletag = {
            cmd: []
        }
    };
    Em = function(a, b) {
        _.G(Bm) ? (_.ni(a, 28), null !== b && tf(b) && _.A(Object, "hasOwn").call(Object, b, "enabled") && (b = b.enabled, Cm(b) && (b = Dm(b), _.kh(a, 28, b)))) : void 0 === b || null === b ? _.ni(a, 28) : (b = b.enabled, Cm(b) ? (b = Dm(b), _.kh(a, 28, b)) : void 0 !== b && null !== b || _.ni(a, 28))
    };
    Fm = function(a, b) {
        if (!b) return [];
        var c = [];
        b = _.z((_.F = Yd(b, 26), _.A(_.F, "values")).call(_.F));
        for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            try {
                c.push(JSON.parse(d))
            } catch (e) {
                Ch(a, 1023, e)
            }
        }
        return c
    };
    Hm = function(a, b, c) {
        return Kk(c, function() {
            return new Gm(a, b, c)
        })
    };
    Pm = function(a, b, c, d, e, f, g) {
        var h = new Bj,
            k = new Im(a, g);
        M(h, k);
        e = new Jm(a, d, e);
        M(h, e);
        e = new Km(a, b, d, f, k.kb);
        M(h, e);
        g = new Lm(a, b, c, d, g, f, k.kb);
        M(h, g);
        if (_.G(Mm)) {
            b = new Nm(a, b, c, d, f, k.kb);
            M(h, b);
            var l = b.l
        }
        a = new Om(a, k.kb, g.l, e.l, l);
        M(h, a);
        Kj(h);
        return {
            kb: a.output,
            Ga: h
        }
    };
    Rm = function(a, b) {
        return Kk(b, function() {
            return new Qm(a, b)
        })
    };
    Tm = function(a, b, c) {
        var d = yh(a, 77, function() {
            var e = b.cmd;
            if (!e || Array.isArray(e)) {
                var f = new Sm(c);
                b.cmd = Rm(a, f);
                null != e && e.length && f.push.apply(f, e)
            }
        });
        b.fifWin && "complete" !== document.readyState ? _.ib(window, "load", function() {
            return window.setTimeout(d, 0)
        }) : d()
    };
    Wm = function(a) {
        var b = window;
        "complete" === _.t.document.readyState ? Eh(a, 94, function() {
            Am()._pubconsole_disable_ || null !== Um(b) && Vm(a, b)
        }) : _.ib(_.t, "load", yh(a, 94, function() {
            Am()._pubconsole_disable_ || null !== Um(b) && Vm(a, b)
        }))
    };
    Vm = function(a, b) {
        b = void 0 === b ? _.t : b;
        if (!Xm) {
            var c = new Ym("gpt_pubconsole_loaded");
            Xi(c, a);
            Yi(c, "param", String(Um(b)));
            Yi(c, "api", String(Zm));
            $m(c);
            _.an(b.document, bn);
            Xm = !0
        }
    };
    Um = function(a) {
        var b = ei(a),
            c;
        return null != (c = (_.F = ["google_debug", "dfpdeb", "google_console", "google_force_console", "googfc"], _.A(_.F, "find")).call(_.F, function(d) {
            return null !== cn(b, d)
        })) ? c : null
    };
    dn = function() {
        Am()._pubconsole_disable_ = !0
    };
    gn = function() {
        en && (Am().console.openConsole(fn), fn = void 0, en = !1)
    };
    hn = function(a) {
        switch (Number(a)) {
            case 0:
                return "";
            case 1:
                return "Out-of-page creative";
            case 2:
            case 3:
                return "Anchor";
            case 5:
                return "Interstitial";
            case 6:
                return "Shoppit";
            case 7:
                return "Game Manual Interstitial";
            case 4:
                return "Rewarded";
            case 8:
            case 9:
                return "Side Rail";
            default:
                return ""
        }
    };
    jn = function(a, b) {
        b = void 0 === b ? null : b;
        var c = [];
        a && (c.push(_.sj(a, 1)), c.push($h(a)), c.push(_.sj(a, 2)));
        if (b) {
            a = [];
            for (var d = 0; b && 25 > d; b = b.parentNode, ++d) 9 === b.nodeType ? a.push("") : a.push(b.id);
            (b = a.join()) && c.push(b)
        }
        return c.length ? _.Rf(c.join(":")).toString() : "0"
    };
    kn = function(a) {
        if (!_.fk(a)) return -1;
        a = a.pageYOffset;
        return 0 > a ? -1 : a
    };
    on = function(a, b, c, d, e) {
        if (_.G(ln)) {
            var f = void 0,
                g = yh(a.context, b, e);
            _.ib(c, d, g) && (f = function() {
                return void _.of(c, d, g)
            }, _.mn(a, f));
            return f
        }
        return null != (f = nn(a, b, c, d, e)) ? f : void 0
    };
    qn = function(a) {
        a = (_.fk(a.top) ? a.top : a).AMP;
        return "object" === typeof a && !!pn(a, function(b, c) {
            return !/^inabox/i.test(c)
        })
    };
    un = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        var p = {
                Aa: new rn,
                La: new rn,
                he: new rn,
                Oh: new rn
            },
            r = new Bj;
        b = new sn(a, b, c.width, k, l, n);
        M(r, b);
        a = new tn(a, d, e, f, h, k, g, b.C, b.v, m, n, p.Aa, p.La, p.he, p.Oh);
        M(r, a);
        Kj(r);
        return {
            Ga: r,
            Ng: p
        }
    };
    yn = function(a, b, c, d, e, f, g, h, k, l, m) {
        var n = window,
            p = {
                Rd: new vn
            },
            r = new Bj,
            w = new wn(a, n, e);
        M(r, w);
        a = new xn(a, n.document, c, d, b, g, e, f, h, k, w.output, l, m, p.Rd);
        M(r, a);
        Kj(r);
        return {
            Ga: r,
            Ng: p
        }
    };
    zn = function(a, b, c, d) {
        var e = _.af("DIV");
        e.id = b;
        e.name = b;
        b = e.style;
        b.border = "0pt none";
        c && (b.margin = "auto", b.textAlign = "center");
        d && (c = Array.isArray(d), b.width = c ? d[0] + "px" : "100%", b.height = c ? d[1] + "px" : "0%");
        a.appendChild(e);
        return e
    };
    An = function(a) {
        return "sticky" === (null == a ? void 0 : a.position) || "fixed" === (null == a ? void 0 : a.position)
    };
    Dn = function(a, b, c) {
        var d = new _.v.Map;
        a = _.z(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            var f = b[e.getDomId()];
            f = Bn(f, Cn, 28) ? _.Qh(f, Cn, 28) : _.Qh(c, Cn, 34);
            var g = void 0;
            d.set(e, (null == (g = f) ? 0 : null != Il(g, 1)) ? _.L(f, 1) ? 2 : 1 : 0)
        }
        return d
    };
    Gn = function(a, b, c) {
        var d, e, f = [],
            g = [];
        a = _.z(a);
        for (d = a.next(); !d.done; d = a.next())
            if (d = d.value, 1 === b.get(d)) f.push(null), g.push(null);
            else {
                var h = c,
                    k = xi(d);
                d = En((null == k ? void 0 : k.parentElement) && zi(k.parentElement, h) || null);
                if (!d || 1 === d[0] && 1 === d[3]) {
                    var l = e = d = void 0,
                        m = null != (l = null == k ? void 0 : k.parentElement) ? l : null;
                    l = null != (e = li(m)) ? e : new _.ki(0, 0);
                    Fn(l, m, h, 100);
                    e = null != (d = li(k)) ? d : new _.ki(0, 0);
                    Fn(e, k, h, 1); - 1 === l.height && (e.height = -1);
                    d = l;
                    d = d.width + "x" + d.height;
                    e = e.width + "x" + e.height
                } else e = d = "-1x-1";
                f.push(d);
                g.push(e)
            }
        return {
            cl: f,
            Ql: g
        }
    };
    Fn = function(a, b, c, d) {
        try {
            var e;
            if (!(e = !b)) {
                var f;
                if (!(f = !Hn(b, c, d))) {
                    a: {
                        do {
                            var g = zi(b, c);
                            if (g && "fixed" == g.position) {
                                var h = !1;
                                break a
                            }
                        } while (b = b.parentElement);h = !0
                    }
                    f = !h
                }
                e = f
            }
            e && (a.height = -1)
        } catch (k) {
            a.width = -1, a.height = -1
        }
    };
    Jn = function(a, b, c) {
        var d = 0 !== (0, _.In)(),
            e = Yh(!0, c, d).width,
            f = [],
            g = [],
            h = [];
        if (null !== c && c != c.top) {
            var k = Yh(!1, c).width;
            (-12245933 === e || -12245933 === k || k < e) && h.push(8)
        } - 12245933 !== e && (1.5 * e < c.document.documentElement.scrollWidth ? h.push(10) : d && 1.5 * c.outerWidth < e && h.push(10));
        a = _.z(a);
        for (d = a.next(); !d.done; d = a.next())
            if (k = d.value, 1 === b.get(k)) f.push(null), g.push(null);
            else {
                d = new Si;
                var l = xi(k);
                k = 0;
                var m = !1,
                    n = !1,
                    p = !1;
                if (l) {
                    for (var r = 0, w = l; w && 100 > r; r++, w = w.parentElement) {
                        var u = zi(w, c);
                        if (u) {
                            var y = u,
                                x = y.display,
                                C = y.overflowX;
                            if ("visible" !== y.overflowY && (d.set(2), (y = li(w)) && (k = k ? Math.min(k, y.width) : y.width), d.get(9))) break;
                            An(u) && d.set(9);
                            "none" === x && d.set(7);
                            "IFRAME" === w.nodeName && (u = parseInt(u.width, 10), u < e && (d.set(8), k = k ? Math.min(u, k) : u));
                            n || (n = "scroll" === C || "auto" === C);
                            m || (m = "flex" === x);
                            p || (p = "listbox" === w.role)
                        } else d.set(3)
                    }
                    if (!p) {
                        if (m = n && m) l = l.getBoundingClientRect().left, m = l > e || 0 > l;
                        p = m
                    }
                    p && d.set(11)
                } else d.set(1);
                l = _.z(h);
                for (m = l.next(); !m.done; m = l.next()) d.set(m.value);
                f.push(Ui(d));
                g.push(k)
            }
        return {
            pk: f,
            bl: g
        }
    };
    Pn = function(a, b, c, d, e) {
        if (null != b && b.size) {
            var f, g;
            e = null != (g = null != (f = null == e ? void 0 : e.adUnits) ? f : null == a ? void 0 : a.adUnits) ? g : [];
            a = _.z(e);
            g = a.next();
            for (f = {}; !g.done; f = {
                    df: f.df
                }, g = a.next()) {
                e = g.value;
                g = e.code;
                e = e.bids;
                var h = void 0;
                if (g && null != (h = e) && h.length && (g = kg(g, b), f.df = g / 1E6, !(0 >= g))) {
                    h = void 0;
                    e = _.z(null != (h = e) ? h : []);
                    var k = e.next();
                    for (h = {}; !k.done; h = {
                            Gb: h.Gb,
                            Yf: h.Yf
                        }, k = e.next()) k = k.value, h.Yf = "function" === typeof k.getFloor ? k.getFloor : void 0, h.Gb = Kn(Ln(Mn(new Nn, 4), g), c), k.getFloor = function(l, m) {
                        return function(n) {
                            4 === _.Ak(l.Gb, 1, 0) && Mn(l.Gb, 1);
                            var p, r = null == (p = l.Yf) ? void 0 : p.apply(this, [n]);
                            n = c ? r || {} : {
                                currency: "USD",
                                floor: m.df
                            };
                            return null != r && r.floor ? (null == r ? 0 : r.currency) && "USD" !== r.currency ? (1 === _.Ak(l.Gb, 1, 0) && (n = Ln(Mn(l.Gb, 6), 1E6 * r.floor), On(n, 3, r.currency)), r) : (r.floor || 0) > m.df ? (1 === _.Ak(l.Gb, 1, 0) && Ln(Mn(l.Gb, 5), 1E6 * r.floor), r) : n : n
                        }
                    }(h, f), d.set(k.getFloor, h.Gb)
                }
            }
        }
    };
    Qn = function(a, b) {
        var c = a.que,
            d = function() {
                var e;
                null == a || null == (e = a.requestBids) || e.before.call(b, function(f, g) {
                    return Am().pbjs_hooks.push({
                        context: b,
                        nextFunction: f,
                        requestBidsConfig: g
                    })
                }, 0)
            };
        (null == c ? 0 : c.hasOwnProperty("push")) ? null == c || c.push(d): null == c || c.unshift(d)
    };
    Sn = function(a, b) {
        return Kk(b, function() {
            return new Rn(a, b)
        })
    };
    ao = function(a, b, c, d, e) {
        var f = e.getBidResponsesForAdUnitCode;
        if (f) {
            var g, h, k, l = null != (k = null == (g = f(b.getDomId())) ? void 0 : g.bids) ? k : null == (h = f(b.getAdUnitPath())) ? void 0 : h.bids;
            if (null != l && l.length && (g = l.filter(function(p) {
                    var r = p.adId;
                    return p.auctionId !== c && d.some(function(w) {
                        return (_.F = _.bl(w, 2), _.A(_.F, "includes")).call(_.F, r)
                    })
                }), g.length)) {
                var m, n;
                f = null == (m = e.adUnits) ? void 0 : null == (n = _.A(m, "find").call(m, function(p) {
                    p = p.code;
                    return p === b.getAdUnitPath() || p === b.getDomId()
                })) ? void 0 : n.mediaTypes;
                m = _.z(g);
                for (n = m.next(); !n.done; n = m.next()) n = n.value, g = Tn(n, d, f), g = Un(a, Vn(xj(Wn(Xn(new Yn, n.bidder), 1), 6, !0), g)), Zn(n.bidder, e, g), "number" === typeof n.timeToRespond && $n(g, n.timeToRespond)
            }
        }
    };
    Zn = function(a, b, c) {
        for (var d = []; a && !_.A(d, "includes").call(d, a);) {
            d.unshift(a);
            var e = void 0,
                f = void 0;
            a = null == (e = b) ? void 0 : null == (f = e.aliasRegistry) ? void 0 : f[a]
        }
        _.Lh(c, 10, d)
    };
    eo = function(a, b, c) {
        null != bo(a, 3) || (c === b.getAdUnitPath() ? _.co(a, 3, 1) : c === b.getDomId() && _.co(a, 3, 2))
    };
    ho = function(a, b, c, d, e, f, g) {
        f = f.get(null != g ? g : function() {
            return null
        });
        1 !== (null == f ? void 0 : _.Ak(f, 1, 0)) && _.kh(b, 5, f);
        Bn(a, Nn, 5) || (f ? 1 === _.Ak(f, 1, 0) ? fo(a, f) : fo(a, Ln(Mn(Kn(new Nn, e), 1), kg(c, d, _.G(go)))) : fo(a, Mn(Kn(new Nn, e), kg(c, d, _.G(go)) ? 2 : 3)))
    };
    Tn = function(a, b, c) {
        var d = a.cpm,
            e = a.originalCpm,
            f = a.currency,
            g = a.originalCurrency,
            h = a.dealId,
            k = a.adserverTargeting,
            l = a.bidder,
            m = a.adUnitCode,
            n = a.adId,
            p = a.mediaType,
            r = a.height;
        a = a.width;
        var w = new io;
        "number" === typeof d && (_.qk(w, 2, Math.round(1E6 * d)), g && g !== f || (d = Math.round(1E6 * Number(e)), isNaN(d) || d === _.mf(w, 2) || _.qk(w, 8, d)));
        "string" === typeof f && On(w, 3, f);
        (_.F = ["string", "number"], _.A(_.F, "includes")).call(_.F, typeof h) && jo(w, ko(new lo, String(h)));
        if ("object" === typeof k)
            for (b = _.A(Object, "fromEntries").call(Object, b.map(function(x) {
                    return [_.sj(x, 1), _.bl(x, 2)]
                })), f = _.z(["", "_" + l]), h = f.next(); !h.done; h = f.next()) {
                h = h.value;
                d = [];
                e = _.z(_.A(Object, "entries").call(Object, k));
                for (g = e.next(); !g.done; g = e.next()) {
                    g = _.z(g.value);
                    var u = g.next().value;
                    g = g.next().value;
                    u = (u + h).slice(0, 20);
                    var y = void 0;
                    if (null != (y = b[u]) && y.length)
                        if (b[u][0] === String(g)) d.push(u);
                        else {
                            d = [];
                            break
                        }
                }
                mo(w, _.bl(w, 4).concat(d))
            }
        switch (p || "banner") {
            case "banner":
                _.co(w, 5, 1);
                break;
            case "native":
                _.co(w, 5, 2);
                Ri("hbyg_nat", function(x) {
                    Yi(x, "pub_url", document.URL);
                    Yi(x, "b", l);
                    Yi(x, "auc", null != m ? m : "");
                    Yi(x, "hmt", Number(!!c));
                    var C;
                    Yi(x, "hat", Number(!!(null == c ? 0 : null == (C = c.native) ? 0 : C.adTemplate)))
                }, _.Uf(no));
                break;
            case "video":
                _.co(w, 5, 3)
        }
        _.A(Number, "isFinite").call(Number, r) && _.A(Number, "isFinite").call(Number, a) && oo(w, po(qo(new ro, Math.round(a)), Math.round(r)));
        "string" === typeof n && On(w, 1, n);
        return w
    };
    so = function(a, b) {
        var c = new _.v.Map,
            d = function(k) {
                var l = c.get(k);
                l || (l = {}, c.set(k, l));
                return l
            },
            e = [];
        a = _.z(a);
        for (var f = a.next(); !f.done; f = a.next()) {
            f = f.value;
            var g = f.args,
                h = f.eventType;
            f = f.elapsedTime;
            "bidTimeout" === h && e.push.apply(e, _.ch(g));
            switch (h) {
                case "bidRequested":
                    if (g.auctionId !== b) continue;
                    if (!Array.isArray(g.bids)) continue;
                    g = _.z(g.bids);
                    for (h = g.next(); !h.done; h = g.next())
                        if (h = h.value.bidId) d(h).requestTime = f;
                    break;
                case "noBid":
                    g.auctionId === b && g.bidId && (d(g.bidId).Bl = f)
            }
        }
        d = new _.v.Map;
        a = _.z(_.A(c, "entries").call(c));
        for (f = a.next(); !f.done; f = a.next()) g = _.z(f.value), f = g.next().value, h = g.next().value, g = h.requestTime, h = h.Bl, g && h && d.set(f, {
            latency: h - g,
            Sh: !1
        });
        e = _.z(e);
        for (a = e.next(); !a.done; a = e.next())
            if (f = a.value, a = f.bidId, f = f.auctionId, a && f === b && (a = d.get(a))) a.Sh = !0;
        return d
    };
    to = function(a, b) {
        for (var c = new Si, d = 0; d < a.length; d++) c.set(a.length - d - 1, b(a[d]));
        return Ui(c)
    };
    wo = function(a, b, c) {
        c = void 0 === c ? {} : c;
        var d = void 0 === c.qd ? "" : c.qd;
        c = void 0 === c.Ba ? "," : c.Ba;
        if (_.G(uo)) return vo(a, b);
        var e = !1;
        a = a.map(function(f) {
            f = b(f);
            e || (e = !!f);
            return String(f || d)
        });
        return e ? a.join(c) : null
    };
    vo = function(a, b) {
        return a.map(function(c) {
            return b(c)
        })
    };
    yo = function(a, b, c, d, e, f, g) {
        if (f) {
            var h = {
                    Lg: new rn
                },
                k = new Bj;
            a = new xo(a, b, c, d, e, f, g, h);
            M(k, a);
            Kj(k);
            return {
                wj: h,
                Ga: k
            }
        }
    };
    Ao = function(a, b, c, d, e) {
        if (b && !(.01 < Math.random())) {
            var f = new Bj;
            M(f, new zo(a, c, b.Ub, d, e));
            Kj(f)
        }
    };
    Co = function(a, b) {
        var c;
        return !(null != (c = Bo(b, 22)) ? !c : !_.L(a, 15))
    };
    Eo = function(a) {
        var b;
        var c = new Do;
        c = _.hh(c, 2, a.pvsid);
        c = _.ih(c, 3, a.fb);
        c = _.ih(c, 6, a.Lf);
        var d = null != (b = a.An) ? b : _.Mg();
        b = _.hh(c, 1, d);
        c = _.If();
        b = _.be(b, 4, c, Kc);
        a.payload && (c = a.payload(), _.kh(b, 7, c));
        a.Cb && _.hh(b, 5, a.Cb);
        return b
    };
    Go = function(a, b, c, d) {
        for (var e = _.z(_.A(Object, "entries").call(Object, Fo)), f = e.next(); !f.done; f = e.next()) {
            var g = _.z(f.value);
            f = g.next().value;
            g = g.next().value;
            b & f && P(a, g(String(c), d))
        }
    };
    Mo = function(a, b, c) {
        a.Il && a.Qa.Hi(Eo(_.A(Object, "assign").call(Object, {}, a, {
            Cb: a.al,
            payload: function() {
                var d = new Ho;
                var e = d.D;
                var f = Gd(e),
                    g = de(e, f, Io),
                    h = Jo(d, Ko, 1);
                g && 1 !== g && Ld(e, f, g);
                e = _.Lo(h, 1, b);
                _.Lo(e, 2, c);
                return d
            }
        })))
    };
    Ro = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = (void 0 === b ? 0 : b) ? 604800 : -1;
        if (!(0 < b) || c && zf(c)) {
            c = c ? Af(c) : null;
            var d = !1,
                e = _.G(_.No);
            d = void 0 === d ? !1 : d;
            e = void 0 === e ? !1 : e;
            var f = 0;
            try {
                f |= a !== a.top ? 512 : 0;
                var g;
                if (!(g = !a.navigator)) {
                    var h = a.navigator;
                    g = "brave" in h && "isBrave" in h.brave || !1
                }
                f |= g || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
                f |= sg(a, 2500, e);
                e || (f |= tg(a));
                0 < b && (d ? c && Oo(c) || (f |= 4194304) : !_.Po(_.Qo(c, b)) && (f |= 134217728))
            } catch (k) {
                f |= 32
            }
            a = f
        } else a = 4194304;
        return a
    };
    So = function(a) {
        switch (a) {
            case 4:
                return 11;
            case 2:
                return 2;
            case 3:
                return 1;
            case 5:
                return 8;
            case 6:
                return 42;
            case 7:
                return 10;
            case 8:
                return 3;
            case 9:
                return 4
        }
    };
    Vo = function(a, b, c) {
        a = So(a);
        if (!a) return null;
        if (10 === a) return 0;
        var d = 0;
        if (!(_.F = [11, 10], _.A(_.F, "includes")).call(_.F, a)) {
            d |= b !== b.top ? 512 : 0;
            var e = _.ah(b);
            e = 26 !== a && 27 !== a && 40 !== a && 41 !== a && 10 !== a && e.adCount ? 1 == a || 2 == a ? !(!e.adCount[1] && !e.adCount[2]) : (e = e.adCount[a]) ? 1 <= e : !1 : !1;
            e && (d |= 64);
            if (d) return d
        }
        if (2 === a || 1 === a) {
            var f = {
                la: b,
                Me: _.To,
                eh: c ? a : void 0,
                im: _.G(_.Uo)
            };
            0 === (0, _.In)() && (f.Me = 3E3, f.ng = 650);
            d |= _.Ig(f)
        } else if (8 === a) d |= Ro(b);
        else if (3 === a || 4 === a) {
            e = a;
            e = void 0 === e ? null : e;
            c = b !== b.top ? 512 : 0;
            Bg(null == (f = b.navigator) ? void 0 : f.userAgent) && (c |= 1048576);
            f = b.innerWidth;
            1200 > f && (c |= 65536);
            var g = b.innerHeight;
            650 > g && (c |= 2097152);
            e && 0 === c && (e = 3 === e ? "left" : "right", (f = _.dh({
                la: b,
                Rh: !0,
                Gi: 1,
                position: e,
                ia: f,
                na: g,
                kc: new _.v.Set,
                minWidth: 120,
                minHeight: 500
            })) ? _.ah(b).sideRailPlasParam.set(e, f.width + "x" + f.height + "_" + String(e).charAt(0)) : c |= 16);
            d |= c
        } else 11 !== a && 42 !== a && (d |= 32);
        d || (b = _.ah(b), b.adCount = b.adCount || {}, b.adCount[a] = b.adCount[a] + 1 || 1);
        return d
    };
    Yo = function(a, b, c, d) {
        var e = d.vh,
            f = d.adUnitPath;
        d = void 0 === d.sb ? !1 : d.sb;
        return "string" === typeof f && f.length && (null == e || "string" === typeof e || "number" === typeof e && Wo(e)) ? Xo(a, b, f, c, {
            Nb: "string" === typeof e ? e : void 0,
            format: "number" === typeof e ? e : 1,
            sb: d
        }) : (b.error(Nk("googletag.defineOutOfPageSlot", [f, e])), null)
    };
    Wo = function(a) {
        switch (a) {
            case 6:
                return !0;
            case 7:
                return !0;
            default:
                return !!pn(nl, function(b) {
                    return b === a
                })
        }
    };
    Xo = function(a, b, c, d, e) {
        var f = e.format;
        b = d.add(a, b, c, [1, 1], {
            Nb: e.Nb,
            format: f,
            sb: e.sb
        });
        a = b.slotId;
        b = b.Da;
        a && b && (_.co(b, 15, f), _.mn(a, function() {
            var g = window,
                h = So(f);
            if (h) {
                g = _.ah(g);
                var k = g.adCount && g.adCount[h];
                k && (g.adCount[h] = k - 1)
            }
        }));
        return null != a ? a : null
    };
    $o = function(a, b, c, d, e, f, g, h) {
        var k = new Bj;
        a = new Zo(a, b, c, d, e, f, g, h);
        M(k, a);
        Kj(k);
        return k
    };
    ap = function(a, b) {
        var c;
        return !(null != (c = Bo(a, 11)) ? !c : !_.L(b, 10))
    };
    bp = function(a, b, c, d) {
        if (a = xi(a, b)) {
            var e;
            if (c = null != (e = Bo(c, 24)) ? e : _.L(d, 30)) c = a.getBoundingClientRect(), d = c.top, e = c.bottom, 0 === c.height ? c = !1 : (c = _.t.innerHeight, c = 0 < e && e < c || 0 < d && d < c);
            c || (a.style.display = "none")
        }
    };
    ep = function(a, b) {
        var c = b.L,
            d = b.P;
        b = b.V;
        a = _.z(a.W);
        for (var e = a.next(); !e.done; e = a.next())
            if (e = e.value, _.cp(c, e)) {
                var f = d,
                    g = f.Z;
                f = f.R[e.getDomId()];
                ap(f, g) && bp(e, b, f, g);
                dp(c, e);
                var h = void 0,
                    k = void 0;
                null != (h = null != (k = Bo(f, 10)) ? k : _.L(g, 11)) && h && bp(e, b, f, g)
            }
        return {}
    };
    fp = function(a, b, c, d) {
        P(a, Fl("googletag.setConfig.commerce", Gl(b), c, Gl(d)))
    };
    gp = function(a) {
        return "string" === typeof a && 0 < a.length && 5E3 > a.length
    };
    hp = function(a) {
        if (!Array.isArray(a) || 0 === a.length) return !1;
        var b = a.length - 1;
        return a.every(function(c) {
            if ("string" !== typeof c || 0 === c.length) return !1;
            b += c.length;
            return 5E3 < b ? !1 : !0
        })
    };
    jp = function(a, b, c) {
        var d = new Bj;
        a = new ip(a, b, c);
        M(d, a);
        Kj(d)
    };
    np = function(a, b, c) {
        var d = window,
            e = new Bj;
        d = new kp(d);
        _.S(e, d);
        c = new lp(a, d, c, _.ci(150));
        M(e, c);
        a = new mp(a, d, b, c.Kc);
        M(e, a);
        Kj(e);
        return {
            Kc: c.Kc,
            Eh: a.l,
            Ga: e
        }
    };
    op = function(a) {
        if (61440 >= a.length) return {
            url: a,
            bh: 0
        };
        var b = a;
        61440 < b.length && (b = b.substring(0, 61432), b = b.replace(/%\w?$/, ""), b = b.replace(/&[^=]*=?$/, ""), b += "&trunc=1");
        return {
            url: b,
            bh: a.length - b.length + 8
        }
    };
    pp = function(a, b) {
        b = void 0 === b ? window : b;
        return b.location ? b.URLSearchParams ? (a = (new URLSearchParams(b.location.search)).get(a), (null == a ? 0 : a.length) ? a : null) : (a = (new RegExp("[?&]" + a + "=([^&]*)")).exec(b.location.search)) ? decodeURIComponent(a[1]) : null : null
    };
    qp = function(a, b) {
        b = void 0 === b ? window : b;
        return !!pp(a, b)
    };
    tp = function(a, b) {
        var c = "";
        if (a) c = "_fy2012";
        else {
            if (a = b && 2012 < b) a = !_.rp("script[nonce]");
            if (a) {
                var d = new _.Oe(sp[0], Pe);
                try {
                    var e = window,
                        f = _.eb(d);
                    e.eval(f) === f && e.eval(f.toString());
                    a = !0
                } catch (g) {
                    a = !1
                }
            }
            a && (c = "_fy" + b)
        }
        return c
    };
    up = function(a) {
        var b, c;
        return null != (c = null == (b = _.A(a, "find").call(a, function(d) {
            return "page_url" === _.sj(d, 1)
        })) ? void 0 : _.bl(b, 2)[0]) ? c : null
    };
    vp = function(a) {
        var b = a.indexOf("google_preview=", a.lastIndexOf("?")),
            c = a.indexOf("&", b); - 1 === c && (c = a.length - 1, --b);
        return a.substring(0, b) + a.substring(c + 1, a.length)
    };
    wp = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Ek(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    xp = function(a, b) {
        var c = b.R;
        return !!up(b.Z.Na()) || a.some(function(d) {
            return null !== up(c[d.getDomId()].Na())
        })
    };
    zp = function() {
        var a = void 0 === a ? window : a;
        yp = _.Mg(a)
    };
    Ap = function(a, b) {
        var c = _.af("DIV");
        c.id = a;
        c.textContent = b;
        _.Ki(c, {
            height: "24px",
            "line-height": "24px",
            "text-align": "center",
            "vertical-align": "middle",
            color: "white",
            "background-color": "black",
            margin: "0",
            "font-family": "Roboto",
            "font-style": "normal",
            "font-weight": "500",
            "font-size": "11px",
            "letter-spacing": "0.08em"
        });
        return c
    };
    Bp = function(a, b) {
        if ("undefined" !== typeof IntersectionObserver) return new IntersectionObserver(b, {
            rootMargin: a + "%"
        })
    };
    Fp = function(a, b, c, d, e) {
        var f = void 0 === f ? _.v.globalThis.IntersectionObserver : f;
        if (!b) return {
            gg: e
        };
        var g = null != Cp(b, 1) ? null != Dp(b) && 0 !== (0, _.In)() ? Cp(b, 1) * Dp(b) : Cp(b, 1) : null;
        if (null == g) return {
            gg: e
        };
        b = new Bj;
        a = new Ep(a, d, c, g, e, f);
        M(b, a);
        Kj(b);
        return {
            gg: a.output,
            Rk: b
        }
    };
    Pp = function(a, b, c, d, e) {
        var f = window,
            g = new Bj,
            h = M(g, new Gp(a, b, Hp, function(m) {
                return Ip("i-adframe-load", m.detail.data)
            })),
            k = M(g, new Gp(a, b, Hp, function(m) {
                return Ip("i-dismiss", m.detail.data)
            }));
        h = 0 < _.Uf(Jp) ? M(g, new Kp(a, h.output, void 0)).output : h.output;
        h = M(g, new Lp(a, b, c, h));
        M(g, new Mp(a, f, d, e, h.output));
        if (f.top === f) var l = M(g, new Np(a, f, h.output)).output;
        M(g, new Op(a, b, c, h.output, k.output, l));
        return g
    };
    Ip = function(a, b) {
        try {
            var c = JSON.parse(b);
            return "sth" === c.googMsgType && c.msg_type === a
        } catch (d) {}
        return !1
    };
    Rp = function(a, b, c) {
        return new Qp(c, a, Hp, function(d) {
            d = d.detail.data;
            try {
                var e = JSON.parse(d);
                if ("rewarded" === e.type && e.message === b) return e
            } catch (f) {}
            return null
        })
    };
    Sp = function(a, b) {
        if ("object" === typeof a && a.hasOwnProperty("taxonomies")) return !0;
        P(b, Nk("googletag.setConfig.pps", [a]));
        return !1
    };
    Yp = function(a, b, c, d) {
        if (null === a) _.G(Tp) ? Up("taxonomies", a, c, d) : _.ni(b, 1);
        else if (Vp(a, c, d)) {
            d = _.z(_.A(Object, "entries").call(Object, a));
            for (var e = d.next(); !e.done; e = d.next()) {
                e = _.z(e.value);
                var f = e.next().value;
                e = e.next().value;
                a: {
                    var g = b,
                        h = c,
                        k = a;
                    if (void 0 === f || null === f) Up("taxonomy", f, h, k);
                    else {
                        var l = Number(f);
                        var m = l,
                            n = h,
                            p = k;
                        (_.F = _.A(Object, "values").call(Object, pl), _.A(_.F, "includes")).call(_.F, Number(m)) ? f = !0 : (Up("taxonomy", f, n, p), f = !1);
                        if (f) {
                            if (_.G(Tp)) {
                                if (null == e) {
                                    Up("taxonomyData", e, h, k);
                                    break a
                                }
                            } else {
                                if (void 0 === e) break a;
                                if (null === e) {
                                    Wp(l, g);
                                    break a
                                }
                            }
                            f = h;
                            m = k;
                            "object" === typeof e && e.hasOwnProperty("values") ? f = !0 : (Up("taxonomyData", e, f, m), f = !1);
                            f && Xp(l, e, g, h, k)
                        }
                    }
                }
            }
        }
    };
    Vp = function(a, b, c) {
        if ("object" === typeof a && null !== a && _.A(Object, "keys").call(Object, a).some(function(d) {
                return (_.F = _.A(Object, "values").call(Object, Zp), _.A(_.F, "includes")).call(_.F, Number(d))
            })) return !0;
        Up("taxonomies", a, b, c);
        return !1
    };
    Wp = function(a, b) {
        var c = Uh(b, aq, 1).filter(function(d) {
            return _.Ak(d, 1, 0) !== a
        });
        _.gl(b, 1, c)
    };
    Xp = function(a, b, c, d, e) {
        if (_.G(Tp)) {
            if (null == _.A(b, "values")) {
                Up("taxonomyData.values", _.A(b, "values"), d, e);
                return
            }
        } else {
            if (void 0 === _.A(b, "values")) return;
            if (null === _.A(b, "values")) {
                Wp(a, c);
                return
            }
        }
        bq(_.A(b, "values"), d, b) && (e = cq(a, _.A(b, "values"), d, b), e.size && (b = (_.F = Uh(c, aq, 1), _.A(_.F, "find")).call(_.F, function(f) {
            return _.Ak(f, 1, 0) === a
        }), e = [].concat(_.ch(e)), b ? dq(b, e) : eq(c, dq(fq(new aq, a), e)), d.info(gq(Gl(e), Gl(a)))))
    };
    bq = function(a, b, c) {
        if (Array.isArray(a)) return !0;
        Up("taxonomyData.values", a, b, c);
        return !1
    };
    cq = function(a, b, c, d) {
        if (_.G(Tp) && !vf(Kh)(b)) return Up("taxonomyData.values", b, c, d), new _.v.Set;
        var e = new _.v.Set,
            f = [],
            g = !1;
        b = _.z(b);
        for (var h = b.next(); !h.done; h = b.next()) h = h.value, _.G(Tp) || "string" === typeof h ? 10 <= e.size ? g = !0 : e.add(h) : f.push(h);
        0 < f.length && Up("taxonomyData.values", f, c, d);
        g && P(c, hq(Gl(a), Gl(10)));
        return e
    };
    Up = function(a, b, c, d) {
        P(c, Fl("googletag.setConfig.pps", Gl(d), a, Gl(b)))
    };
    kq = function(a, b) {
        if (3 === _.iq(b)) {
            var c = {
                    Md: new vn
                },
                d = new Bj;
            M(d, new jq(a, b, c.Md));
            Kj(d);
            return {
                Ga: d,
                ml: c
            }
        }
    };
    mq = function(a, b, c, d, e, f) {
        if (b) {
            var g = {
                    Bg: new rn
                },
                h = new Bj;
            M(h, new lq(a, b, c, g, d, e, f));
            Kj(h);
            return {
                Ga: h,
                ef: g
            }
        }
    };
    nq = function(a) {
        var b = function() {
            return a.Reflect.construct(a.HTMLElement, [], this.constructor)
        };
        b.prototype = a.HTMLElement.prototype;
        b.prototype.constructor = b;
        _.A(Object, "setPrototypeOf").call(Object, b, a.HTMLElement);
        return b
    };
    pq = function(a, b) {
        var c = _.Uf(oq);
        Math.random() <= c && nj(b, a)
    };
    vq = function(a, b, c) {
        var d = {};
        if (!c) return b.error(qq("missing data-rendering attribute")), d;
        try {
            var e = rq(sq(c))
        } catch (k) {}
        var f;
        (null == (f = e) ? 0 : Bn(f, tq, 1)) ? (b = _.H(new uq, 4, 1), b = _.H(b, 2, 7), a = _.ih(b, 3, a.zb || a.fb), b = _.Qh(e, tq, 1), a = _.kh(a, 5, b), a = _.oh(a, 6, !0), d.Rl = a) : b.error(qq("invalid data-rendering attribute"));
        var g;
        d.zl = null == (g = e) ? void 0 : _.R(g, 2);
        var h;
        d.Af = null == (h = e) ? void 0 : _.R(h, 3);
        return d
    };
    yq = function(a, b) {
        var c = cn(b, "ai");
        if (!c || 0 === c.length) return _.v.Promise.resolve(b);
        var d = wq();
        if (null == d ? 0 : d.gmaSdk) {
            if (c = d.gmaSdk.getClickSignalsWithTimeout ? d.gmaSdk.getClickSignalsWithTimeout(c, 200) : d.gmaSdk.getClickSignals(c)) return _.v.Promise.resolve(b.replace("?", "?ms=" + encodeURIComponent(c) + "&"))
        } else {
            var e, f;
            if (null == d ? 0 : null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaClickSignals) {
                e = new _.cg;
                var g = e.resolve;
                e = e.promise;
                xq(d.webkit.messageHandlers.getGmaClickSignals, {
                    click_string: c
                }, function(h) {
                    g(b.replace("?", "?" + h + "&"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return yh(a, h, k)
                });
                return e
            }
        }
        return _.v.Promise.resolve(b)
    };
    Aq = function(a, b, c, d) {
        var e, f, g;
        return _.kb(function(h) {
            e = b.getBoundingClientRect();
            f = {};
            g = d.replace("?", _.zq("", (f.nx = Math.floor(c.clientX - e.x), f.ny = Math.floor(c.clientY - e.y), f.dim = Math.floor(e.width) + "x" + Math.floor(e.height), f)) + "&");
            return h.return(yq(a, g))
        })
    };
    Bq = function(a, b, c) {
        var d;
        if (null == c ? 0 : null == (d = c.gmaSdk) ? 0 : d.getViewSignals) {
            if (c = c.gmaSdk.getViewSignals()) return c = b.replace(/^(.*?)(&adurl=)?$/, "$1&ms=" + c + "$2"), _.v.Promise.resolve(c)
        } else {
            var e, f;
            if (null == c ? 0 : null == (e = c.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals) {
                d = new _.cg;
                var g = d.resolve;
                d = d.promise;
                xq(c.webkit.messageHandlers.getGmaViewSignals, {}, function(h) {
                    g(b.replace(/^(.*?)(&adurl=)?$/, "$1&" + h + "$2"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return yh(a, h, k)
                });
                return d
            }
        }
        return _.v.Promise.resolve(b)
    };
    Gq = function(a, b) {
        var c = window;
        var d = void 0 === d ? sb : d;
        var e;
        if (c.customElements && null != (e = c.Reflect) && e.construct && !c.customElements.get("google-product-ad")) {
            var f = wq(),
                g;
            null == (g = f ? new Cq(function(k, l) {
                return yh(a, k, l)
            }, function() {}) : void 0) || g.oa();
            var h = nq(c);
            e = function() {
                return h.apply(this, arguments) || this
            };
            _.T(e, h);
            e.prototype.connectedCallback = function() {
                var k = vq(a, b, this.dataset.rendering),
                    l = k.Rl,
                    m = k.zl;
                k = k.Af;
                l && d(Dq(window, l));
                m && Bq(a, m, f).then(function(n) {
                    return void Eq(n)
                });
                k && ("true" === this.getAttribute("data-enable-click") || this.querySelector('[data-enable-click="true"]') ? (this.Af = k, this.addEventListener("click", this.j)) : P(b, Fq(k)))
            };
            e.prototype.j = function(k) {
                var l = k.target instanceof c.HTMLElement ? k.target.closest("[data-enable-click]") : void 0;
                l instanceof c.HTMLElement && "true" === l.getAttribute("data-enable-click") && Aq(a, this, k, this.Af).then(function(m) {
                    return void Eq(m)
                })
            };
            c.customElements.define("google-product-ad", e)
        }
    };
    Iq = function(a) {
        Hq = a
    };
    Kq = function(a, b, c, d) {
        Rj(b, d, function(e, f) {
            Ch(a, e, f);
            var g, h;
            null == (h = (g = window.console).error) || h.call(g, f)
        }, function() {
            return void P(c, Jq())
        })
    };
    Nq = function(a, b, c, d, e, f) {
        var g = window,
            h = new Bj;
        b = 8 === b ? 3 : 4;
        c = new Lq(a, c);
        M(h, c);
        M(h, new Mq(a, g, b, c.output, d, e, f));
        Kj(h);
        return h
    };
    ra = function(a, b) {
        a: {
            b = b[0];a = a[0];
            for (var c = _.oa, d = Math.min(b.length, a.length), e = 0; e < d; e++) {
                var f = c(b[e], a[e]);
                if (0 != f) {
                    b = f;
                    break a
                }
            }
            b = _.oa(b.length, a.length)
        }
        return b
    };
    Oq = function(a) {
        return Array.isArray(a) && 2 === a.length && "number" === typeof a[0] && _.A(a, "includes").call(a, 0)
    };
    Pq = function(a) {
        if (Oq(a)) return {
            size: [],
            Fg: !0
        };
        if (Array.isArray(a) && 0 < a.length && "number" !== typeof a[0]) {
            var b = !1;
            a = a.filter(function(c) {
                c = Oq(c);
                b = b || c;
                return !c
            });
            return {
                size: a,
                Fg: b
            }
        }
        return {
            size: a,
            Fg: !1
        }
    };
    Rq = function(a, b) {
        var c = b.R;
        return wo(a, function(d) {
            return Qq(c[d.getDomId()]).join("&")
        }, {
            Ba: "|"
        })
    };
    Qq = function(a) {
        a = Sq(a);
        var b = [];
        _.El(a, function(c, d) {
            c.length && (c = c.map(encodeURIComponent), d = encodeURIComponent(d), b.push(d + "=" + c.join()))
        });
        return b
    };
    Sq = function(a) {
        for (var b = {}, c = _.z(Vk(a)), d = c.next(); !d.done; d = c.next()) d = d.value, b[_.R(d, 1)] = _.bl(d, 2);
        a = _.bl(a, 8);
        a.length && (null != b.excl_cat || (b.excl_cat = a));
        return b
    };
    Tq = function(a) {
        var b = !1,
            c = Uh(a, Yk, 2).map(function(d) {
                var e = _.R(d, 1);
                b = "excl_cat" === e;
                d = _.bl(d, 2);
                return encodeURIComponent(e) + "=" + encodeURIComponent(d.join())
            });
        a = _.bl(a, 3);
        !b && a.length && c.push(encodeURIComponent("excl_cat") + "=" + encodeURIComponent(a.join()));
        return c
    };
    Vq = function(a, b, c, d) {
        if (c) {
            var e = {
                    Xd: new rn,
                    Yd: new rn,
                    Zc: new rn
                },
                f = new Bj;
            M(f, new Uq(a, b, c, d, e));
            Kj(f);
            return {
                Ga: f,
                Xl: e
            }
        }
    };
    Xq = function(a, b, c) {
        var d = window;
        if (_.G(lk) && b) {
            var e = new Bj;
            M(e, new Wq(a, d, b, c));
            Kj(e);
            return e
        }
    };
    Yq = function(a) {
        return "gads_privacy_sandbox_td_buyerlist__" + a
    };
    $q = function(a, b) {
        return a.filter(function(c) {
            return Zq(c, 2) > b
        })
    };
    br = function(a, b) {
        a = new _.v.Map(a.map(function(e) {
            return [_.R(e, 1), e]
        }));
        b = _.z(b);
        for (var c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = a.get(_.R(c, 1));
            d ? ar(d, Math.max(Zq(c, 2), Zq(d, 2))) : a.set(_.R(c, 1), c)
        }
        return _.A(Array, "from").call(Array, _.A(a, "values").call(a))
    };
    fr = function(a, b, c) {
        var d = Date.now();
        if (cr(a, b, c)) return new _.v.Map;
        b = new _.v.Map(_.A(Object, "entries").call(Object, a).filter(function(k) {
            var l = _.z(k);
            k = l.next().value;
            l = l.next().value;
            return _.A(k, "startsWith").call(k, "gads_privacy_sandbox_td_buyerlist__") && l
        }).map(function(k) {
            var l = _.z(k);
            k = l.next().value;
            l = l.next().value;
            return [k, dr(l)]
        }));
        c = _.z(b);
        for (var e = c.next(); !e.done; e = c.next()) {
            var f = _.z(e.value);
            e = f.next().value;
            f = f.next().value;
            var g = Uh(f, er, 1),
                h = $q(g, d);
            0 === h.length ? (b.delete(e), a.removeItem(e)) : h.length < g.length && (_.gl(f, 1, h), a.setItem(e, tk(f)))
        }
        return b
    };
    cr = function(a, b, c) {
        if (!_.L(b, 3)) return !1;
        b = String(_.Rf(c + "-" + _.R(b, 2) + _.R(b, 4) + _.L(b, 3)));
        if (a.getItem("gads_privacy_sandbox_tcf_hash") === b) return !1;
        c = _.z(_.A(Object, "keys").call(Object, a).filter(function(e) {
            return _.A(e, "startsWith").call(e, "gads_privacy_sandbox_td_buyerlist__")
        }));
        for (var d = c.next(); !d.done; d = c.next()) a.removeItem(d.value);
        a.setItem("gads_privacy_sandbox_tcf_hash", b);
        return !0
    };
    gr = function(a) {
        return (_.F = ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"], _.A(_.F, "includes")).call(_.F, a)
    };
    hr = function(a) {
        return (_.F = ["https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"], _.A(_.F, "includes")).call(_.F, a)
    };
    jr = function(a, b, c, d) {
        if (b) {
            var e = b.Sb,
                f = b.wl;
            if (b.Qg && 4 === e) {
                b = new rn;
                e = new rn;
                if (!f) return b.F({
                    kind: 1,
                    reason: 1
                }), e.F(!1), {
                    Ri: {
                        yi: b,
                        Lh: e
                    }
                };
                f = new Bj;
                a = new ir(a, c, d, b, e);
                M(f, a);
                Kj(f);
                return {
                    Ri: {
                        yi: b,
                        Lh: e
                    },
                    cm: f
                }
            }
        }
    };
    kr = function(a) {
        var b = a.Hf,
            c = a.Db,
            d = void 0 === a.gh ? [] : a.gh,
            e = a.interestGroupBuyers;
        a = a.Hc;
        var f = {};
        void 0 !== a && (f["https://googleads.g.doubleclick.net"] = a, f["https://td.doubleclick.net"] = a);
        e = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            trustedScoringSignalsUrl: "https://securepubads.g.doubleclick.net/td/sts",
            interestGroupBuyers: null != e ? e : ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"],
            sellerExperimentGroupId: a,
            auctionSignals: b.auctionSignals.promise,
            sellerSignals: b.j.promise,
            sellerTimeout: 50,
            sellerCurrency: "USD",
            perBuyerCurrencies: b.perBuyerCurrencies.promise,
            perBuyerExperimentGroupIds: f,
            perBuyerSignals: b.perBuyerSignals.promise,
            perBuyerTimeouts: b.perBuyerTimeouts.promise,
            perBuyerCumulativeTimeouts: b.perBuyerCumulativeTimeouts.promise
        };
        e.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        c = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            interestGroupBuyers: [],
            auctionSignals: {},
            sellerExperimentGroupId: a,
            sellerSignals: b.topLevelSellerSignals.promise,
            sellerTimeout: 50,
            signal: c.signal,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: {},
            perBuyerTimeouts: {},
            perBuyerCumulativeTimeouts: {},
            componentAuctions: [e].concat(_.ch(d)),
            resolveToConfig: b.resolveToConfig.promise
        };
        c.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        return c
    };
    lr = function(a, b) {
        b = b.Hf;
        b.topLevelSellerSignals.resolve(a.sellerSignals);
        b.directFromSellerSignals.resolve(a.directFromSellerSignals);
        b.directFromSellerSignalsHeaderAdSlot.resolve(a.directFromSellerSignalsHeaderAdSlot);
        b.resolveToConfig.resolve(!!a.resolveToConfig);
        var c;
        if (a = null == (c = a.componentAuctions) ? void 0 : _.A(c, "find").call(c, function(g) {
                return hr(g.seller)
            })) {
            b.auctionSignals.resolve(a.auctionSignals);
            b.j.resolve(a.sellerSignals);
            b.perBuyerSignals.resolve(a.perBuyerSignals);
            var d;
            b.perBuyerTimeouts.resolve(null != (d = a.perBuyerTimeouts) ? d : {});
            var e;
            b.perBuyerCumulativeTimeouts.resolve(null != (e = a.perBuyerCumulativeTimeouts) ? e : {});
            var f;
            b.perBuyerCurrencies.resolve(null != (f = a.perBuyerCurrencies) ? f : {})
        } else b.auctionSignals.resolve(void 0), b.j.resolve(void 0), b.perBuyerSignals.resolve({}), b.perBuyerTimeouts.resolve({}), b.perBuyerCumulativeTimeouts.resolve({}), b.perBuyerCurrencies.resolve({})
    };
    mr = function(a) {
        var b = Date.now() + 864E5;
        return a.map(function(c) {
            var d = new er;
            c = _.ih(d, 1, c);
            return ar(c, b)
        })
    };
    nr = function(a, b, c) {
        var d = "https://googleads.g.doubleclick.net/td/auctionwinner?status=nowinner",
            e = _.L(c, 18),
            f = _.L(c, 7);
        if (f || e) d += "&isContextualWinner=1";
        f && (d += "&hasXfpAds=1");
        e = c.getEscapedQemQueryId();
        f = _.R(c, 6);
        e && (d += "&winner_qid=" + encodeURIComponent(e));
        f && (d += "&xfpQid=" + encodeURIComponent(f));
        _.L(c, 4) && (d += "&is_plog=1");
        (e = _.R(c, 11)) && (d += "&ecrs=" + e);
        (null == c ? 0 : _.L(c, 21)) || (d += "&turtlexTest=1");
        d += "&applied_timeout_ms=" + (b + "&duration_ms=" + Math.round(a));
        Eq(d)
    };
    or = function(a, b, c, d, e) {
        a.Hb.F(e);
        a.Aa.F(c);
        a.La.F(d);
        null == b || b.F(!1)
    };
    wr = function(a, b) {
        var c, d, e, f, g, h, k, l, m, n, p, r, w, u;
        return _.kb(function(y) {
            if (1 == y.j) return ("string" !== typeof a || _.A(a, "startsWith").call(a, "urn:")) && pr.deprecatedURNToURL && pr.deprecatedReplaceInURN ? y.yield(pr.deprecatedURNToURL(a), 2) : y.return();
            c = y.o;
            d = {};
            e = b.gdprApplies || "";
            (null != (f = c.match(qr)) ? f : []).forEach(function(x) {
                d[x] = e
            });
            g = b.wk || "";
            (null != (h = c.match(rr)) ? h : []).forEach(function(x) {
                d[x] = g
            });
            k = b.sj || "";
            (null != (l = c.match(sr)) ? l : []).forEach(function(x) {
                d[x] = k
            });
            m = b.pj || "";
            (null != (n = c.match(tr)) ? n : []).forEach(function(x) {
                d[x] = m
            });
            p = b.nj || "";
            (null != (r = c.match(ur)) ? r : []).forEach(function(x) {
                d[x] = p
            });
            w = b.yl || "";
            (null != (u = c.match(vr)) ? u : []).forEach(function(x) {
                d[x] = w
            });
            return y.yield(pr.deprecatedReplaceInURN(a, d), 0)
        })
    };
    xr = function(a, b, c, d, e, f, g, h) {
        var k = 3 === b,
            l = 2 === b,
            m = 1 === b,
            n = f.getEscapedQemQueryId(),
            p = _.R(f, 6);
        Ri("run_ad_auction_stats", function(r) {
            Xi(r, a);
            Yi(r, "duration_ms", c);
            Yi(r, "applied_timeout_ms", d);
            Yi(r, "timed_out", l ? 1 : 0);
            Yi(r, "error", k ? 1 : 0);
            Yi(r, "auction_skipped", m ? 1 : 0);
            Yi(r, "auction_winner", h ? 1 : 0);
            Yi(r, "thread_release_only", _.L(f, 15) ? 1 : 0);
            Yi(r, "winner_qid", null != n ? n : "");
            Yi(r, "xfpQid", null != p ? p : "");
            Yi(r, "publisher_tag", "gpt");
            e && Yi(r, "parallel", "1");
            0 < g && Yi(r, "nc", g)
        }, 1)
    };
    yr = function(a, b, c, d, e) {
        var f = e.getEscapedQemQueryId(),
            g = _.R(e, 6);
        Ri("run_ad_auction_complete", function(h) {
            Xi(h, a);
            Yi(h, "duration_ms", Math.round(d));
            Yi(h, "applied_timeout_ms", c);
            Yi(h, "auction_has_winner", b);
            f && Yi(h, "winner_qid", f);
            g && Yi(h, "xfpQid", g)
        }, 1)
    };
    zr = function(a, b) {
        var c = b.getEscapedQemQueryId(),
            d = _.R(b, 6);
        Ri("pre_run_ad_auction_ping", function(e) {
            Xi(e, a);
            Yi(e, "winner_qid", null != c ? c : "");
            Yi(e, "xfpQid", null != d ? d : "");
            Yi(e, "publisher_tag", "gpt")
        }, 1)
    };
    Fr = function(a, b, c, d) {
        var e = xi(a, document);
        e && og(e, window, d, !0);
        Ar(_.Ff(Ah), "5", Br(c.R[a.getDomId()], 20));
        Cr(a, Dr, 801, {
            nh: null,
            isBackfill: !1
        });
        if (_.cp(b, a) && !Gi(a, document)) {
            b = c.Z;
            c = c.R[a.getDomId()];
            var f;
            (null != (f = Bo(c, 10)) ? f : _.L(b, 11)) && bp(a, document, c, b)
        }
        Cr(a, Er, 825, {
            isEmpty: !0
        })
    };
    Ir = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y) {
        if (Nf(window.isSecureContext, window.navigator, window.document) && !_.G(Gr) && u) {
            u = {
                Rd: new vn,
                Aa: new rn,
                La: new rn,
                Lc: new rn
            };
            var x = new Bj;
            M(x, new Hr(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y));
            Kj(x);
            return {
                Ga: x,
                dm: u
            }
        }
    };
    Kr = function(a, b, c, d, e, f, g, h) {
        if (b) {
            var k = b.Sb;
            if (b.Qg && 0 !== k) return b = new Bj, a = new Jr(a, k, c, d, e, f, g, h), M(b, a), Kj(b), {
                bm: a.l,
                am: b
            }
        }
    };
    Lr = function() {
        for (var a = _.z(_.A(Array, "from").call(Array, document.getElementsByTagName("script"))), b = a.next(); !b.done; b = a.next()) {
            var c = b = b.value,
                d = b.src;
            d && (_.Ia(d, "/tag/js/gpt.js") || _.Ia(d, "/tag/js/gpt_mobile.js")) && !c.googletag_executed && b.textContent && (c.googletag_executed = !0, c = document.createElement("script"), fb(c, new _.Oe(b.textContent, Pe)), document.head.appendChild(c), document.head.removeChild(c))
        }
    };
    Mr = function(a, b) {
        b = _.z(_.A(Object, "entries").call(Object, b));
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = _.z(c.value);
            c = d.next().value;
            d = d.next().value;
            a.hasOwnProperty(c) || (a[c] = d)
        }
    };
    Pr = function(a, b, c) {
        var d = [];
        c = [].concat(_.ch(c.W)).slice();
        if (b) {
            if (!Array.isArray(b)) return P(a, Nk("googletag.destroySlots", [b])), !1;
            la(b);
            d = c.filter(function(e) {
                return _.A(b, "includes").call(b, e.j)
            })
        } else d = c;
        if (!d.length) return !1;
        Nr(d);
        Or(d);
        return !0
    };
    os = function(a, b, c, d, e, f, g, h, k, l) {
        var m = Am(),
            n, p, r = K(a, 74, function(u, y, x) {
                return e.defineSlot(a, b, u, y, x)
            }),
            w = {};
        r = (w._loaded_ = !0, w.cmd = [], w._vars_ = m._vars_, w.evalScripts = function() {
            try {
                Lr()
            } catch (x) {
                Ch(a, 297, x);
                var u, y;
                null == (u = window.console) || null == (y = u.error) || y.call(u, x)
            }
        }, w.display = K(a, 95, function(u) {
            void Qr(c, u, e)
        }), w.defineOutOfPageSlot = K(a, 73, function(u, y) {
            return (u = Yo(a, b, e, {
                vh: y,
                adUnitPath: u
            })) ? u.j : null
        }), w.getVersion = K(a, 946, function() {
            return a.wc ? String(a.wc) : a.fb
        }), w.pubads = K(a, 947, function() {
            return km(a, b, c, e, h)
        }), w.companionAds = K(a, 816, function() {
            null != n || (n = new Rr(a, b, c, f));
            return Qk(a, b, n)
        }), w.content = K(a, 817, function() {
            null != p || (p = new Sr(a, b, g));
            return Sk(a, b, p)
        }), w.setAdIframeTitle = K(a, 729, Iq), w.getEventLog = K(a, 945, function() {
            return new Tr(a, b)
        }), w.sizeMapping = K(a, 90, function() {
            return new Ur(a, b)
        }), w.enableServices = K(a, 91, function() {
            for (var u = _.z(Vr), y = u.next(); !y.done; y = u.next()) y = y.value, y.enabled && b.info(Wr()), Xr(y)
        }), w.destroySlots = K(a, 75, function(u) {
            return Pr(b, u, e)
        }), w.enums = ql(), w.defineSlot = r, w.defineUnit = r, w.getWindowsThatCanCommunicateWithHostpageLibrary = K(a, 955, function(u) {
            return Yr(k, u).map(function(y) {
                var x;
                return null == (x = Gi(y, document)) ? void 0 : x.contentWindow
            }).filter(function(y) {
                return !!y
            })
        }), w.disablePublisherConsole = K(a, 93, dn), w.onPubConsoleJsLoad = K(a, 731, gn), w.openConsole = K(a, 732, function(u) {
            Zm = !0;
            var y;
            (null == (y = Am()) ? 0 : y.console) ? Am().console.openConsole(u): (u && (fn = u), en = !0, Vm(a))
        }), w.setConfig = K(a, 1034, function(u) {
            if (tf(u)) {
                var y = u.commerce,
                    x = u.pps;
                if (null === y) y = Jo(d, hs, 33), _.ni(y, 1);
                else if (void 0 !== y) {
                    var C = Jo(d, hs, 33);
                    if (_.ja(y)) {
                        var I = y.query,
                            D = y.categories,
                            J = y.productIds,
                            Q = y.filter,
                            N = _.Jd(is(C, js, 1));
                        null === I ? _.ni(N, 1) : gp(I) ? On(N, 1, I) : void 0 !== I && fp(b, y, "query", I);
                        null === D ? _.ni(N, 2) : hp(D) ? _.Lh(N, 2, D) : void 0 !== D && fp(b, y, "categories", D);
                        null === J ? _.ni(N, 3) : hp(J) ? _.Lh(N, 3, J) : void 0 !== J && fp(b, y, "productIds", J);
                        null === Q ? _.ni(N, 4) : gp(Q) ? On(N, 4, Q) : void 0 !== Q && fp(b, y, "filter", Q);
                        null != _.sj(N, 1) || _.bl(N, 2).length ? _.kh(C, 1, N) : P(b, ks())
                    } else P(b, Nk("googletag.setConfig.commerce", [y]))
                }
                _.G(Tp) ? _.A(Object, "hasOwn").call(Object, u, "pps") && (x = u.pps, null === x ? (x = Jo(d, hs, 33), _.ni(x, 2)) : (y = Jo(Jo(d, hs, 33), ls, 2), _.G(Tp) && _.ni(y, 1), Sp(x, b) && Yp(x.taxonomies, y, b, x))) : null === x ? (x = Jo(d, hs, 33), _.ni(x, 2)) : void 0 !== x && (y = Jo(Jo(d, hs, 33), ls, 2), _.G(Tp) && _.ni(y, 1), Sp(x, b) && Yp(x.taxonomies, y, b, x));
                _.G(ms) ? _.A(Object, "hasOwn").call(Object, u, "adExpansion") && (_.ni(d, 34), x = u.adExpansion, null !== x && tf(x) && _.A(Object, "hasOwn").call(Object, x, "enabled") && (x = x.enabled, Cm(x) && (x = Dm(x), _.kh(d, 34, x)))) : (x = u.adExpansion, void 0 === x || null === x ? _.ni(d, 34) : (x = x.enabled, Cm(x) ? (x = Dm(x), _.kh(d, 34, x)) : void 0 !== x && null !== x || _.ni(d, 34)));
                if (_.A(Object, "hasOwn").call(Object, u, "privacyTreatments")) {
                    u = u.privacyTreatments;
                    _.ni(d, 35);
                    a: {
                        if (null !== u) {
                            if (ns(u)) break a;
                            P(b, Nk("googletag.setConfig", [u]))
                        }
                        u = void 0
                    }
                    x = u;
                    if (void 0 !== x) {
                        u = new _.v.Set;
                        x = _.z(x);
                        for (y = x.next(); !y.done; y = x.next()) {
                            y = y.value;
                            a: {
                                switch (y) {
                                    case "disablePersonalization":
                                        C = 1;
                                        break a
                                }
                                C = void 0
                            }
                            void 0 === C ? P(b, Nk("googletag.setConfig", [y])) : u.add(C)
                        }
                        x = d.D;
                        y = Ub(x);
                        pc(Gd(d.D));
                        x = Pd(x, y, 35, 2, !1);
                        if (Array.isArray(u))
                            for (y = 0; y < u.length; y++) x.push(Ic(u[y]));
                        else
                            for (u = _.z(u), y = u.next(); !y.done; y = u.next()) x.push(Ic(y.value))
                    }
                }
            } else P(b, Nk("googletag.setConfig", [u]))
        }), w.apiReady = !0, w);
        Kq(a, m, b, l);
        Mr(m, r)
    };
    vs = function(a) {
        var b = window,
            c = new Bj,
            d = new ps(a, b);
        d = M(c, d).output;
        var e = new Bj;
        var f = new qs(a, b);
        M(e, f);
        Kj(e);
        e = {
            il: f.l
        };
        _.G(rs) && M(c, new ss(a, b));
        if (Ma()) {
            f = {
                si: new rn
            };
            var g = new Bj;
            M(g, new ts(a, window, f.si));
            Kj(g);
            a = f
        } else a = void 0;
        g = _.G(Gr);
        f = b.navigator;
        b = Nf(b.isSecureContext, b.navigator, b.document);
        b = !g && b;
        g = _.Uf(us);
        b = {
            Qg: b,
            Sb: g,
            wl: !!f.getInterestGroupAdAuctionData
        };
        Kj(c);
        return {
            gl: e,
            tl: a,
            qe: d,
            Zl: b
        }
    };
    ws = function(a) {
        return window.IntersectionObserver && new IntersectionObserver(a, {
            threshold: [.5]
        })
    };
    As = function(a, b, c, d, e) {
        var f = void 0 === f ? ws : f;
        var g = new Bj,
            h = M(g, new Gp(a, e, xs));
        c = M(g, new ys(a, c, d, h.output, f));
        M(g, new zs(a, c.output, b, e));
        Kj(g);
        return {
            ik: g,
            Fn: c.output
        }
    };
    Bs = function(a) {
        var b = {
            threshold: [0, .3, .5, .75, 1]
        };
        return window.IntersectionObserver && new IntersectionObserver(a, b)
    };
    jt = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y, x, C, I) {
        var D = new Bj,
            J = Yh(!0, window),
            Q = k.Z,
            N = k.R[e.getDomId()],
            Y = I.qe,
            ua = null == C ? void 0 : C.pf,
            ma = new Cs(a, window);
        M(D, ma);
        var na = m.Bk,
            za = m.lm,
            pa = m.nk,
            Ta = m.jc,
            ab = m.tj,
            lb = m.Ik,
            mb = m.rf,
            ac = m.vk,
            ic = m.Uf,
            td = m.he,
            Gc = m.hm,
            $d = m.Hk,
            Hc = m.Qk,
            Ge = m.Sg,
            Kf = m.Ek,
            xb = m.bk,
            jc = m.Aa,
            Th = m.Qi;
        C = m.Qd;
        I = m.Kj;
        var il = m.Fj,
            Lf = new rn;
        Lf.F(p);
        var Eg = new Ds(a, window.top, Lf);
        M(D, Eg);
        var Uc = new Es(a, Fs(N), J.height, ic, na);
        M(D, Uc);
        var ae = new Gs(a, e, xi(e, n), e.getDomId(), Fi(e), n.documentElement, Fs(N), h, f);
        Hs(D, ae);
        m = new rn;
        m.Ka(ae.m.promise.then(function($p) {
            return $p.output
        }));
        ae = new Is(a, jc, ab, lb, mb);
        M(D, ae);
        jc = new Js(a, _.Qh(Q, Ks, 5));
        M(D, jc);
        za = un(a, window.location.hash, J, e.getAdUnitPath(), N, f, Uc.output, td, za, na, ae.output, m);
        na = za.Ng;
        _.S(D, za.Ga);
        mb = new Ls(a, Q, N, ab, mb, na.Oh);
        M(D, mb);
        if (f = Ir(a, e, Eg.output, N, h, p, f, na.Aa, na.La, m, r, k, x, Ta, Th, g, w)) {
            _.S(D, f.Ga);
            var ud = f.dm
        }
        var Pa, Fg;
        f = null != (Fg = null == (Pa = ud) ? void 0 : Pa.Aa) ? Fg : na.Aa;
        var kc, Mf;
        Pa = null != (Mf = null == (kc = ud) ? void 0 : kc.La) ? Mf : na.La;
        var wc;
        kc = null == (wc = ud) ? void 0 : wc.Rd;
        var xc;
        ud = null == (xc = ud) ? void 0 : xc.Lc;
        xc = new Ms(a, e, Q, N, Fs(N), n, h, m, mb.output, Pa, pa, kc);
        M(D, xc);
        wc = new Ns(a, xc.output);
        M(D, wc);
        wc = new Os(a, e, J, h, wc.output, jc.l, kc);
        M(D, wc);
        wc = new Ps(a, wc.output, xc.output, jc.l, kc);
        M(D, wc);
        jc = yn(a, J, e, N, m, xc.output, pa, Pa, na.he, Ta, kc);
        J = jc.Ng;
        _.S(D, jc.Ga);
        Gc = new Qs(a, Q, N, f, mb.output, Gc);
        M(D, Gc);
        jc = new Rs(a, window, xb, ma.output, kc);
        M(D, jc);
        Mf = new Ss(a, Fs(N), n);
        M(D, Mf);
        xb = new Ts(a, y, Fs(N), ic, ac, kc);
        M(D, xb);
        Hc = new Us(a, Hc, ud, Lf, kc);
        M(D, Hc);
        (ua = Xq(a, ua, il)) && _.S(D, ua);
        l = new Vs(a, e, h, k, u, l, window, f, mb.output, wc.output, m, xc.output, Pa, Ta, pa, Gc.output, lb, $d, Ge, J.Rd, jc.output, Mf.output, xb.output, Th, Y, kc);
        M(D, l);
        Y = new Ws(a, window, e, l.v, Lf);
        M(D, Y);
        Y = Fs(N);
        switch (Y) {
            case 2:
            case 3:
                _.G(Xs) ? M(D, new Ys(a, h, Fs(N), e, window, ic, l.l, m, xb.output, Pa)) : M(D, new Zs(a, h, Fs(N), e, window, ic, l.l, m, xb.output, Pa));
                break;
            case 5:
                M(D, new $s(a, e, k.dd, ac, l.l, m, Eg.output, xb.output));
                break;
            case 4:
                k = new at(a, e, u, window, l.l, m);
                _.S(D, k);
                Kj(k);
                break;
            case 7:
                Hs(D, Pp(a, e, u, l.l, m));
                break;
            case 8:
            case 9:
                (k = Nq(a, Y, y, l.l, xc.output, Pa)) && _.S(D, k)
        }
        k = new bt(a, e, l.l, n, u);
        M(D, k);
        k = new ct(a, e, dt(h, e), window.top);
        M(D, k);
        u = As(a, u, n, l.l, e).ik;
        _.S(D, u);
        h = new et(a, dt(h, e), window.top, l.l, ma.output, k.output, k.l);
        M(D, h);
        M(D, new ft(a, e, pa, ab, Ge, l.l, xc.output, l.C));
        e = new gt(a, window, Kf, l.l, xc.output, m);
        M(D, e);
        _.S(D, $o(a, n, Am(), Q, c, b, d, I));
        M(D, new ht(a, Am(), Q, b, c, d, C));
        return D
    };
    mt = function(a, b, c) {
        var d = null;
        try {
            var e = kt(b.top.document, b.top).y;
            d = a.map(function(f) {
                var g = c.Z,
                    h = c.R[f.getDomId()],
                    k;
                f = null == (k = Di(f, h, b.document, Co(g, h))) ? void 0 : k.y;
                k = Yh(!0, b).height;
                return void 0 === f || -12245933 === f || -12245933 === k ? -1 : f < e + k ? 0 : ++lt
            })
        } catch (f) {}
        return d
    };
    ut = function(a) {
        return Eh(a.ja.context, 1132, function() {
            if (a.ka.W.length) {
                var b = new _.v.Set(Wf(nt));
                for (var c = _.z(_.L(a.ja.X, 8) ? "loc gpic cookie ms ppid top etu uule video_doc_id".split(" ") : []), d = c.next(); !d.done; d = c.next()) b.add(d.value);
                d = new _.v.Map;
                c = _.z(ot);
                for (var e = c.next(); !e.done; e = c.next()) e = e.value, e(a, d);
                c = "https://" + (pt(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
                d = _.z(d);
                for (e = d.next(); !e.done; e = d.next()) {
                    var f = _.z(e.value);
                    e = f.next().value;
                    var g = f.next().value;
                    f = g.value;
                    g = void 0 === g.options ? {} : g.options;
                    (new RegExp("[?&]" + e + "=")).test(c);
                    if (!b.has(e) && null != f) {
                        var h = void 0 === g.Ba ? "," : g.Ba,
                            k = void 0 === g.Fa ? !1 : g.Fa,
                            l = void 0 === g.Qb ? !1 : g.Qb;
                        if (f = "object" !== typeof f ? null == f || !k && 0 === f ? null : encodeURIComponent(f) : Array.isArray(f) && f.length ? _.G(uo) && l || _.G(qt) ? rt(f, g) : encodeURIComponent(f.join(h)) : null) "?" !== c[c.length - 1] && (c += "&"), c += e + "=" + f
                    }
                }
                if (1 === _.Uf(st) || 2 === _.Uf(st)) b = _.Uf(tt), b = 0 >= b ? "" : (_.F = _.A(Array, "from").call(Array, {
                    length: Math.ceil(b / 8)
                }), _.A(_.F, "fill")).call(_.F, "testdata").join("").substring(0, b), 2 === _.Uf(st) && (c += "&dblt=" + b);
                b = c
            } else b = "";
            return b
        })
    };
    pt = function(a) {
        var b = a.ja.X,
            c, d;
        a = null != (d = null == (c = vt(a.ka.P.Z)) ? void 0 : _.L(c, 9)) ? d : !1;
        c = _.L(b, 8);
        return a || c || !zf(b)
    };
    rt = function(a, b) {
        var c = void 0 === b.Ba ? "," : b.Ba,
            d = void 0 === b.ld ? "" : b.ld,
            e = void 0 === b.Fa ? !1 : b.Fa,
            f = !1;
        a = a.map(function(g) {
            f || (f = !!g);
            return String(0 === g && e ? g : g || d)
        });
        return f || e ? encodeURIComponent(a.join(c)) : null
    };
    xt = function(a, b, c) {
        b = wt(b, c);
        switch (b) {
            case 0:
                a();
                break;
            case 1:
                c.setTimeout(a, 0);
                break;
            case 2:
                c.scheduler.yield().then(a);
                break;
            default:
                _.cb(b)
        }
    };
    wt = function(a, b) {
        if (0 === a) return 0;
        a = _.Uf(yt);
        switch (a) {
            case 0:
                return 0;
            case 1:
                return 1;
            case 6:
                var c;
                return (null == (c = b.scheduler) ? 0 : c.yield) ? 2 : 1;
            case 5:
                var d;
                return (null == (d = b.scheduler) ? 0 : d.yield) ? 2 : 0;
            default:
                _.cb(a)
        }
    };
    zt = function(a) {
        function b(f) {
            var g = f;
            return function() {
                var h = _.Wa.apply(0, arguments);
                if (g) {
                    var k = g;
                    g = null;
                    k.apply(null, _.ch(h))
                }
            }
        }
        var c = null,
            d = 0,
            e = 0;
        return function() {
            var f, g, h, k;
            return _.kb(function(l) {
                if (1 == l.j) return d && clearTimeout(d), d = 0, f = new _.cg, g = b(f.resolve), h = ++e, l.yield(0, 2);
                if (e !== h) return g(!1), l.return(f.promise);
                c ? c(!1) : g(!0);
                k = b(function() {
                    c = null;
                    d = 0;
                    g(!0)
                });
                d = setTimeout(k, 1E3);
                _.mn(a, function() {
                    return void g(!1)
                });
                c = g;
                return l.return(f.promise)
            })
        }
    };
    Bt = function(a, b) {
        a = a.W;
        var c = b.L,
            d = b.Va;
        b = b.Ie;
        if (!a.length) return {
            Rc: []
        };
        for (var e = _.z(a), f = e.next(); !f.done; f = e.next()) dp(c, f.value);
        return b ? {
            Rc: []
        } : d ? (c = eh(a[0].getAdUnitPath()), {
            Rc: At(a, c)
        }) : {
            Rc: a.map(function(g) {
                return {
                    hb: eh(g.getAdUnitPath()),
                    W: [g]
                }
            })
        }
    };
    At = function(a, b) {
        var c = [];
        a = xa(a, function(f) {
            return eh(f.getAdUnitPath())
        });
        a = _.z(_.A(Object, "entries").call(Object, a));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = _.z(d.value);
            d = e.next().value;
            e = e.next().value;
            d === b ? c.unshift({
                hb: d,
                W: e
            }) : c.push({
                hb: d,
                W: e
            })
        }
        return c
    };
    Dt = function(a, b) {
        a = a.W;
        var c = function(d) {
            return !!Zh(b.R[d.getDomId()]).length
        };
        return {
            Jg: a.filter(c),
            Tg: a.filter(Ct(c))
        }
    };
    Lt = function() {
        var a = new Et;
        var b = (new Ft).setCorrelator(_.Ih(_.t));
        var c = _.If().join();
        b = _.ih(b, 5, c);
        b = _.H(b, 2, 1);
        a = _.kh(a, 1, b);
        b = new Gt;
        c = _.G(Ht);
        b = _.oh(b, 7, c);
        c = _.G(It);
        b = _.oh(b, 8, c);
        c = _.G(Jt);
        b = _.oh(b, 9, c);
        b = _.oh(b, 10, !0);
        c = _.G(Kt);
        b = _.oh(b, 13, c);
        b = _.oh(b, 16, !0);
        a = _.kh(a, 2, b);
        window.google_rum_config = a.toJSON()
    };
    Pt = function() {
        var a = _.G(Mt) ? _.Me(Nt) : _.Me(Ot);
        _.an(document, a)
    };
    Vt = function(a, b) {
        var c = Qt() || (0, _.Rt)() ? 1 : _.Qf(),
            d = .001 > c;
        d ? (b.l = !0, Hf(31067358)) : .002 > c && Hf(31067357);
        Kl(23, a);
        a = 1E-4 > c;
        b = _.Uf(St);
        var e = 0 < b && c < b,
            f = _.Uf(Tt),
            g = 0 < f && c < 1 / f,
            h = _.G(Ut);
        return {
            Bc: d,
            Wh: 1E3,
            Ji: a,
            Vh: 1E4,
            Ig: d,
            Pf: 1E3,
            Kl: e,
            ul: b,
            Il: g,
            al: f,
            Ll: h,
            lh: c
        }
    };
    $t = function(a, b) {
        var c = _.A(Object, "assign").call(Object, {}, a);
        a = a.lh;
        c = (delete c.lh, c);
        var d = b.zb;
        /m\d+/.test(d) ? d = Number(d.substring(1)) : (d && nj({
            mjsv: d
        }, "gpt_inv_ver"), d = void 0);
        var e = window.document.URL,
            f = _.Uf(Wt);
        f = new Xt(4, b.zb, f);
        return _.A(Object, "assign").call(Object, {}, b, c, {
            Ln: new Yt(b)
        }, {
            wc: d,
            Qa: f,
            Lf: e,
            Ah: 2012,
            Uk: new Zt(f, a)
        })
    };
    _.au = function(a) {
        var b;
        a = (null != (b = void 0 === a ? null : a) ? b : window).googletag;
        return (null == a ? 0 : a.apiReady) ? a : void 0
    };
    _.aa = [];
    bu = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    };
    cu = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };
    du = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    };
    _.eu = du(this);
    fu = "function" === typeof Symbol && "symbol" === typeof Symbol("x");
    _.v = {};
    gu = {};
    _.A = function(a, b, c) {
        if (!c || null != a) {
            c = gu[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    };
    hu = function(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in _.v ? f = _.v : f = _.eu;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = fu && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? cu(_.v, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === gu[d] && (a = 1E9 * Math.random() >>> 0, gu[d] = fu ? _.eu.Symbol(d) : "$jscp$" + a + "$" + d), cu(f, gu[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    };
    hu("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.j = f;
            cu(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.j
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    hu("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, _.v.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = _.eu[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && cu(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return iu(bu(this))
                }
            })
        }
        return a
    }, "es6");
    iu = function(a) {
        a = {
            next: a
        };
        a[_.A(_.v.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    _.ju = function(a) {
        return a.raw = a
    };
    ku = function(a, b) {
        a.raw = b;
        return a
    };
    _.z = function(a) {
        var b = "undefined" != typeof _.v.Symbol && _.A(_.v.Symbol, "iterator") && a[_.A(_.v.Symbol, "iterator")];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: bu(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    };
    _.ch = function(a) {
        if (!(a instanceof Array)) {
            a = _.z(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    };
    lu = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    mu = fu && "function" == typeof _.A(Object, "assign") ? _.A(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) lu(d, e) && (a[e] = d[e])
        }
        return a
    };
    hu("Object.assign", function(a) {
        return a || mu
    }, "es6");
    var nu = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ou = function() {
            function a() {
                function c() {}
                new c;
                Reflect.construct(c, [], function() {});
                return new c instanceof c
            }
            if (fu && "undefined" != typeof Reflect && Reflect.construct) {
                if (a()) return Reflect.construct;
                var b = Reflect.construct;
                return function(c, d, e) {
                    c = b(c, d);
                    e && Reflect.setPrototypeOf(c, e.prototype);
                    return c
                }
            }
            return function(c, d, e) {
                void 0 === e && (e = c);
                e = nu(e.prototype || Object.prototype);
                return Function.prototype.apply.call(c, e, d) || e
            }
        }(),
        pu;
    if (fu && "function" == typeof _.A(Object, "setPrototypeOf")) pu = _.A(Object, "setPrototypeOf");
    else {
        var qu;
        a: {
            var ru = {
                    a: !0
                },
                su = {};
            try {
                su.__proto__ = ru;
                qu = su.a;
                break a
            } catch (a) {}
            qu = !1
        }
        pu = qu ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    tu = pu;
    _.T = function(a, b) {
        a.prototype = nu(b.prototype);
        a.prototype.constructor = a;
        if (tu) tu(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Sl = b.prototype
    };
    uu = function() {
        this.l = !1;
        this.A = null;
        this.o = void 0;
        this.j = 1;
        this.I = this.m = 0;
        this.J = null
    };
    vu = function(a) {
        if (a.l) throw new TypeError("Generator is already running");
        a.l = !0
    };
    uu.prototype.H = function(a) {
        this.o = a
    };
    var wu = function(a, b) {
        a.J = {
            exception: b,
            Kk: !0
        };
        a.j = a.m || a.I
    };
    uu.prototype.return = function(a) {
        this.J = {
            return: a
        };
        this.j = this.I
    };
    uu.prototype.yield = function(a, b) {
        this.j = b;
        return {
            value: a
        }
    };
    ob = function(a) {
        a.m = 0;
        var b = a.J.exception;
        a.J = null;
        return b
    };
    xu = function(a) {
        this.j = new uu;
        this.o = a
    };
    Au = function(a, b) {
        vu(a.j);
        var c = a.j.A;
        if (c) return yu(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.j.return);
        a.j.return(b);
        return zu(a)
    };
    yu = function(a, b, c, d) {
        try {
            var e = b.call(a.j.A, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.j.l = !1, e;
            var f = e.value
        } catch (g) {
            return a.j.A = null, wu(a.j, g), zu(a)
        }
        a.j.A = null;
        d.call(a.j, f);
        return zu(a)
    };
    zu = function(a) {
        for (; a.j.j;) try {
            var b = a.o(a.j);
            if (b) return a.j.l = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.j.o = void 0, wu(a.j, c)
        }
        a.j.l = !1;
        if (a.j.J) {
            b = a.j.J;
            a.j.J = null;
            if (b.Kk) throw b.exception;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    };
    Bu = function(a) {
        this.next = function(b) {
            vu(a.j);
            a.j.A ? b = yu(a, a.j.A.next, b, a.j.H) : (a.j.H(b), b = zu(a));
            return b
        };
        this.throw = function(b) {
            vu(a.j);
            a.j.A ? b = yu(a, a.j.A["throw"], b, a.j.H) : (wu(a.j, b), b = zu(a));
            return b
        };
        this.return = function(b) {
            return Au(a, b)
        };
        this[_.A(_.v.Symbol, "iterator")] = function() {
            return this
        }
    };
    Cu = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new _.v.Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : _.v.Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    };
    _.kb = function(a) {
        return Cu(new Bu(new xu(a)))
    };
    _.Wa = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    hu("Reflect", function(a) {
        return a ? a : {}
    }, "es6");
    hu("Reflect.construct", function() {
        return ou
    }, "es6");
    hu("Reflect.setPrototypeOf", function(a) {
        return a ? a : tu ? function(b, c) {
            try {
                return tu(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6");
    hu("Promise", function(a) {
        function b() {
            this.j = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.o = function(g) {
            if (null == this.j) {
                this.j = [];
                var h = this;
                this.m(function() {
                    h.J()
                })
            }
            this.j.push(g)
        };
        var d = _.eu.setTimeout;
        b.prototype.m = function(g) {
            d(g, 0)
        };
        b.prototype.J = function() {
            for (; this.j && this.j.length;) {
                var g = this.j;
                this.j = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.A(l)
                    }
                }
            }
            this.j = null
        };
        b.prototype.A = function(g) {
            this.m(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.o = 0;
            this.m = void 0;
            this.j = [];
            this.H = !1;
            var h = this.A();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.A = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.ta),
                reject: g(this.J)
            }
        };
        e.prototype.ta = function(g) {
            if (g === this) this.J(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.K(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = null != g;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.C(g) : this.l(g)
            }
        };
        e.prototype.C = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.J(k);
                return
            }
            "function" == typeof h ? this.O(h, g) : this.l(g)
        };
        e.prototype.J = function(g) {
            this.I(2, g)
        };
        e.prototype.l = function(g) {
            this.I(1, g)
        };
        e.prototype.I = function(g, h) {
            if (0 != this.o) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.o);
            this.o = g;
            this.m = h;
            2 === this.o && this.G();
            this.M()
        };
        e.prototype.G = function() {
            var g = this;
            d(function() {
                if (g.v()) {
                    var h = _.eu.console;
                    "undefined" !== typeof h && h.error(g.m)
                }
            }, 1)
        };
        e.prototype.v = function() {
            if (this.H) return !1;
            var g = _.eu.CustomEvent,
                h = _.eu.Event,
                k = _.eu.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = _.eu.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.m;
            return k(g)
        };
        e.prototype.M = function() {
            if (null != this.j) {
                for (var g = 0; g < this.j.length; ++g) f.o(this.j[g]);
                this.j = null
            }
        };
        var f = new b;
        e.prototype.K = function(g) {
            var h = this.A();
            g.me(h.resolve, h.reject)
        };
        e.prototype.O = function(g, h) {
            var k = this.A();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(p, r) {
                return "function" == typeof p ? function(w) {
                    try {
                        l(p(w))
                    } catch (u) {
                        m(u)
                    }
                } : r
            }
            var l, m, n = new e(function(p, r) {
                l = p;
                m = r
            });
            this.me(k(g, l), k(h, m));
            return n
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.me = function(g, h) {
            function k() {
                switch (l.o) {
                    case 1:
                        g(l.m);
                        break;
                    case 2:
                        h(l.m);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.o);
                }
            }
            var l = this;
            null == this.j ? f.o(k) : this.j.push(k);
            this.H = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = _.z(g), m = l.next(); !m.done; m = l.next()) c(m.value).me(h, k)
            })
        };
        e.all = function(g) {
            var h = _.z(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function n(w) {
                    return function(u) {
                        p[w] = u;
                        r--;
                        0 == r && l(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, c(k.value).me(n(p.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    }, "es6");
    hu("Object.setPrototypeOf", function(a) {
        return a || tu
    }, "es6");
    hu("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.j = (e += Math.random() + 1).toString();
                if (g) {
                    g = _.z(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!lu(g, d)) {
                var k = new b;
                cu(g, d, {
                    value: k
                })
            }
            if (!lu(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.j] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && lu(g, d) ? g[d][this.j] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && lu(g, d) && lu(g[d], this.j)
        };
        f.prototype.delete = function(g) {
            return c(g) && lu(g, d) && lu(g[d], this.j) ? delete g[d][this.j] : !1
        };
        return f
    }, "es6");
    hu("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.A(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(_.z([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = _.A(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                    m = l.next();
                    return m.done || 4 != m.value[0].x || "t" != m.value[1] || !l.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new _.v.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = _.z(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.Sa ? l.Sa.value = k : (l.Sa = {
                next: this[1],
                Jb: this[1].Jb,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.Sa), this[1].Jb.next = l.Sa, this[1].Jb = l.Sa, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.Sa && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.Sa.Jb.next = h.Sa.next, h.Sa.next.Jb = h.Sa.Jb, h.Sa.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Jb = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).Sa
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).Sa) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = _.A(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        c.prototype[_.A(_.v.Symbol, "iterator")] = _.A(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && lu(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (k !== k && n.key !== n.key || k === n.key) return {
                            id: l,
                            list: m,
                            index: h,
                            Sa: n
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    Sa: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return iu(function() {
                    if (l) {
                        for (; l.head != h[1];) l = l.Jb;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.Jb = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    var Du = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[_.A(_.v.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    hu("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Du(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    hu("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Du(this, function(b) {
                return b
            })
        }
    }, "es6");
    var Eu = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    hu("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Eu(this, b, "endsWith");
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    }, "es6");
    var Fu = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                i: e,
                Vi: f
            }
        }
        return {
            i: -1,
            Vi: void 0
        }
    };
    hu("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            return Fu(this, b, c).Vi
        }
    }, "es6");
    hu("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
            var c = Math.floor(Math.abs(b));
            return 0 > b ? -c : c
        }
    }, "es6");
    hu("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) lu(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    hu("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    hu("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || _.A(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    hu("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Eu(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    hu("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.A(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(_.z([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = _.A(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.j = new _.v.Map;
            if (c) {
                c = _.z(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.j.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.j.set(c, c);
            this.size = this.j.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.j.delete(c);
            this.size = this.j.size;
            return c
        };
        b.prototype.clear = function() {
            this.j.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.j.has(c)
        };
        b.prototype.entries = function() {
            return _.A(this.j, "entries").call(this.j)
        };
        b.prototype.values = function() {
            return _.A(this.j, "values").call(this.j)
        };
        b.prototype.keys = _.A(b.prototype, "values");
        b.prototype[_.A(_.v.Symbol, "iterator")] = _.A(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.j.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    hu("Number.EPSILON", function() {
        return Math.pow(2, -52)
    }, "es6");
    hu("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    hu("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    hu("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return _.A(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    hu("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return _.A(Number, "isInteger").call(Number, b) && Math.abs(b) <= _.A(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    hu("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return "number" === typeof b && isNaN(b)
        }
    }, "es6");
    hu("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Du(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    hu("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof _.v.Symbol && _.A(_.v.Symbol, "iterator") && b[_.A(_.v.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    hu("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            0 > c && (c = Math.max(0, e + c));
            if (null == d || d > e) d = e;
            d = Number(d);
            0 > d && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    }, "es6");
    var Gu = function(a) {
        return a ? a : _.A(Array.prototype, "fill")
    };
    hu("Int8Array.prototype.fill", Gu, "es6");
    hu("Uint8Array.prototype.fill", Gu, "es6");
    hu("Uint8ClampedArray.prototype.fill", Gu, "es6");
    hu("Int16Array.prototype.fill", Gu, "es6");
    hu("Uint16Array.prototype.fill", Gu, "es6");
    hu("Int32Array.prototype.fill", Gu, "es6");
    hu("Uint32Array.prototype.fill", Gu, "es6");
    hu("Float32Array.prototype.fill", Gu, "es6");
    hu("Float64Array.prototype.fill", Gu, "es6");
    hu("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) lu(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    hu("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Eu(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    hu("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = Eu(this, null, "repeat");
            if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    hu("globalThis", function(a) {
        return a || _.eu
    }, "es_2020");
    hu("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = Eu(this, null, "padStart");
            b -= d.length;
            c = void 0 !== c ? String(c) : " ";
            return (0 < b && c ? _.A(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    hu("AggregateError", function(a) {
        if (a) return a;
        a = function(b, c) {
            c = Error(c);
            "stack" in c && (this.stack = c.stack);
            this.errors = b;
            this.message = c.message
        };
        _.T(a, Error);
        a.prototype.name = "AggregateError";
        return a
    }, "es_2021");
    hu("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : _.A(Array, "from").call(Array, b);
            return _.v.Promise.all(b.map(function(c) {
                return _.v.Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new _.v.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    hu("Array.prototype.findIndex", function(a) {
        return a ? a : function(b, c) {
            return Fu(this, b, c).i
        }
    }, "es6");
    hu("Object.fromEntries", function(a) {
        return a ? a : function(b) {
            var c = {};
            if (!(_.A(_.v.Symbol, "iterator") in b)) throw new TypeError("" + b + " is not iterable");
            b = b[_.A(_.v.Symbol, "iterator")].call(b);
            for (var d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                c[d[0]] = d[1]
            }
            return c
        }
    }, "es_2019");
    hu("Object.hasOwn", function(a) {
        return a ? a : function(b, c) {
            return Object.prototype.hasOwnProperty.call(b, c)
        }
    }, "es_next");
    hu("Promise.prototype.finally", function(a) {
        return a ? a : function(b) {
            return this.then(function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    return c
                })
            }, function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    throw c;
                })
            })
        }
    }, "es9");
    hu("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = _.A(Array.prototype, "flat").call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    }, "es9");
    hu("String.raw", function(a) {
        return a ? a : function(b, c) {
            if (null == b) throw new TypeError("Cannot convert undefined or null to object");
            for (var d = b.raw, e = d.length, f = "", g = 0; g < e; ++g) f += d[g], g + 1 < e && g + 1 < arguments.length && (f += String(arguments[g + 1]));
            return f
        }
    }, "es6");
    hu("Math.sign", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            return 0 === b || isNaN(b) ? b : 0 < b ? 1 : -1
        }
    }, "es6");
    hu("String.fromCodePoint", function(a) {
        return a ? a : function(b) {
            for (var c = "", d = 0; d < arguments.length; d++) {
                var e = Number(arguments[d]);
                if (0 > e || 1114111 < e || e !== Math.floor(e)) throw new RangeError("invalid_code_point " + e);
                65535 >= e ? c += String.fromCharCode(e) : (e -= 65536, c += String.fromCharCode(e >>> 10 & 1023 | 55296), c += String.fromCharCode(e & 1023 | 56320))
            }
            return c
        }
    }, "es6");
    hu("Array.prototype.flatMap", function(a) {
        return a ? a : function(b, c) {
            var d = [];
            Array.prototype.forEach.call(this, function(e, f) {
                e = b.call(c, e, f, this);
                Array.isArray(e) ? d.push.apply(d, e) : d.push(e)
            });
            return d
        }
    }, "es9");
    var Hu, Bc, Iu, Ju, Ku, Lu;
    _.t = this || self;
    Hu = function(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = _.t, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    };
    Bc = function(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    };
    _.ta = function(a) {
        var b = Bc(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    };
    _.ja = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    };
    _.ka = function(a) {
        return Object.prototype.hasOwnProperty.call(a, Iu) && a[Iu] || (a[Iu] = ++Ju)
    };
    Iu = "closure_uid_" + (1E9 * Math.random() >>> 0);
    Ju = 0;
    Ku = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    };
    Lu = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    };
    _.Mu = function(a, b, c) {
        _.Mu = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Ku : Lu;
        return _.Mu.apply(null, arguments)
    };
    _.Nu = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    };
    var Ou;
    var Qu, Pu;
    _.Ru = function(a, b) {
        this.j = a === Pu && b || "";
        this.o = Qu
    };
    _.Ru.prototype.qb = !0;
    _.Ru.prototype.ab = function() {
        return this.j
    };
    _.Su = function(a) {
        return a instanceof _.Ru && a.constructor === _.Ru && a.o === Qu ? a.j : "type_error:Const"
    };
    _.Tu = function(a) {
        return new _.Ru(Pu, a)
    };
    Qu = {};
    Pu = {};
    var rb = _.Tu("https://tpc.googlesyndication.com/sodar/%{basename}.js");
    var Uu, Ct, yi;
    Uu = function() {
        return !0
    };
    Ct = function(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    };
    yi = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    _.Vu = function(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    _.Wu = function(a, b) {
        var c = 0,
            d = !1,
            e = [],
            f = function() {
                c = 0;
                d && (d = !1, g())
            },
            g = function() {
                c = _.t.setTimeout(f, b);
                var h = e;
                e = [];
                a.apply(void 0, h)
            };
        return function(h) {
            e = arguments;
            c ? d = !0 : g()
        }
    };
    var ca;
    _.Xu = {
        passive: !0
    };
    ca = yi(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            _.t.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });
    _.ib = function(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, da(d)), !0) : !1
    };
    _.of = function(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, da(d)), !0) : !1
    };
    _.ea = function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };
    _.Yu = function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    _.Qg = function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    };
    _.Zu = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };
    _.Sg = function(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    };
    var vc = function(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Da = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    var $u = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var Pe;
    Pe = {};
    _.Oe = function(a) {
        this.j = a;
        this.qb = !0
    };
    _.Oe.prototype.toString = function() {
        return this.j.toString()
    };
    _.Oe.prototype.ab = function() {
        return this.j.toString()
    };
    _.eb = function(a) {
        return a instanceof _.Oe && a.constructor === _.Oe ? a.j : "type_error:SafeScript"
    };
    var fv, ev, bv, gv, Le, cv;
    _.av = function(a) {
        this.j = a
    };
    _.av.prototype.toString = function() {
        return this.j + ""
    };
    _.av.prototype.qb = !0;
    _.av.prototype.ab = function() {
        return this.j.toString()
    };
    _.dv = function(a, b) {
        a = bv.exec(_.gb(a).toString());
        var c = a[3] || "";
        return Le(a[1] + cv("?", a[2] || "", b) + cv("#", c))
    };
    _.gb = function(a) {
        return a instanceof _.av && a.constructor === _.av ? a.j : "type_error:TrustedResourceUrl"
    };
    _.qb = function(a, b) {
        var c = _.Su(a);
        if (!ev.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(fv, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof _.Ru ? _.Su(d) : encodeURIComponent(String(d))
        });
        return Le(a)
    };
    fv = /%{(\w+)}/g;
    ev = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i");
    bv = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;
    gv = {};
    Le = function(a) {
        return new _.av(a, gv)
    };
    cv = function(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var hv, Uk, iv, qv, kv, lv, mv, nv, ov, pv, jv;
    hv = function(a, b) {
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) == c
    };
    Uk = function(a) {
        return /^[\s\xa0]*$/.test(a)
    };
    iv = function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };
    qv = function(a) {
        if (!jv.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(kv, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(lv, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(mv, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(nv, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(ov, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(pv, "&#0;"));
        return a
    };
    kv = /&/g;
    lv = /</g;
    mv = />/g;
    nv = /"/g;
    ov = /'/g;
    pv = /\x00/g;
    jv = /[\x00&<>"']/;
    _.Ia = function(a, b) {
        return -1 != a.indexOf(b)
    };
    var rv, sv, uv, vv, xv, Sa;
    _.Ra = function(a) {
        this.j = a
    };
    _.Ra.prototype.toString = function() {
        return this.j.toString()
    };
    _.Ra.prototype.qb = !0;
    _.Ra.prototype.ab = function() {
        return this.j.toString()
    };
    _.$a = function(a) {
        return a instanceof _.Ra && a.constructor === _.Ra ? a.j : "type_error:SafeUrl"
    };
    rv = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;
    sv = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    _.tv = function(a) {
        if (a instanceof _.Ra) return a;
        a = "object" == typeof a && a.qb ? a.ab() : String(a);
        sv.test(a) ? a = Sa(a) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(rv) ? Sa(a) : null);
        return a
    };
    try {
        new URL("s://g"), uv = !0
    } catch (a) {
        uv = !1
    }
    vv = uv;
    _.wv = function(a) {
        if (a instanceof _.Ra) return a;
        a = "object" == typeof a && a.qb ? a.ab() : String(a);
        a: {
            var b = a;
            if (vv) {
                try {
                    var c = new URL(b)
                } catch (d) {
                    b = "https:";
                    break a
                }
                b = c.protocol
            } else b: {
                c = document.createElement("a");
                try {
                    c.href = b
                } catch (d) {
                    b = void 0;
                    break b
                }
                b = c.protocol;b = ":" === b || "" === b ? "https:" : b
            }
        }
        "javascript:" === b && (a = "about:invalid#zClosurez");
        return Sa(a)
    };
    xv = {};
    Sa = function(a) {
        return new _.Ra(a, xv)
    };
    _.Ua = Sa("about:invalid#zClosurez");
    _.yv = {};
    _.zv = function(a) {
        this.j = a;
        this.qb = !0
    };
    _.zv.prototype.ab = function() {
        return this.j
    };
    _.zv.prototype.toString = function() {
        return this.j.toString()
    };
    _.Av = new _.zv("", _.yv);
    _.Bv = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$");
    _.Cv = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g");
    _.Dv = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g");
    _.Ev = {};
    _.Fv = function(a) {
        this.j = a;
        this.qb = !0
    };
    _.Fv.prototype.toString = function() {
        return this.j.toString()
    };
    _.Fv.prototype.ab = function() {
        return this.j
    };
    _.Gv = function(a) {
        return a instanceof _.Fv && a.constructor === _.Fv ? a.j : "type_error:SafeStyleSheet"
    };
    var Ga = Hu(610401301, !1),
        Hv = Hu(572417392, Hu(1, !0));
    var Ha, Iv = _.t.navigator;
    Ha = Iv ? Iv.userAgentData || null : null;
    var Jv, Mv, Rv, Nv, Tv, Ov, Qv;
    Jv = {};
    _.Kv = function(a) {
        this.j = a;
        this.qb = !0
    };
    _.Kv.prototype.ab = function() {
        return this.j.toString()
    };
    _.Kv.prototype.toString = function() {
        return this.j.toString()
    };
    _.Lv = function(a) {
        return a instanceof _.Kv && a.constructor === _.Kv ? a.j : "type_error:SafeHtml"
    };
    Mv = function(a) {
        return a instanceof _.Kv ? a : _.kj(qv("object" == typeof a && a.qb ? a.ab() : String(a)))
    };
    _.Pv = function(a) {
        if (!Nv.test(a)) throw Error("");
        if (a.toUpperCase() in Ov) throw Error("");
    };
    Rv = function(a) {
        var b = Mv(Qv),
            c = [],
            d = function(e) {
                Array.isArray(e) ? e.forEach(d) : (e = Mv(e), c.push(_.Lv(e).toString()))
            };
        a.forEach(d);
        return _.kj(c.join(_.Lv(b).toString()))
    };
    _.Sv = function(a) {
        return Rv(Array.prototype.slice.call(arguments))
    };
    _.kj = function(a) {
        return new _.Kv(a, Jv)
    };
    _.Uv = function(a, b, c) {
        var d = "";
        if (b)
            for (var e in b)
                if (Object.prototype.hasOwnProperty.call(b, e)) {
                    if (!Nv.test(e)) throw Error("");
                    var f = b[e];
                    if (null != f) {
                        var g = e;
                        if (f instanceof _.Ru) f = _.Su(f);
                        else {
                            if ("style" == g.toLowerCase()) throw Error("");
                            if (/^on/i.test(g)) throw Error("");
                            if (g.toLowerCase() in Tv)
                                if (f instanceof _.av) f = _.gb(f).toString();
                                else if (f instanceof _.Ra) f = _.$a(f);
                            else if ("string" === typeof f) f = (_.tv(f) || _.Ua).ab();
                            else throw Error("");
                        }
                        f.qb && (f = f.ab());
                        f = g + '="' + qv(String(f)) + '"';
                        d += " " + f
                    }
                }
        b = "<" + a + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === $u[a.toLowerCase()] ? b += ">" : (c = _.Sv(c), b += ">" + _.Lv(c).toString() + "</" + a + ">");
        return _.kj(b)
    };
    Nv = /^[a-zA-Z0-9-]+$/;
    Tv = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    };
    Ov = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    };
    Qv = new _.Kv(_.t.trustedTypes && _.t.trustedTypes.emptyHTML || "", Jv);
    _.Vv = _.kj("<br>");
    var Na = function(a) {
            this.Ok = a
        },
        Qa = [Oa("data"), Oa("http"), Oa("https"), Oa("mailto"), Oa("ftp"), new Na(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })],
        Ya = "function" === typeof URL;
    var Wv = {
            Km: 0,
            Nm: 1,
            Im: 2,
            Jm: 3,
            0: "FORMATTED_HTML_CONTENT",
            1: "HTML_FORMATTED_CONTENT",
            2: "EMBEDDED_INTERNAL_CONTENT",
            3: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
        },
        Xv = function(a, b) {
            b = Error.call(this, a + " cannot be used with intent " + Wv[b]);
            this.message = b.message;
            "stack" in b && (this.stack = b.stack);
            this.type = a;
            this.name = "TypeCannotBeUsedWithIntentError"
        };
    _.T(Xv, Error);
    var nb = function(a) {
        return new _.v.Promise(function(b, c) {
            var d = new XMLHttpRequest;
            d.onreadystatechange = function() {
                d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
            };
            d.open("GET", a, !0);
            d.send()
        })
    };
    var ub, tb = "undefined" !== typeof TextEncoder;
    _.Yv = function(a) {
        _.Yv[" "](a);
        return a
    };
    _.Yv[" "] = function() {};
    var Zv = function(a, b) {
        try {
            return _.Yv(a[b]), !0
        } catch (c) {}
        return !1
    };
    var $v, bw, cw, dw, ew, fw;
    $v = La() ? !1 : Ka("Opera");
    _.aw = La() ? !1 : Ka("Trident") || Ka("MSIE");
    bw = Ka("Edge");
    cw = Ka("Gecko") && !(_.Ia(Fa().toLowerCase(), "webkit") && !Ka("Edge")) && !(Ka("Trident") || Ka("MSIE")) && !Ka("Edge");
    dw = _.Ia(Fa().toLowerCase(), "webkit") && !Ka("Edge");
    ew = function() {
        var a = _.t.document;
        return a ? a.documentMode : void 0
    };
    a: {
        var gw = "",
            hw = function() {
                var a = Fa();
                if (cw) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (bw) return /Edge\/([\d\.]+)/.exec(a);
                if (_.aw) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (dw) return /WebKit\/(\S+)/.exec(a);
                if ($v) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();hw && (gw = hw ? hw[1] : "");
        if (_.aw) {
            var iw = ew();
            if (null != iw && iw > parseFloat(gw)) {
                fw = String(iw);
                break a
            }
        }
        fw = gw
    }
    var jw = fw,
        kw;
    if (_.t.document && _.aw) {
        var lw = ew();
        kw = lw ? lw : parseInt(jw, 10) || void 0
    } else kw = void 0;
    var mw = kw;
    !Ka("Android") || Ma();
    Ma();
    Ka("Safari") && (Ma() || (La() ? 0 : Ka("Coast")) || (La() ? 0 : Ka("Opera")) || (La() ? 0 : Ka("Edge")) || (La() ? Ja("Microsoft Edge") : Ka("Edg/")) || La() && Ja("Opera"));
    var nw = {},
        ow = null,
        pw = cw || dw || "function" == typeof _.t.btoa,
        zb = function(a, b) {
            void 0 === b && (b = 0);
            qw();
            b = nw[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        rw = function(a, b) {
            if (pw && !b) a = _.t.btoa(a);
            else {
                for (var c = [], d = 0, e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    255 < f && (c[d++] = f & 255, f >>= 8);
                    c[d++] = f
                }
                a = zb(c, b)
            }
            return a
        },
        sq = function(a) {
            var b = "";
            sw(a, function(c) {
                b += String.fromCharCode(c)
            });
            return b
        },
        Se = function(a) {
            var b = [];
            sw(a, function(c) {
                b.push(c)
            });
            return b
        },
        tw = function(a) {
            var b = a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : _.Ia("=.", a[b - 1]) && (c = _.Ia("=.", a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            sw(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        sw = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = ow[l];
                    if (null != m) return m;
                    if (!Uk(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            qw();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        qw = function() {
            if (!ow) {
                ow = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    nw[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === ow[f] && (ow[f] = e)
                    }
                }
            }
        };
    var Eb = "undefined" !== typeof Uint8Array,
        yb = !_.aw && "function" === typeof btoa,
        uw = /[-_.]/g,
        Cb = {
            "-": "+",
            _: "/",
            ".": "="
        },
        vw, Gb = {};
    var ww, lc = function(a, b) {
            Hb(b);
            this.ha = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        },
        mc = function() {
            return ww || (ww = new lc(null, Gb))
        },
        wd = function(a) {
            var b = a.ha;
            return null == b ? "" : "string" === typeof b ? b : a.ha = Ab(b)
        },
        xk = function(a) {
            Hb(Gb);
            var b = a.ha;
            if (null != b && !Fb(b))
                if ("string" === typeof b)
                    if (yb) {
                        uw.test(b) && (b = b.replace(uw, Db));
                        b = atob(b);
                        for (var c = new Uint8Array(b.length), d = 0; d < b.length; d++) c[d] = b.charCodeAt(d);
                        b = c
                    } else b = tw(b);
            else b = null;
            return (a = null == b ? b : a.ha = b) ? new Uint8Array(a) : vw || (vw = new Uint8Array(0))
        };
    lc.prototype.isEmpty = function() {
        return null == this.ha
    };
    var zd = !Hv,
        he = !Hv;
    var Kb = 0,
        Lb = 0,
        xw;
    var yw = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        Aw = function(a) {
            if (!a) return zw || (zw = new yw(0, 0));
            if (!/^\d+$/.test(a)) return null;
            Rb(a);
            return new yw(Kb, Lb)
        },
        zw, Bw = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        ye = function(a) {
            if (!a) return Cw || (Cw = new Bw(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            Rb(a);
            return new Bw(Kb, Lb)
        },
        Cw;
    var Dw = function() {
        this.j = []
    };
    Dw.prototype.length = function() {
        return this.j.length
    };
    Dw.prototype.end = function() {
        var a = this.j;
        this.j = [];
        return a
    };
    var Ae = function(a, b, c) {
            for (; 0 < c || 127 < b;) a.j.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
            a.j.push(b)
        },
        ze = function(a, b) {
            for (; 127 < b;) a.j.push(b & 127 | 128), b >>>= 7;
            a.j.push(b)
        },
        Ew = function(a, b) {
            if (0 <= b) ze(a, b);
            else {
                for (var c = 0; 9 > c; c++) a.j.push(b & 127 | 128), b >>= 7;
                a.j.push(1)
            }
        };
    var He = function() {
            this.m = [];
            this.o = 0;
            this.j = new Dw
        },
        Ce = function(a, b) {
            0 !== b.length && (a.m.push(b), a.o += b.length)
        },
        Fw = function(a, b, c) {
            ze(a.j, 8 * b + 2);
            ze(a.j, c.length);
            Ce(a, a.j.end());
            Ce(a, c)
        };
    var se = function(a, b) {
        this.j = a;
        this.fj = b
    };
    var Gw = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : void 0,
        Yb = Gw ? function(a, b) {
            a[Gw] |= b
        } : function(a, b) {
            void 0 !== a.rb ? a.rb |= b : Object.defineProperties(a, {
                rb: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        },
        Od = Gw ? function(a, b) {
            a[Gw] &= ~b
        } : function(a, b) {
            void 0 !== a.rb && (a.rb &= ~b)
        },
        Ub = Gw ? function(a) {
            return a[Gw] | 0
        } : function(a) {
            return a.rb | 0
        },
        Gd = Gw ? function(a) {
            return a[Gw]
        } : function(a) {
            return a.rb
        },
        Vb = Gw ? function(a, b) {
            a[Gw] = b
        } : function(a, b) {
            void 0 !== a.rb ? a.rb = b : Object.defineProperties(a, {
                rb: {
                    value: b,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            })
        };
    var cd = {},
        fc = {},
        Hw, vd = !Hv,
        Nd, Iw = [];
    Vb(Iw, 55);
    Nd = Object.freeze(Iw);
    var Jw = function(a, b, c) {
        this.m = 0;
        this.j = a;
        this.o = b;
        this.A = c
    };
    Jw.prototype.next = function() {
        if (this.m < this.j.length) {
            var a = this.j[this.m++];
            return {
                done: !1,
                value: this.o ? this.o.call(this.A, a) : a
            }
        }
        return {
            done: !0,
            value: void 0
        }
    };
    Jw.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return new Jw(this.j, this.o, this.A)
    };
    var Vd = {};
    var qc;
    var Ec = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/,
        fd = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : "di";
    var id, kd, ld;
    var Kw = function() {
            try {
                var a = function() {
                    return ou(_.v.Map, [], this.constructor)
                };
                _.T(a, _.v.Map);
                new a;
                return !1
            } catch (b) {
                return !0
            }
        }(),
        Lw = function() {
            this.j = new _.v.Map
        };
    _.q = Lw.prototype;
    _.q.get = function(a) {
        return this.j.get(a)
    };
    _.q.set = function(a, b) {
        this.j.set(a, b);
        this.size = this.j.size;
        return this
    };
    _.q.delete = function(a) {
        a = this.j.delete(a);
        this.size = this.j.size;
        return a
    };
    _.q.clear = function() {
        this.j.clear();
        this.size = this.j.size
    };
    _.q.has = function(a) {
        return this.j.has(a)
    };
    _.q.entries = function() {
        return _.A(this.j, "entries").call(this.j)
    };
    _.q.keys = function() {
        return _.A(this.j, "keys").call(this.j)
    };
    _.q.values = function() {
        return _.A(this.j, "values").call(this.j)
    };
    _.q.forEach = function(a, b) {
        return this.j.forEach(a, b)
    };
    Lw.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return _.A(this, "entries").call(this)
    };
    var Mw = function() {
            if (Kw) return _.A(Object, "setPrototypeOf").call(Object, Lw.prototype, _.v.Map.prototype), Object.defineProperties(Lw.prototype, {
                size: {
                    value: 0,
                    configurable: !0,
                    enumerable: !0,
                    writable: !0
                }
            }), Lw;
            var a = function() {
                return ou(_.v.Map, [], this.constructor)
            };
            _.T(a, _.v.Map);
            return a
        }(),
        xd = function(a, b, c, d) {
            c = void 0 === c ? gd : c;
            d = void 0 === d ? gd : d;
            var e = Mw.call(this) || this;
            var f = Ub(a);
            f |= 64;
            Vb(a, f);
            e.ee = f;
            e.sf = b;
            e.Fd = c || gd;
            e.Ug = e.sf ? od : d || gd;
            for (var g = 0; g < a.length; g++) {
                var h = a[g],
                    k = c(h[0], !1, !0),
                    l = h[1];
                b ? void 0 === l && (l = null) : l = d(h[1], !1, !0, void 0, void 0, f);
                Mw.prototype.set.call(e, k, l)
            }
            return e
        };
    _.T(xd, Mw);
    var Nw = function(a) {
            if (a.ee & 2) throw Error("Cannot mutate an immutable Map");
        },
        yd = function(a, b) {
            b = void 0 === b ? pd : b;
            return Id(a, b)
        },
        Id = function(a, b) {
            b = void 0 === b ? pd : b;
            var c = [];
            a = _.A(Mw.prototype, "entries").call(a);
            for (var d; !(d = a.next()).done;) d = d.value, d[0] = b(d[0]), d[1] = b(d[1]), c.push(d);
            return c
        };
    _.q = xd.prototype;
    _.q.clear = function() {
        Nw(this);
        Mw.prototype.clear.call(this)
    };
    _.q.delete = function(a) {
        Nw(this);
        return Mw.prototype.delete.call(this, this.Fd(a, !0, !1))
    };
    _.q.entries = function() {
        var a = _.A(Array, "from").call(Array, _.A(Mw.prototype, "keys").call(this));
        return new Jw(a, qd, this)
    };
    _.q.keys = function() {
        return _.A(Mw.prototype, "keys").call(this)
    };
    _.q.values = function() {
        var a = _.A(Array, "from").call(Array, _.A(Mw.prototype, "keys").call(this));
        return new Jw(a, xd.prototype.get, this)
    };
    _.q.forEach = function(a, b) {
        var c = this;
        Mw.prototype.forEach.call(this, function(d, e) {
            a.call(b, c.get(e), e, c)
        })
    };
    _.q.set = function(a, b) {
        Nw(this);
        a = this.Fd(a, !0, !1);
        return null == a ? this : null == b ? (Mw.prototype.delete.call(this, a), this) : Mw.prototype.set.call(this, a, this.Ug(b, !0, !0, this.sf, !1, this.ee))
    };
    _.q.has = function(a) {
        return Mw.prototype.has.call(this, this.Fd(a, !1, !1))
    };
    _.q.get = function(a) {
        a = this.Fd(a, !1, !1);
        var b = Mw.prototype.get.call(this, a);
        if (void 0 !== b) {
            var c = this.sf;
            return c ? (c = this.Ug(b, !1, !0, c, this.Ej, this.ee), c !== b && Mw.prototype.set.call(this, a, c), c) : b
        }
    };
    xd.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return _.A(this, "entries").call(this)
    };
    xd.prototype.toJSON = void 0;
    xd.prototype.Vk = fc;
    Object.freeze({});
    var bo, Md, Bn, Dp, Il, yk, Ud, rk, zk, wk, Jo, Ow, is, Uh, yj, Cp, Sh, Pw, Qw, Br, Zq, Sw, Tw, Vw, Ww, Bo, Xw, Yw, Zw, xj, On, $w;
    bo = function(a, b) {
        a = a.D;
        return Md(a, Gd(a), b)
    };
    Md = function(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= ec(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    };
    _.ni = function(a, b, c) {
        var d = a.D,
            e = Gd(d);
        pc(e);
        Ld(d, e, b, c);
        return a
    };
    Bn = function(a, b, c) {
        return void 0 !== Ow(a, b, c, !1)
    };
    Dp = function(a) {
        a = a.D;
        var b = Gd(a),
            c = Md(a, b, 3),
            d = Ac(c);
        null != d && d !== c && Ld(a, b, 3, d);
        return d
    };
    Il = function(a, b) {
        return Dc(bo(a, b))
    };
    yk = function(a, b) {
        a = a.D;
        var c = Gd(a),
            d = Md(a, c, b),
            e = nc(d, !0, !!(c & 34));
        null != e && e !== d && Ld(a, c, b, e);
        return null == e ? mc() : e
    };
    _.Lh = function(a, b, c) {
        return _.be(a, b, c, $c)
    };
    rk = function(a, b, c, d) {
        var e = a.D,
            f = Gd(e);
        pc(f);
        (c = de(e, f, c)) && c !== b && null != d && (f = Ld(e, f, c));
        Ld(e, f, b, d);
        return a
    };
    zk = function(a, b, c) {
        a = a.D;
        return de(a, Gd(a), b) === c ? c : -1
    };
    wk = function(a, b) {
        a = a.D;
        return de(a, Gd(a), b)
    };
    Jo = function(a, b, c) {
        a = a.D;
        var d = Gd(a);
        pc(d);
        var e = Md(a, d, c);
        b = nd(ed(e, b, !0, d));
        e !== b && Ld(a, d, c, b);
        return b
    };
    Ow = function(a, b, c, d) {
        a = a.D;
        var e = Gd(a),
            f = Md(a, e, c, d);
        b = ed(f, b, !1, e);
        b !== f && null != b && Ld(a, e, c, b, d);
        return b
    };
    is = function(a, b, c) {
        return (a = Ow(a, b, c, !1)) ? a : dd(b)
    };
    _.Qh = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        b = Ow(a, b, c, d);
        if (null == b) return b;
        a = a.D;
        var e = Gd(a);
        if (!(e & 2)) {
            var f = nd(b);
            f !== b && (b = f, Ld(a, e, c, b, d))
        }
        return b
    };
    Uh = function(a, b, c) {
        a = a.D;
        var d = Gd(a),
            e = !!(2 & d);
        return ee(a, d, b, c, e ? 1 : 2, !1, !e)
    };
    _.kh = function(a, b, c) {
        null == c && (c = void 0);
        return _.ni(a, b, c)
    };
    _.qh = function(a, b, c, d) {
        null == d && (d = void 0);
        return rk(a, b, c, d)
    };
    _.gl = function(a, b, c) {
        var d = a.D,
            e = Gd(d);
        pc(e);
        if (null == c) return Ld(d, e, b), a;
        for (var f = Ub(c), g = f, h = !!(2 & f) || !!(2048 & f), k = h || Object.isFrozen(c), l = !k && !1, m = !0, n = !0, p = 0; p < c.length; p++) {
            var r = c[p];
            h || (r = !!(Ub(r.D) & 2), m && (m = !r), n && (n = r))
        }
        h || (f = Xb(f, 5, !0), f = Xb(f, 8, m), f = Xb(f, 16, n), l && (f = Xb(f, n ? 2 : 2048, !0)), f !== g && (k && (c = Sb(c), f = Qd(f, e, !0)), Vb(c, f)), l && Object.freeze(c));
        Ld(d, e, b, c);
        return a
    };
    yj = function(a, b, c, d) {
        fe(a, b, c, d);
        return a
    };
    Cp = function(a, b) {
        return Lc(bo(a, b))
    };
    Sh = function(a, b) {
        return Oc(bo(a, b))
    };
    Pw = function(a, b) {
        a = bo(a, b);
        a = null == a ? a : Fc(a) ? "number" === typeof a ? Vc(a) : Wc(a, !1) : void 0;
        return a
    };
    Qw = function(a, b) {
        return Rd(a, b, Xc, void 0, void 0, void 0, 0)
    };
    _.sj = function(a, b) {
        return bd(bo(a, b))
    };
    _.bl = function(a, b, c, d, e) {
        return Rd(a, b, bd, c, d, e)
    };
    _.L = function(a, b, c) {
        return ge(Il(a, b), void 0 === c ? !1 : c)
    };
    _.Rw = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ge(Cp(a, b), c)
    };
    Br = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ge(Sh(a, b), c)
    };
    _.mf = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ge(Xc(bo(a, b)), c)
    };
    Zq = function(a, b) {
        var c = void 0 === c ? 0 : c;
        return ge(Pw(a, b), c)
    };
    Sw = function(a) {
        var b = void 0 === b ? "0" : b;
        return ge(Yc(bo(a, 2)), b)
    };
    _.R = function(a, b) {
        return ge(_.sj(a, b), "")
    };
    _.Ak = function(a, b, c) {
        return ge(bo(a, b), void 0 === c ? 0 : c)
    };
    Tw = function(a, b, c) {
        a = _.bl(a, b, void 0, 3, !0);
        if ("number" !== typeof c || 0 > c || c >= a.length) throw Error();
        return a[c]
    };
    Vw = function(a) {
        return _.mf(a, zk(a, Uw, 3))
    };
    Ww = function(a, b) {
        return _.R(a, zk(a, b, 2))
    };
    Bo = function(a, b) {
        a = Il(a, b);
        return null == a ? void 0 : a
    };
    Xw = function(a, b) {
        a = Cp(a, b);
        return null == a ? void 0 : a
    };
    Yw = function(a, b) {
        a = _.sj(a, b);
        return null == a ? void 0 : a
    };
    Zw = function(a, b) {
        a = bo(a, b);
        return null == a ? void 0 : a
    };
    xj = function(a, b, c) {
        return _.ni(a, b, null == c ? c : Cc(c))
    };
    _.oh = function(a, b, c) {
        return _.ce(a, b, null == c ? c : Cc(c), !1)
    };
    _.Lo = function(a, b, c) {
        return _.ni(a, b, null == c ? c : Kc(c))
    };
    _.ph = function(a, b, c) {
        return _.ce(a, b, null == c ? c : Kc(c), 0)
    };
    _.qk = function(a, b, c) {
        return _.ni(a, b, Tc(c))
    };
    _.hh = function(a, b, c) {
        return _.ce(a, b, Tc(c), "0")
    };
    On = function(a, b, c) {
        return _.ni(a, b, ad(c))
    };
    _.ih = function(a, b, c) {
        return _.ce(a, b, ad(c), "")
    };
    _.co = function(a, b, c) {
        return _.ni(a, b, null == c ? c : Ic(c))
    };
    _.H = function(a, b, c) {
        return _.ce(a, b, null == c ? c : Ic(c), 0)
    };
    $w = function(a, b, c) {
        var d = a.D,
            e = Gd(d);
        pc(e);
        b = Pd(d, e, b, 2);
        d = Ub(b);
        c = $c(c, !!(4 & d) && !!(4096 & d));
        b.push(c);
        return a
    };
    _.E = function(a, b, c) {
        this.D = _.B(a, b, c)
    };
    _.E.prototype.toJSON = function() {
        if (Hw) var a = ie(this, this.D, !1);
        else a = Bd(this.D, Dd, void 0, void 0, !1, !1), a = ie(this, a, !0);
        return a
    };
    var tk = function(a) {
        Hw = !0;
        try {
            return JSON.stringify(a.toJSON(), sd)
        } finally {
            Hw = !1
        }
    };
    _.E.prototype.kg = cd;
    var le = (0, _.v.Symbol)(),
        re = (0, _.v.Symbol)(),
        ue = (0, _.v.Symbol)(),
        ax = xe(function(a, b, c) {
            b = Ac(b);
            null != b && (ze(a.j, 8 * c + 5), a = a.j, c = xw || (xw = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), Lb = 0, b = Kb = c.getUint32(0, !0), a.j.push(b >>> 0 & 255), a.j.push(b >>> 8 & 255), a.j.push(b >>> 16 & 255), a.j.push(b >>> 24 & 255))
        }),
        bx = xe(Be),
        cx = xe(Be),
        dx = xe(function(a, b, c) {
            a: if (null != b) {
                if (Fc(b)) {
                    if ("string" === typeof b) {
                        b = Wc(b, !1);
                        break a
                    }
                    if ("number" === typeof b) {
                        b = Vc(b);
                        break a
                    }
                }
                b = void 0
            }null != b && ("string" === typeof b && Aw(b), null != b && (ze(a.j, 8 * c), "number" === typeof b ? (a = a.j, Nb(b), Ae(a, Kb, Lb)) : (c = Aw(b), Ae(a.j, c.o, c.j))))
        }),
        ex = xe(function(a, b, c) {
            b = Lc(b);
            null != b && null != b && (ze(a.j, 8 * c), Ew(a.j, b))
        }),
        fx = xe(function(a, b, c) {
            b = Dc(b);
            null != b && (ze(a.j, 8 * c), a.j.j.push(b ? 1 : 0))
        }),
        gx = xe(function(a, b, c) {
            b = bd(b);
            null != b && Fw(a, c, vb(b))
        }),
        hx;
    hx = new se(function(a, b, c) {
        if (Array.isArray(b)) {
            var d = Ub(b);
            if (!(d & 4)) {
                for (var e = 0, f = 0; e < b.length; e++) {
                    var g = bd(b[e]);
                    null != g && (b[f++] = g)
                }
                f < e && (b.length = f);
                Vb(b, (d | 5) & -12289);
                d & 2 && Object.freeze(b)
            }
        } else b = void 0;
        if (null != b)
            for (d = 0; d < b.length; d++) e = b[d], null != e && Fw(a, c, vb(e))
    }, !1);
    var ve = new se(De, !0),
        te = new se(De, !0),
        ix;
    ix = new se(function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) De(a, b[f], c, d, e)
    }, !0);
    var jx = xe(function(a, b, c) {
        b = Lc(b);
        null != b && (b = parseInt(b, 10), ze(a.j, 8 * c), Ew(a.j, b))
    });
    var Ee = void 0;
    var tq = function(a) {
        this.D = _.B(a)
    };
    _.T(tq, _.E);
    var uq = function(a) {
        this.D = _.B(a)
    };
    _.T(uq, _.E);
    var kx = function(a) {
            this.j = a.o;
            this.o = a.m;
            this.A = a.A;
            this.Ed = a.Ed;
            this.B = a.B;
            this.Xc = a.Xc;
            this.Je = a.Je;
            this.jf = a.jf;
            this.He = a.He;
            this.m = a.j
        },
        lx = function(a, b, c) {
            this.o = a;
            this.m = b;
            this.A = c;
            this.B = window;
            this.Xc = "env";
            this.Je = "n";
            this.jf = "0";
            this.He = "1";
            this.j = !0
        };
    lx.prototype.build = function() {
        return new kx(this)
    };
    var Dq = function(a, b) {
        var c = void 0 === _.L(b, 6) ? !0 : _.L(b, 6),
            d, e, f = Ke(_.Ak(b, 2, 0)),
            g = _.R(b, 3);
        a: switch (_.Ak(b, 4, 0)) {
            case 1:
                var h = "pt";
                break a;
            case 2:
                h = "cr";
                break a;
            default:
                h = ""
        }
        f = new lx(f, g, h);
        b = null != (e = null == (d = _.Qh(b, tq, 5)) ? void 0 : _.R(d, 1)) ? e : "";
        f.Ed = b;
        f.j = c;
        f.B = a;
        return f.build()
    };
    var lo = function(a) {
        this.D = _.B(a)
    };
    _.T(lo, _.E);
    lo.prototype.getId = function() {
        return _.R(this, 1)
    };
    var ko = function(a, b) {
            return On(a, 1, b)
        },
        mx = [0, gx];
    var ro = function(a) {
        this.D = _.B(a)
    };
    _.T(ro, _.E);
    ro.prototype.getWidth = function() {
        return _.Rw(this, 1)
    };
    var qo = function(a, b) {
        return _.Lo(a, 1, b)
    };
    ro.prototype.getHeight = function() {
        return _.Rw(this, 2)
    };
    var po = function(a, b) {
            return _.Lo(a, 2, b)
        },
        nx = [0, ex, -1];
    var ox = [0, cx, fx];
    var io = function(a) {
        this.D = _.B(a)
    };
    _.T(io, _.E);
    var mo = function(a, b) {
            _.Lh(a, 4, b)
        },
        jo = function(a, b) {
            _.kh(a, 6, b)
        },
        oo = function(a, b) {
            _.kh(a, 7, b)
        };
    io.ca = [4];
    var px = [0, gx, cx, gx, hx, jx, mx, nx, cx, ox];
    var Nn = function(a) {
        this.D = _.B(a)
    };
    _.T(Nn, _.E);
    var Mn = function(a, b) {
            return _.co(a, 1, b)
        },
        Kn = function(a, b) {
            return xj(a, 4, b)
        },
        Ln = function(a, b) {
            return _.Lo(a, 2, b)
        },
        qx = [0, jx, ex, gx, fx];
    var Yn = function(a) {
        this.D = _.B(a)
    };
    _.T(Yn, _.E);
    var Xn = function(a, b) {
            return On(a, 1, b)
        },
        $n = function(a, b) {
            _.qk(a, 2, b)
        },
        Vn = function(a, b) {
            return yj(a, 3, io, b)
        },
        Wn = function(a, b) {
            return _.co(a, 4, b)
        };
    Yn.prototype.Gh = function() {
        return _.Ak(this, 7, 0)
    };
    Yn.ca = [10, 3];
    var rx = [0, gx, cx, ix, px, jx, qx, fx, jx, 2, hx];
    var sx = function(a) {
        this.D = _.B(a)
    };
    _.T(sx, _.E);
    var tx = [0, jx, fx];
    var ux = function(a) {
        this.D = _.B(a)
    };
    _.T(ux, _.E);
    var Un = function(a, b) {
            return fe(a, 2, Yn, b)
        },
        fo = function(a, b) {
            _.kh(a, 5, b)
        },
        vx = function(a, b) {
            _.kh(a, 9, b)
        };
    ux.ca = [2];
    var wx = [0, jx, ix, rx, jx, gx, qx, gx, fx, ex, tx];
    var xx = function(a) {
        this.D = _.B(a)
    };
    _.T(xx, _.E);
    var yx = function(a) {
        var b = new ux;
        b = _.co(b, 1, 1);
        return fe(a, 1, ux, b)
    };
    xx.ca = [1];
    xx.prototype.j = Ie([0, ix, wx]);
    var zx = function(a) {
        this.D = _.B(a)
    };
    _.T(zx, _.E);
    var Uw = [2, 3];
    var Ax = function(a) {
        this.D = _.B(a)
    };
    _.T(Ax, _.E);
    Ax.ca = [1];
    var Bx = function(a) {
        this.D = _.B(a)
    };
    _.T(Bx, _.E);
    Bx.ca = [1];
    var Cx = function(a) {
        this.D = _.B(a)
    };
    _.T(Cx, _.E);
    var Dx = [2, 3];
    var Ex = function(a) {
        this.D = _.B(a)
    };
    _.T(Ex, _.E);
    Ex.ca = [2];
    var Fx = function(a) {
        this.D = _.B(a)
    };
    _.T(Fx, _.E);
    Fx.ca = [6, 4];
    var Gx = function(a) {
        this.D = _.B(a)
    };
    _.T(Gx, _.E);
    Gx.ca = [4, 5];
    var Hx = function(a) {
        this.D = _.B(a)
    };
    _.T(Hx, _.E);
    var Ix = function(a) {
        this.D = _.B(a)
    };
    _.T(Ix, _.E);
    Ix.prototype.Ge = function() {
        return is(this, Hx, 2)
    };
    Ix.ca = [1];
    var Jx = function(a) {
        this.D = _.B(a)
    };
    _.T(Jx, _.E);
    var Kx = function(a) {
        this.D = _.B(a)
    };
    _.T(Kx, _.E);
    Kx.ca = [1];
    var Lx = function(a) {
        this.D = _.B(a)
    };
    _.T(Lx, _.E);
    var Mx = [0, jx, cx];
    var Nx = function(a) {
        this.D = _.B(a)
    };
    _.T(Nx, _.E);
    var Ox = [0, bx];
    var Px = function(a) {
        this.D = _.B(a)
    };
    _.T(Px, _.E);
    Px.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 1)
    };
    var Qx = [0, gx, Ox, Mx];
    var Rx = function(a) {
        this.D = _.B(a)
    };
    _.T(Rx, _.E);
    Rx.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    var Sx = function(a) {
        this.D = _.B(a)
    };
    _.T(Sx, _.E);
    Sx.ca = [5];
    _.Tx = function(a) {
        this.D = _.B(a)
    };
    _.T(_.Tx, _.E);
    _.Ux = function(a) {
        return Uh(a, Sx, 15)
    };
    _.Tx.prototype.ud = ba(0);
    _.Tx.prototype.vd = ba(1);
    _.Tx.prototype.Fe = ba(2);
    _.Tx.ca = [15];
    var Vx = function(a) {
        this.D = _.B(a)
    };
    _.T(Vx, _.E);
    Vx.prototype.getAdUnitPath = function() {
        return _.R(this, 2)
    };
    var Wx = function(a) {
        this.D = _.B(a)
    };
    _.T(Wx, _.E);
    var Xx = [5, 7, 8, 9];
    var Yx = function(a) {
        this.D = _.B(a)
    };
    _.T(Yx, _.E);
    var Zx = function(a) {
        this.D = _.B(a)
    };
    _.T(Zx, _.E);
    Zx.ca = [4, 5, 6];
    var $x = function(a) {
        this.D = _.B(a)
    };
    _.T($x, _.E);
    $x.prototype.getValue = function() {
        return _.R(this, 2)
    };
    $x.prototype.Wf = function() {
        return null != _.sj(this, 2)
    };
    var ay = function(a) {
        this.D = _.B(a)
    };
    _.T(ay, _.E);
    ay.ca = [13];
    var by = function(a) {
        this.D = _.B(a)
    };
    _.T(by, _.E);
    by.ca = [15, 13];
    var cy = function(a) {
        this.D = _.B(a)
    };
    _.T(cy, _.E);
    var dy = function(a) {
            var b = new cy;
            return _.co(b, 1, a)
        },
        ey = [0, jx];
    var rj = function(a) {
        this.D = _.B(a)
    };
    _.T(rj, _.E);
    var fy = function(a) {
            var b = new rj;
            return On(b, 1, a)
        },
        gy = function(a) {
            var b = window.Date.now();
            b = _.A(Number, "isFinite").call(Number, b) ? Math.round(b) : 0;
            return _.qk(a, 3, b)
        };
    rj.prototype.ib = function(a) {
        return _.kh(this, 10, a)
    };
    var hy = Je(rj),
        iy = [0, gx, -1, cx, ex, -2, cx, ax, fx, ey, fx];
    var jy = [0, 1, [0, dx, -2], -1, gx, -1, fx, [0, 3, jx, gx], cx];
    var ky = function(a) {
        this.D = _.B(a)
    };
    _.T(ky, _.E);
    ky.ca = [1, 2];
    ky.prototype.j = Ie([0, ix, jy, ix, iy]);
    var ly = function(a) {
        this.D = _.B(a)
    };
    _.T(ly, _.E);
    var my = function(a) {
        this.D = _.B(a)
    };
    _.T(my, _.E);
    my.prototype.getValue = function() {
        return _.R(this, 1)
    };
    my.prototype.Wf = function() {
        return null != _.sj(this, 1)
    };
    my.prototype.getVersion = function() {
        return _.Ak(this, 5, 0)
    };
    var ny = function(a) {
        this.D = _.B(a)
    };
    _.T(ny, _.E);
    var oy = function(a) {
        this.D = _.B(a)
    };
    _.T(oy, _.E);
    oy.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    var py = function(a) {
        this.D = _.B(a)
    };
    _.T(py, _.E);
    var qy = function(a) {
        this.D = _.B(a)
    };
    _.T(qy, _.E);
    var ry = function(a) {
        this.D = _.B(a)
    };
    _.T(ry, _.E);
    ry.prototype.getContentUrl = function() {
        return _.R(this, 2)
    };
    var sy = function(a) {
        this.D = _.B(a)
    };
    _.T(sy, _.E);
    sy.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 4)
    };
    sy.ca = [2];
    var ty = function(a) {
        this.D = _.B(a)
    };
    _.T(ty, _.E);
    var uy = function(a) {
        this.D = _.B(a)
    };
    _.T(uy, _.E);
    var vy = function(a) {
        this.D = _.B(a)
    };
    _.T(vy, _.E);
    var wy = function(a) {
        this.D = _.B(a)
    };
    _.T(wy, _.E);
    var xy = function(a) {
        this.D = _.B(a)
    };
    _.T(xy, _.E);
    xy.prototype.getEscapedQemQueryId = function() {
        return _.R(this, 2)
    };
    var yy = function(a) {
        this.D = _.B(a)
    };
    _.T(yy, _.E);
    var zy = function(a) {
        this.D = _.B(a)
    };
    _.T(zy, _.E);
    zy.prototype.getWidth = function() {
        return _.Rw(this, 9)
    };
    zy.prototype.getHeight = function() {
        return _.Rw(this, 10)
    };
    zy.ca = [3, 7, 27, 11];
    var Ay = function(a) {
        this.D = _.B(a)
    };
    _.T(Ay, _.E);
    Ay.prototype.getHeight = function() {
        return Cp(this, 6)
    };
    Ay.prototype.getWidth = function() {
        return Cp(this, 7)
    };
    Ay.prototype.getEscapedQemQueryId = function() {
        return _.sj(this, 34)
    };
    Ay.ca = [14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 23, 27, 38, 53, 62, 63, 67];
    var By = [39, 48];
    var Cy = function(a) {
        this.D = _.B(a)
    };
    _.T(Cy, _.E);
    var rq = Je(Cy);
    var Dy = function(a) {
        this.D = _.B(a)
    };
    _.T(Dy, _.E);
    var Ey = Je(Dy);
    Dy.ca = [1, 2, 3];
    var Fy = window;
    var Gt = function(a) {
        this.D = _.B(a)
    };
    _.T(Gt, _.E);
    Gt.ca = [15];
    var Ft = function(a) {
        this.D = _.B(a)
    };
    _.T(Ft, _.E);
    Ft.prototype.getCorrelator = function() {
        return _.mf(this, 1)
    };
    Ft.prototype.setCorrelator = function(a) {
        return _.hh(this, 1, a)
    };
    var Et = function(a) {
        this.D = _.B(a)
    };
    _.T(Et, _.E);
    var Gy = _.aw || dw;
    var Iy, Jy;
    _.Hy = yi(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = _.Lv(Qv);
        return !b.parentElement
    });
    Iy = function(a, b) {
        b = b instanceof _.Ra ? b : _.wv(b);
        a.href = _.$a(b)
    };
    Jy = /^[\w+/_-]+[=]{0,2}$/;
    _.rp = function(a, b) {
        b = (b || _.t).document;
        return b.querySelector ? (a = b.querySelector(a)) && (a = a.nonce || a.getAttribute("nonce")) && Jy.test(a) ? a : "" : ""
    };
    _.gi = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    _.gi.prototype.equals = function(a) {
        return a instanceof _.gi && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    _.gi.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    _.gi.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    _.gi.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    _.ki = function(a, b) {
        this.width = a;
        this.height = b
    };
    _.q = _.ki.prototype;
    _.q.aspectRatio = function() {
        return this.width / this.height
    };
    _.q.isEmpty = function() {
        return !(this.width * this.height)
    };
    _.q.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    _.q.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    _.q.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Ky, Ly, Ny;
    Ky = function() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Date.now()).toString(36)
    };
    Ly = 2147483648 * Math.random() | 0;
    _.My = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    Ny = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var cf, Ry, Qy, Uy, Wy, az;
    cf = function(a) {
        return a ? new _.Oy(_.Py(a)) : Ou || (Ou = new _.Oy)
    };
    Ry = function(a, b) {
        Aa(b, function(c, d) {
            c && "object" == typeof c && c.qb && (c = c.ab());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : Qy.hasOwnProperty(d) ? a.setAttribute(Qy[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
        })
    };
    Qy = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.Ty = function(a) {
        a = a.document;
        a = _.Sy(a) ? a.documentElement : a.body;
        return new _.ki(a.clientWidth, a.clientHeight)
    };
    Uy = function(a) {
        return a.scrollingElement ? a.scrollingElement : !dw && _.Sy(a) ? a.documentElement : a.body || a.documentElement
    };
    _.Vy = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    };
    Wy = function(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!_.ta(f) || _.ja(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (_.ja(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                _.Yu(g ? _.ha(f) : f, d)
            }
        }
    };
    _.Xy = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    };
    _.Sy = function(a) {
        return "CSS1Compat" == a.compatMode
    };
    _.Yy = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    _.Zy = function(a) {
        var b;
        if (Gy && (b = a.parentElement)) return b;
        b = a.parentNode;
        return _.ja(b) && 1 == b.nodeType ? b : null
    };
    _.$y = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    _.Py = function(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    };
    az = function(a) {
        try {
            return a.contentWindow || (a.contentDocument ? _.Vy(a.contentDocument) : null)
        } catch (b) {}
        return null
    };
    _.Ug = function(a, b, c, d) {
        a && !c && (a = a.parentNode);
        for (c = 0; a && (null == d || c <= d);) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    };
    _.Oy = function(a) {
        this.j = a || _.t.document || document
    };
    _.q = _.Oy.prototype;
    _.q.xk = function(a) {
        return "string" === typeof a ? this.j.getElementById(a) : a
    };
    _.q.pm = _.Oy.prototype.xk;
    _.q.getElementsByTagName = function(a, b) {
        return (b || this.j).getElementsByTagName(String(a))
    };
    _.q.createElement = function(a) {
        return _.Xy(this.j, a)
    };
    _.q.createTextNode = function(a) {
        return this.j.createTextNode(String(a))
    };
    _.q.append = function(a, b) {
        Wy(_.Py(a), a, arguments)
    };
    _.q.mj = _.Yy;
    _.q.contains = _.$y;
    var cz = function() {
            return Ga && Ha ? Ha.mobile : !bz() && (Ka("iPod") || Ka("iPhone") || Ka("Android") || Ka("IEMobile"))
        },
        bz = function() {
            return Ga && Ha ? !Ha.mobile && (Ka("iPad") || Ka("Android") || Ka("Silk")) : Ka("iPad") || Ka("Android") && !Ka("Mobile") || Ka("Silk")
        };
    var ez, Bl, fz, cn;
    _.dz = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    ez = function(a) {
        return a ? decodeURI(a) : a
    };
    Bl = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) Bl(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };
    _.zq = function(a, b) {
        var c = [];
        for (d in b) Bl(d, b[d], c);
        b = c.join("&");
        if (b) {
            c = a.indexOf("#");
            0 > c && (c = a.length);
            var d = a.indexOf("?");
            if (0 > d || d > c) {
                d = c;
                var e = ""
            } else e = a.substring(d + 1, c);
            a = [a.slice(0, d), e, a.slice(c)];
            c = a[1];
            a[1] = b ? c ? c + "&" + b : b : c;
            a = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
        }
        return a
    };
    fz = /#|$/;
    cn = function(a, b) {
        var c = a.search(fz);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };
    var Ek, Nj, gz, Oj, zi, pn, Qt, iz, jz, Ai, kz, lz, mz, nz, oz, pz, qz, rz, sz, bj, dj, cj, En, tz, vz, wz, xz, yz, zz, Az, xm, om, Bz, Gl, Cz, Dz;
    _.fk = function(a) {
        try {
            return !!a && null != a.location.href && Zv(a, "foo")
        } catch (b) {
            return !1
        }
    };
    Ek = function(a, b, c, d) {
        b = void 0 === b ? !1 : b;
        d = void 0 === d ? _.t : d;
        c = (void 0 === c ? 0 : c) ? gz(d) : d;
        for (d = 0; c && 40 > d++ && (!b && !_.fk(c) || !a(c));) c = gz(c)
    };
    Nj = function() {
        var a = window;
        Ek(function(b) {
            a = b;
            return !1
        });
        return a
    };
    gz = function(a) {
        try {
            var b = a.parent;
            if (b && b != a) return b
        } catch (c) {}
        return null
    };
    Oj = function(a) {
        return _.fk(a.top) ? a.top : null
    };
    _.an = function(a, b) {
        var c = _.af("SCRIPT", a);
        hb(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    };
    zi = function(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    };
    _.Qf = function() {
        if (!_.v.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            _.v.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    _.El = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    _.hz = function(a) {
        var b = [];
        _.El(a, function(c) {
            b.push(c)
        });
        return b
    };
    pn = function(a, b) {
        return Ca(a, function(c, d) {
            return Object.prototype.hasOwnProperty.call(a, d) && b(c, d)
        })
    };
    _.Rf = function(a) {
        var b = a.length;
        if (0 == b) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    };
    _.Rt = yi(function() {
        return _.Sg(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], iz) || 1E-4 > Math.random()
    });
    Qt = yi(function() {
        return iz("MSIE")
    });
    iz = function(a) {
        return _.Ia(Fa(), a)
    };
    jz = /^([0-9.]+)px$/;
    Ai = function(a) {
        return (a = jz.exec(a)) ? +a[1] : null
    };
    kz = function() {
        var a = window;
        try {
            for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                case "https:":
                    return !0;
                case "file:":
                    return !0;
                case "http:":
                    return !1
            }
        } catch (c) {}
        return !0
    };
    lz = function(a) {
        if (!a) return "";
        var b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            var c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && 1 < c[1].length ? c[1].substring(1) : "true"
        } catch (d) {}
        return ""
    };
    mz = {
        tm: "allow-forms",
        um: "allow-modals",
        vm: "allow-orientation-lock",
        wm: "allow-pointer-lock",
        xm: "allow-popups",
        ym: "allow-popups-to-escape-sandbox",
        zm: "allow-presentation",
        Am: "allow-same-origin",
        Bm: "allow-scripts",
        Cm: "allow-top-navigation",
        Dm: "allow-top-navigation-by-user-activation"
    };
    nz = yi(function() {
        return _.hz(mz)
    });
    oz = function(a) {
        var b = nz();
        return a.length ? _.Qg(b, function(c) {
            return !(0 <= _.ea(a, c))
        }) : b
    };
    pz = function() {
        var a = _.af("IFRAME"),
            b = {};
        _.Yu(nz(), function(c) {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    };
    qz = function(a) {
        a = a && a.toString && a.toString();
        return "string" === typeof a && _.Ia(a, "[native code]")
    };
    rz = function(a, b) {
        for (var c = 0; 50 > c; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (e) {
                d = !1
            }
            if (d) return a;
            if (!(a = gz(a))) break
        }
        return null
    };
    sz = function(a) {
        if (!a || !a.frames) return null;
        if (a.frames.google_ads_top_frame) return a.frames.google_ads_top_frame.frameElement;
        try {
            var b = a.document,
                c = b.head,
                d, e = null != (d = b.body) ? d : null == c ? void 0 : c.parentElement;
            if (e) {
                var f = _.af("IFRAME");
                f.name = "google_ads_top_frame";
                f.id = "google_ads_top_frame";
                f.style.display = "none";
                f.style.position = "fixed";
                f.style.left = "-999px";
                f.style.top = "-999px";
                f.style.width = "0px";
                f.style.height = "0px";
                e.appendChild(f);
                return f
            }
        } catch (g) {}
        return null
    };
    _.In = yi(function() {
        return cz() ? 2 : bz() ? 1 : 0
    });
    bj = function(a, b) {
        var c;
        for (c = void 0 === c ? 100 : c; a && c--;) {
            if (a == b) return !0;
            a = a.parentElement
        }
        return !1
    };
    _.Ki = function(a, b) {
        _.El(b, function(c, d) {
            a.style.setProperty(d, c, "important")
        })
    };
    dj = function(a, b, c) {
        for (c = void 0 === c ? 100 : c; a && c-- && !1 !== b(a);) a = a.parentElement
    };
    cj = function(a, b) {
        for (var c = 100; a && c--;) {
            var d = zi(a, window);
            if (d) {
                if (b(d, a)) return !0;
                a = a.parentElement
            }
        }
        return !1
    };
    En = function(a) {
        if (!a) return null;
        a = a.transform;
        if (!a) return null;
        a = a.replace(/^.*\(([0-9., -]+)\)$/, "$1").split(/, /);
        return 6 != a.length ? null : _.Zu(a, parseFloat)
    };
    tz = {};
    _.uz = (tz["http://googleads.g.doubleclick.net"] = !0, tz["http://pagead2.googlesyndication.com"] = !0, tz["https://googleads.g.doubleclick.net"] = !0, tz["https://pagead2.googlesyndication.com"] = !0, tz);
    vz = function(a) {
        _.t.console && _.t.console.warn && _.t.console.warn(a)
    };
    wz = [];
    xz = function() {
        var a = wz;
        wz = [];
        a = _.z(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                b()
            } catch (c) {}
        }
    };
    yz = function(a) {
        return a.replace(/\\(n|r|\\)/g, function(b, c) {
            return "n" == c ? "\n" : "r" == c ? "\r" : "\\"
        })
    };
    zz = function() {
        var a = void 0 === a ? Math.random : a;
        return Math.floor(a() * Math.pow(2, 52))
    };
    _.Ih = function(a) {
        if ("number" !== typeof a.goog_pvsid) try {
            Object.defineProperty(a, "goog_pvsid", {
                value: zz(),
                configurable: !1
            })
        } catch (b) {}
        return Number(a.goog_pvsid) || -1
    };
    Az = function(a, b) {
        "complete" === a.readyState || "interactive" === a.readyState ? (wz.push(b), 1 == wz.length && (_.v.Promise ? _.v.Promise.resolve().then(xz) : window.setImmediate ? setImmediate(xz) : setTimeout(xz, 0))) : a.addEventListener("DOMContentLoaded", b)
    };
    xm = function(a) {
        return "number" === typeof a && isFinite(a) && 0 == a % 1 && 0 < a
    };
    om = function(a) {
        return 0 === a || xm(a)
    };
    Bz = function(a) {
        return new _.v.Promise(function(b) {
            setTimeout(function() {
                return void b(void 0)
            }, a)
        })
    };
    Gl = function(a) {
        try {
            var b = JSON.stringify(a)
        } catch (c) {}
        return b || String(a)
    };
    _.af = function(a, b) {
        b = void 0 === b ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    Cz = function(a) {
        for (var b = a; a && a != a.parent;) a = a.parent, _.fk(a) && (b = a);
        return b
    };
    _.wg = function(a) {
        return Ma() && cz() ? Dz(a, !0) : 1
    };
    Dz = function(a, b) {
        var c = (void 0 === b ? 0 : b) ? Oj(a) : a;
        if (!c) return 1;
        a = 0 === (0, _.In)();
        b = !!c.document.querySelector('meta[name=viewport][content*="width=device-width"]');
        var d = c.innerWidth;
        c = c.outerWidth;
        return 0 === d ? 1 : a || b ? Math.round(100 * (c / d + _.A(Number, "EPSILON"))) / 100 : Math.round(100 * (c / d / .4 + _.A(Number, "EPSILON"))) / 100
    };
    _.Ez = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    _.Ez.prototype.getWidth = function() {
        return this.right - this.left
    };
    _.Ez.prototype.getHeight = function() {
        return this.bottom - this.top
    };
    _.Fz = function(a) {
        return new _.Ez(a.top, a.right, a.bottom, a.left)
    };
    _.Ez.prototype.contains = function(a) {
        return this && a ? a instanceof _.Ez ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    _.Ez.prototype.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    _.Ez.prototype.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    _.Ez.prototype.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    var Gz = function(a, b, c, d) {
            this.left = a;
            this.top = b;
            this.width = c;
            this.height = d
        },
        Hz = function(a) {
            return new _.Ez(a.top, a.left + a.width, a.top + a.height, a.left)
        },
        Iz = function(a, b) {
            var c = Math.max(a.left, b.left),
                d = Math.min(a.left + a.width, b.left + b.width);
            if (c <= d) {
                var e = Math.max(a.top, b.top);
                a = Math.min(a.top + a.height, b.top + b.height);
                if (e <= a) return new Gz(c, e, d - c, a - e)
            }
            return null
        };
    Gz.prototype.contains = function(a) {
        return a instanceof _.gi ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    Gz.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    Gz.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    Gz.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Jz = function(a) {
        return (a = void 0 === a ? Re() : a) ? _.fk(a.master) ? a.master : null : null
    };
    var Mz, Oz, ji, Pz, Qz, fi;
    _.Lz = function(a, b, c) {
        if ("string" === typeof b)(b = _.Kz(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = _.Kz(c, d);
                f && (c.style[f] = e)
            }
    };
    Mz = {};
    _.Kz = function(a, b) {
        var c = Mz[b];
        if (!c) {
            var d = _.My(b);
            c = d;
            void 0 === a.style[d] && (d = (dw ? "Webkit" : cw ? "Moz" : _.aw ? "ms" : null) + Ny(d), void 0 !== a.style[d] && (c = d));
            Mz[b] = c
        }
        return c
    };
    _.Nz = function(a, b) {
        var c = _.Py(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    };
    Oz = function(a, b) {
        return _.Nz(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    };
    ji = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };
    Pz = function(a) {
        if (_.aw && !(8 <= Number(mw))) return a.offsetParent;
        var b = _.Py(a),
            c = Oz(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = Oz(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
        return null
    };
    Qz = function(a) {
        var b = _.Py(a),
            c = new _.gi(0, 0);
        var d = b ? _.Py(b) : document;
        d = !_.aw || 9 <= Number(mw) || _.Sy(cf(d).j) ? d.documentElement : d.body;
        if (a == d) return c;
        a = ji(a);
        d = cf(b).j;
        b = Uy(d);
        d = d.parentWindow || d.defaultView;
        b = _.aw && d.pageYOffset != b.scrollTop ? new _.gi(b.scrollLeft, b.scrollTop) : new _.gi(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    };
    fi = function(a, b) {
        var c = new _.gi(0, 0),
            d = _.Vy(_.Py(a));
        if (!Zv(d, "parent")) return c;
        do {
            var e = d == b ? Qz(a) : _.Rz(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    _.Rz = function(a) {
        a = ji(a);
        return new _.gi(a.left, a.top)
    };
    _.Sz = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    };
    _.ii = function(a, b) {
        if ("none" != Oz(b, "display")) return a(b);
        var c = b.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = a(b);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    };
    _.Tz = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = dw && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = ji(a), new _.ki(a.right - a.left, a.bottom - a.top)) : new _.ki(b, c)
    };
    var Zi;
    _.Uz = _.ju(["//fonts.googleapis.com/css"]);
    Zi = function(a) {
        a = Jz(Re(a)) || a;
        a = a.google_unique_id;
        return "number" === typeof a ? a : 0
    };
    var Vz = function(a) {
        this.D = _.B(a)
    };
    _.T(Vz, _.E);
    var Wz = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var Xz = function(a) {
        this.D = _.B(a)
    };
    _.T(Xz, _.E);
    Xz.prototype.getVersion = function() {
        return _.Rw(this, 2)
    };
    Xz.ca = [3];
    var Yz = function(a) {
        this.D = _.B(a)
    };
    _.T(Yz, _.E);
    var Zz = function(a) {
        this.D = _.B(a)
    };
    _.T(Zz, _.E);
    var $z = function(a) {
        this.D = _.B(a)
    };
    _.T($z, _.E);
    $z.prototype.getVersion = function() {
        return _.Rw(this, 1)
    };
    var aA = function(a) {
        this.D = _.B(a)
    };
    _.T(aA, _.E);
    var bA = function(a) {
        this.D = _.B(a)
    };
    _.T(bA, _.E);
    var cA = function(a) {
        var b = new bA;
        return _.kh(b, 1, a)
    };
    var dA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        eA = dA.reduce(function(a, b) {
            return a + b
        });
    var fA = function(a) {
        this.D = _.B(a)
    };
    _.T(fA, _.E);
    var gA = function(a) {
        this.D = _.B(a)
    };
    _.T(gA, _.E);
    gA.prototype.getVersion = function() {
        return _.Rw(this, 1)
    };
    var hA = function(a) {
        this.D = _.B(a)
    };
    _.T(hA, _.E);
    var iA = function(a) {
        this.D = _.B(a)
    };
    _.T(iA, _.E);
    var jA = function(a) {
        var b = new iA;
        return _.kh(b, 1, a)
    };
    var kA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        lA = kA.reduce(function(a, b) {
            return a + b
        });
    var mA = function(a) {
        this.D = _.B(a)
    };
    _.T(mA, _.E);
    var nA = function(a) {
        this.D = _.B(a)
    };
    _.T(nA, _.E);
    var oA = function(a) {
        this.D = _.B(a)
    };
    _.T(oA, _.E);
    oA.prototype.getVersion = function() {
        return _.Rw(this, 1)
    };
    var pA = function(a) {
        this.D = _.B(a)
    };
    _.T(pA, _.E);
    var qA = function(a) {
        this.D = _.B(a)
    };
    _.T(qA, _.E);
    var rA = function(a) {
        var b = new qA;
        return _.kh(b, 1, a)
    };
    var sA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        tA = sA.reduce(function(a, b) {
            return a + b
        });
    var uA = function(a) {
        this.D = _.B(a)
    };
    _.T(uA, _.E);
    var vA = function(a) {
        this.D = _.B(a)
    };
    _.T(vA, _.E);
    vA.prototype.getVersion = function() {
        return _.Rw(this, 1)
    };
    var wA = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        xA = wA.reduce(function(a, b) {
            return a + b
        });
    var yA = function(a) {
        this.D = _.B(a)
    };
    _.T(yA, _.E);
    var zA = function(a, b) {
        var c = new yA;
        a = _.H(c, 1, a);
        b = _.ih(a, 2, b);
        this.J = _.Kd(b)
    };
    var AA = function(a) {
        this.D = _.B(a)
    };
    _.T(AA, _.E);
    var BA = [1, 2, 3];
    var CA = function(a) {
        this.D = _.B(a)
    };
    _.T(CA, _.E);
    var DA = [2, 4];
    var EA = function(a) {
        this.D = _.B(a)
    };
    _.T(EA, _.E);
    EA.ca = [4];
    var FA = function(a) {
        this.D = _.B(a)
    };
    _.T(FA, _.E);
    var GA = function(a) {
        this.D = _.B(a)
    };
    _.T(GA, _.E);
    var zh = function(a) {
        this.D = _.B(a)
    };
    _.T(zh, _.E);
    var nh = function(a) {
        this.D = _.B(a)
    };
    _.T(nh, _.E);
    var mh = function(a) {
        this.D = _.B(a)
    };
    _.T(mh, _.E);
    var jh = function(a) {
        this.D = _.B(a)
    };
    _.T(jh, _.E);
    var uh = function(a) {
        this.D = _.B(a)
    };
    _.T(uh, _.E);
    var HA = function(a) {
        this.D = _.B(a)
    };
    _.T(HA, _.E);
    var IA = function(a) {
        this.D = _.B(a)
    };
    _.T(IA, _.E);
    var gh = function(a) {
        this.D = _.B(a)
    };
    _.T(gh, _.E);
    gh.prototype.getTagSessionCorrelator = function() {
        return _.mf(this, 2)
    };
    var th = function(a) {
        var b = new HA;
        return _.qh(a, 13, rh, b)
    };
    gh.ca = [4];
    var rh = [6, 7, 8, 9, 11, 13, 14];
    var Ko = function(a) {
        this.D = _.B(a)
    };
    _.T(Ko, _.E);
    var Ho = function(a) {
        this.D = _.B(a)
    };
    _.T(Ho, _.E);
    var Io = [1, 2, 3, 4];
    var Do = function(a) {
        this.D = _.B(a)
    };
    _.T(Do, _.E);
    Do.prototype.getTagSessionCorrelator = function() {
        return _.mf(this, 2)
    };
    Do.ca = [4];
    var Mh = function(a) {
        this.D = _.B(a)
    };
    _.T(Mh, _.E);
    Mh.ca = [3];
    var Jh = function(a) {
        this.D = _.B(a)
    };
    _.T(Jh, _.E);
    Jh.ca = [4, 5];
    var Hh = function(a) {
        this.D = _.B(a)
    };
    _.T(Hh, _.E);
    Hh.prototype.getTagSessionCorrelator = function() {
        return _.mf(this, 1)
    };
    Hh.ca = [2];
    var Gh = function(a) {
        this.D = _.B(a)
    };
    _.T(Gh, _.E);
    var Ph = [4, 6];
    var JA = function(a) {
        this.D = _.B(a)
    };
    _.T(JA, _.E);
    JA.prototype.getTagSessionCorrelator = function() {
        return _.mf(this, 1)
    };
    JA.prototype.getMessageId = function() {
        return _.Ak(this, 8, 0)
    };
    JA.prototype.getMessageArgs = function(a) {
        return Tw(this, 9, a)
    };
    JA.ca = [2, 9];
    var KA = function() {
            zA.apply(this, arguments)
        },
        wh;
    _.T(KA, zA);
    wh = function(a, b) {
        var c = void 0 === b.Cb ? 1 : b.Cb,
            d = void 0 === b.step ? 1 : b.step;
        b = b.tf;
        var e = new EA;
        e = _.ih(e, 1, "uWt0se");
        var f = new AA;
        b = rk(f, 1, BA, ad(b));
        b = yj(e, 4, AA, b);
        c = _.hh(b, 2, Math.round(c));
        b = new CA;
        d = rk(b, 2, DA, Tc(Math.round(d)));
        d = _.kh(c, 3, d);
        a.Gl(d)
    };
    _.LA = function() {
        KA.apply(this, arguments)
    };
    _.T(_.LA, KA);
    _.q = _.LA.prototype;
    _.q.Hl = function() {
        this.o.apply(this, _.ch(_.Wa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Yc: 2,
                Oc: a.toJSON()
            }
        })))
    };
    _.q.Ac = function() {
        this.o.apply(this, _.ch(_.Wa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Yc: 5,
                Oc: a.toJSON()
            }
        })))
    };
    _.q.Hi = function() {
        this.o.apply(this, _.ch(_.Wa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Yc: 15,
                Oc: a.toJSON()
            }
        })))
    };
    _.q.Ii = ba(3);
    _.q.Jl = function() {
        this.o.apply(this, _.ch(_.Wa.apply(0, arguments).map(function(a) {
            return {
                vc: !0,
                Yc: 17,
                Oc: a.toJSON()
            }
        })))
    };
    _.q.Gl = function() {
        this.o.apply(this, _.ch(_.Wa.apply(0, arguments).map(function(a) {
            return {
                vc: !1,
                Yc: 1,
                Oc: a.toJSON()
            }
        })))
    };
    var MA = function(a, b) {
        if (_.v.globalThis.fetch) _.v.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var NA = function(a, b, c, d, e, f, g, h) {
        _.LA.call(this, a, b);
        this.v = c;
        this.M = d;
        this.C = e;
        this.H = f;
        this.I = g;
        this.A = h;
        this.j = [];
        this.m = null;
        this.l = !1
    };
    _.T(NA, _.LA);
    var OA = function(a) {
        null !== a.m && (clearTimeout(a.m), a.m = null);
        if (a.j.length) {
            var b = $e(a.j, a.J);
            a.M(a.v + "?e=1", b);
            a.j = []
        }
    };
    NA.prototype.o = function() {
        var a = _.Wa.apply(0, arguments),
            b = this;
        this.I && 65536 <= $e(this.j.concat(a), this.J).length && OA(this);
        this.A && !this.l && (this.l = !0, PA(this.A, function() {
            OA(b)
        }));
        this.j.push.apply(this.j, _.ch(a));
        this.j.length >= this.H && OA(this);
        this.j.length && null === this.m && (this.m = setTimeout(function() {
            OA(b)
        }, this.C))
    };
    var Xt = function(a, b, c, d, e, f) {
        NA.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", MA, void 0 === c ? 1E3 : c, void 0 === d ? 100 : d, (void 0 === e ? !1 : e) && !!_.v.globalThis.fetch, f)
    };
    _.T(Xt, NA);
    var RA, TA;
    _.QA = function(a, b) {
        this.j = a;
        this.defaultValue = void 0 === b ? !1 : b
    };
    RA = function(a, b) {
        this.j = a;
        this.defaultValue = void 0 === b ? 0 : b
    };
    _.SA = function(a, b) {
        this.j = a;
        this.defaultValue = void 0 === b ? "" : b
    };
    TA = function(a) {
        var b = void 0 === b ? [] : b;
        this.j = a;
        this.defaultValue = b
    };
    var ms, Bm, Pi, UA, VA, no, WA, go, XA, YA, tt, st, yt, ZA, Tt, $A, aB, bB, cB, dB, eB, fB, gB, hB, iB, jB, kB, lB, St, mB, nB, oB, pB, oq, qB, Mm, rB, lg, qt, uo, Bh, zB, AB, Xs, Jp, BB, CB, DB, EB, FB, GB, Tp, HB, IB, ln, JB, KB, LB, MB, Al, xl, nt, PB, QB, RB, wm, SB, TB, UB, Wt, Ut, mk, VB, WB, XB, YB, lk, ZB, $B, Gr, aC, us, bC, cC, dC, eC, fC, gC, hC, iC, It, Jt, jC, Kt, Ht, kC, lC, rs, Mt, mC;
    ms = new _.QA(577837147);
    Bm = new _.QA(577939489);
    Pi = new RA(7, .1);
    UA = new _.QA(212);
    VA = new _.QA(561694963);
    no = new RA(474069761);
    WA = new RA(462420536);
    go = new _.QA(476475256, !0);
    XA = new RA(427198696, 1);
    YA = new RA(438663674);
    tt = new RA(45409629);
    st = new RA(522348973);
    yt = new RA(550605190);
    ZA = new RA(564509649);
    Tt = new RA(578655462);
    _.Uo = new _.QA(571050247, !0);
    _.No = new _.QA(570864697, !0);
    $A = new _.QA(558225291);
    aB = new _.QA(577861852);
    bB = new _.QA(573236024);
    cB = new RA(494575051);
    dB = new TA(489560439);
    eB = new TA(505762507);
    fB = new _.QA(453);
    gB = new _.QA(454);
    hB = new RA(377289019, 1E4);
    iB = new _.QA(579191270);
    jB = new _.QA(580185501);
    kB = new _.QA(576957572);
    lB = new RA(529, 20);
    St = new RA(573282293, .01);
    mB = new _.SA(10);
    nB = new _.QA(489217043);
    oB = new _.QA(549005203, !0);
    pB = new _.QA(495013820);
    oq = new RA(447000223, .01);
    qB = new _.QA(360245597, !0);
    Mm = new _.QA(540043576);
    rB = new _.QA(471855283);
    lg = new _.QA(465118388);
    qt = new _.QA(45401686);
    uo = new _.QA(45401685, !0);
    _.sB = new _.QA(479390945);
    _.tB = new _.QA(518650310);
    _.uB = new _.QA(551365509, !0);
    _.vB = new _.QA(547020083);
    _.wB = new _.QA(561164161, !0);
    _.xB = new RA(550718589, 250);
    _.yB = new _.QA(531615531);
    Bh = new _.QA(85);
    zB = new _.QA(547249510);
    AB = new _.QA(537116804);
    Xs = new _.QA(524098256);
    Jp = new RA(532520346, 120);
    BB = new _.QA(557870754, !0);
    CB = new RA(553562174, 10);
    DB = new TA(466086960);
    EB = new RA(398776877, 6E4);
    FB = new RA(374201269, 6E4);
    GB = new RA(371364213, 6E4);
    Tp = new _.QA(574948950);
    HB = new _.QA(570764855, !0);
    IB = new RA(570764854, 50);
    ln = new _.QA(560793105);
    JB = new _.QA(568657332);
    KB = new _.QA(453275889);
    LB = new _.QA(377936516, !0);
    MB = new RA(24);
    Al = new TA(1);
    xl = new _.SA(2, "1-0-40");
    _.NB = new RA(506394061, 100);
    _.OB = new _.QA(526684968, !0);
    nt = new TA(489);
    PB = new _.QA(392065905);
    QB = new RA(360245595, 500);
    RB = new _.QA(561985307);
    wm = new _.QA(45397804, !0);
    SB = new _.QA(580311360);
    TB = new _.QA(45398607, !0);
    UB = new _.QA(424117738);
    Wt = new RA(397316938, 1E3);
    Ut = new _.QA(579196150);
    mk = new _.QA(531493729);
    VB = new _.QA(563462360, !0);
    WB = new _.QA(555237688);
    XB = new _.QA(555237687);
    YB = new _.QA(555237686);
    lk = new _.QA(507033477, !0);
    ZB = new _.QA(552803605, !0);
    $B = new _.QA(568640849, !0);
    Gr = new _.QA(399705355);
    aC = new _.QA(45420038);
    us = new RA(514795754, 2);
    bC = new _.QA(564724551);
    cC = new _.QA(567489814, !0);
    dC = new _.QA(45415915, !0);
    eC = new _.QA(564852646, !0);
    fC = new _.QA(501);
    gC = new _.QA(439828594);
    hC = new _.QA(483962503);
    iC = new _.QA(506738118);
    It = new _.QA(77);
    Jt = new _.QA(78);
    jC = new _.QA(83);
    Kt = new _.QA(80);
    Ht = new _.QA(76);
    kC = new _.QA(84);
    lC = new _.QA(1958);
    rs = new _.QA(1973);
    Mt = new _.QA(188);
    mC = new _.QA(485990406);
    var nC = new _.QA(1958);
    Ba({
        Ym: 0,
        Xm: 1,
        Um: 2,
        Pm: 3,
        Vm: 4,
        Qm: 5,
        Wm: 6,
        Sm: 7,
        Tm: 8,
        Om: 9,
        Rm: 10,
        Zm: 11
    }).map(function(a) {
        return Number(a)
    });
    Ba({
        bn: 0,
        cn: 1,
        an: 2
    }).map(function(a) {
        return Number(a)
    });
    var oC = function(a, b) {
        this.j = ef(a);
        this.o = b
    };
    oC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return this
    };
    oC.prototype.next = function() {
        var a = this.j.next();
        return {
            value: a.done ? void 0 : this.o.call(void 0, a.value),
            done: a.done
        }
    };
    var pC = function(a, b) {
            return new oC(a, b)
        },
        qC = function(a) {
            this.o = a;
            this.j = 0
        };
    qC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return this
    };
    qC.prototype.next = function() {
        for (; this.j < this.o.length;) {
            var a = this.o[this.j].next();
            if (!a.done) return a;
            this.j++
        }
        return {
            done: !0
        }
    };
    var rC = function() {
        return new qC(_.Wa.apply(0, arguments).map(ef))
    };
    var sC = _.t.URL,
        tC;
    try {
        new sC("http://example.com"), tC = !0
    } catch (a) {
        tC = !1
    }
    var uC = tC,
        vC = function(a) {
            this.j = new _.v.Map;
            0 == a.indexOf("?") && (a = a.substring(1));
            a = _.z(a.split("&"));
            for (var b = a.next(); !b.done; b = a.next()) {
                var c = b.value;
                b = c;
                var d = "";
                c = c.split("=");
                1 < c.length && (b = decodeURIComponent(c[0].replace("+", " ")), d = decodeURIComponent(c[1].replace("+", " ")));
                c = this.j.get(b);
                null == c && (c = [], this.j.set(b, c));
                c.push(d)
            }
        };
    vC.prototype.get = function(a) {
        return (a = this.j.get(a)) && a.length ? a[0] : null
    };
    vC.prototype.getAll = function(a) {
        return [].concat(_.ch(this.j.get(a) || []))
    };
    vC.prototype.has = function(a) {
        return this.j.has(a)
    };
    vC.prototype[_.A(_.v.Symbol, "iterator")] = function() {
        return rC.apply(null, _.ch(pC(this.j, function(a) {
            var b = a[0];
            return pC(a[1], function(c) {
                return [b, c]
            })
        })))
    };
    vC.prototype.toString = function() {
        return wC(this)
    };
    var wC = function(a) {
            var b = function(c) {
                return encodeURIComponent(c).replace(/[!()~']|(%20)/g, function(d) {
                    return {
                        "!": "%21",
                        "(": "%28",
                        ")": "%29",
                        "%20": "+",
                        "'": "%27",
                        "~": "%7E"
                    }[d]
                })
            };
            return _.A(Array, "from").call(Array, a, function(c) {
                return b(c[0]) + "=" + b(c[1])
            }).join("&")
        },
        yC = function(a) {
            var b = _.Xy(document, "A");
            try {
                Iy(b, Sa(a));
                var c = b.protocol
            } catch (e) {
                throw Error(a + " is not a valid URL.");
            }
            if ("" === c || ":" === c || ":" != c[c.length - 1]) throw Error(a + " is not a valid URL.");
            if (!xC.has(c)) throw Error(a + " is not a valid URL.");
            if (!b.hostname) throw Error(a + " is not a valid URL.");
            var d = b.href;
            a = {
                href: d,
                protocol: b.protocol,
                username: "",
                password: "",
                hostname: b.hostname,
                pathname: "/" + b.pathname,
                search: b.search,
                hash: b.hash,
                toString: function() {
                    return d
                }
            };
            xC.get(b.protocol) === b.port ? (a.host = a.hostname, a.port = "", a.origin = a.protocol + "//" + a.hostname) : (a.host = b.host, a.port = b.port, a.origin = a.protocol + "//" + a.hostname + ":" + a.port);
            return a
        },
        gf = function(a) {
            if (uC) {
                try {
                    var b = new sC(a)
                } catch (d) {
                    throw Error(a + " is not a valid URL.");
                }
                var c = xC.get(b.protocol);
                if (!c) throw Error(a + " is not a valid URL.");
                if (!b.hostname) throw Error(a + " is not a valid URL.");
                "null" == b.origin && (a = {
                    href: b.href,
                    protocol: b.protocol,
                    username: "",
                    password: "",
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    pathname: b.pathname,
                    search: b.search,
                    hash: b.hash
                }, a.origin = c === b.port ? b.protocol + "//" + b.hostname : b.protocol + "//" + b.hostname + ":" + b.port, b = a);
                return b
            }
            return yC(a)
        },
        xC = new _.v.Map([
            ["http:", "80"],
            ["https:", "443"],
            ["ws:", "80"],
            ["wss:", "443"],
            ["ftp:", "21"]
        ]),
        ff = function(a) {
            return uC && a.searchParams ? a.searchParams : new vC(a.search)
        };
    var zC = function(a) {
        var b = a.document,
            c = function() {
                if (!a.frames.googlefcPresent)
                    if (b.body) {
                        var d = _.af("IFRAME", b);
                        d.style.display = "none";
                        d.style.width = "0px";
                        d.style.height = "0px";
                        d.style.border = "none";
                        d.style.zIndex = "-1000";
                        d.style.left = "-1000px";
                        d.style.top = "-1000px";
                        d.name = "googlefcPresent";
                        b.body.appendChild(d)
                    } else a.setTimeout(c, 5)
            };
        c()
    };
    var AC = function(a) {
        this.D = _.B(a)
    };
    _.T(AC, _.E);
    AC.ca = [1, 2];
    var BC = function(a) {
        this.D = _.B(a)
    };
    _.T(BC, _.E);
    var lf = Je(BC);
    _.U = function() {
        this.J = this.J;
        this.ta = this.ta
    };
    _.U.prototype.J = !1;
    _.U.prototype.xa = function() {
        this.J || (this.J = !0, this.o())
    };
    _.S = function(a, b) {
        _.mn(a, _.Nu(kf, b))
    };
    _.mn = function(a, b) {
        a.J ? b() : (a.ta || (a.ta = []), a.ta.push(b))
    };
    _.U.prototype.o = function() {
        if (this.ta)
            for (; this.ta.length;) this.ta.shift()()
    };
    var CC = function(a, b, c, d) {
        _.U.call(this);
        this.C = b;
        this.v = c;
        this.M = d;
        this.l = new _.v.Map;
        this.G = 0;
        this.m = new _.v.Map;
        this.I = new _.v.Map;
        this.H = void 0;
        this.A = a
    };
    _.T(CC, _.U);
    CC.prototype.o = function() {
        delete this.j;
        this.l.clear();
        this.m.clear();
        this.I.clear();
        this.H && (_.of(this.A, "message", this.H), delete this.H);
        delete this.A;
        delete this.M;
        _.U.prototype.o.call(this)
    };
    var DC = function(a) {
            if (a.j) return a.j;
            a.v && a.v(a.A) ? a.j = a.A : a.j = rz(a.A, a.C);
            var b;
            return null != (b = a.j) ? b : null
        },
        FC = function(a, b, c) {
            if (DC(a))
                if (a.j === a.A)(b = a.l.get(b)) && b(a.j, c);
                else {
                    var d = a.m.get(b);
                    if (d && d.Mc) {
                        EC(a);
                        var e = ++a.G;
                        a.I.set(e, {
                            xc: d.xc,
                            Sj: d.Hd(c),
                            jl: "addEventListener" === b
                        });
                        a.j.postMessage(d.Mc(c, e), "*")
                    }
                }
        },
        EC = function(a) {
            a.H || (a.H = function(b) {
                try {
                    var c = a.M ? a.M(b) : void 0;
                    if (c) {
                        var d = c.Ag,
                            e = a.I.get(d);
                        if (e) {
                            e.jl || a.I.delete(d);
                            var f;
                            null == (f = e.xc) || f.call(e, e.Sj, c.payload)
                        }
                    }
                } catch (g) {}
            }, _.ib(a.A, "message", a.H))
        };
    var GC = function(a, b) {
            var c = {
                cb: function(d) {
                    d = lf(d);
                    b.Mb({
                        hc: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        HC = {
            Hd: function(a) {
                return a.Mb
            },
            Mc: function(a, b) {
                return {
                    __fciCall: {
                        callId: b,
                        command: a.command,
                        spsp: a.spsp || void 0
                    }
                }
            },
            xc: function(a, b) {
                a({
                    hc: b
                })
            }
        },
        kp = function(a) {
            _.U.call(this);
            this.j = this.m = !1;
            this.caller = new CC(a, "googlefcPresent", void 0, nf);
            this.caller.l.set("getDataWithCallback", GC);
            this.caller.m.set("getDataWithCallback", HC)
        };
    _.T(kp, _.U);
    kp.prototype.o = function() {
        this.caller.xa();
        _.U.prototype.o.call(this)
    };
    var IC = function(a, b) {
            if (void 0 === b ? 0 : b) return !1;
            a.m || (a.j = !!DC(a.caller), a.m = !0);
            return a.j
        },
        JC = function(a) {
            return new _.v.Promise(function(b) {
                IC(a) && FC(a.caller, "getDataWithCallback", {
                    command: "loaded",
                    Mb: function(c) {
                        b(c.hc)
                    }
                })
            })
        },
        KC = function(a, b) {
            IC(a) && FC(a.caller, "getDataWithCallback", {
                command: "prov",
                spsp: tk(b),
                Mb: function() {}
            })
        };
    var LC = function(a, b, c, d, e) {
            pf(a, b, void 0 === c ? null : c, void 0 === d ? !1 : d, void 0 === e ? !1 : e)
        },
        nj = function(a, b) {
            var c = void 0 === c ? !1 : c;
            var d = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + b;
            _.El(a, function(e, f) {
                if (e || 0 === e) d += "&" + f + "=" + encodeURIComponent("" + e)
            });
            Eq(d, c)
        },
        Eq = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : LC(c, a, void 0, b, d)
        };
    var MC = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        NC = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.m = a;
            this.j = null;
            this.l = {};
            this.M = 0;
            var c;
            this.I = null != (c = b.timeoutMs) ? c : 500;
            var d;
            this.H = null != (d = b.xj) ? d : !1;
            this.A = null
        };
    _.T(NC, _.U);
    NC.prototype.o = function() {
        this.l = {};
        this.A && (_.of(this.m, "message", this.A), delete this.A);
        delete this.l;
        delete this.m;
        delete this.j;
        _.U.prototype.o.call(this)
    };
    var PC = function(a) {
        return "function" === typeof a.m.__tcfapi || null != OC(a)
    };
    NC.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.H
            },
            d = _.Vu(function() {
                return a(c)
            }),
            e = 0; - 1 !== this.I && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.I));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = MC(c), c.internalBlockOnErrors = b.H, h && 0 === c.internalErrorState || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            QC(this, "addEventListener", f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    NC.prototype.removeEventListener = function(a) {
        a && a.listenerId && QC(this, "removeEventListener", null, a.listenerId)
    };
    var RC = function(a, b) {
            var c = void 0 === c ? "755" : c;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var d = a.publisher.restrictions[b];
                    if (void 0 !== d) {
                        d = d[void 0 === c ? "755" : c];
                        break a
                    }
                }
                d = void 0
            }
            if (0 === d) return !1;
            a.purpose && a.vendor ? (d = a.vendor.consents, (c = !(!d || !d[void 0 === c ? "755" : c])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
            return b
        },
        QC = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.m.__tcfapi) a = a.m.__tcfapi, a(b, 2, c, d);
            else if (OC(a)) {
                SC(a);
                var e = ++a.M;
                a.l[e] = c;
                a.j && (c = {}, a.j.postMessage((c.__tcfapiCall = {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }, c), "*"))
            } else c({}, !1)
        },
        OC = function(a) {
            if (a.j) return a.j;
            a.j = rz(a.m, "__tcfapiLocator");
            return a.j
        },
        SC = function(a) {
            a.A || (a.A = function(b) {
                try {
                    var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.l[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, _.ib(a.m, "message", a.A))
        },
        TC = function(a) {
            if (!1 === a.gdprApplies) return !0;
            void 0 === a.internalErrorState && (a.internalErrorState = MC(a));
            return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (nj({
                e: String(a.internalErrorState)
            }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
        },
        UC = function(a, b) {
            return !1 === a.gdprApplies ? !0 : b.every(function(c) {
                return RC(a, c)
            })
        };
    var VC = function(a, b, c) {
            this.j = a;
            this.m = b;
            this.o = void 0 === c ? function() {} : c
        },
        WC = function(a, b, c) {
            return new VC(a, b, c)
        };
    VC.prototype.start = function(a) {
        if (this.j === this.j.top) try {
            zC(this.j), XC(this, a)
        } catch (b) {}
    };
    var XC = function(a, b) {
            var c = hf(a.j),
                d = jf(a.j),
                e = {};
            c = (e.fc = c, e.fctype = d, e);
            c = YC(a.m, c);
            df(a.j, c, function() {
                a.o(!0)
            }, function() {
                a.o(!1)
            });
            b && KC(new kp(a.j), b)
        },
        YC = function(a, b) {
            var c = _.Tu("https://fundingchoicesmessages.google.com/i/%{id}");
            b = _.A(Object, "assign").call(Object, {}, b, {
                ers: 3
            });
            return _.dv(_.qb(c, {
                id: a
            }), b)
        };
    var ZC = _.v.Promise;
    var $C = function(a) {
        this.o = a
    };
    $C.prototype.send = function(a, b, c) {
        this.o.then(function(d) {
            d.send(a, b, c)
        })
    };
    $C.prototype.j = function(a, b) {
        return this.o.then(function(c) {
            return c.j(a, b)
        })
    };
    var hE = function(a) {
        this.data = a
    };
    var iE = function(a) {
        this.o = a
    };
    iE.prototype.send = function(a, b, c) {
        c = void 0 === c ? [] : c;
        var d = new MessageChannel;
        jE(d.port1, b);
        this.o.postMessage(a, [d.port2].concat(c))
    };
    iE.prototype.j = function(a, b) {
        var c = this;
        return new ZC(function(d) {
            c.send(a, d, b)
        })
    };
    var kE = function(a, b) {
            jE(a, b);
            return new iE(a)
        },
        jE = function(a, b) {
            b && (a.onmessage = function(c) {
                b(new hE(c.data, kE(c.ports[0])))
            })
        };
    var jk = function(a) {
            var b = a.pb,
                c = void 0 === a.wb ? "ZNWN1d" : a.wb,
                d = void 0 === a.onMessage ? void 0 : a.onMessage,
                e = void 0 === a.Te ? void 0 : a.Te;
            return lE({
                destination: a.destination,
                Gh: function() {
                    return b.contentWindow
                },
                Zk: mE(a.origin),
                wb: c,
                onMessage: d,
                Te: e
            })
        },
        lE = function(a) {
            var b = a.destination,
                c = a.Gh,
                d = a.Zk,
                e = void 0 === a.Wd ? void 0 : a.Wd,
                f = a.wb,
                g = void 0 === a.onMessage ? void 0 : a.onMessage,
                h = void 0 === a.Te ? void 0 : a.Te,
                k = Object.create(null);
            d.forEach(function(l) {
                k[l] = !0
            });
            return new $C(new ZC(function(l, m) {
                var n = function(p) {
                    p.source && p.source === c() && !0 === k[p.origin] && (p.data.n || p.data) === f && (b.removeEventListener("message", n, !1), e && p.data.t !== e ? m(Error('Token mismatch while establishing channel "' + f + '". Expected ' + e + ", but received " + p.data.t + ".")) : (l(kE(p.ports[0], g)), h && h(p)))
                };
                b.addEventListener("message", n, !1)
            }))
        },
        mE = function(a) {
            a = "string" === typeof a ? [a] : a;
            var b = Object.create(null);
            a.forEach(function(c) {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };
    var Kh = function(a) {
            return "string" === typeof a
        },
        Cm = function(a) {
            return "boolean" === typeof a
        },
        tf = function(a) {
            return !!a && ("object" === typeof a || "function" === typeof a)
        };
    var nE = navigator,
        oE = function(a) {
            var b = 1,
                c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        pE = function(a, b) {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return oE(a.toLowerCase())
        },
        qE = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        rE = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        sE = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");
    var di = function(a) {
            return !!a && a.top == a
        },
        Gk = function(a, b, c) {
            b = b || a.google_ad_width;
            c = c || a.google_ad_height;
            if (di(a)) return !1;
            var d = a.document,
                e = d.documentElement;
            if (b && c) {
                var f = 1,
                    g = 1;
                a.innerHeight ? (f = a.innerWidth, g = a.innerHeight) : e && e.clientHeight ? (f = e.clientWidth, g = e.clientHeight) : d.body && (f = d.body.clientWidth, g = d.body.clientHeight);
                if (g > 2 * c || f > 2 * b) return !1
            }
            return !0
        };
    var Si = function() {
        this.data = [];
        this.j = -1
    };
    Si.prototype.set = function(a, b) {
        b = void 0 === b ? !0 : b;
        0 <= a && 52 > a && _.A(Number, "isInteger").call(Number, a) && this.data[a] !== b && (this.data[a] = b, this.j = -1)
    };
    Si.prototype.get = function(a) {
        return !!this.data[a]
    };
    var Ui = function(a) {
        -1 === a.j && (a.j = a.data.reduce(function(b, c, d) {
            return b + (c ? Math.pow(2, d) : 0)
        }, 0));
        return a.j
    };
    _.Fh = function(a) {
        return !!(a.error && a.meta && a.id)
    };
    var tE = function(a, b) {
            (0, a.__uspapi)("getUSPData", 1, function(c, d) {
                b.Mb({
                    hc: null != c ? c : void 0,
                    xe: d ? void 0 : 2
                })
            })
        },
        uE = {
            Hd: function(a) {
                return a.Mb
            },
            Mc: function(a, b) {
                a = {};
                return a.__uspapiCall = {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }, a
            },
            xc: function(a, b) {
                b = b.__uspapiReturn;
                var c;
                a({
                    hc: null != (c = b.returnValue) ? c : void 0,
                    xe: b.success ? void 0 : 2
                })
            }
        },
        vE = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            var c;
            this.timeoutMs = null != (c = b.timeoutMs) ? c : 500;
            this.caller = new CC(a, "__uspapiLocator", function(d) {
                return "function" === typeof d.__uspapi
            }, wf);
            this.caller.l.set("getDataWithCallback", tE);
            this.caller.m.set("getDataWithCallback", uE)
        };
    _.T(vE, _.U);
    vE.prototype.o = function() {
        this.caller.xa();
        _.U.prototype.o.call(this)
    };
    var wE = function(a, b) {
        var c = {};
        if (DC(a.caller)) {
            var d = _.Vu(function() {
                b(c)
            });
            FC(a.caller, "getDataWithCallback", {
                Mb: function(e) {
                    e.xe || (c = e.hc);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    };
    var xE = function(a, b) {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        yE = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        zE = function(a, b) {
            (0, a.__gpp)("getSection", function(c) {
                b.Mb({
                    hc: null != c ? c : void 0,
                    xe: c ? void 0 : 4
                })
            }, b.apiPrefix)
        },
        AE = {
            Hd: function(a) {
                return a.listener
            },
            Mc: function(a, b) {
                a = {};
                return a.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, a
            },
            xc: function(a, b) {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        BE = {
            Hd: function(a) {
                return a.listener
            },
            Mc: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            xc: function(a, b) {
                b = b.__gppReturn;
                var c = b.returnValue.data;
                null == a || a(c, b.success)
            }
        },
        CE = {
            Hd: function(a) {
                return a.Mb
            },
            Mc: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "getSection",
                    version: "1.1",
                    parameter: a.apiPrefix
                }, c
            },
            xc: function(a, b) {
                b = b.__gppReturn;
                var c;
                a({
                    hc: null != (c = b.returnValue) ? c : void 0,
                    xe: b.success ? void 0 : 2
                })
            }
        },
        DE = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.caller = new CC(a, "__gppLocator", function(d) {
                return "function" === typeof d.__gpp
            }, xf);
            this.caller.l.set("addEventListener", xE);
            this.caller.m.set("addEventListener", AE);
            this.caller.l.set("removeEventListener", yE);
            this.caller.m.set("removeEventListener", BE);
            this.caller.l.set("getDataWithCallback", zE);
            this.caller.m.set("getDataWithCallback", CE);
            var c;
            this.timeoutMs = null != (c = b.timeoutMs) ? c : 500
        };
    _.T(DE, _.U);
    DE.prototype.o = function() {
        this.caller.xa();
        _.U.prototype.o.call(this)
    };
    DE.prototype.addEventListener = function(a) {
        var b = this,
            c = _.Vu(function() {
                a(EE, !0)
            }),
            d = -1 === this.timeoutMs ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        FC(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    if (void 0 === (null == (g = e.pingData) ? void 0 : g.gppVersion) || "1" === e.pingData.gppVersion || "1.0" === e.pingData.gppVersion) {
                        b.removeEventListener(e.listenerId);
                        var h = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 1,
                                gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                applicableSections: [-1]
                            }
                        }
                    } else Array.isArray(e.pingData.applicableSections) && 0 !== e.pingData.applicableSections.length ? h = e : (b.removeEventListener(e.listenerId), h = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(h, f)
                } catch (k) {
                    if (null == e ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (l) {
                        a(FE, !0);
                        return
                    }
                    a(GE, !0)
                }
            }
        })
    };
    DE.prototype.removeEventListener = function(a) {
        FC(this.caller, "removeEventListener", {
            listenerId: a
        })
    };
    var HE = function(a) {
            var b = We(a.split("~")[0] + "A"),
                c = Xe(b.slice(0, 6)),
                d = Xe(b.slice(6, 12)),
                e = new Xz;
            var f = _.ph(e, 1, c);
            var g = _.ph(f, 2, d);
            for (var h = b.slice(12), k = Xe(h.slice(0, 12)), l = [], m = h.slice(12).replace(/0+$/, ""), n = 0; n < k; n++) {
                if (0 === m.length) throw Error("Found " + n + " of " + k + " sections [" + l + "] but reached end of input [" + h + "]");
                var p = 0 === Xe(m[0]);
                m = m.slice(1);
                var r = Ze(m, h),
                    w = 0 === l.length ? 0 : l[l.length - 1],
                    u = Ye(r) + w;
                m = m.slice(r.length);
                if (p) l.push(u);
                else {
                    for (var y = Ze(m, h), x = Ye(y), C = 0; C <= x; C++) l.push(u + C);
                    m = m.slice(y.length)
                }
            }
            if (0 < m.length) throw Error("Found " + k + " sections [" + l + "] but has remaining input [" + m + "], entire input [" + h + "]");
            var I = _.be(g, 3, l, Kc);
            var D = _.A(a, "includes").call(a, "~") ? a.split("~").slice(1) : [];
            for (var J = 0; J < Rd(I, 3, Lc).length; ++J) {
                var Q = Rd(I, 3, Lc)[J],
                    N = D[J];
                switch (Q) {
                    case 8:
                        if (0 === N.length) throw Error("Cannot decode empty USCA section string");
                        var Y = N.split(".");
                        if (2 < Y.length) throw Error("Expected at most 1 sub-section but got " + (Y.length - 1) + " when decoding " + N);
                        var ua = void 0,
                            ma = void 0,
                            na = void 0,
                            za = void 0,
                            pa = void 0,
                            Ta = void 0,
                            ab = void 0,
                            lb = void 0,
                            mb = void 0,
                            ac = void 0,
                            ic = void 0,
                            td = void 0,
                            Gc = void 0,
                            $d = void 0,
                            Hc = void 0,
                            Ge = void 0,
                            Kf = void 0,
                            xb = void 0,
                            jc = void 0,
                            Th = void 0,
                            il = void 0,
                            Lf = void 0,
                            Eg = void 0,
                            Uc = We(Y[0]),
                            ae = Xe(Uc.slice(0, 6));
                        Uc = Uc.slice(6);
                        if (1 !== ae) throw Error("Unable to decode unsupported USCA Section specification version " + ae + " - only version 1 is supported.");
                        if (Uc.length < eA)
                            if (Uc.length + 8 >= eA) Uc += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + eA + " but was " + (Uc.length + 8));
                        for (var ud = 0, Pa = [], Fg = 0; Fg < dA.length; Fg++) {
                            var kc = dA[Fg];
                            Pa.push(Xe(Uc.slice(ud, ud + kc)));
                            ud += kc
                        }
                        var Mf = new $z;
                        Eg = _.ph(Mf, 1, ae);
                        var wc = Pa.shift();
                        Lf = _.H(Eg, 2, wc);
                        var xc = Pa.shift();
                        il = _.H(Lf, 3, xc);
                        var $p = Pa.shift();
                        Th = _.H(il, 4, $p);
                        var DS = Pa.shift();
                        jc = _.H(Th, 5, DS);
                        var ES = Pa.shift();
                        xb = _.H(jc, 6, ES);
                        var FS = new Zz,
                            GS = Pa.shift();
                        Kf = _.H(FS, 1, GS);
                        var HS = Pa.shift();
                        Ge = _.H(Kf, 2, HS);
                        var IS = Pa.shift();
                        Hc = _.H(Ge, 3, IS);
                        var JS = Pa.shift();
                        $d = _.H(Hc, 4, JS);
                        var KS = Pa.shift();
                        Gc = _.H($d, 5, KS);
                        var LS = Pa.shift();
                        td = _.H(Gc, 6, LS);
                        var MS = Pa.shift();
                        ic = _.H(td, 7, MS);
                        var NS = Pa.shift();
                        ac = _.H(ic, 8, NS);
                        var OS = Pa.shift();
                        mb = _.H(ac, 9, OS);
                        lb = _.kh(xb, 7, mb);
                        var PS = new Yz,
                            QS = Pa.shift();
                        ab = _.H(PS, 1, QS);
                        var RS = Pa.shift();
                        Ta = _.H(ab, 2, RS);
                        pa = _.kh(lb, 8, Ta);
                        var SS = Pa.shift();
                        za = _.H(pa, 9, SS);
                        var TS = Pa.shift();
                        na = _.H(za, 10, TS);
                        var US = Pa.shift();
                        ma = _.H(na, 11, US);
                        var VS = Pa.shift();
                        var aD = ua = _.H(ma, 12, VS);
                        if (1 === Y.length) var bD = cA(aD);
                        else {
                            var WS = cA(aD),
                                cD = void 0,
                                dD = void 0,
                                eD = void 0,
                                qi = We(Y[1]);
                            if (3 > qi.length) throw Error("Invalid GPC Segment [" + qi + "]. Expected length 3, but was " + qi.length + ".");
                            var Ul = Xe(qi.slice(0, 2));
                            if (0 > Ul || 1 < Ul) throw Error("Attempting to decode unknown GPC segment subsection type " + Ul + ".");
                            eD = Ul + 1;
                            var XS = Xe(qi.charAt(2)),
                                YS = new aA;
                            dD = _.H(YS, 2, eD);
                            cD = _.oh(dD, 1, !!XS);
                            bD = _.kh(WS, 2, cD)
                        }
                        var fD = _.Qh(bD, $z, 1);
                        if (1 === _.Ak(fD, 5, 0) || 1 === _.Ak(fD, 6, 0)) return !0;
                        break;
                    case 10:
                        if (0 === N.length) throw Error("Cannot decode empty USCO section string.");
                        var ri = N.split(".");
                        if (2 < ri.length) throw Error("Expected at most 2 segments but got " + ri.length + " when decoding " + N);
                        var ZS = void 0,
                            gD = void 0,
                            hD = void 0,
                            iD = void 0,
                            jD = void 0,
                            kD = void 0,
                            lD = void 0,
                            mD = void 0,
                            nD = void 0,
                            oD = void 0,
                            pD = void 0,
                            qD = void 0,
                            rD = void 0,
                            sD = void 0,
                            tD = void 0,
                            uD = void 0,
                            vD = void 0,
                            wD = void 0,
                            Te = We(ri[0]),
                            Zr = Xe(Te.slice(0, 6));
                        Te = Te.slice(6);
                        if (1 !== Zr) throw Error("Unable to decode unsupported USCO Section specification version " + Zr + " - only version 1 is supported.");
                        if (Te.length < lA)
                            if (Te.length + 8 >= lA) Te += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + lA + " but was " + (Te.length + 8));
                        for (var $r = 0, Tb = [], as = 0; as < kA.length; as++) {
                            var xD = kA[as];
                            Tb.push(Xe(Te.slice($r, $r + xD)));
                            $r += xD
                        }
                        var $S = new gA;
                        wD = _.ph($S, 1, Zr);
                        var aT = Tb.shift();
                        vD = _.H(wD, 2, aT);
                        var bT = Tb.shift();
                        uD = _.H(vD, 3, bT);
                        var cT = Tb.shift();
                        tD = _.H(uD, 4, cT);
                        var dT = Tb.shift();
                        sD = _.H(tD, 5, dT);
                        var eT = Tb.shift();
                        rD = _.H(sD, 6, eT);
                        var fT = new fA,
                            gT = Tb.shift();
                        qD = _.H(fT, 1, gT);
                        var hT = Tb.shift();
                        pD = _.H(qD, 2, hT);
                        var iT = Tb.shift();
                        oD = _.H(pD, 3, iT);
                        var jT = Tb.shift();
                        nD = _.H(oD, 4, jT);
                        var kT = Tb.shift();
                        mD = _.H(nD, 5, kT);
                        var lT = Tb.shift();
                        lD = _.H(mD, 6, lT);
                        var mT = Tb.shift();
                        kD = _.H(lD, 7, mT);
                        jD = _.kh(rD, 7, kD);
                        var nT = Tb.shift();
                        iD = _.H(jD, 8, nT);
                        var oT = Tb.shift();
                        hD = _.H(iD, 9, oT);
                        var pT = Tb.shift();
                        gD = _.H(hD, 10, pT);
                        var qT = Tb.shift();
                        var yD = ZS = _.H(gD, 11, qT);
                        if (1 === ri.length) var zD = jA(yD);
                        else {
                            var rT = jA(yD),
                                AD = void 0,
                                BD = void 0,
                                CD = void 0,
                                si = We(ri[1]);
                            if (3 > si.length) throw Error("Invalid GPC Segment [" + si + "]. Expected length 3, but was " + si.length + ".");
                            var Vl = Xe(si.slice(0, 2));
                            if (0 > Vl || 1 < Vl) throw Error("Attempting to decode unknown GPC segment subsection type " + Vl + ".");
                            CD = Vl + 1;
                            var sT = Xe(si.charAt(2)),
                                tT = new hA;
                            BD = _.H(tT, 2, CD);
                            AD = _.oh(BD, 1, !!sT);
                            zD = _.kh(rT, 2, AD)
                        }
                        var DD = _.Qh(zD, gA, 1);
                        if (1 === _.Ak(DD, 5, 0) || 1 === _.Ak(DD, 6, 0)) return !0;
                        break;
                    case 12:
                        if (0 === N.length) throw Error("Cannot decode empty usct section string.");
                        var ti = N.split(".");
                        if (2 < ti.length) throw Error("Expected at most 2 segments but got " + ti.length + " when decoding " + N);
                        var uT = void 0,
                            ED = void 0,
                            FD = void 0,
                            GD = void 0,
                            HD = void 0,
                            ID = void 0,
                            JD = void 0,
                            KD = void 0,
                            LD = void 0,
                            MD = void 0,
                            ND = void 0,
                            OD = void 0,
                            PD = void 0,
                            QD = void 0,
                            RD = void 0,
                            SD = void 0,
                            TD = void 0,
                            UD = void 0,
                            VD = void 0,
                            WD = void 0,
                            XD = void 0,
                            YD = void 0,
                            Ue = We(ti[0]),
                            bs = Xe(Ue.slice(0, 6));
                        Ue = Ue.slice(6);
                        if (1 !== bs) throw Error("Unable to decode unsupported USCT Section specification version " + bs + " - only version 1 is supported.");
                        if (Ue.length < tA)
                            if (Ue.length + 8 >= tA) Ue += "00000000";
                            else throw Error("Expected core segment bitstring minus version plus padding to be at least of length " + tA + " but was " + (Ue.length + 8));
                        for (var cs = 0, Bb = [], ds = 0; ds < sA.length; ds++) {
                            var ZD = sA[ds];
                            Bb.push(Xe(Ue.slice(cs, cs + ZD)));
                            cs += ZD
                        }
                        var vT = new oA;
                        YD = _.ph(vT, 1, bs);
                        var wT = Bb.shift();
                        XD = _.H(YD, 2, wT);
                        var xT = Bb.shift();
                        WD = _.H(XD, 3, xT);
                        var yT = Bb.shift();
                        VD = _.H(WD, 4, yT);
                        var zT = Bb.shift();
                        UD = _.H(VD, 5, zT);
                        var AT = Bb.shift();
                        TD = _.H(UD, 6, AT);
                        var BT = new nA,
                            CT = Bb.shift();
                        SD = _.H(BT, 1, CT);
                        var DT = Bb.shift();
                        RD = _.H(SD, 2, DT);
                        var ET = Bb.shift();
                        QD = _.H(RD, 3, ET);
                        var FT = Bb.shift();
                        PD = _.H(QD, 4, FT);
                        var GT = Bb.shift();
                        OD = _.H(PD, 5, GT);
                        var HT = Bb.shift();
                        ND = _.H(OD, 6, HT);
                        var IT = Bb.shift();
                        MD = _.H(ND, 7, IT);
                        var JT = Bb.shift();
                        LD = _.H(MD, 8, JT);
                        KD = _.kh(TD, 7, LD);
                        var KT = new mA,
                            LT = Bb.shift();
                        JD = _.H(KT, 1, LT);
                        var MT = Bb.shift();
                        ID = _.H(JD, 2, MT);
                        var NT = Bb.shift();
                        HD = _.H(ID, 3, NT);
                        GD = _.kh(KD, 8, HD);
                        var OT = Bb.shift();
                        FD = _.H(GD, 9, OT);
                        var PT = Bb.shift();
                        ED = _.H(FD, 10, PT);
                        var QT = Bb.shift();
                        var $D = uT = _.H(ED, 11, QT);
                        if (1 === ti.length) var aE = rA($D);
                        else {
                            var RT = rA($D),
                                bE = void 0,
                                cE = void 0,
                                dE = void 0,
                                ui = We(ti[1]);
                            if (3 > ui.length) throw Error("Invalid GPC Segment [" + ui + "]. Expected length 3, but was " + ui.length + ".");
                            var Wl = Xe(ui.slice(0, 2));
                            if (0 > Wl || 1 < Wl) throw Error("Attempting to decode unknown GPC segment subsection type " + Wl + ".");
                            dE = Wl + 1;
                            var ST = Xe(ui.charAt(2)),
                                TT = new pA;
                            cE = _.H(TT, 2, dE);
                            bE = _.oh(cE, 1, !!ST);
                            aE = _.kh(RT, 2, bE)
                        }
                        var eE = _.Qh(aE, oA, 1);
                        if (1 === _.Ak(eE, 5, 0) || 1 === _.Ak(eE, 6, 0)) return !0;
                        break;
                    case 9:
                        if (0 === N.length) throw Error("Cannot decode empty USVA section string.");
                        var Ve = We(N),
                            es = Xe(Ve.slice(0, 6));
                        Ve = Ve.slice(6);
                        if (1 !== es) throw Error("Unable to decode unsupported USVA Section specification version " + es + " - only version 1 is supported.");
                        if (Ve.length < xA)
                            if (Ve.length + 8 >= xA) Ve += "00000000";
                            else throw Error("Expected bitstring minus version plus padding to be at least of length " + xA + " but was " + (Ve.length + 8));
                        for (var fs = 0, Mb = [], gs = 0; gs < wA.length; gs++) {
                            var fE = wA[gs];
                            Mb.push(Xe(Ve.slice(fs, fs + fE)));
                            fs += fE
                        }
                        var UT = es,
                            VT = new vA;
                        var WT = _.ph(VT, 1, UT);
                        var XT = Mb.shift();
                        var YT = _.H(WT, 2, XT);
                        var ZT = Mb.shift();
                        var $T = _.H(YT, 3, ZT);
                        var aU = Mb.shift();
                        var bU = _.H($T, 4, aU);
                        var cU = Mb.shift();
                        var dU = _.H(bU, 5, cU);
                        var eU = Mb.shift();
                        var fU = _.H(dU, 6, eU);
                        var gU = new uA,
                            hU = Mb.shift();
                        var iU = _.H(gU, 1, hU);
                        var jU = Mb.shift();
                        var kU = _.H(iU, 2, jU);
                        var lU = Mb.shift();
                        var mU = _.H(kU, 3, lU);
                        var nU = Mb.shift();
                        var oU = _.H(mU, 4, nU);
                        var pU = Mb.shift();
                        var qU = _.H(oU, 5, pU);
                        var rU = Mb.shift();
                        var sU = _.H(qU, 6, rU);
                        var tU = Mb.shift();
                        var uU = _.H(sU, 7, tU);
                        var vU = Mb.shift();
                        var wU = _.H(uU, 8, vU);
                        var xU = _.kh(fU, 7, wU);
                        var yU = Mb.shift();
                        var zU = _.H(xU, 8, yU);
                        var AU = Mb.shift();
                        var BU = _.H(zU, 9, AU);
                        var CU = Mb.shift();
                        var DU = _.H(BU, 10, CU);
                        var EU = Mb.shift(),
                            gE = _.H(DU, 11, EU);
                        if (1 === _.Ak(gE, 5, 0) || 1 === _.Ak(gE, 6, 0)) return !0
                }
            }
            return !1
        },
        GE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        EE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        FE = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };
    var Cf = function(a) {
            this.j = a || {
                cookie: ""
            }
        },
        KE = function() {
            var a = IE;
            if (!_.t.navigator.cookieEnabled) return !1;
            if (!a.isEmpty()) return !0;
            a.set("TESTCOOKIESENABLED", "1", {
                ig: 60
            });
            if ("1" !== a.get("TESTCOOKIESENABLED")) return !1;
            JE(a, "TESTCOOKIESENABLED");
            return !0
        };
    Cf.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.Mn;
            d = c.El || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.ig
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.j.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    Cf.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.j.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = iv(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    var JE = function(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            ig: 0,
            path: c,
            domain: d
        })
    };
    Cf.prototype.isEmpty = function() {
        return !this.j.cookie
    };
    Cf.prototype.clear = function() {
        for (var a = (this.j.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = iv(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) JE(this, b[a])
    };
    var IE = new Cf("undefined" == typeof document ? null : document);
    var ym = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, ym.prototype)
    };
    _.T(ym, Error);
    ym.prototype.name = "PublisherInputError";
    var LE = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, LE.prototype)
    };
    _.T(LE, Error);
    LE.prototype.name = "ServerError";
    var ME = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, ME.prototype)
    };
    _.T(ME, Error);
    ME.prototype.name = "NetworkError";
    var NE = 0,
        OE = Le(_.Su(_.Tu("https://pagead2.googlesyndication.com/pagead/expansion_embed.js")));
    var PE = null,
        QE = function() {
            if (null === PE) {
                PE = "";
                try {
                    var a = "";
                    try {
                        a = _.t.top.location.hash
                    } catch (c) {
                        a = _.t.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        PE = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return PE
        };
    _.Ff = function(a) {
        var b = "tc";
        if (a.tc && a.hasOwnProperty(b)) return a.tc;
        b = new a;
        return a.tc = b
    };
    var Gf = function() {};
    Gf.prototype.j = function() {};
    Gf.prototype.m = function() {};
    Gf.prototype.o = function() {
        return []
    };
    Gf.prototype.A = function() {
        return []
    };
    var Zf = function(a, b) {
        a.j = Ef(1, b, function() {});
        a.o = function(c, d) {
            return Ef(2, b, function() {
                return []
            })(c, 2, d)
        };
        a.A = function() {
            return Ef(3, b, function() {
                return []
            })(2)
        };
        a.m = function(c) {
            Ef(16, b, function() {})(c, 2)
        }
    };
    var Tf = function() {
        var a = {};
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.m = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.A = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.J = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.j = function() {}
    };
    var Xf = function() {
            this.j = function() {}
        },
        ag = function(a, b) {
            a.j = Ef(14, b, function() {})
        };
    var sp = _.ju(["(a=0)=>{let b;const c=null ?? 1;}"]);
    var Yh = function(a, b, c) {
            a && null !== b && b != b.top && (b = b.top);
            try {
                return (void 0 === c ? 0 : c) ? (new _.ki(b.innerWidth, b.innerHeight)).round() : _.Ty(b || window).round()
            } catch (d) {
                return new _.ki(-12245933, -12245933)
            }
        },
        RE = function(a) {
            return "CSS1Compat" == a.compatMode ? a.documentElement : a.body
        },
        kt = function(a, b) {
            b = void 0 === b ? _.t : b;
            a = a.scrollingElement || RE(a);
            return new _.gi(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
        },
        Bi = function(a) {
            try {
                return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
            } catch (b) {
                return !1
            }
        };
    var SE = function(a) {
        this.D = _.B(a)
    };
    _.T(SE, _.E);
    var zf = function(a) {
            return _.L(a, 5)
        },
        TE = function(a, b) {
            xj(a, 13, b)
        },
        UE = function(a, b) {
            xj(a, 12, b)
        },
        VE = function(a, b) {
            return _.be(a, 10, b, _.Sc)
        },
        WE = function(a, b) {
            return On(a, 11, b)
        };
    SE.ca = [10];
    var YE, ZE, $E;
    _.XE = function(a) {
        this.j = a;
        this.o = 0
    };
    YE = function(a, b) {
        if (0 === a.o) {
            if (_.Ll(a, "__gads", b)) b = !0;
            else {
                var c = a.j;
                zf(b) && Bf(c) && (new Cf(c.document)).set("GoogleAdServingTest", "Good", void 0);
                if (c = "Good" === Df("GoogleAdServingTest", b, a.j)) {
                    var d = a.j;
                    zf(b) && Bf(d) && JE(new Cf(d.document), "GoogleAdServingTest")
                }
                b = c
            }
            a.o = b ? 2 : 1
        }
        return 2 === a.o
    };
    _.Ll = function(a, b, c) {
        return c ? Df(b, c, a.j) : null
    };
    ZE = function(a, b, c, d) {
        if (d) {
            var e = _.mf(c, 2) - Date.now() / 1E3;
            e = {
                ig: Math.max(e, 0),
                path: _.R(c, 3),
                domain: _.R(c, 4),
                El: !1
            };
            c = c.getValue();
            a = a.j;
            zf(d) && Bf(a) && (new Cf(a.document)).set(b, c, e)
        }
    };
    $E = function(a, b, c) {
        if (c && Df(b, c, a.j)) {
            var d = a.j.location.hostname;
            if ("localhost" === d) d = ["localhost"];
            else if (d = d.split("."), 2 > d.length) d = [];
            else {
                for (var e = [], f = 0; f < d.length - 1; ++f) e.push(d.slice(f).join("."));
                d = e
            }
            d = _.z(d);
            for (e = d.next(); !e.done; e = d.next()) f = a.j, zf(c) && Bf(f) && JE(new Cf(f.document), b, "/", e.value)
        }
    };
    var aF = {},
        bF = (aF[3] = Le(_.Su(_.Tu("https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"))), aF);
    ({})[3] = Le(_.Su(_.Tu("https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js")));
    var cF = function(a) {
            this.j = a;
            this.o = Ky()
        },
        dF = function(a) {
            var b = {};
            _.Yu(a, function(c) {
                b[c.j] = c.o
            });
            return b
        };
    _.eF = _.ju(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]);
    var fF = function(a, b, c, d, e, f) {
        _.U.call(this);
        this.wb = a;
        this.status = 1;
        this.A = b;
        this.m = c;
        this.G = d;
        this.Cd = !!e;
        this.l = Math.random();
        this.H = {};
        this.j = null;
        this.M = (0, _.Mu)(this.C, this);
        this.I = f
    };
    _.T(fF, _.U);
    fF.prototype.C = function(a) {
        if (!("*" !== this.m && a.origin !== this.m || !this.Cd && a.source != this.A)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (_.ja(b) && (a = b.i, b.c === this.wb && a != this.l)) {
                if (2 !== this.status) try {
                    this.status = 2, gF(this), this.j && (this.j(), this.j = null)
                } catch (c) {}
                a = b.s;
                b = b.p;
                if ("string" === typeof a && ("string" === typeof b || _.ja(b)) && this.H.hasOwnProperty(a)) this.H[a](b)
            }
        }
    };
    var gF = function(a) {
        var b = {};
        b.c = a.wb;
        b.i = a.l;
        a.I && (b.e = a.I);
        a.A.postMessage(JSON.stringify(b), a.m)
    };
    fF.prototype.v = function() {
        if (1 === this.status) {
            try {
                this.A.postMessage && gF(this)
            } catch (a) {}
            window.setTimeout((0, _.Mu)(this.v, this), 50)
        }
    };
    fF.prototype.connect = function(a) {
        a && (this.j = a);
        _.ib(window, "message", this.M);
        this.G && this.v()
    };
    var hF = function(a, b, c) {
        a.H[b] = c
    };
    fF.prototype.send = function(a, b) {
        var c = {};
        c.c = this.wb;
        c.i = this.l;
        c.s = a;
        c.p = b;
        try {
            this.A.postMessage(JSON.stringify(c), this.m)
        } catch (d) {}
    };
    fF.prototype.o = function() {
        this.status = 3;
        _.of(window, "message", this.M);
        _.U.prototype.o.call(this)
    };
    var iF = new _.v.Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        jF = new _.v.Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);
    var kF = function(a) {
        this.D = _.B(a)
    };
    _.T(kF, _.E);
    var lF = Je(kF);
    var mF = function(a) {
        this.D = _.B(a)
    };
    _.T(mF, _.E);
    var nF = function(a) {
        this.D = _.B(a)
    };
    _.T(nF, _.E);
    var oF, pF, qF, rF;
    _.iq = function(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    };
    oF = function(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };
    pF = function(a) {
        return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
    };
    qF = function(a, b) {
        if (3 == _.iq(b)) return !1;
        a();
        return !0
    };
    rF = function(a, b) {
        var c = _.G(kB);
        c = void 0 === c ? !1 : c;
        if (!qF(a, b))
            if (c) {
                var d = function() {
                    _.of(b, "prerenderingchange", d);
                    a()
                };
                _.ib(b, "prerenderingchange", d)
            } else {
                var e = !1,
                    f = oF(b),
                    g = function() {
                        !e && qF(a, b) && (e = !0, _.of(b, f, g))
                    };
                f && _.ib(b, f, g)
            }
    };
    var Cq = function(a, b) {
        this.j = a;
        this.m = b;
        this.o = {}
    };
    Cq.prototype.oa = function() {
        var a = this;
        wq() && (document.addEventListener("touchstart", function(b) {
            a.j(902, function() {
                a.o[b.touches[0].identifier] = Date.now()
            })()
        }, _.Xu), document.addEventListener("touchend", function(b) {
            a.j(902, function() {
                var c = b.changedTouches[0],
                    d = c.clientX,
                    e = c.clientY,
                    f = c.force;
                c = a.o[c.identifier];
                if (void 0 !== c) try {
                    var g = wq(),
                        h = {
                            x: d,
                            y: e,
                            duration_ms: Date.now() - c
                        };
                    if (null == g ? 0 : g.gmaSdk) g.gmaSdk.reportTouchEvent(JSON.stringify(_.A(Object, "assign").call(Object, {}, h, {
                        type: 1,
                        force: f
                    })));
                    else {
                        var k, l, m;
                        null == g || null == (k = g.webkit) || null == (l = k.messageHandlers) || null == (m = l.reportGmaTouchEvent) || m.postMessage(h)
                    }
                } catch (n) {
                    a.m("paw_sigs", {
                        msg: "reportTouchError",
                        err: n instanceof Error ? n.message : "nonError"
                    })
                }
            })()
        }, _.Xu))
    };
    var xq = function(a, b, c, d, e) {
            var f = 200,
                g = pq;
            b = void 0 === b ? {} : b;
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            f = void 0 === f ? 200 : f;
            var h = String(Math.floor(2147483647 * _.Qf())),
                k = 0,
                l = function(m) {
                    try {
                        var n = "object" === typeof m.data ? m.data : JSON.parse(m.data);
                        h === n.paw_id && (window.clearTimeout(k), window.removeEventListener("message", l), n.signal ? c(n.signal) : n.error && d(n.error))
                    } catch (p) {
                        g("paw_sigs", {
                            msg: "postmessageError",
                            err: p instanceof Error ? p.message : "nonError",
                            data: null == m.data ? "null" : 500 < m.data.length ? m.data.substring(0, 500) : m.data
                        })
                    }
                };
            window.addEventListener("message", function(m) {
                e(903, function() {
                    l(m)
                })()
            });
            a.postMessage(_.A(Object, "assign").call(Object, {}, {
                paw_id: h
            }, b));
            k = window.setTimeout(function() {
                window.removeEventListener("message", l);
                d("PAW GMA postmessage timed out.")
            }, f)
        },
        wq = function() {
            var a = window,
                b, c;
            if (a.gmaSdk || (null == (b = a.webkit) ? 0 : null == (c = b.messageHandlers) ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, f;
                if (d.gmaSdk || (null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals)) return d
            } catch (g) {}
            return null
        };
    _.cg = function() {
        var a = this;
        this.promise = new _.v.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };
    var vF, uF, xF, wF;
    _.sF = function() {
        this.m = "&";
        this.o = {};
        this.A = 0;
        this.j = []
    };
    _.tF = function(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    };
    vF = function(a, b, c, d, e) {
        var f = [];
        _.El(a, function(g, h) {
            (g = uF(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    };
    uF = function(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push(uF(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(vF(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    };
    xF = function(a, b) {
        var c = "https://pagead2.googlesyndication.com" + b,
            d = wF(a) - b.length;
        if (0 > d) return "";
        a.j.sort(function(m, n) {
            return m - n
        });
        b = null;
        for (var e = "", f = 0; f < a.j.length; f++)
            for (var g = a.j[f], h = a.o[g], k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                var l = vF(h[k], a.m, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.m;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    };
    wF = function(a) {
        var b = 1,
            c;
        for (c in a.o) b = c.length > b ? c.length : b;
        return 3997 - b - a.m.length - 1
    };
    _.yF = function() {
        this.j = Math.random()
    };
    _.Lg = function(a, b, c, d, e) {
        if (((void 0 === d ? 0 : d) ? a.j : Math.random()) < (e || .001)) try {
            if (c instanceof _.sF) var f = c;
            else f = new _.sF, _.El(c, function(h, k) {
                var l = f,
                    m = l.A++;
                h = _.tF(k, h);
                l.j.push(m);
                l.o[m] = h
            });
            var g = xF(f, "/pagead/gen_204?id=" + b + "&");
            g && LC(_.t, g)
        } catch (h) {}
    };
    var zF = function(a) {
        this.D = _.B(a)
    };
    _.T(zF, _.E);
    var AF = function(a, b) {
        return _.Lh(a, 1, b)
    };
    zF.ca = [1];
    var BF = function(a) {
        this.D = _.B(a)
    };
    _.T(BF, _.E);
    BF.ca = [1];
    var CF = function(a) {
        this.D = _.B(a)
    };
    _.T(CF, _.E);
    var DF = function(a, b) {
        return _.H(a, 1, b)
    };
    var EF = function(a) {
        this.D = _.B(a)
    };
    _.T(EF, _.E);
    var FF = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.A(Object, "setPrototypeOf").call(Object, this, FF.prototype);
        this.name = "InputError"
    };
    _.T(FF, Error);
    var GF = function() {
            this.gb = !1
        },
        HF = function() {
            GF.apply(this, arguments);
            this.j = [];
            this.Pd = new _.cg
        };
    _.T(HF, GF);
    var JF = function(a, b) {
            a.gb || (a.gb = !0, a.Qc = b, a.Pd.resolve(b), _.G(rB) && IF(a))
        },
        KF = function(a, b) {
            a.gb = !0;
            a.We = b;
            a.Pd.reject(b);
            _.G(rB) && IF(a)
        },
        IF = function(a) {
            for (var b = _.z(a.j), c = b.next(); !c.done; c = b.next()) c = c.value, c(a.Qc);
            a.j.length = 0
        };
    HF.prototype.oe = function() {
        this.j.length = 0
    };
    var PA = function(a, b) {
        _.G(rB) && a.j.push(b)
    };
    _.eu.Object.defineProperties(HF.prototype, {
        promise: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Pd.promise
            }
        },
        Bb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.gb
            }
        },
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.We
            }
        }
    });
    var rn = function() {
        HF.apply(this, arguments)
    };
    _.T(rn, HF);
    _.q = rn.prototype;
    _.q.F = function(a) {
        JF(this, a)
    };
    _.q.Ca = function(a) {
        JF(this, null != a ? a : null)
    };
    _.q.aa = function() {
        JF(this, null)
    };
    _.q.Ka = function(a) {
        var b = this;
        a.then(function(c) {
            JF(b, c)
        })
    };
    _.q.ib = function(a) {
        this.gb || (this.gb = !0, this.Qc = null, this.We = a, this.Pd.reject(a), _.G(rB) && IF(this))
    };
    var LF = function() {
        HF.apply(this, arguments)
    };
    _.T(LF, HF);
    LF.prototype.F = function(a) {
        JF(this, a)
    };
    LF.prototype.Ka = function(a) {
        var b = this;
        a.then(function(c) {
            return void JF(b, c)
        })
    };
    LF.prototype.ib = function(a) {
        this.gb || (this.gb = !0, this.We = a, this.Pd.reject(a))
    };
    var MF = function() {
        LF.apply(this, arguments)
    };
    _.T(MF, LF);
    MF.prototype.Ca = function(a) {
        JF(this, null != a ? a : null)
    };
    MF.prototype.aa = function() {
        JF(this, null)
    };
    MF.prototype.Ka = function(a) {
        var b = this;
        a.then(function(c) {
            return void b.Ca(c)
        })
    };
    var NF = function(a) {
        this.gb = !1;
        this.Rb = a
    };
    _.T(NF, GF);
    NF.prototype.Bb = function() {
        return this.Rb.gb
    };
    NF.prototype.Wf = function() {
        return null != this.Rb.Qc
    };
    _.eu.Object.defineProperties(NF.prototype, {
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Rb.We
            }
        }
    });
    var OF = function(a) {
        NF.call(this, a);
        this.Rb = a
    };
    _.T(OF, NF);
    _.eu.Object.defineProperties(OF.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Rb.Qc
            }
        }
    });
    var PF = function(a) {
        NF.call(this, a);
        this.Rb = a
    };
    _.T(PF, NF);
    _.eu.Object.defineProperties(PF.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.Rb.Qc) ? a : null
            }
        }
    });
    var QF = function() {
        NF.apply(this, arguments)
    };
    _.T(QF, NF);
    _.eu.Object.defineProperties(QF.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.Rb.Qc) ? a : null
            }
        }
    });
    var vn = function() {
        HF.apply(this, arguments)
    };
    _.T(vn, HF);
    vn.prototype.notify = function() {
        JF(this, null)
    };
    var RF = function(a, b) {
            b.then(function() {
                a.notify()
            })
        },
        SF = function(a, b) {
            b = void 0 === b ? !1 : b;
            HF.call(this);
            var c = this;
            this.m = a;
            this.o = 0;
            if (_.G(rB)) {
                a = _.z(this.m);
                for (var d = a.next(), e = {}; !d.done; e = {
                        Od: e.Od
                    }, d = a.next()) e.Od = d.value, PA(e.Od, function(f) {
                    return function(g) {
                        c.o += 1;
                        f.Od.error ? KF(c, f.Od.error) : b || null !== g ? JF(c, null != g ? g : null) : c.o === c.m.length && JF(c, null)
                    }
                }(e))
            } else a = a.map(function(f) {
                return f.promise.then(function(g) {
                    if (b || null != g) return g;
                    throw g;
                }, function(g) {
                    KF(c, g);
                    return null
                })
            }), _.A(_.v.Promise, "any").call(_.v.Promise, a).then(function(f) {
                c.gb || JF(c, f)
            }, function() {
                c.gb || JF(c, null)
            })
        };
    _.T(SF, HF);
    var TF = function(a, b) {
        HF.call(this);
        this.timeoutMs = a;
        this.defaultValue = b
    };
    _.T(TF, HF);
    var mg = function(a) {
        setTimeout(function() {
            var b;
            JF(a, null != (b = a.defaultValue) ? b : null)
        }, a.timeoutMs)
    };
    var UF = function(a) {
        _.U.call(this);
        this.H = a;
        this.j = [];
        this.m = [];
        this.l = [];
        this.A = []
    };
    _.T(UF, _.U);
    var VF = function(a, b, c) {
        a.m.push({
            Yb: void 0 === c ? !1 : c,
            Fb: b
        });
        _.G(rB) && PA(b, a.H)
    };
    UF.prototype.o = function() {
        this.j.length = 0;
        this.l.length = 0;
        if (_.G(rB))
            for (var a = _.z(this.m), b = a.next(); !b.done; b = a.next()) b.value.Fb.oe();
        this.m.length = 0;
        this.A.length = 0;
        _.U.prototype.o.call(this)
    };
    var XF = function(a, b, c) {
        _.U.call(this);
        var d = this;
        this.id = a;
        this.timeoutMs = b;
        this.M = c;
        this.Ha = this.Ea = this.ua = this.started = !1;
        this.A = new UF(function() {
            WF(d)
        });
        _.S(this, this.A)
    };
    _.T(XF, _.U);
    XF.prototype.start = function() {
        var a = this,
            b;
        return _.kb(function(c) {
            if (1 == c.j) {
                if (a.started) return c.return();
                a.started = !0;
                c.m = 2;
                return c.yield(ng(a.A.m, a.A.A, a.timeoutMs), 4)
            }
            if (2 != c.j) {
                if (!a.J) {
                    for (var d = 0, e = _.z(a.A.l), f = e.next(); !f.done; f = e.next()) {
                        if (!f.value.Wf()) throw Error("missing input: " + a.id + "/" + d);
                        ++d
                    }
                    a.j()
                }
                c.j = 0;
                c.m = 0
            } else {
                b = ob(c);
                if (a.J) return c.return();
                b instanceof FF ? a.H(b) : b instanceof Error && (a.M ? a.M(a.id, b) : a.I(b), a.m(b));
                c.j = 0
            }
        })
    };
    var WF = function(a) {
            if (!a.started && a.ua) try {
                var b = a.A.m,
                    c = a.timeoutMs ? b.filter(function(k) {
                        return !k.Yb
                    }) : b,
                    d = b.filter(function(k) {
                        return k.Yb
                    }),
                    e, f = null == (e = _.A(b, "find").call(b, function(k) {
                        return void 0 !== k.Fb.error
                    })) ? void 0 : e.Fb.error;
                if (f) throw a.started = !0, f;
                if (!c.some(function(k) {
                        return !k.Fb.Bb
                    })) {
                    if (d.length)
                        if (_.G(lg)) {
                            for (var g = _.z(a.A.A), h = g.next(); !h.done; h = g.next()) mg(h.value);
                            if (d.some(function(k) {
                                    return !k.Fb.Bb
                                })) return
                        } else if (a.Ea || (a.Ea = !0, setTimeout(function() {
                            a.Ha = !0;
                            WF(a)
                        }, a.timeoutMs)), d.some(function(k) {
                            return !k.Fb.Bb
                        }) && !a.Ha) return;
                    a.started = !0;
                    a.j()
                }
            } catch (k) {
                a.J || (k instanceof FF ? a.H(k) : k instanceof Error && (a.M ? a.M(a.id, k) : a.I(k), a.m(k)))
            }
        },
        V = function(a, b) {
            b = void 0 === b ? new rn : b;
            a.A.j.push(b);
            return b
        },
        YF = function(a) {
            var b = void 0 === b ? new LF : b;
            a.A.j.push(b);
            return b
        },
        ZF = function(a) {
            var b = void 0 === b ? new MF : b;
            a.A.j.push(b);
            return b
        },
        $F = function(a, b) {
            b = void 0 === b ? new vn : b;
            a.A.j.push(b);
            return b
        },
        W = function(a, b) {
            VF(a.A, b);
            b = new OF(b);
            a.A.l.push(b);
            return b
        },
        X = function(a, b) {
            VF(a.A, b);
            return new PF(b)
        },
        aG = function(a, b) {
            if (_.G(lg)) {
                if (a.timeoutMs) {
                    var c = new TF(a.timeoutMs, void 0);
                    b = new SF([b, c], !0);
                    VF(a.A, b, !0);
                    a.A.A.push(c);
                    return new PF(b)
                }
                VF(a.A, b);
                return new PF(b)
            }
            VF(a.A, b, !0);
            return new PF(b)
        },
        bG = function(a, b) {
            VF(a.A, b)
        },
        cG = function(a, b) {
            if (_.G(lg))
                if (a.timeoutMs) {
                    var c = new TF(a.timeoutMs);
                    b = new SF([b, c], !0);
                    VF(a.A, b, !0);
                    a.A.A.push(c)
                } else bG(a, b);
            else VF(a.A, b, !0)
        },
        dG = function(a, b) {
            b = new SF(b);
            VF(a.A, b);
            b = new OF(b);
            a.A.l.push(b);
            return b
        };
    XF.prototype.H = function() {};
    XF.prototype.m = function(a) {
        if (!this.M && this.A.j.length) {
            a = new FF(a.message);
            for (var b = _.z(this.A.j), c = b.next(); !c.done; c = b.next()) c = c.value, c.Bb || KF(c, a)
        }
    };
    var eG = function(a, b, c, d, e, f) {
        XF.call(this, a, e, f);
        this.f = b;
        this.v = d;
        a = {};
        c = _.z(_.A(Object, "entries").call(Object, c));
        for (b = c.next(); !b.done; b = c.next()) d = _.z(b.value), b = d.next().value, d = d.next().value, a[b] = W(this, d);
        this.l = a
    };
    _.T(eG, XF);
    eG.prototype.j = function() {
        for (var a = this.f, b = {}, c = _.z(_.A(Object, "entries").call(Object, this.l)), d = c.next(); !d.done; d = c.next()) {
            var e = _.z(d.value);
            d = e.next().value;
            e = e.next().value;
            b[d] = e.value
        }
        a = a.call(this, b, this.v);
        a = _.z(_.A(Object, "entries").call(Object, a));
        for (b = a.next(); !b.done; b = a.next()) c = _.z(b.value), b = c.next().value, c = c.next().value, JF(this[b], c);
        this.finished.notify()
    };
    eG.prototype.I = function() {};
    var fG = function(a, b, c, d, e, f, g) {
        eG.call(this, a, b, c, d, f, g);
        this.finished = new vn;
        a = _.A(Object, "keys").call(Object, e);
        a = _.z(a);
        for (b = a.next(); !b.done; b = a.next()) this[b.value] = V(this)
    };
    _.T(fG, eG);
    var gG = function(a) {
        this.j = void 0 === a ? function() {} : a
    };
    var Bj = function(a) {
        a = void 0 === a ? new gG : a;
        _.U.call(this);
        this.ba = a;
        this.l = [];
        this.H = [];
        this.v = {};
        this.A = [];
        this.m = new _.cg;
        this.j = {}
    };
    _.T(Bj, _.U);
    var M = function(a, b) {
            _.S(a, b);
            a.l.push(b);
            return b
        },
        Vj = function(a, b) {
            b = _.z(b);
            for (var c = b.next(); !c.done; c = b.next()) M(a, c.value)
        },
        hG = function(a, b, c, d, e, f) {
            b = new fG(b, c, d, e, f, void 0, a.ba.j);
            return M(a, b)
        },
        Hs = function(a, b) {
            a.H.push(b);
            _.S(a, b)
        },
        Kj = function(a) {
            var b, c, d, e, f, g, h, k, l, m, n, p;
            return _.kb(function(r) {
                switch (r.j) {
                    case 1:
                        if (!a.A.length) {
                            r.j = 2;
                            break
                        }
                        return r.yield(_.v.Promise.all(a.A.map(function(w) {
                            return w.m.promise
                        })), 2);
                    case 2:
                        b = _.z(a.l);
                        for (c = b.next(); !c.done; c = b.next()) d = c.value, _.G(rB) ? (d.ua = !0, WF(d)) : d.start();
                        e = _.z(a.H);
                        for (f = e.next(); !f.done; f = e.next()) g = f.value, Kj(g);
                        if (!a.j) {
                            r.j = 4;
                            break
                        }
                        h = _.A(Object, "keys").call(Object, a.j);
                        if (!h.length) {
                            r.j = 4;
                            break
                        }
                        return r.yield(_.v.Promise.all(_.A(Object, "values").call(Object, a.j).map(function(w) {
                            return w.promise
                        })), 6);
                    case 6:
                        for (k = r.o, l = 0, m = _.z(h), n = m.next(); !n.done; n = m.next()) p = n.value, a.v[p] = k[l++];
                    case 4:
                        return a.m.resolve(a.v), r.return(a.m.promise)
                }
            })
        };
    Bj.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.l.length = 0;
        this.H.length = 0;
        this.A.length = 0
    };
    var iG = function(a) {
        this.D = _.B(a)
    };
    _.T(iG, _.E);
    iG.ca = [1];
    var jG = [0, ix, Qx];
    var kG = function(a) {
        this.D = _.B(a)
    };
    _.T(kG, _.E);
    kG.ca = [1, 2];
    kG.prototype.j = Ie([0, ix, Qx, ix, jG]);
    var mG, lG;
    mG = function() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new lG;
        this.sideRailProcessedFixedElements = new _.v.Set;
        this.sideRailAvailableSpace = new _.v.Map;
        this.sideRailPlasParam = new _.v.Map
    };
    _.ah = function(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new _.v.Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new _.v.Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new _.v.Map)) : a.google_reactive_ads_global_state = new mG;
        return a.google_reactive_ads_global_state
    };
    lG = function() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = []
    };
    var qG, sG, oG;
    _.nG = function(a) {
        this.j = _.ah(a).floatingAdsStacking
    };
    _.pG = function(a, b) {
        return new oG(a, b)
    };
    qG = function(a) {
        a = _.hz(a.j.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    };
    _.rG = function(a, b) {
        a.j.maxZIndexListeners.push(b);
        b(qG(a))
    };
    sG = function(a) {
        var b = qG(a);
        _.Yu(a.j.maxZIndexListeners, function(c) {
            return c(b)
        })
    };
    oG = function(a, b) {
        this.o = a;
        this.m = b;
        this.j = null
    };
    _.tG = function(a) {
        if (null == a.j) {
            var b = a.o,
                c = a.m,
                d = b.j.nextRestrictionId++;
            b.j.maxZIndexRestrictions[d] = c;
            sG(b);
            a.j = d
        }
    };
    _.uG = function(a) {
        if (null != a.j) {
            var b = a.o;
            delete b.j.maxZIndexRestrictions[a.j];
            sG(b);
            a.j = null
        }
    };
    _.To = 728 * 1.38;
    var Dg, vG;
    _.Jg = function(a, b) {
        b = void 0 === b ? {} : b;
        this.la = a;
        this.Da = b
    };
    _.wG = function(a, b) {
        var c = Ag(a.la.document, b);
        if (c) {
            var d;
            if (!(d = vG(a, c, b))) a: {
                d = a.la.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    var e = vG(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    };
    Dg = function(a, b) {
        b = _.z(b);
        for (var c = b.next(); !c.done; c = b.next())
            if (c = _.wG(a, c.value)) return c;
        return null
    };
    vG = function(a, b, c) {
        if ("fixed" !== Oz(b, "position")) return null;
        var d = "GoogleActiveViewInnerContainer" === b.getAttribute("class") || 1 >= _.ii(_.Tz, b).width && 1 >= _.ii(_.Tz, b).height || a.Da.Yj && !a.Da.Yj(b) ? !0 : !1;
        a.Da.Bh && a.Da.Bh(b, c, d);
        return d ? null : b
    };
    var Cg = 90 * 1.38;
    var xG, yG, zG;
    xG = _.ju(["* { pointer-events: none; }"]);
    yG = function(a, b) {
        var c = _.af("STYLE", a);
        c.textContent = _.Gv(new _.Fv(xG[0], _.Ev));
        null == a || a.head.appendChild(c);
        setTimeout(function() {
            null == a || a.head.removeChild(c)
        }, b)
    };
    _.AG = function(a, b, c) {
        if (!a.body) return null;
        var d = new zG;
        d.apply(a, b);
        return function() {
            var e = c || 0;
            0 < e && yG(b.document, e);
            _.Lz(a.body, {
                filter: d.j,
                webkitFilter: d.j,
                overflow: d.m,
                position: d.A,
                top: d.J
            });
            b.scrollTo(0, d.o)
        }
    };
    zG = function() {
        this.j = this.J = this.A = this.m = null;
        this.o = 0
    };
    zG.prototype.apply = function(a, b) {
        this.m = a.body.style.overflow;
        this.A = a.body.style.position;
        this.J = a.body.style.top;
        this.j = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
        this.o = _.yg(b);
        _.Lz(a.body, "top", -this.o + "px")
    };
    var Oo;
    Oo = function(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            var b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return "__storage_test__" === b
        } catch (c) {
            return !1
        }
    };
    _.Qo = function(a, b) {
        return 0 >= b || null == a || !Oo(a) ? null : Tg(a, b)
    };
    _.Po = function(a) {
        return !!a && 1 > a.length
    };
    var Ym = function(a) {
            var b = void 0 === b ? _.Ih(_.t) : b;
            this.id = a;
            this.o = .001 > Math.random();
            this.j = {
                pvsid: String(b)
            }
        },
        BG = function(a) {
            a = eh(a);
            var b;
            Oh.set(a, (null != (b = Oh.get(a)) ? b : 0) + 1)
        },
        Nh = function() {
            return [].concat(_.ch(_.A(Oh, "values").call(Oh))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        Yi = function(a, b, c) {
            "string" !== typeof c && (c = String(c));
            /^\w+$/.test(b) && (c ? a.j[b] = c : delete a.j[b])
        },
        $m = function(a) {
            var b = 1;
            b = void 0 === b ? null : b;
            if (CG()) b = !0;
            else {
                var c = a.o;
                b && 0 <= b && (c = Math.random() < b);
                b = c && !!a.id
            }
            b && LC(window, DG(a) || "", void 0, !0)
        },
        DG = function(a) {
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + encodeURIComponent(a.id);
            _.El(a.j, function(c, d) {
                c && (b += "&" + d + "=" + encodeURIComponent(c))
            });
            return b
        },
        EG = function(a) {
            var b = [].concat(_.ch(_.A(Oh, "keys").call(Oh)));
            b = b.map(function(c) {
                return c.replace(/,/g, "\\,")
            });
            3 >= b.length ? Yi(a, "nw_id", b.join()) : (b = b.slice(0, 3), b.push("__extra__"), Yi(a, "nw_id", b.join()))
        },
        Xi = function(a, b) {
            Yi(a, "vrg", String(b.wc || b.fb));
            EG(a);
            Yi(a, "nslots", Nh().toString());
            b = _.If();
            b.length && Yi(a, "eid", b.join());
            Yi(a, "pub_url", document.URL)
        },
        Ri = function(a, b, c) {
            c = void 0 === c ? .001 : c;
            if (void 0 === c || 0 > c || 1 < c) c = .001;
            Math.random() < c && (a = new Ym(a), b(a), $m(a))
        },
        Oh = new _.v.Map,
        CG = yi(function() {
            return !!lz(_.t.location.href)
        });
    var FG = function(a, b, c, d, e) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = void 0 === d ? 0 : d;
        this.slotId = e;
        this.taskId = void 0;
        this.uniqueId = Math.random()
    };
    var GG, HG, IG, JG, KG;
    GG = _.t.performance;
    HG = !!(GG && GG.mark && GG.measure && GG.clearMarks);
    IG = yi(function() {
        var a;
        if (a = HG) a = QE(), a = !!a.indexOf && 0 <= a.indexOf("1337");
        return a
    });
    JG = function(a, b) {
        this.o = [];
        var c = null;
        b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.o = b.google_js_reporting_queue, c = b.google_measure_js_timing);
        this.j = IG() || (null != c ? c : Math.random() < a)
    };
    _.Dh = function(a) {
        a && GG && IG() && (GG.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), GG.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    KG = function(a, b, c, d, e, f) {
        a.j && (b = new FG(b, c, d, void 0 === e ? 0 : e, f), !a.j || 2048 < a.o.length || a.o.push(b))
    };
    JG.prototype.start = function(a, b) {
        if (!this.j) return null;
        a = new FG(a, b, _.Ng() || _.Mg());
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        GG && IG() && GG.mark(b);
        return a
    };
    JG.prototype.end = function(a) {
        if (this.j && "number" === typeof a.value) {
            a.duration = (_.Ng() || _.Mg()) - a.value;
            var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            GG && IG() && GG.mark(b);
            !this.j || 2048 < this.o.length || this.o.push(a)
        }
    };
    var Ar = function(a, b, c) {
        var d = _.Ng();
        d && KG(a, b, 9, d, 0, c)
    };
    var Ah = function() {
        JG.call(this, _.G(Bh) || _.G(kC) ? 1 : 0, _.t);
        this.m = 0;
        var a = _.G(Bh) || _.G(kC);
        _.t.google_measure_js_timing = a || _.t.google_measure_js_timing
    };
    _.T(Ah, JG);
    _.LG = function(a) {
        this.context = a
    };
    _.LG.prototype.Kb = function(a, b) {
        return Eh(this.context, a, b)
    };
    _.LG.prototype.ya = function(a, b) {
        return yh(this.context, a, b)
    };
    _.LG.prototype.vb = function(a, b) {
        Ch(this.context, a, b);
        return !1
    };
    _.LG.prototype.Wc = ba(4);
    var MG = {},
        NG = (MG.companion_ads = "companionAds", MG.content = "content", MG.publisher_ads = "pubads", MG);
    var Cn = function(a) {
        this.D = _.B(a)
    };
    _.T(Cn, _.E);
    var Dm = function(a) {
        var b = new Cn;
        return xj(b, 1, a)
    };
    var Ks = function(a) {
        this.D = _.B(a)
    };
    _.T(Ks, _.E);
    var Dl = function(a) {
        this.D = _.B(a)
    };
    _.T(Dl, _.E);
    var Yk = function(a) {
        this.D = _.B(a)
    };
    _.T(Yk, _.E);
    var Xk = function(a, b) {
            return On(a, 1, b)
        },
        Wk = function(a, b) {
            return _.Lh(a, 2, b)
        },
        sl = function(a, b) {
            return $w(a, 2, b)
        };
    Yk.ca = [2];
    var js = function(a) {
        this.D = _.B(a)
    };
    _.T(js, _.E);
    js.ca = [2, 3];
    var aq = function(a) {
        this.D = _.B(a)
    };
    _.T(aq, _.E);
    var fq = function(a, b) {
            return _.co(a, 1, b)
        },
        dq = function(a, b) {
            return _.Lh(a, 2, b)
        };
    aq.ca = [2];
    var ls = function(a) {
        this.D = _.B(a)
    };
    _.T(ls, _.E);
    var eq = function(a, b) {
        yj(a, 1, aq, b)
    };
    ls.ca = [1];
    var hs = function(a) {
        this.D = _.B(a)
    };
    _.T(hs, _.E);
    var OG = function(a) {
        this.D = _.B(a)
    };
    _.T(OG, _.E);
    OG.prototype.setTagForChildDirectedTreatment = function(a) {
        return _.co(this, 5, a)
    };
    OG.prototype.clearTagForChildDirectedTreatment = function() {
        return _.ni(this, 5)
    };
    OG.prototype.setTagForUnderAgeOfConsent = function(a) {
        return _.co(this, 6, a)
    };
    var PG = function(a) {
        this.D = _.B(a)
    };
    _.T(PG, _.E);
    PG.prototype.getCategoryExclusions = function(a) {
        return Tw(this, 3, a)
    };
    PG.prototype.Na = function() {
        return Uh(this, Yk, 14)
    };
    PG.prototype.nc = function() {
        return _.Qh(this, Dl, 18)
    };
    var vt = function(a) {
        return _.Qh(a, OG, 25)
    };
    PG.prototype.getCorrelator = function() {
        return Zq(this, 26)
    };
    PG.prototype.setCorrelator = function(a) {
        return _.ni(this, 26, null == a ? a : Zc(a))
    };
    PG.prototype.Ge = function() {
        return is(this, hs, 33)
    };
    PG.ca = [2, 3, 14, 35];
    var mi = function() {
        this.j = new _.v.Map
    };
    var QG = {},
        bi = (QG[253] = !1, QG[246] = [], QG[150] = "", QG[221] = !1, QG[36] = /^true$/.test("false"), QG[172] = null, QG[260] = void 0, QG[251] = null, QG),
        ai = function() {
            this.j = !1
        };
    var RG = function() {
            this.o = {};
            this.j = new PG;
            this.m = new _.v.Map;
            this.j.setCorrelator(zz());
            _.ci(36) && xj(this.j, 15, !0)
        },
        SG = function(a) {
            var b = Hi(),
                c = a.getDomId();
            if (c && !b.o.hasOwnProperty(c)) {
                var d = _.Ff(mi),
                    e = ++_.Ff(Ah).m;
                d.j.set(c, e);
                _.ni(a, 20, _.Nc(e));
                b.o[c] = a
            }
        },
        TG = function(a, b) {
            return a.o[b]
        },
        Hi = function() {
            return _.Ff(RG)
        };
    var UG = yi(vi);
    var fj = ["auto", "inherit", "100%"],
        gj = fj.concat(["none"]),
        VG = [2, 1];
    var Hn = function(a, b, c) {
        if (!a) return !0;
        var d = !0;
        dj(a, function(e) {
            return d = ej(e, b, 10, 10)
        }, c);
        return d
    };
    var WG = /^data-(?!xml)[_a-z][_a-z.0-9-]*$/;
    var XG = function(a, b, c, d, e, f) {
            this.m = _.Fz(a);
            this.o = _.Fz(b);
            this.A = c;
            this.j = _.Fz(d);
            this.J = e;
            this.l = f
        },
        YG = function(a) {
            return JSON.stringify({
                windowCoords_t: a.m.top,
                windowCoords_r: a.m.right,
                windowCoords_b: a.m.bottom,
                windowCoords_l: a.m.left,
                frameCoords_t: a.o.top,
                frameCoords_r: a.o.right,
                frameCoords_b: a.o.bottom,
                frameCoords_l: a.o.left,
                styleZIndex: a.A,
                allowedExpansion_t: a.j.top,
                allowedExpansion_r: a.j.right,
                allowedExpansion_b: a.j.bottom,
                allowedExpansion_l: a.j.left,
                xInView: a.J,
                yInView: a.l
            })
        },
        ZG = function(a) {
            var b = window,
                c = b.screenX || b.screenLeft || 0,
                d = b.screenY || b.screenTop || 0;
            b = new _.Ez(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
            c = Qz(a);
            d = _.ii(_.Tz, a);
            var e = new Gz(c.x, c.y, d.width, d.height);
            c = Hz(e);
            d = String(Oz(a, "zIndex"));
            var f = new _.Ez(0, Infinity, Infinity, 0);
            for (var g = cf(a), h = g.j.body, k = g.j.documentElement, l = Uy(g.j); a = Pz(a);)
                if (!(_.aw && 0 == a.clientWidth || dw && 0 == a.clientHeight && a == h) && a != h && a != k && "visible" != Oz(a, "overflow")) {
                    var m = Qz(a),
                        n = new _.gi(a.clientLeft, a.clientTop);
                    m.x += n.x;
                    m.y += n.y;
                    f.top = Math.max(f.top, m.y);
                    f.right = Math.min(f.right, m.x + a.clientWidth);
                    f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                    f.left = Math.max(f.left, m.x)
                }
            a = l.scrollLeft;
            l = l.scrollTop;
            f.left = Math.max(f.left, a);
            f.top = Math.max(f.top, l);
            g = g.j;
            g = _.Ty(g.parentWindow || g.defaultView || window);
            f.right = Math.min(f.right, a + g.width);
            f.bottom = Math.min(f.bottom, l + g.height);
            l = (f = (f = 0 <= f.top && 0 <= f.left && f.bottom > f.top && f.right > f.left ? f : null) ? new Gz(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ? Iz(e, f) : null;
            g = a = 0;
            l && !(new _.ki(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
            l = new _.Ez(0, 0, 0, 0);
            if (h = f)(e = Iz(e, f)) ? (k = Hz(f), m = Hz(e), h = m.right != k.left && k.right != m.left, k = m.bottom != k.top && k.bottom != m.top, h = (0 != e.width || h) && (0 != e.height || k)) : h = !1;
            h && (l = new _.Ez(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
            return new XG(b, c, d, l, a, g)
        };
    var $G = function(a) {
        this.A = a;
        this.J = null;
        this.v = this.status = 0;
        this.o = null;
        this.wb = "sfchannel" + a
    };
    $G.prototype.dg = function() {
        return 2 == this.v
    };
    var aH = function(a) {
        this.j = a
    };
    aH.prototype.getValue = function(a, b) {
        return null == this.j[a] || null == this.j[a][b] ? null : this.j[a][b]
    };
    var bH = function(a, b) {
        this.ye = a;
        this.ze = b;
        this.o = this.j = !1
    };
    var cH = function(a, b, c, d, e, f, g, h) {
        h = void 0 === h ? [] : h;
        this.o = a;
        this.m = b;
        this.A = c;
        this.permissions = d;
        this.metadata = e;
        this.J = f;
        this.Cd = g;
        this.hostpageLibraryTokens = h;
        this.j = ""
    };
    var dH = function(a, b) {
        this.o = a;
        this.A = b
    };
    dH.prototype.j = function(a) {
        this.A && a && (a.sentinel = this.A);
        return JSON.stringify(a)
    };
    var eH = function(a, b, c) {
        dH.call(this, a, void 0 === c ? "" : c);
        this.version = b
    };
    _.T(eH, dH);
    eH.prototype.j = function() {
        return dH.prototype.j.call(this, {
            uid: this.o,
            version: this.version
        })
    };
    var fH = function(a, b, c, d) {
        dH.call(this, a, void 0 === d ? "" : d);
        this.J = b;
        this.m = c
    };
    _.T(fH, dH);
    fH.prototype.j = function() {
        return dH.prototype.j.call(this, {
            uid: this.o,
            initialWidth: this.J,
            initialHeight: this.m
        })
    };
    var gH = function(a, b, c) {
        dH.call(this, a, void 0 === c ? "" : c);
        this.description = b
    };
    _.T(gH, dH);
    gH.prototype.j = function() {
        return dH.prototype.j.call(this, {
            uid: this.o,
            description: this.description
        })
    };
    var hH = function(a, b, c, d) {
        dH.call(this, a, void 0 === d ? "" : d);
        this.m = b;
        this.push = c
    };
    _.T(hH, dH);
    hH.prototype.j = function() {
        return dH.prototype.j.call(this, {
            uid: this.o,
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        })
    };
    var iH = function(a, b) {
        dH.call(this, a, void 0 === b ? "" : b)
    };
    _.T(iH, dH);
    iH.prototype.j = function() {
        return dH.prototype.j.call(this, {
            uid: this.o
        })
    };
    var jH = function(a, b, c) {
        dH.call(this, a, void 0 === c ? "" : c);
        this.J = b
    };
    _.T(jH, dH);
    jH.prototype.j = function() {
        var a = {
            uid: this.o,
            newGeometry: YG(this.J)
        };
        return dH.prototype.j.call(this, a)
    };
    var kH = function(a, b, c, d, e, f) {
        jH.call(this, a, c, void 0 === f ? "" : f);
        this.success = b;
        this.m = d;
        this.push = e
    };
    _.T(kH, jH);
    kH.prototype.j = function() {
        var a = {
            uid: this.o,
            success: this.success,
            newGeometry: YG(this.J),
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        };
        this.A && (a.sentinel = this.A);
        return JSON.stringify(a)
    };
    var lH = function(a, b, c, d) {
        dH.call(this, a, void 0 === d ? "" : d);
        this.width = b;
        this.height = c
    };
    _.T(lH, dH);
    lH.prototype.j = function() {
        return dH.prototype.j.call(this, {
            uid: this.o,
            width: this.width,
            height: this.height
        })
    };
    var mH = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Ek(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    var nH, qH, rH, pH;
    nH = function() {
        this.j = []
    };
    _.oH = function(a) {
        return a + "px"
    };
    qH = function(a, b, c, d, e) {
        a.j.push(new pH(b, c, d, e))
    };
    rH = function(a) {
        for (var b = a.j.length - 1; 0 <= b; b--) {
            var c = a.j[b];
            c.o ? (c.m.style.removeProperty(c.j), c.m.style.setProperty(c.j, String(c.A), c.J)) : c.m.style[c.j] = c.A
        }
        a.j.length = 0
    };
    pH = function(a, b, c, d) {
        this.m = a;
        this.j = (this.o = !(void 0 === d || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
        this.A = this.o ? a.style.getPropertyValue(this.j) : a.style[this.j];
        this.J = this.o ? a.style.getPropertyPriority(this.j) : void 0;
        this.o ? (a.style.removeProperty(this.j), a.style.setProperty(this.j, String(c), d)) : a.style[this.j] = String(c)
    };
    var sH, tH;
    sH = function(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    tH = function() {
        var a = window,
            b = _.Ng(a);
        b && sH({
            label: "2",
            type: 9,
            value: b
        }, a)
    };
    _.uH = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        var f = d || window,
            g = "undefined" !== typeof queueMicrotask;
        return function() {
            e && g && queueMicrotask(function() {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var h = _.Ng(),
                k = 3;
            try {
                var l = b.apply(this, arguments)
            } catch (m) {
                k = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                f.google_measure_js_timing && h && sH(_.A(Object, "assign").call(Object, {}, {
                    label: a.toString(),
                    value: h,
                    duration: (_.Ng() || 0) - h,
                    type: k
                }, e && g && {
                    taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                }), f)
            }
            return l
        }
    };
    var zH = function(a) {
        $G.call(this, a.uniqueId);
        var b = this;
        this.H = a.Uk;
        this.M = 1 === a.size;
        this.U = new bH(a.permissions.ye && !this.M, a.permissions.ze && !this.M);
        this.l = a.yg;
        var c;
        this.pa = null != (c = a.hostpageLibraryTokens) ? c : [];
        var d = window.location;
        c = d.protocol;
        d = d.host;
        this.ma = "file:" == c ? "*" : c + "//" + d;
        this.za = !!a.Cd;
        this.K = a.Di ? "//" + a.Di + ".safeframe.googlesyndication.com" : "//tpc.googlesyndication.com";
        this.Ha = a.pb ? "*" : "https:" + this.K;
        this.ba = !!a.ak;
        this.ua = vH(a);
        this.m = new nH;
        wH(this, a.yg, a.size);
        this.J = this.fa = ZG(a.yg);
        this.G = a.Dl || "1-0-40";
        var e;
        this.Ea = null != (e = a.Dj) ? e : "";
        xH(this, a);
        this.C = _.uH(412, function() {
            return yH(b)
        }, a.ob);
        this.ta = -1;
        this.I = 0;
        var f = _.uH(415, function() {
            b.j && (b.j.name = "", a.gi && a.gi(), _.of(b.j, "load", f))
        }, a.ob);
        _.ib(this.j, "load", f);
        this.Zf = _.uH(413, this.Zf, a.ob);
        this.Cg = _.uH(417, this.Cg, a.ob);
        this.Gg = _.uH(419, this.Gg, a.ob);
        this.Sf = _.uH(411, this.Sf, a.ob);
        this.Cf = _.uH(409, this.Cf, a.ob);
        this.O = _.uH(410, this.O, a.ob);
        this.tg = _.uH(416, this.tg, a.ob);
        this.o = new fF(this.wb, this.j.contentWindow, this.Ha, !1);
        hF(this.o, "init_done", (0, _.Mu)(this.Zf, this));
        hF(this.o, "register_done", (0, _.Mu)(this.Cg, this));
        hF(this.o, "report_error", (0, _.Mu)(this.Gg, this));
        hF(this.o, "expand_request", (0, _.Mu)(this.Sf, this));
        hF(this.o, "collapse_request", (0, _.Mu)(this.Cf, this));
        hF(this.o, "creative_geometry_update", (0, _.Mu)(this.O, this));
        this.o.connect((0, _.Mu)(this.tg, this))
    };
    _.T(zH, $G);
    var wH = function(a, b, c) {
            a.M ? (b.style.width = _.Sz("100%", !0), b.style.height = _.Sz("auto", !0)) : (b.style.width = _.Sz(c.width, !0), b.style.height = _.Sz(c.height, !0))
        },
        xH = function(a, b) {
            var c = b.pb,
                d = b.content,
                e = b.zd,
                f = b.size,
                g = void 0 === b.Bd ? "3rd party ad content" : b.Bd,
                h = b.Ae;
            b = b.yf;
            var k = {
                shared: {
                    sf_ver: a.G,
                    ck_on: KE() ? 1 : 0,
                    flash_ver: "0"
                }
            };
            d = c ? "" : null != d ? d : "";
            d = a.G + ";" + d.length + ";" + d;
            k = new cH(a.A, a.ma, a.fa, a.U, new aH(k), a.M, a.za, a.pa);
            var l = {};
            l.uid = k.o;
            l.hostPeerName = k.m;
            l.initialGeometry = YG(k.A);
            var m = k.permissions;
            m = JSON.stringify({
                expandByOverlay: m.ye,
                expandByPush: m.ze,
                readCookie: m.j,
                writeCookie: m.o
            });
            l = (l.permissions = m, l.metadata = JSON.stringify(k.metadata.j), l.reportCreativeGeometry = k.J, l.isDifferentSourceWindow = k.Cd, l.goog_safeframe_hlt = dF(k.hostpageLibraryTokens), l);
            k.j && (l.sentinel = k.j);
            k = JSON.stringify(l);
            d += k;
            a.ba && f instanceof _.ki && (k = _.Vy(_.Py(a.l)), l = _.Vy(_.Py(a.l)).location.protocol + a.K, NE || _.an(k.document, OE), NE++, k.google_eas_queue = k.google_eas_queue || [], k.google_eas_queue.push({
                a: e,
                b: l,
                c: f.width,
                d: f.height,
                e: "sf-gdn-exp-" + NE,
                f: void 0,
                g: void 0,
                h: void 0,
                i: void 0
            }));
            k = f.width;
            f = f.height;
            a.M && (f = k = 0);
            l = {};
            e = (l.id = e, l.title = g, l.name = d, l.scrolling = "no", l.marginWidth = "0", l.marginHeight = "0", l.width = String(k), l.height = String(f), l["data-is-safeframe"] = "true", l);
            void 0 === c && (g = _.Vy(_.Py(a.l)), f = a.Ea, d = a.K, (k = f) && (k = "?" + k), d = (void 0 === d ? "//tpc.googlesyndication.com" : d) + ("/safeframe/" + a.G + "/html/container.html" + k), (k = mH(g)) && (d += (f ? "&" : "?") + "n=" + k), f = "https:" + d, d = [], a.ba && (k = lz(g.location.href), g = d.push, k = [0 < k.length ? "google_debug" + (k ? "=" + k : "") + "&" : "", "xpc=", "sf-gdn-exp-" + a.A, "&p=", encodeURIComponent(_.t.document.location.protocol), "//", encodeURIComponent(_.t.document.location.host)].join(""), g.call(d, k)), d.length && (f += "#" + d.join("&")), e.src = f);
            null !== a.ua && (e.sandbox = a.ua);
            h && (e.allow = h);
            b && (e.credentialless = "true");
            e.role = "region";
            e["aria-label"] = "Advertisement";
            e.tabIndex = "0";
            c ? (a.j = c, Ry(a.j, e)) : (c = {}, c = (c.frameborder = 0, c.allowTransparency = "true", c.style = "border:0;vertical-align:bottom;", c.src = "about:blank", c), e && Ea(c, e), h = _.af("IFRAME"), Ry(h, c), a.j = h);
            a.M && (a.j.style.minWidth = "100%");
            a.l.appendChild(a.j)
        };
    _.q = zH.prototype;
    _.q.tg = function() {
        _.ib(window, "resize", this.C);
        _.ib(window, "scroll", this.C)
    };
    _.q.Zf = function(a) {
        try {
            if (0 != this.status) throw Error("Container already initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ja(b) || !ij(b.uid) || "string" !== typeof b.version) throw Error("Cannot parse JSON message");
            var c = new eH(b.uid, b.version, b.sentinel);
            if (this.A !== c.o || this.G !== c.version) throw Error("Wrong source container");
            this.status = 1
        } catch (e) {
            var d;
            null == (d = this.H) || d.error("Invalid INITIALIZE_DONE message. Reason: " + e.message)
        }
    };
    _.q.Cg = function(a) {
        try {
            if (1 != this.status) throw Error("Container not initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ja(b) || !ij(b.uid) || "number" !== typeof b.initialWidth || "number" !== typeof b.initialHeight) throw Error("Cannot parse JSON message");
            if (this.A !== (new fH(b.uid, b.initialWidth, b.initialHeight, b.sentinel)).o) throw Error("Wrong source container");
            this.status = 2
        } catch (d) {
            var c;
            null == (c = this.H) || c.error("Invalid REGISTER_DONE message. Reason: " + d.message)
        }
    };
    _.q.Gg = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ja(b) || !ij(b.uid) || "string" !== typeof b.description) throw Error("Cannot parse JSON message");
            var c = new gH(b.uid, b.description, b.sentinel);
            if (this.A !== c.o) throw Error("Wrong source container");
            var d;
            null == (d = this.H) || d.info("Ext reported an error. Description: " + c.description)
        } catch (f) {
            var e;
            null == (e = this.H) || e.error("Invalid REPORT_ERROR message. Reason: " + f.message)
        }
    };
    _.q.Sf = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (0 != this.v) throw Error("Container is not collapsed");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ja(b) || !ij(b.uid) || "number" !== typeof b.expand_t || "number" !== typeof b.expand_r || "number" !== typeof b.expand_b || "number" !== typeof b.expand_l || "boolean" !== typeof b.push) throw Error("Cannot parse JSON message");
            var c = new hH(b.uid, new _.Ez(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.A !== c.o) throw Error("Wrong source container");
            if (!(0 <= c.m.top && 0 <= c.m.left && 0 <= c.m.bottom && 0 <= c.m.right)) throw Error("Invalid expansion amounts");
            var d;
            if (d = c.push && this.U.ze || !c.push && this.U.ye) {
                var e = c.m,
                    f = c.push,
                    g = this.J = ZG(this.j);
                if (e.top <= g.j.top && e.right <= g.j.right && e.bottom <= g.j.bottom && e.left <= g.j.left) {
                    if (!f)
                        for (var h = this.j.parentNode; h && h.style; h = h.parentNode) qH(this.m, h, "overflowX", "visible", "important"), qH(this.m, h, "overflowY", "visible", "important");
                    var k = Hz(new Gz(0, 0, this.J.o.getWidth(), this.J.o.getHeight()));
                    _.ja(e) ? (k.top -= e.top, k.right += e.right, k.bottom += e.bottom, k.left -= e.left) : (k.top -= e, k.right += Number(void 0), k.bottom += Number(void 0), k.left -= Number(void 0));
                    qH(this.m, this.l, "position", "relative");
                    qH(this.m, this.j, "position", "absolute");
                    if (f) {
                        var l = k.getWidth();
                        qH(this.m, this.l, "width", _.oH(l));
                        var m = k.getHeight();
                        qH(this.m, this.l, "height", _.oH(m))
                    } else qH(this.m, this.j, "zIndex", "10000");
                    var n = k.getWidth();
                    qH(this.m, this.j, "width", _.oH(n));
                    var p = k.getHeight();
                    qH(this.m, this.j, "height", _.oH(p));
                    qH(this.m, this.j, "left", _.oH(k.left));
                    qH(this.m, this.j, "top", _.oH(k.top));
                    this.v = 2;
                    this.J = ZG(this.j);
                    d = !0
                } else d = !1
            }
            a = d;
            this.o.send("expand_response", (new kH(this.A, a, this.J, c.m, c.push)).j());
            if (!a) throw Error("Viewport or document body not large enough to expand into.");
        } catch (w) {
            var r;
            null == (r = this.H) || r.error("Invalid EXPAND_REQUEST message. Reason: " + w.message)
        }
    };
    _.q.Cf = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (!this.dg()) throw Error("Container is not expanded");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ja(b) || !ij(b.uid)) throw Error("Cannot parse JSON message");
            if (this.A !== (new iH(b.uid, b.sentinel)).o) throw Error("Wrong source container");
            rH(this.m);
            this.v = 0;
            this.j && (this.J = ZG(this.j));
            this.o.send("collapse_response", (new jH(this.A, this.J)).j())
        } catch (d) {
            var c;
            null == (c = this.H) || c.error("Invalid COLLAPSE_REQUEST message. Reason: " + d.message)
        }
    };
    var yH = function(a) {
        if (1 == a.status || 2 == a.status) switch (a.I) {
            case 0:
                AH(a);
                a.ta = window.setTimeout((0, _.Mu)(a.da, a), 1E3);
                a.I = 1;
                break;
            case 1:
                a.I = 2;
                break;
            case 2:
                a.I = 2
        }
    };
    zH.prototype.O = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.ja(b) || !ij(b.uid) || "number" !== typeof b.width || "number" !== typeof b.height || b.sentinel && "string" !== typeof b.sentinel) throw Error("Cannot parse JSON message");
            var c = new lH(b.uid, b.width, b.height, b.sentinel);
            if (this.A !== c.o) throw Error("Wrong source container");
            var d = String(c.height);
            if (this.M) d !== this.j.height && (this.j.height = d, yH(this));
            else {
                var e;
                null == (e = this.H) || e.error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            }
        } catch (g) {
            var f;
            null == (f = this.H) || f.error("Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: " + g.message)
        }
    };
    zH.prototype.da = function() {
        if (1 == this.status || 2 == this.status) switch (this.I) {
            case 1:
                this.I = 0;
                break;
            case 2:
                AH(this), this.ta = window.setTimeout((0, _.Mu)(this.da, this), 1E3), this.I = 1
        }
    };
    var AH = function(a) {
            a.J = ZG(a.j);
            a.o.send("geometry_update", (new jH(a.A, a.J)).j())
        },
        vH = function(a) {
            var b = null;
            a.Fi && (b = a.Fi);
            return null == b ? null : b.join(" ")
        },
        BH = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        CH = ["allow-top-navigation"],
        DH = ["allow-same-origin"],
        EH = oz([].concat(_.ch(BH), _.ch(CH)));
    oz([].concat(_.ch(BH), _.ch(DH)));
    oz([].concat(_.ch(BH), _.ch(CH), _.ch(DH)));
    var FH = _.ju(["https://tpc.googlesyndication.com/safeframe/", "/html/container.html"]),
        GH = {
            Pk: function(a) {
                if ("string" !== typeof a.version) throw new TypeError("version is not a string");
                if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError("Invalid version: " + a.version);
                if ("string" !== typeof a.mf) throw new TypeError("subdomain is not a string");
                if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.mf)) throw new RangeError("Invalid subdomain: " + a.mf);
                return Le("https://" + a.mf + ".safeframe.googlesyndication.com/safeframe/" + a.version + "/html/container.html")
            },
            On: function(a) {
                return _.Me(FH, a)
            }
        };
    var HH = function() {};
    HH.j = function() {
        throw Error("Must be overridden");
    };
    var mj = function() {
        this.j = 0
    };
    _.T(mj, HH);
    mj.tc = void 0;
    mj.j = function() {
        return mj.tc ? mj.tc : mj.tc = new mj
    };
    var IH = function() {
            this.cache = {}
        },
        vj = function() {
            JH || (JH = new IH);
            return JH
        },
        wj = function(a) {
            var b = Xc(bo(a, 3));
            if (!b) return 3;
            if (void 0 === _.sj(a, 2)) return 4;
            a = Date.now();
            return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
        };
    IH.prototype.get = function(a, b) {
        if (this.cache[a]) return {
            Cc: this.cache[a],
            success: !0
        };
        var c = "";
        try {
            c = b.getItem("_GESPSK-" + a)
        } catch (g) {
            var d;
            oj(6, a, null == (d = g) ? void 0 : d.message);
            return {
                Cc: null,
                success: !1
            }
        }
        if (!c) return {
            Cc: null,
            success: !0
        };
        try {
            var e = hy(c);
            this.cache[a] = e;
            return {
                Cc: e,
                success: !0
            }
        } catch (g) {
            var f;
            oj(5, a, null == (f = g) ? void 0 : f.message);
            return {
                Cc: null,
                success: !1
            }
        }
    };
    IH.prototype.set = function(a, b) {
        var c = _.sj(a, 1),
            d = "_GESPSK-" + c;
        gy(a);
        try {
            b.setItem(d, tk(a))
        } catch (f) {
            var e;
            oj(7, c, null == (e = f) ? void 0 : e.message);
            return !1
        }
        this.cache[c] = a;
        return !0
    };
    var JH = null;
    var KH = function(a, b) {
        XF.call(this, a);
        this.id = a;
        this.C = b
    };
    _.T(KH, XF);
    KH.prototype.I = function(a) {
        this.C(this.id, a)
    };
    var Dj = function(a, b, c, d) {
        KH.call(this, 1041, d);
        this.l = b;
        this.G = W(this, a);
        c && (this.v = X(this, c))
    };
    _.T(Dj, KH);
    Dj.prototype.j = function() {
        var a = this.G.value,
            b, c, d = null != (c = this.l) ? c : null == (b = this.v) ? void 0 : b.value;
        d && vj().set(a, d) && null != _.sj(a, 2) && oj(27, _.sj(a, 1))
    };
    var Fj = function(a, b) {
        KH.call(this, 1048, b);
        this.l = V(this);
        this.v = V(this);
        this.G = W(this, a)
    };
    _.T(Fj, KH);
    Fj.prototype.j = function() {
        var a = this.G.value,
            b = function(c) {
                var d = {};
                oj(c, _.sj(a, 1), null, (d.tic = String(Math.round((Date.now() - Xc(bo(a, 3))) / 6E4)), d))
            };
        switch (wj(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                this.v.F(a);
                break;
            case 2:
                b(26);
                this.l.F(a);
                break;
            case 3:
                oj(9, _.sj(a, 1));
                this.l.F(a);
                break;
            case 4:
                b(23), this.l.F(a)
        }
    };
    var LH = function(a, b) {
        KH.call(this, 1094, b);
        this.l = $F(this);
        this.v = W(this, a)
    };
    _.T(LH, KH);
    LH.prototype.j = function() {
        var a = this.v.value;
        if (a) {
            if (void 0 !== a)
                for (var b = _.z(_.A(Object, "keys").call(Object, a)), c = b.next(); !c.done; c = b.next())
                    if (c = c.value, _.A(c, "startsWith").call(c, "_GESPSK")) try {
                        a.removeItem(c)
                    } catch (d) {}
            JH = new IH;
            this.l.notify()
        }
    };
    var Uj = function(a, b, c) {
        KH.call(this, 1049, c);
        this.l = b;
        bG(this, a)
    };
    _.T(Uj, KH);
    Uj.prototype.j = function() {
        for (var a = _.z(qj(this.l)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = vj().get(b, this.l).Cc;
            if (c) {
                var d = wj(c);
                if (2 === d || 3 === d) {
                    d = void 0;
                    var e = vj();
                    c = _.sj(c, 1);
                    try {
                        this.l.removeItem("_GESPSK-" + c), delete e.cache[c]
                    } catch (f) {
                        oj(8, c, null == (d = f) ? void 0 : d.message)
                    }
                    oj(40, b)
                }
            }
        }
    };
    var Cj = function(a, b, c) {
        KH.call(this, 1027, c);
        this.pe = a;
        this.G = b;
        this.l = V(this);
        this.v = V(this)
    };
    _.T(Cj, KH);
    Cj.prototype.j = function() {
        var a = vj().get(this.pe, this.G).Cc;
        a || (a = gy(fy(this.pe)), this.v.F(a.ib(dy(100))));
        this.l.F(a)
    };
    var Mj = {};
    var Yj = function(a, b) {
        KH.call(this, 1036, b);
        this.l = V(this);
        this.v = W(this, a)
    };
    _.T(Yj, KH);
    Yj.prototype.j = function() {
        var a = this.v.value;
        0 !== wj(a) && this.l.F(a)
    };
    var Jj = function(a, b, c) {
        KH.call(this, 1046, c);
        this.output = $F(this);
        this.l = V(this);
        this.v = W(this, b);
        bG(this, a)
    };
    _.T(Jj, KH);
    Jj.prototype.j = function() {
        this.l.F(this.v.value)
    };
    var Gj = function(a, b, c) {
        KH.call(this, 1047, c);
        this.collectorFunction = a;
        this.l = V(this);
        this.v = V(this);
        this.G = V(this);
        this.K = W(this, b)
    };
    _.T(Gj, KH);
    Gj.prototype.j = function() {
        var a = this,
            b = this.K.value,
            c = _.sj(b, 1);
        oj(18, c);
        try {
            var d = _.Mg();
            this.collectorFunction().then(function(e) {
                oj(29, c, null, {
                    delta: String(_.Mg() - d)
                });
                a.l.F(On(b, 2, e));
                a.G.Ca(e)
            }).catch(function(e) {
                oj(28, c, Aj(e));
                a.v.F(b.ib(dy(106)))
            })
        } catch (e) {
            oj(1, c, Aj(e)), this.v.F(b.ib(dy(107)))
        }
    };
    var Ej = function(a, b) {
        KH.call(this, 1028, b);
        this.l = V(this);
        this.v = W(this, a)
    };
    _.T(Ej, KH);
    Ej.prototype.j = function() {
        var a = this.v.value,
            b = _.sj(a, 1);
        null != Xc(bo(a, 3)) || oj(35, b);
        this.l.F(a)
    };
    var Hj = function(a, b, c, d, e) {
        KH.call(this, 1050, e);
        this.K = c;
        this.G = d;
        this.l = V(this);
        this.v = W(this, a);
        this.O = X(this, b)
    };
    _.T(Hj, KH);
    Hj.prototype.j = function() {
        var a = this.v.value,
            b = _.sj(a, 1),
            c = this.O.value;
        if (null == c) oj(41, b), a.ib(dy(111)), this.l.F(a);
        else if ("string" !== typeof c) oj(21, b), this.l.F(a.ib(dy(113)));
        else {
            if (c.length > (/^(\d+)$/.test(b) ? this.G : this.K)) {
                var d = {};
                oj(12, b, null, (d.sl = String(c.length), d));
                b = a.ib(dy(108));
                _.ni(b, 2)
            } else c.length || oj(20, b), _.ni(a, 10);
            this.l.F(a)
        }
    };
    var Ij = function(a) {
        KH.call(this, 1046, a);
        this.output = $F(this)
    };
    _.T(Ij, KH);
    Ij.prototype.j = function() {
        var a = this;
        pj().then(function() {
            a.output.notify()
        })
    };
    var MH = function(a, b, c, d) {
        KH.call(this, 1059, d);
        this.K = b;
        this.G = c;
        this.l = V(this);
        this.O = W(this, a);
        this.v = X(this, c)
    };
    _.T(MH, KH);
    MH.prototype.j = function() {
        var a = this.v.value;
        if (a) {
            var b = this.O.value,
                c = b.id,
                d = b.collectorFunction,
                e;
            b = null != (e = b.networkCode) ? e : c;
            c = {};
            oj(42, b, null, (c.ea = String(Number(this.K)), c));
            this.l.Ka(Lj(b, d, a, this.G, this.C))
        }
    };
    var NH = function(a, b) {
        KH.call(this, 1057, b);
        this.l = a;
        this.v = V(this);
        this.G = V(this)
    };
    _.T(NH, KH);
    NH.prototype.j = function() {
        if (this.l)
            if ("object" !== typeof this.l) oj(46, "UNKNOWN_COLLECTOR_ID"), OH(this, "UNKNOWN_COLLECTOR_ID", 112);
            else {
                var a = this.l.id,
                    b = this.l.networkCode;
                a && b && (delete this.l.id, oj(47, a + ";" + b));
                a = null != b ? b : a;
                "string" !== typeof a ? (b = {}, oj(37, "INVALID_COLLECTOR_ID", null, (b.ii = JSON.stringify(a), b)), OH(this, "INVALID_COLLECTOR_ID", 102)) : "function" !== typeof this.l.collectorFunction ? (oj(14, a), OH(this, a, 105)) : (_.F = Wf(eB), _.A(_.F, "includes")).call(_.F, a) ? (oj(22, a), OH(this, a, 104)) : this.G.F(this.l)
            }
        else oj(39, "UNKNOWN_COLLECTOR_ID"), OH(this, "UNKNOWN_COLLECTOR_ID", 110)
    };
    var OH = function(a, b, c) {
        a.v.F(fy(b).ib(dy(c)))
    };
    var Sj = function(a, b, c, d, e) {
        var f = document;
        f = void 0 === f ? document : f;
        e = void 0 === e ? Mj : e;
        this.j = b;
        this.m = c;
        this.V = f;
        this.I = d;
        this.H = e;
        this.l = [];
        this.J = [];
        this.A = [];
        this.o = 0;
        a = _.z(a);
        for (b = a.next(); !b.done; b = a.next()) this.push(b.value)
    };
    Sj.prototype.push = function(a) {
        var b = this;
        this.m || this.I();
        var c = function(f, g) {
            return void PH(b, f, g)
        };
        a = new NH(a, c);
        var d = new Dj(a.v, void 0, this.j, c);
        c = new MH(a.G, this.m, this.j, c, this.H);
        var e = new Bj;
        Vj(e, [a, d, c]);
        Kj(e);
        a = c.l.promise;
        this.l.push(a);
        d = _.z(this.J);
        for (c = d.next(); !c.done; c = d.next()) a.then(c.value)
    };
    Sj.prototype.addOnSignalResolveCallback = function(a) {
        this.J.push(a);
        for (var b = _.z(this.l), c = b.next(); !c.done; c = b.next()) c.value.then(a)
    };
    Sj.prototype.addErrorHandler = function(a) {
        this.A.push(a)
    };
    Sj.prototype.clearAllCache = function() {
        var a = this,
            b = this.V.currentScript instanceof HTMLScriptElement ? this.V.currentScript.src : "";
        if (1 === this.o) {
            var c = {};
            oj(49, "", null, (c.url = b, c))
        } else if (c = String(_.Rf(null != b ? b : "")), (_.F = Wf(dB), _.A(_.F, "includes")).call(_.F, c)) c = {}, oj(48, "", null, (c.url = b, c));
        else {
            var d = new Bj;
            c = new LH(this.j, function(e, f) {
                return void PH(a, e, f)
            });
            M(d, c);
            Kj(d);
            this.o = 1;
            setTimeout(function() {
                a.o = 0
            }, 1E3 * _.Uf(cB));
            d = {};
            oj(43, "", null, (d.url = b, d));
            return c.l.promise
        }
    };
    var PH = function(a, b, c) {
            a = _.z(a.A);
            for (var d = a.next(); !d.done; d = a.next()) d = d.value, d(b, c)
        },
        Tj = function(a) {
            this.push = function(b) {
                a.push(b)
            };
            this.addOnSignalResolveCallback = function(b) {
                a.addOnSignalResolveCallback(b)
            };
            this.addErrorHandler = function(b) {
                a.addErrorHandler(b)
            };
            this.clearAllCache = function() {
                a.clearAllCache()
            }
        };
    var Zj = function(a, b, c) {
        KH.call(this, 1035, c);
        this.v = b;
        this.l = V(this);
        this.G = W(this, a)
    };
    _.T(Zj, KH);
    Zj.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c = _.sj(b, 1),
            d = this.v.toString(),
            e = {};
        oj(30, c, null, (e.url = d, e));
        var f = document.createElement("script");
        f.setAttribute("esp-signal", "true");
        hb(f, this.v);
        var g = function() {
            var h = {};
            oj(31, c, null, (h.url = d, h));
            a.l.F(b.ib(dy(109)));
            _.of(f, "error", g)
        };
        document.head.appendChild(f);
        _.ib(f, "error", g)
    };
    var Xj = new _.v.Set;
    var bk = function(a, b) {
        try {
            sb(Dq(a, b))
        } catch (c) {}
    };
    var QH = function(a) {
        this.D = _.B(a)
    };
    _.T(QH, _.E);
    QH.prototype.j = Ie([0, cx, -3, fx]);
    var RH = [.05, .1, .2, .5],
        SH = [0, .5, 1],
        TH = function(a) {
            a = Oj(a);
            if (!a) return -1;
            try {
                var b = RE(a.document);
                var c = new _.ki(b.clientWidth, b.clientHeight)
            } catch (d) {
                c = new _.ki(-12245933, -12245933)
            }
            return -12245933 == c.width || -12245933 == c.height ? -1 : c.width * c.height
        },
        UH = function(a, b) {
            return 0 >= a || 0 >= b ? [] : RH.map(function(c) {
                return Math.min(a / b * c, 1)
            })
        },
        WH = function(a) {
            this.J = a.B;
            this.m = a.Nb;
            this.H = a.timer;
            this.o = null;
            this.A = a.ob;
            this.j = VH(this);
            this.l = a.Ol || !1
        },
        XH = function() {
            var a;
            return !!window.IntersectionObserver && qz(null == (a = window.performance) ? void 0 : a.now)
        };
    WH.prototype.getSlotId = function() {
        return this.o
    };
    var ZH = function(a, b) {
            if (a.j) {
                if (null != a.o) {
                    try {
                        YH(a, Math.round(performance.now()), 0, 0, 0, !1)
                    } catch (c) {
                        a.A && a.A(c)
                    }
                    a.j && a.j.unobserve(a.m)
                }
                a.o = b;
                a.j.observe(a.m)
            }
        },
        VH = function(a) {
            if (!_.t.IntersectionObserver) return null;
            var b = a.m.offsetWidth * a.m.offsetHeight,
                c = TH(a.J);
            b = [].concat(_.ch(SH), _.ch(UH(c, b)));
            la(b);
            return new _.t.IntersectionObserver(function(d) {
                try {
                    for (var e = TH(a.J), f = _.z(d), g = f.next(); !g.done; g = f.next()) {
                        var h = g.value;
                        a.l && YH(a, Math.round(h.time), h.boundingClientRect.width * h.boundingClientRect.height, h.intersectionRect.width * h.intersectionRect.height, e, h.isIntersecting)
                    }
                } catch (k) {
                    a.A && a.A(k)
                }
            }, {
                threshold: b
            })
        },
        YH = function(a, b, c, d, e, f) {
            if (null == a.o) throw Error("Not Attached.");
            var g = new QH;
            c = _.qk(g, 1, c);
            d = _.qk(c, 2, d);
            e = _.qk(d, 3, e);
            b = _.qk(e, 4, b);
            f = xj(b, 5, f);
            f = zb(f.j(), 4);
            KG(a.H, "1", 10, f, void 0, a.o)
        };
    var $H = function(a, b) {
            this.j = a;
            this.o = b
        },
        aI = function(a) {
            if (a.j.frames.google_ads_top_frame) return !0;
            var b = sz(a.j);
            b = b && b.contentWindow;
            if (!b) return !1;
            b.addEventListener("message", function(c) {
                var d = c.ports;
                "__goog_top_url_req" === c.data.msgType && d.length && d[0].postMessage({
                    msgType: "__goog_top_url_resp",
                    topUrl: a.o
                })
            }, !1);
            return !0
        };
    var pk = function(a) {
        this.D = _.B(a)
    };
    _.T(pk, _.E);
    var vk = Je(pk),
        sk = [1, 3];
    var ok = {
        vn: 0,
        qn: 1,
        rn: 9,
        nn: 2,
        on: 3,
        un: 5,
        sn: 7,
        pn: 10
    };
    var bI = _.ju(["https://securepubads.g.doubleclick.net/static/topics/topics_frame.html"]),
        ik = _.Me(bI);
    var cI = function() {
            this.id = "goog_" + Ly++
        },
        dI = function(a) {
            _.U.call(this);
            this.context = a;
            this.m = new _.v.Map
        };
    _.T(dI, _.U);
    dI.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.m.clear()
    };
    dI.prototype.listen = function(a, b) {
        var c = this;
        if (this.J) return function() {};
        var d = "string" === typeof a ? a : a.id,
            e, f, g = null != (f = null == (e = this.m.get(d)) ? void 0 : e.add(b)) ? f : new _.v.Set([b]);
        this.m.set(d, g);
        return function() {
            return void eI(c, a, b)
        }
    };
    var fI = function(a) {
            var b = xs;
            var c = void 0 === c ? function() {
                return !0
            } : c;
            return new _.v.Promise(function(d) {
                var e = a.listen(b, function(f) {
                    c(f) && (e(), d(f))
                })
            })
        },
        eI = function(a, b, c) {
            var d;
            return !(null == (d = a.m.get("string" === typeof b ? b : b.id)) || !d.delete(c))
        },
        Cr = function(a, b, c, d) {
            var e, f, g, h, k, l, m, n;
            _.kb(function(p) {
                e = "string" === typeof b ? b : b.id;
                f = a.m.get(e);
                if (null == (g = f) || !g.size) return p.return();
                h = "function" === typeof window.CustomEvent ? new CustomEvent(e, {
                    detail: d,
                    bubbles: !0,
                    cancelable: !0
                }) : function() {
                    var r = document.createEvent("CustomEvent");
                    r.initCustomEvent(e, !0, !0, d);
                    return r
                }();
                k = [];
                l = _.z(f);
                m = l.next();
                for (n = {}; !m.done; n = {
                        Ke: n.Ke
                    }, m = l.next()) n.Ke = m.value, k.push(new _.v.Promise(function(r) {
                    return function(w) {
                        return _.kb(function(u) {
                            if (1 == u.j) return u.yield(0, 2);
                            Eh(a.context, c, function() {
                                a.m.has(e) && f.has(r.Ke) && (0, r.Ke)(h)
                            }, !0);
                            w();
                            u.j = 0
                        })
                    }
                }(n)));
                return p.yield(_.v.Promise.all(k), 0)
            })
        },
        gI = new cI,
        hI = new cI,
        Dr = new cI,
        iI = new cI,
        Er = new cI,
        jI = new cI,
        kI = new cI,
        Hp = new cI,
        xs = new cI,
        lI = new cI;
    var mI = function() {
            this.data = void 0;
            this.status = 0;
            this.j = []
        },
        nI = function(a) {
            a.data = void 0;
            a.status = 1
        };
    mI.prototype.oe = function() {
        this.j = []
    };
    var oI, sI, vI, dt, wI, rI, qI, pI, dp;
    oI = function() {
        this.j = new _.v.Map;
        this.l = 0;
        this.o = new _.v.Map;
        this.te = null;
        this.A = this.m = this.M = this.H = 0;
        this.Be = null;
        this.I = new mI;
        this.J = new mI
    };
    sI = function(a, b) {
        a.j.get(b) || (a.j.set(b, {
            zc: !0,
            wg: "",
            fd: "",
            Ai: 0,
            ug: [],
            vg: [],
            qc: !1
        }), _.mn(b, function() {
            a.j.delete(b);
            pI(a, b)
        }), b.listen(hI, function(c) {
            c = c.detail;
            var d = a.j.get(b);
            d.wg = _.sj(c, 33) || "";
            d.qc = !0;
            qI(a, b, function() {
                return void(d.wg = "")
            });
            rI(a, b, function() {
                return void(d.qc = !1)
            })
        }))
    };
    _.cp = function(a, b) {
        var c;
        return null == (c = a.j.get(b)) ? void 0 : c.zc
    };
    _.tI = function(a, b) {
        if (a = a.j.get(b)) a.zc = !1
    };
    _.uI = function(a, b) {
        if (a = a.j.get(b)) a.zc = !0
    };
    vI = function(a, b) {
        if (!b.length) return [];
        var c = eh(b[0].getAdUnitPath());
        b.every(function(g) {
            return eh(g.getAdUnitPath()) === c
        });
        var d = [];
        a = _.z(a.j);
        for (var e = a.next(); !e.done; e = a.next()) {
            var f = _.z(e.value);
            e = f.next().value;
            (f = f.next().value.wg) && eh(e.getAdUnitPath()) === c && !_.A(b, "includes").call(b, e) && d.push(f)
        }
        return d
    };
    dt = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.j.get(b)) ? void 0 : c.fd) ? d : ""
    };
    wI = function(a, b) {
        return (a = a.j.get(b)) ? a.Ai - 1 : 0
    };
    rI = function(a, b, c) {
        (a = a.j.get(b)) && a.ug.push(c)
    };
    qI = function(a, b, c) {
        (a = a.j.get(b)) && a.vg.push(c)
    };
    pI = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.vg.slice(), a.vg.length = 0, a = _.z(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    dp = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.ug.slice(), a.ug.length = 0, a = _.z(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    oI.prototype.qc = function(a) {
        var b, c;
        return null != (c = null == (b = this.j.get(a)) ? void 0 : b.qc) ? c : !1
    };
    var xI = function(a, b, c) {
            if (a = a.j.get(b)) a.zi = c
        },
        yI = function(a, b) {
            if (a = a.j.get(b)) {
                var c;
                null == (c = a.zi) || c.xa();
                delete a.zi
            }
        };
    var Jk = new _.v.Map,
        Ik = new _.v.Map;
    var Lk = function(a, b) {
        this.messageId = a;
        this.messageArgs = b
    };
    Lk.prototype.getMessageId = function() {
        return this.messageId
    };
    Lk.prototype.getMessageArgs = function() {
        return this.messageArgs
    };
    var zI = O(2),
        AI = O(3),
        BI = O(4),
        CI = O(5),
        DI = O(6),
        EI = O(12),
        FI = O(14),
        GI = O(16),
        el = O(19),
        HI = O(20),
        II = O(23),
        JI = O(26),
        KI = O(28),
        LI = O(149),
        MI = O(30),
        NI = O(31),
        OI = O(34),
        PI = O(35),
        tl = O(36),
        Wr = O(38),
        QI = O(40),
        RI = O(48),
        SI = O(50),
        TI = O(60),
        UI = O(63),
        VI = O(64),
        WI = O(66),
        XI = O(68),
        YI = O(69),
        ZI = O(70),
        $I = O(71),
        aJ = O(78),
        bJ = O(80),
        Zl = O(82),
        fl = O(84),
        cJ = O(85),
        dJ = O(87),
        Zk = O(88),
        eJ = O(92),
        fJ = O(93),
        gJ = O(99),
        hl = O(103),
        Xl = O(104),
        hJ = O(105),
        Ol = O(106),
        Pl = O(107),
        Yl = O(108),
        iJ = O(113),
        jJ = O(114),
        kJ = O(115),
        lJ = O(117),
        mJ = O(118),
        nJ = O(120),
        oJ = O(119),
        Fl = O(121),
        pJ = O(122),
        qJ = O(123),
        qq = O(125),
        rJ = O(126),
        sJ = O(127),
        tJ = O(144),
        gq = O(129),
        hq = O(132),
        uJ = O(134),
        vJ = O(135),
        wJ = O(136),
        xJ = O(137),
        yJ = O(138),
        zJ = O(139),
        AJ = O(140),
        Fq = O(142),
        BJ = O(143),
        CJ = O(145),
        DJ = O(147),
        ks = O(148),
        EJ = O(150),
        FJ = O(152),
        GJ = O(153),
        HJ = O(154),
        Jq = O(155),
        IJ = O(156),
        JJ = O(157),
        KJ = O(158),
        LJ = O(159),
        MJ = O(160);
    var NJ = function(a, b, c) {
        var d = this;
        this.addEventListener = K(a, 86, function(e, f) {
            if ("function" !== typeof f) return P(b, Nk("Service.addEventListener", [e, f])), d;
            var g = Ok(e);
            if (!g) return P(b, fJ(e)), d;
            c.addEventListener(g, f);
            return d
        });
        this.removeEventListener = K(a, 904, function(e, f) {
            var g = Ok(e);
            "function" === typeof f && g ? c.removeEventListener(g, f) : P(b, Nk("Service.removeEventListener", [e, f]))
        });
        this.getSlots = K(a, 573, function() {
            return c.j.map(function(e) {
                return e.j
            })
        });
        this.getSlotIdMap = K(a, 574, function() {
            for (var e = {}, f = _.z(c.j), g = f.next(); !g.done; g = f.next()) g = g.value, e[g.toString()] = g.j;
            return e
        });
        this.getName = K(a, 575, function() {
            return c.getName()
        })
    };
    var Pk = function(a, b, c) {
        NJ.call(this, a, b, c);
        this.setRefreshUnfilledSlots = K(a, 59, function(d) {
            c.setRefreshUnfilledSlots(d)
        });
        this.notifyUnfilledSlots = K(a, 69, function(d) {
            c.zc && OJ(c, PJ(c, d))
        });
        this.refreshAllSlots = K(a, 60, function() {
            c.zc && OJ(c)
        });
        this.setVideoSession = K(a, 61, function(d, e, f) {
            c.H = e;
            c.v = f;
            "number" === typeof d && (e = Hi().j, _.ni(e, 29, null == d ? d : Zc(d)))
        });
        this.getDisplayAdsCorrelator = K(a, 62, function() {
            return String(Pw(Hi().j, 26))
        });
        this.getVideoStreamCorrelator = K(a, 63, function() {
            var d = Hi().j;
            d = Zq(d, 29);
            return null != d ? d : 0
        });
        this.isSlotAPersistentRoadblock = K(a, 64, function(d) {
            var e = _.A(c.j, "find").call(c.j, function(f) {
                return f.j === d
            });
            return !!e && QJ(c, e)
        });
        this.onImplementationLoaded = K(a, 65, function() {
            c.T.info(RI("GPT CompanionAds"))
        });
        this.slotRenderEnded = K(a, 67, function(d, e, f) {
            var g = _.A(c.j, "find").call(c.j, function(h) {
                return h.j === d
            });
            return g && RJ(c, g, e, f)
        })
    };
    _.T(Pk, NJ);
    var Rk = function(a, b, c) {
        NJ.call(this, a, b, c);
        this.setContent = K(a, 72, function(d) {
            var e = _.A(c.j, "find").call(c.j, function(f) {
                return f.j === d
            });
            b.error(tJ(), e)
        })
    };
    _.T(Rk, NJ);
    var kl = function(a, b, c, d) {
        var e = this,
            f = c.getSlotId(),
            g = Hi().j,
            h = TG(Hi(), f.getDomId());
        this.set = K(a, 83, function(k, l) {
            "page_url" === k && l && (k = [Wk(Xk(new Yk, k), [String(l)])], _.gl(h, 3, k));
            return e
        });
        this.get = K(a, 84, function(k) {
            if ("page_url" !== k) return null;
            var l, m;
            return null != (m = null == (l = (_.F = h.Na(), _.A(_.F, "find")).call(_.F, function(n) {
                return _.sj(n, 1) === k
            })) ? void 0 : _.bl(l, 2)[0]) ? m : null
        });
        this.setClickUrl = K(a, 79, function(k) {
            Tk(k, h, f, b);
            return e
        });
        this.setTargeting = K(a, 81, function(k, l) {
            $k(k, l, f, h, b);
            return e
        });
        this.updateTargetingFromMap = K(a, 85, function(k) {
            al(k, f, h, b);
            return e
        });
        this.display = K(a, 78, function() {
            var k = oi(g, Hi().o);
            var l = void 0 === l ? document : l;
            var m;
            null != (m = k.R[f.getDomId()]) && xj(m, 19, !0);
            m = f.getDomId();
            m = qv(m);
            var n = {
                id: m
            };
            var p = void 0 === p ? Qv : p;
            var r = _.A(Object, "assign").call(Object, {}, n);
            m = n.id;
            var w = n.style;
            n = n.data;
            r = (delete r.id, delete r.style, delete r.data, r);
            if (_.A(Object, "keys").call(Object, r).length) throw Error("Invalid attribute(s): " + _.A(Object, "keys").call(Object, r));
            m = {
                id: m,
                style: w ? w : void 0
            };
            if (n)
                for (w = _.z(_.A(n, "entries").call(n)), n = w.next(); !n.done; n = w.next()) r = _.z(n.value), n = r.next().value, r = r.next().value, Fe(WG.test(n)), m[n] = r;
            _.Pv("div");
            p = _.Uv("div", m, p);
            l.write(_.Lv(p));
            xi(f, l) && (Xr(d), sI(d.L, f), SJ(d, k, f))
        });
        this.setTagForChildDirectedTreatment = K(a, 80, function(k) {
            if (0 === k || 1 === k) {
                var l = vt(g) || new OG;
                l.setTagForChildDirectedTreatment(k);
                _.kh(g, 25, l)
            }
            return e
        });
        this.setForceSafeFrame = K(a, 567, function(k) {
            "boolean" === typeof k ? xj(h, 12, k) : P(b, Nk("PassbackSlot.setForceSafeFrame", [String(k)]), f);
            return e
        });
        this.setTagForUnderAgeOfConsent = K(a, 448, function(k) {
            if (0 === k || 1 === k) {
                var l = vt(g) || new OG;
                l.setTagForUnderAgeOfConsent(k);
                _.kh(g, 25, l)
            }
            return e
        })
    };
    var Zp = {
        mn: 0,
        jn: 1,
        kn: 2,
        ln: 3
    };
    var nl = {
            REWARDED: 4,
            TOP_ANCHOR: 2,
            BOTTOM_ANCHOR: 3,
            INTERSTITIAL: 5,
            GAME_MANUAL_INTERSTITIAL: 7,
            LEFT_SIDE_RAIL: 8,
            RIGHT_SIDE_RAIL: 9
        },
        pl = {
            IAB_AUDIENCE_1_1: 1,
            IAB_CONTENT_2_1: 2,
            IAB_CONTENT_2_2: 3
        },
        ol = {
            PURCHASED: 1,
            ORGANIC: 2
        };
    var rl = function() {
        var a = {};
        return a.adsense_channel_ids = "channel", a.adsense_ad_types = "ad_type", a.adsense_ad_format = "format", a.adsense_background_color = "color_bg", a.adsense_border_color = "color_border", a.adsense_link_color = "color_link", a.adsense_text_color = "color_text", a.adsense_url_color = "color_url", a.page_url = "url", a.adsense_allow_expandable_ads = "ea", a.adsense_encoding = "oe", a.adsense_family_safe = "adsafe", a.adsense_flash_version = "flash", a.adsense_font_face = "f", a.adsense_hints = "hints", a.adsense_keyword_type = "kw_type", a.adsense_keywords = "kw", a.adsense_test_mode = "adtest", a.alternate_ad_iframe_color = "alt_color", a.alternate_ad_url = "alternate_ad_url", a.demographic_age = "cust_age", a.demographic_gender = "cust_gender", a.document_language = "hl", a
    };
    var TJ = "",
        zl = null;
    var hm = function(a, b, c) {
        dI.call(this, a);
        this.slotId = b;
        this.j = c
    };
    _.T(hm, dI);
    hm.prototype.getSlotId = function() {
        return this.slotId
    };
    var rf = function(a, b, c, d) {
        dI.call(this, a);
        this.adUnitPath = b;
        this.Nb = d;
        this.j = null;
        this.id = this.adUnitPath + "_" + c
    };
    _.T(rf, dI);
    _.q = rf.prototype;
    _.q.getId = function() {
        return this.id
    };
    _.q.getAdUnitPath = function() {
        return this.adUnitPath
    };
    _.q.getName = function() {
        return this.adUnitPath
    };
    _.q.toString = function() {
        return this.getId()
    };
    _.q.getDomId = function() {
        return this.Nb
    };
    var UJ = function(a, b) {
        a.j = b
    };
    var am = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;
    var em = _.Vu(function() {
            return void vz("google_DisableInitialLoad is deprecated and will be removed. Please use googletag.pubads().isInitialLoadDisabled() instead to check if initial load has been disabled.")
        }),
        VJ = _.Vu(function() {
            return void vz("googletag.pubads().setCookieOptions() has been removed, and no longer has any effect. Consider migrating to Limited Ads.")
        }),
        WJ = _.Vu(function() {
            return void vz("The following functions are deprecated: googletag.pubads().setTagForChildDirectedTreatment(), googletag.pubads().clearTagForChildDirectedTreatment(), googletag.pubads().setRequestNonPersonalizedAds(), and googletag.pubads().setTagForUnderAgeOfConsent(). Please use googletag.pubads().setPrivacySettings() instead.")
        }),
        jm = function(a, b, c, d, e) {
            NJ.call(this, a, b, c);
            var f = this,
                g = Hi().j,
                h = Hi().o,
                k = !1;
            this.setTargeting = K(a, 1, function(l, m) {
                Rl({
                    key: l,
                    value: m,
                    Da: g,
                    serviceName: c.getName(),
                    Nl: c.enabled,
                    bb: e,
                    T: b,
                    context: a
                });
                return f
            });
            this.clearTargeting = K(a, 2, function(l) {
                $l(l, g, c.getName(), b);
                return f
            });
            this.getTargeting = K(a, 38, function(l) {
                return Sl(l, g, b)
            });
            this.getTargetingKeys = K(a, 39, function() {
                return Tl(g)
            });
            this.setCategoryExclusion = K(a, 3, function(l) {
                "string" !== typeof l || Uk(l) ? P(b, Nk("PubAdsService.setCategoryExclusion", [l])) : ((_.F = _.bl(g, 3), _.A(_.F, "includes")).call(_.F, l) || $w(g, 3, l), b.info(cJ(l)));
                return f
            });
            this.clearCategoryExclusions = K(a, 4, function() {
                _.ni(g, 3);
                b.info(dJ());
                return f
            });
            this.disableInitialLoad = K(a, 5, function() {
                xj(g, 4, !0);
                k || (k = !0, fm())
            });
            this.enableSingleRequest = K(a, 6, function() {
                if (c.enabled && !_.L(g, 6)) return P(b, TI("PubAdsService.enableSingleRequest")), !1;
                b.info(UI("single request"));
                xj(g, 6, !0);
                return !0
            });
            this.enableAsyncRendering = K(a, 7, function() {
                return !0
            });
            this.enableSyncRendering = K(a, 8, function() {
                vz("GPT synchronous rendering is no longer supported, ads will be requested and rendered asynchronously. See https://support.google.com/admanager/answer/9212594 for more details.");
                return !1
            });
            this.enableLazyLoad = K(a, 485, function(l) {
                var m = new Ks;
                m = _.Lo(m, 1, 800);
                m = _.Lo(m, 2, 400);
                m = _.ni(m, 3, _.zc(3));
                if (_.ja(l)) {
                    var n = l.fetchMarginPercent;
                    "number" === typeof n && (0 <= n ? _.Lo(m, 1, n) : -1 === n && _.ni(m, 1));
                    n = l.renderMarginPercent;
                    "number" === typeof n && (0 <= n ? _.Lo(m, 2, n) : -1 === n && _.ni(m, 2));
                    l = l.mobileScaling;
                    "number" === typeof l && (0 < l ? _.ni(m, 3, _.zc(l)) : -1 === l && _.ni(m, 3, _.zc(1)))
                }
                window.IntersectionObserver || !Cp(m, 1) && !Cp(m, 2) ? _.kh(g, 5, m) : P(b, EJ())
            });
            this.setCentering = K(a, 9, function(l) {
                l = !!l;
                b.info(VI("centering", String(l)));
                xj(g, 15, l)
            });
            this.definePassback = K(a, 10, function(l, m) {
                return (l = im(a, b, c, l, m, d)) && l.ni
            });
            this.refresh = K(a, 11, function() {
                var l = _.Wa.apply(0, arguments),
                    m = _.z(l),
                    n = m.next().value;
                m = m.next().value;
                m = void 0 === m ? {} : m;
                n && !Array.isArray(n) || !_.ja(m) || m.changeCorrelator && "boolean" !== typeof m.changeCorrelator ? P(b, Nk("PubAdsService.refresh", l)) : (m && !1 === m.changeCorrelator || g.setCorrelator(zz()), n = n ? dm(n, c) : c.j, c.refresh(oi(g, h), n) || P(b, Nk("PubAdsService.refresh", l)))
            });
            this.enableVideoAds = K(a, 12, function() {
                xj(g, 21, !0);
                XJ(c, g)
            });
            this.setVideoContent = K(a, 13, function(l, m) {
                YJ(c, l, m, g)
            });
            this.collapseEmptyDivs = K(a, 14, function(l) {
                l = void 0 === l ? !1 : l;
                l = void 0 === l ? !1 : l;
                xj(g, 11, !0);
                l = !!l;
                xj(g, 10, l);
                b.info(aJ(String(l)));
                return !!_.L(g, 11)
            });
            this.clear = K(a, 15, function(l) {
                if (Array.isArray(l)) return ZJ(c, g, h, dm(l, c));
                if (void 0 === l) return ZJ(c, g, h, c.j);
                P(b, Nk("PubAdsService.clear", [l]));
                return !1
            });
            this.setLocation = K(a, 16, function(l) {
                "string" !== typeof l ? P(b, Nk("PubAdsService.setLocation", [l])) : On(g, 8, l);
                return f
            });
            this.setCookieOptions = K(a, 17, function() {
                VJ();
                return f
            });
            this.setTagForChildDirectedTreatment = K(a, 18, function(l) {
                WJ();
                if (1 !== l && 0 !== l) return P(b, pJ("PubadsService.setTagForChildDirectedTreatment", Gl(l), "0,1")), f;
                var m = vt(g) || new OG;
                m.setTagForChildDirectedTreatment(l);
                _.kh(g, 25, m);
                return f
            });
            this.clearTagForChildDirectedTreatment = K(a, 19, function() {
                WJ();
                var l = vt(g);
                if (!l) return f;
                l.clearTagForChildDirectedTreatment();
                _.kh(g, 25, l);
                return f
            });
            this.setPublisherProvidedId = K(a, 20, function(l) {
                l = String(l);
                b.info(VI("PPID", l));
                On(g, 16, l);
                return f
            });
            this.set = K(a, 21, function(l, m) {
                ul(l, m, g, c.getName(), b);
                return f
            });
            this.get = K(a, 22, function(l) {
                return vl(l, g, b)
            });
            this.getAttributeKeys = K(a, 23, function() {
                return wl(g)
            });
            this.display = K(a, 24, function(l, m, n, p) {
                return void c.display(l, m, d, n, p)
            });
            this.updateCorrelator = K(a, 25, function() {
                vz(cm("update"));
                P(b, kJ());
                g.setCorrelator(zz());
                return f
            });
            this.defineOutOfPagePassback = K(a, 35, function(l) {
                l = im(a, b, c, l, [1, 1], d);
                if (!l) return null;
                _.co(l.Da, 15, 1);
                return l.ni
            });
            this.setForceSafeFrame = K(a, 36, function(l) {
                "boolean" !== typeof l ? P(b, Nk("PubAdsService.setForceSafeFrame", [Gl(l)])) : xj(g, 13, l);
                return f
            });
            this.setSafeFrameConfig = K(a, 37, function(l) {
                var m = Hl(b, l);
                m ? _.kh(g, 18, m) : P(b, Nk("PubAdsService.setSafeFrameConfig", [l]));
                return f
            });
            this.setRequestNonPersonalizedAds = K(a, 445, function(l) {
                WJ();
                if (0 !== l && 1 !== l) return P(b, pJ("PubAdsService.setRequestNonPersonalizedAds", Gl(l), "0,1")), f;
                var m = vt(g) || new OG;
                xj(m, 8, !!l);
                _.kh(g, 25, m);
                return f
            });
            this.setTagForUnderAgeOfConsent = K(a, 447, function(l) {
                l = void 0 === l ? 2 : l;
                WJ();
                if (2 !== l && 0 !== l && 1 !== l) return P(b, pJ("PubadsService.setTagForUnderAgeOfConsent", Gl(l), "2,0,1")), f;
                var m = vt(g) || new OG;
                m.setTagForUnderAgeOfConsent(l);
                _.kh(g, 25, m);
                return f
            });
            this.getCorrelator = K(a, 27, function() {
                return String(Pw(g, 26))
            });
            this.getTagSessionCorrelator = K(a, 631, function() {
                return _.Ih(_.t)
            });
            this.getVideoContent = K(a, 30, function() {
                return $J(c, g)
            });
            this.getVersion = K(a, 568, function() {
                return a.wc ? String(a.wc) : a.fb
            });
            this.forceExperiment = K(a, 569, function(l) {
                return void c.forceExperiment(l)
            });
            this.setCorrelator = K(a, 28, function(l) {
                vz(cm("set"));
                P(b, jJ());
                if (di(window)) return f;
                if (!xm(l)) return P(b, Nk("PubadsService.setCorrelator", [Gl(l)])), f;
                l = g.setCorrelator(l);
                xj(l, 27, !0);
                return f
            });
            this.markAsAmp = K(a, 570, function() {
                window.console && window.console.warn && window.console.warn("googletag.pubads().markAsAmp() is deprecated and ignored.")
            });
            this.isSRA = K(a, 571, function() {
                return !!_.L(g, 6)
            });
            this.setImaContent = K(a, 328, function(l, m) {
                null != _.sj(g, 22) ? YJ(c, l, m, g) : (xj(g, 21, !0), XJ(c, g), "string" === typeof l && On(g, 19, l), "string" === typeof m && On(g, 20, m))
            });
            this.getImaContent = K(a, 329, function() {
                return null != _.sj(g, 22) ? $J(c, g) : c.enabled ? {
                    vid: _.R(g, 19) || "",
                    cmsid: _.R(g, 20) || ""
                } : null
            });
            this.isInitialLoadDisabled = K(a, 572, function() {
                return !!_.L(g, 4)
            });
            this.setPrivacySettings = K(a, 648, function(l) {
                if (!_.ja(l)) return P(b, Nk("PubAdsService.setPrivacySettings", [l])), f;
                var m = l.restrictDataProcessing,
                    n = l.childDirectedTreatment,
                    p = l.underAgeOfConsent,
                    r = l.limitedAds,
                    w = l.nonPersonalizedAds,
                    u = l.userOptedOutOfPersonalization,
                    y = l.trafficSource,
                    x, C = null != (x = vt(g)) ? x : new OG;
                "boolean" === typeof w ? xj(C, 8, w) : void 0 !== w && P(b, Fl("PubAdsService.setPrivacySettings", Gl(l), "nonPersonalizedAds", Gl(w)));
                "boolean" === typeof u ? xj(C, 13, u) : void 0 !== u && P(b, Fl("PubAdsService.setPrivacySettings", Gl(l), "userOptedOutOfPersonalization", Gl(u)));
                "boolean" === typeof m ? xj(C, 1, m) : void 0 !== m && P(b, Fl("PubAdsService.setPrivacySettings", Gl(l), "restrictDataProcessing", Gl(m)));
                if ("boolean" === typeof r) {
                    m = bm();
                    if (r && !_.L(C, 9) && a.Bc) {
                        w = a.Qa;
                        u = w.Ac;
                        x = lh(a);
                        var I = new IA;
                        I = _.oh(I, 1, !0);
                        I = _.oh(I, 2, m);
                        x = _.qh(x, 11, rh, I);
                        u.call(w, x)
                    }
                    m ? xj(C, 9, r) : r && P(b, DJ())
                } else void 0 !== r && P(b, Fl("PubAdsService.setPrivacySettings", Gl(l), "limitedAds", Gl(r)));
                void 0 !== p && (null === p ? C.setTagForUnderAgeOfConsent(2) : !1 === p ? C.setTagForUnderAgeOfConsent(0) : !0 === p ? C.setTagForUnderAgeOfConsent(1) : P(b, Fl("PubAdsService.setPrivacySettings", Gl(l), "underAgeOfConsent", Gl(p))));
                void 0 !== n && (null === n ? C.clearTagForChildDirectedTreatment() : !1 === n ? C.setTagForChildDirectedTreatment(0) : !0 === n ? C.setTagForChildDirectedTreatment(1) : P(b, Fl("PubAdsService.setPrivacySettings", Gl(l), "childDirectedTreatment", Gl(n))));
                void 0 !== y && (null === y ? _.ni(C, 10) : (_.F = _.A(Object, "values").call(Object, ol), _.A(_.F, "includes")).call(_.F, y) ? _.co(C, 10, y) : P(b, Fl("PubAdsService.setPrivacySettings", Gl(l), "trafficSource", Gl(y))));
                _.kh(g, 25, C);
                return f
            })
        };
    _.T(jm, NJ);
    var aK = function(a, b) {
        this.getId = K(a, 593, function() {
            return b.getId()
        });
        this.getAdUnitPath = K(a, 594, function() {
            return b.getAdUnitPath()
        });
        this.getName = K(a, 595, function() {
            return b.getName()
        });
        this.toString = K(a, 596, function() {
            return b.toString()
        });
        this.getDomId = K(a, 597, function() {
            return b.getDomId()
        })
    };
    var bK = function() {
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.creativeId = this.campaignId = this.advertiserId = null;
            this.isBackfill = !1;
            this.encryptedTroubleshootingInfo = this.creativeTemplateId = this.companyIds = this.yieldGroupIds = null
        },
        cK = function(a, b) {
            a.advertiserId = b
        },
        dK = function(a, b) {
            a.campaignId = b
        },
        eK = function(a, b) {
            a.yieldGroupIds = b
        },
        fK = function(a, b) {
            a.companyIds = b
        };
    var Rh = function(a) {
        this.D = _.B(a)
    };
    _.T(Rh, _.E);
    Rh.prototype.getWidth = function() {
        return Br(this, 1)
    };
    Rh.prototype.getHeight = function() {
        return Br(this, 2)
    };
    var rm = function() {
        var a = new Rh;
        return xj(a, 3, !0)
    };
    var Wh = function(a) {
        this.D = _.B(a)
    };
    _.T(Wh, _.E);
    Wh.ca = [2];
    var gK = function(a) {
        this.D = _.B(a)
    };
    _.T(gK, _.E);
    var hK = function(a) {
        this.D = _.B(a)
    };
    _.T(hK, _.E);
    hK.ca = [1];
    var iK = function(a) {
        this.D = _.B(a)
    };
    _.T(iK, _.E);
    iK.prototype.getAdUnitPath = function() {
        return _.R(this, 1)
    };
    iK.prototype.getDomId = function() {
        return _.R(this, 2)
    };
    var jK = function(a, b) {
        On(a, 2, b)
    };
    iK.prototype.Na = function() {
        return Uh(this, Yk, 3)
    };
    iK.prototype.getServices = function(a) {
        return Tw(this, 4, a)
    };
    var kK = function(a, b) {
        _.gl(a, 5, b)
    };
    iK.prototype.getClickUrl = function() {
        return _.R(this, 7)
    };
    iK.prototype.setClickUrl = function(a) {
        return On(this, 7, a)
    };
    iK.prototype.getCategoryExclusions = function(a) {
        return Tw(this, 8, a)
    };
    var Vk = function(a) {
        return Uh(a, Yk, 9)
    };
    iK.prototype.nc = function() {
        return _.Qh(this, Dl, 13)
    };
    var Fs = function(a) {
        return _.Ak(a, 15, 0)
    };
    iK.ca = [3, 4, 5, 6, 8, 9, 27];
    var lK = function(a, b) {
        this.width = a;
        this.height = b
    };
    lK.prototype.getWidth = function() {
        return this.width
    };
    lK.prototype.getHeight = function() {
        return this.height
    };
    var mK = new _.v.Set(["unhideWindow"]);
    var Gm = function(a, b, c) {
        var d = this,
            e = TG(Hi(), c.getDomId()),
            f = "",
            g = null,
            h = function() {
                return ""
            },
            k = "",
            l = !1;
        _.mn(c, function() {
            e = new iK;
            f = "";
            g = null;
            h = function() {
                return ""
            };
            k = ""
        });
        c.listen(Dr, function(n) {
            var p = n.detail;
            n = p.nh;
            p = p.isBackfill;
            n && (f = n, l = p)
        });
        this.set = K(a, 40, function(n, p) {
            lm(n, p, c, e, b);
            return d
        });
        this.get = K(a, 41, function(n) {
            return mm(n, c, e, b)
        });
        this.getAttributeKeys = K(a, 42, function() {
            return nm(e)
        });
        this.addService = K(a, 43, function(n) {
            n = Jk.get(n);
            if (!n) return P(b, Nk("Slot.addService", [n]), c), d;
            var p = n.getName();
            if ((_.F = _.bl(e, 4), _.A(_.F, "includes")).call(_.F, p)) return b.info(EI(p, c.toString()), c), d;
            n.slotAdded(c, e);
            return d
        });
        this.defineSizeMapping = K(a, 44, function(n) {
            try {
                var p = e;
                if (!Array.isArray(n)) throw new ym("Size mapping must be an array");
                var r = n.map(zm);
                _.gl(p, 6, r)
            } catch (w) {
                n = w, Ch(a, 44, n), vz("Incorrect usage of googletag.Slot defineSizeMapping: " + n.message)
            }
            return d
        });
        this.setClickUrl = K(a, 45, function(n) {
            Tk(n, e, c, b);
            return d
        });
        this.setCategoryExclusion = K(a, 46, function(n) {
            var p = e;
            "string" !== typeof n || Uk(n) ? P(b, Nk("Slot.setCategoryExclusion", [n]), c) : ((_.F = _.bl(p, 8), _.A(_.F, "includes")).call(_.F, n) || $w(p, 8, n), b.info(FI(n), c));
            return d
        });
        this.clearCategoryExclusions = K(a, 47, function() {
            _.ni(e, 8);
            b.info(GI(), c);
            return d
        });
        this.getCategoryExclusions = K(a, 48, function() {
            return _.bl(e, 8).slice()
        });
        this.setTargeting = K(a, 49, function(n, p) {
            $k(n, p, c, e, b);
            return d
        });
        this.updateTargetingFromMap = K(a, 649, function(n) {
            al(n, c, e, b);
            return d
        });
        this.clearTargeting = K(a, 50, function(n) {
            jl(n, c, e, b);
            return d
        });
        this.getTargeting = K(a, 51, function(n) {
            return cl(n, c, e, b)
        });
        this.getTargetingKeys = K(a, 52, function() {
            return dl(e)
        });
        this.setCollapseEmptyDiv = K(a, 53, function(n, p) {
            var r = e;
            p = void 0 === p ? !1 : p;
            p = void 0 === p ? !1 : p;
            "boolean" !== typeof n || "boolean" !== typeof p ? P(b, Nk("Slot.setCollapseEmptyDiv", [n, p]), c) : (r = xj(r, 10, n), xj(r, 11, n && p), p && !n && P(b, HI(c.toString()), c));
            return d
        });
        this.getAdUnitPath = K(a, 54, function() {
            return c.getAdUnitPath()
        });
        this.getSlotElementId = K(a, 598, function() {
            return c.getDomId()
        });
        this.setForceSafeFrame = K(a, 55, function(n) {
            var p = e;
            "boolean" !== typeof n ? P(b, Nk("Slot.setForceSafeFrame", [String(n)]), c) : xj(p, 12, n);
            return d
        });
        this.setSafeFrameConfig = K(a, 56, function(n) {
            var p = e,
                r = Hl(b, n);
            r ? _.kh(p, 13, r) : b.error(Nk("Slot.setSafeFrameConfig", [n]), c);
            return d
        });
        c.listen(hI, function(n) {
            n = n.detail;
            if (Il(n, 8)) g = null;
            else {
                g = new bK;
                var p = !!Il(n, 9);
                g.isBackfill = p;
                var r = Qw(n, 15),
                    w = Qw(n, 16);
                r.length && w.length && (g.sourceAgnosticCreativeId = r[0], g.sourceAgnosticLineItemId = w[0], p || (g.creativeId = r[0], g.lineItemId = w[0], (p = Qw(n, 22)) && p.length && (g.creativeTemplateId = p[0])));
                Qw(n, 17).length && cK(g, Qw(n, 17)[0]);
                Qw(n, 18).length && dK(g, Qw(n, 18)[0]);
                Qw(n, 19).length && eK(g, Qw(n, 19));
                Qw(n, 20).length && fK(g, Qw(n, 20));
                n = Rd(n, 45, Gd(n.D) & 34 ? Sd : Td).map(function(u) {
                    return wd(u)
                });
                n.length && (g.encryptedTroubleshootingInfo = n[0])
            }
        });
        this.getResponseInformation = K(a, 355, function() {
            return g
        });
        this.getName = K(a, 170, function() {
            b.error(BJ());
            return c.getAdUnitPath()
        });
        var m = new aK(a, c);
        this.getSlotId = K(a, 579, function() {
            return m
        });
        this.getServices = K(a, 580, function() {
            return _.bl(e, 4).map(function(n) {
                var p = NG[n];
                if (p) {
                    var r, w, u;
                    n = null != (u = null == (w = (r = Am())[p]) ? void 0 : w.call(r)) ? u : null
                } else n = null;
                return n
            })
        });
        this.getSizes = K(a, 581, function(n, p) {
            var r, w;
            return null != (w = null == (r = Xh(e, n, p)) ? void 0 : r.map(function(u) {
                return _.L(u, 3) ? "fluid" : new lK(u.getWidth(), u.getHeight())
            })) ? w : null
        });
        this.getClickUrl = K(a, 582, function() {
            var n;
            return null != (n = e.getClickUrl()) ? n : ""
        });
        this.getTargetingMap = K(a, 583, function() {
            for (var n = {}, p = _.z(Vk(e)), r = p.next(); !r.done; r = p.next()) r = r.value, _.R(r, 1) && (n[_.sj(r, 1)] = _.bl(r, 2));
            return n
        });
        this.getOutOfPage = K(a, 584, function(n) {
            return "number" === typeof n ? Fs(e) === n : 0 !== Fs(e)
        });
        this.getCollapseEmptyDiv = K(a, 585, function() {
            return null != Il(e, 10) ? _.L(e, 10) : null
        });
        this.getDivStartsCollapsed = K(a, 586, function() {
            return null != Il(e, 11) ? _.L(e, 11) : null
        });
        c.listen(iI, function(n) {
            h = n.detail.Oj
        });
        this.getContentUrl = K(a, 587, function() {
            return h()
        });
        this.getFirstLook = K(a, 588, function() {
            vz("The getFirstLook method of SlotInterface is deprecated. Please update your code to no longer call this method.");
            return 0
        });
        c.listen(hI, function(n) {
            var p;
            k = null != (p = n.detail.getEscapedQemQueryId()) ? p : ""
        });
        this.getEscapedQemQueryId = K(a, 591, function() {
            return k
        });
        this.getHtml = K(a, 592, function() {
            return l ? (window.console && console.warn && console.warn("This ad's html cannot be accessed using the getHtml method on googletag.Slot. Returning the empty string instead."), "") : f
        });
        this.setConfig = K(a, 1022, function(n) {
            var p = e;
            if (tf(n)) {
                var r = n.componentAuction,
                    w = n.adExpansion;
                if (null != r) {
                    var u = {
                        componentAuction: r
                    };
                    if (_.ja(u)) {
                        if (r = Yd(p, 26), void 0 !== u.componentAuction) {
                            u = _.z(u.componentAuction);
                            for (var y = u.next(); !y.done; y = u.next()) {
                                var x = y.value;
                                y = x.configKey;
                                x = x.auctionConfig;
                                "string" !== typeof y || Uk(y) || (null === x ? r.delete(y) : x && r.set(y, JSON.stringify(x)))
                            }
                        }
                    } else P(b, Nk("googletag.Slot.setConfig", [u]))
                }
                if (_.A(Object, "hasOwn").call(Object, n, "interstitial"))
                    if (5 !== Fs(p)) P(b, MJ("interstitial"), c);
                    else {
                        u = n.interstitial;
                        b.info(IJ("interstitial", Gl(u)), c);
                        if (tf(u))
                            for (r = {}, u = _.z(_.A(Object, "entries").call(Object, u)), y = u.next(); !y.done; y = u.next()) switch (x = _.z(y.value), y = x.next().value, x = x.next().value, y) {
                                case "triggers":
                                    r.triggers = x;
                                    break;
                                default:
                                    P(b, KJ("interstitial", y), c)
                            } else P(b, LJ("googletag.slot.setConfig", "interstitial", Gl(u)), c), r = null;
                        y = r;
                        r = new hK;
                        u = {};
                        if (y && y.triggers)
                            if (y = y.triggers, tf(y))
                                for (u.triggers = {}, y = _.z(_.A(Object, "entries").call(Object, y)), x = y.next(); !x.done; x = y.next()) {
                                    var C = _.z(x.value);
                                    x = C.next().value;
                                    C = C.next().value;
                                    var I = x;
                                    x = C;
                                    if (mK.has(I))
                                        if (Cm(x)) switch (I) {
                                            case "unhideWindow":
                                                C = new gK, C = _.co(C, 1, 2), C = xj(C, 2, x), yj(r, 1, gK, C), u.triggers.Rn = x
                                        } else P(b, LJ("interstitial.triggers", I, Gl(x)), c);
                                        else P(b, KJ("interstitial.triggers", I), c)
                                } else P(b, LJ("interstitial", "triggers", Gl(y)), c);
                        b.info(JJ("interstitial", Gl(u)), c);
                        _.kh(p, 29, r)
                    }
                _.G(Bm) ? _.A(Object, "hasOwn").call(Object, n, "adExpansion") && Em(p, w) : Em(p, w)
            } else P(b, Nk("googletag.slot.setConfig", [n]), c)
        })
    };
    var Z = function(a, b, c) {
        XF.call(this, b, c);
        this.context = a
    };
    _.T(Z, XF);
    Z.prototype.I = function(a) {
        Ch(this.context, this.id, a);
        var b, c;
        null == (b = window.console) || null == (c = b.error) || c.call(b, a)
    };
    var nn = function(a, b, c, d, e) {
        var f = null,
            g = yh(a.context, b, e);
        _.ib(c, d, g) && (f = function() {
            return _.of(c, d, g)
        }, _.mn(a, f));
        return f
    };
    var Om = function(a, b, c, d, e) {
        Z.call(this, a, 959);
        this.kb = b;
        this.output = V(this);
        this.l = W(this, b);
        bG(this, c);
        bG(this, d);
        e && bG(this, e)
    };
    _.T(Om, Z);
    Om.prototype.j = function() {
        this.output.F(this.l.value)
    };
    var Nm = function(a, b, c, d, e, f) {
        Z.call(this, a, 1172);
        this.T = b;
        this.L = c;
        this.B = d;
        this.l = $F(this);
        bG(this, e);
        this.v = W(this, f)
    };
    _.T(Nm, Z);
    Nm.prototype.j = function() {
        var a = this,
            b = new DE(this.B);
        _.S(this, b);
        if (DC(b.caller)) {
            var c = this.L.J,
                d = c.status,
                e = function(f) {
                    if (f.internalErrorState) WE(a.v.value, f.gppString);
                    else if (yf(f.applicableSections)) UE(VE(a.v.value, f.applicableSections.filter(function(k) {
                        return _.A(Number, "isInteger").call(Number, k)
                    })), !1);
                    else {
                        var g = WE(VE(a.v.value, f.applicableSections.filter(function(k) {
                            return _.A(Number, "isInteger").call(Number, k)
                        })), f.gppString);
                        try {
                            var h = HE(f.gppString)
                        } catch (k) {
                            Ch(a.context, 1182, k), h = !1
                        }
                        UE(g, h)
                    }
                    a.l.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    nI(c);
                    c.j.push(e);
                    this.T.info(nJ());
                    b.addEventListener(yh(this.context, 1173, function(f) {
                        if ("ready" === f.pingData.signalStatus || yf(f.pingData.applicableSections)) c.data = f.pingData, c.status = 2, c.j.forEach(function(g) {
                            g(f.pingData)
                        }), c.oe()
                    }));
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.l.notify()
    };
    var Lm = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 874);
        this.T = b;
        this.L = c;
        this.B = d;
        this.v = e;
        this.l = $F(this);
        bG(this, f);
        this.C = W(this, g)
    };
    _.T(Lm, Z);
    Lm.prototype.j = function() {
        var a = this,
            b = new NC(this.B, {
                timeoutMs: -1,
                xj: !0
            });
        _.S(this, b);
        if (PC(b)) {
            var c = this.L.I,
                d = c.status,
                e = function(f) {
                    var g = a.C.value,
                        h, k;
                    if (k = !(a.v ? _.L(a.v, 9) : _.G(aB) && bm())) {
                        var l = void 0 === l ? !1 : l;
                        k = TC(f) ? !1 === f.gdprApplies || "tcunavailable" === f.tcString || void 0 === f.gdprApplies && !l || "string" !== typeof f.tcString || !f.tcString.length ? !0 : RC(f, "1") : !1
                    }
                    k = xj(g, 5, k);
                    l = !UC(f, ["3", "4"]);
                    k = xj(k, 9, l);
                    k = On(k, 2, f.tcString);
                    l = null != (h = f.addtlConsent) ? h : "";
                    h = On(k, 4, l);
                    _.co(h, 7, f.internalErrorState);
                    null != f.gdprApplies && xj(g, 3, f.gdprApplies);
                    _.G(UB) && !UC(f, ["2", "7", "9", "10"]) && xj(g, 8, !0);
                    a.l.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    nI(c);
                    c.j.push(e);
                    this.T.info(mJ());
                    b.addEventListener(function(f) {
                        TC(f) ? ("tcunavailable" === f.tcString ? a.T.info(oJ("failed")) : a.T.info(oJ("succeeded")), c.data = f, c.status = 2, c.j.forEach(function(g) {
                            g(f)
                        }), c.oe()) : nI(c)
                    });
                    break;
                default:
                    throw Error("Impossible CacheStatus: " + d);
            }
        } else this.l.notify()
    };
    var Km = function(a, b, c, d, e) {
        Z.call(this, a, 875);
        this.T = b;
        this.B = c;
        this.l = $F(this);
        bG(this, d);
        this.v = W(this, e)
    };
    _.T(Km, Z);
    Km.prototype.j = function() {
        var a = this,
            b = new vE(this.B);
        _.S(this, b);
        if (DC(b.caller)) {
            var c = yh(this.context, 660, function(d) {
                d && "string" === typeof d.uspString && (On(a.v.value, 1, d.uspString), TE(a.v.value, yh(a.context, 1187, function() {
                    var e = d.uspString;
                    var f = e = e.toUpperCase();
                    4 == f.length && (-1 == f.indexOf("-") || "---" === f.substring(1)) && "1" <= f[0] && "9" >= f[0] && Wz.hasOwnProperty(f[1]) && Wz.hasOwnProperty(f[2]) && Wz.hasOwnProperty(f[3]) ? (f = new Vz, f = _.ph(f, 1, parseInt(e[0], 10)), f = _.H(f, 2, Wz[e[1]]), f = _.H(f, 3, Wz[e[2]]), e = _.H(f, 4, Wz[e[3]])) : e = null;
                    return 2 === (null == e ? void 0 : _.Ak(e, 3, 0))
                })()));
                a.l.notify()
            });
            this.T.info(lJ());
            wE(b, c)
        } else this.l.notify()
    };
    var Im = function(a, b) {
        Z.call(this, a, 958);
        this.l = b;
        this.kb = V(this)
    };
    _.T(Im, Z);
    Im.prototype.j = function() {
        var a = new SE,
            b = this.l ? _.L(this.l, 9) : bm();
        xj(a, 5, !b);
        this.kb.F(a)
    };
    var Jm = function(a, b, c, d) {
        d = void 0 === d ? .001 : d;
        Z.call(this, a, 960);
        this.B = b;
        this.v = d;
        this.l = W(this, c)
    };
    _.T(Jm, Z);
    Jm.prototype.j = function() {
        var a = this;
        Eh(this.context, 894, function() {
            return void Ri("cmpMet", function(b) {
                Xi(b, a.context);
                var c = new NC(a.B);
                _.S(a, c);
                var d = new vE(a.B);
                _.S(a, d);
                Yi(b, "fc", Number(a.l.value));
                Yi(b, "tcfv1", Number(!!a.B.__cmp));
                Yi(b, "tcfv2", Number(PC(c)));
                Yi(b, "usp", Number(!!DC(d.caller)));
                Yi(b, "ptt", 17)
            }, a.v)
        })
    };
    var nK = function(a, b, c, d) {
        Z.call(this, a, 1103);
        this.l = b;
        this.X = c;
        this.privacyTreatments = d;
        this.output = V(this)
    };
    _.T(nK, Z);
    nK.prototype.j = function() {
        this.output.F(!!zf(this.X) && !_.L(this.X, 9) && !_.L(this.X, 13) && (!_.G(Mm) || !_.L(this.X, 12)) && (this.l ? _.L(this.l, 9) || _.L(this.l, 8) || _.L(this.l, 1) || _.G(KB) && _.L(this.l, 13) || 1 === _.Ak(this.l, 6, 2) || 1 === bo(this.l, 5) || _.A(this.privacyTreatments, "includes").call(this.privacyTreatments, 1) ? !1 : !0 : !0))
    };
    var Sm = function(a) {
        this.T = a;
        this.o = this.j = 0
    };
    Sm.prototype.push = function() {
        for (var a = _.z(_.Wa.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                "function" === typeof b && (b.call(_.v.globalThis), this.j++)
            } catch (c) {
                this.o++, b = void 0, null == (b = window.console) || b.error("Exception in queued GPT command", c), this.T.error(MI(String(c)))
            }
        }
        this.T.info(NI(String(this.j), String(this.o)));
        return this.j
    };
    var Qm = function(a, b) {
        this.push = K(a, 76, b.push.bind(b))
    };
    var oK = ["Debug", "Info", "Warning", "Error", "Fatal"],
        pK = function(a, b, c) {
            this.level = a;
            this.message = b;
            this.j = c;
            this.timestamp = new Date
        };
    _.q = pK.prototype;
    _.q.getSlot = function() {
        return this.j
    };
    _.q.getLevel = function() {
        return this.level
    };
    _.q.getTimestamp = function() {
        return this.timestamp
    };
    _.q.getMessage = function() {
        return this.message
    };
    _.q.toString = function() {
        return this.timestamp.toTimeString() + ": " + oK[this.level] + ": " + this.message
    };
    var qK = _.ju(["https://console.googletagservices.com/pubconsole/loader.js"]),
        bn = _.Me(qK),
        fn, en = !1,
        Xm = !1,
        Zm = !1;
    var Tr = function(a, b) {
        this.getAllEvents = K(a, 563, function() {
            return Xm ? rK(b).slice() : []
        });
        this.getEventsBySlot = K(a, 565, function(c) {
            return Xm ? sK(b, c).slice() : []
        });
        this.getEventsByLevel = K(a, 566, function(c) {
            return Xm ? tK(b, c).slice() : []
        })
    };
    var uK = {
            20: function(a) {
                return "Ignoring a call to setCollapseEmptyDiv(false, true). Slots that start out collapsed should also collapse when empty. Slot: " + a[0] + "."
            },
            23: function(a) {
                return 'Error in googletag.display: could not find div with id "' + a[1] + '" in DOM for slot: ' + a[0] + "."
            },
            34: function(a) {
                return "Size mapping is null because invalid mappings were added: " + a[0] + "."
            },
            60: function(a) {
                return "Ignoring the " + a[0] + "(" + (a[1] || "") + ") call since the service is already enabled."
            },
            66: function(a) {
                return "Slot " + a[0] + " cannot be refreshed until PubAdsService is enabled."
            },
            68: function() {
                return "Slots cannot be cleared until service is enabled."
            },
            80: function(a) {
                return "Slot object at position " + a[0] + " is of incorrect type."
            },
            84: function(a) {
                return 'Cannot find targeting attribute "' + a[0] + '" for "' + a[1] + '".'
            },
            93: function(a) {
                return "Failed to register listener. Unknown event type: " + a[0] + "."
            },
            96: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + ")."
            },
            122: function(a) {
                return "Invalid argument: " + a[0] + "(" + a[1] + "). Valid values: " + a[2] + "."
            },
            121: function(a) {
                return "Invalid object passed to " + a[0] + "(" + a[1] + "), for " + a[2] + ": " + a[3] + "."
            },
            151: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + "). All zero-area slot sizes were removed."
            },
            105: function(a) {
                return "SRA requests may include a maximum of 30 ad slots. " + a[1] + " were requested, so the last " + a[2] + " were ignored."
            },
            106: function(a) {
                return "Publisher betas " + a[0] + " were declared after enableServices() was called."
            },
            107: function(a) {
                return "Publisher betas may only be declared once. " + a[0] + " were added after betas had already been declared."
            },
            108: function(a) {
                return "Beta keys cannot be cleared. clearTargeting() was called on " + a[0] + "."
            },
            123: function(a) {
                return "Refresh was throttled for slot: " + a[0] + "."
            },
            113: function(a) {
                return a[0] + " ad slot ineligible as page is not mobile optimized: " + a[1] + "."
            },
            114: function() {
                return 'setCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            115: function() {
                return 'updateCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            132: function(a) {
                return "Taxonomy with id " + a[0] + " has reached the limit of " + a[1] + " values."
            },
            133: function() {
                return "No taxonomy values were cleared, either due to an invalid taxonomy or no values present."
            },
            134: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: Format already created on the page."
            },
            135: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: Frequency cap of 1 has been exceeded."
            },
            136: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: The viewport exceeds the current maximum width of 2500px."
            },
            137: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: Format currently only supported on mobile."
            },
            138: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: Format currently only supports portrait orientation."
            },
            139: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: GPT is not running in the top-level window."
            },
            140: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: Detected browser is currently unsupported."
            },
            142: function(a) {
                return "A google product ad tag with click url " + a[0] + " does not contain any elements enabled for clicking."
            },
            145: function(a) {
                return hn(a[0]) + " " + a[1] + " not requested: Unable to access local storage to determine if the frequency cap has been exceeded due to insufficient user consent."
            },
            143: function() {
                return "getName on googletag.Slot is deprecated and will be removed. Use getAdUnitPath instead."
            },
            147: function() {
                return "GPT must be loaded from the limited ads URL to enable limited ads functionality."
            },
            148: function() {
                return "CommerceAdsConfig must contain a valid value for either categories or queries."
            },
            150: function() {
                return "Legacy browser does not support intersection observer causing lazy render/fetch as well as viewability events not to work properly."
            },
            154: function(a) {
                return "Refresh is disabled for " + hn(a[0]) + " " + a[1] + "."
            },
            152: function() {
                return "Attempted to load GPT multiple times."
            },
            155: function() {
                return "Using deprecated googletag.encryptedSignalProviders. Please use googletag.secureSignalProviders instead."
            },
            158: function(a) {
                return "Unrecognized property encountered when calling setConfig: " + a[0] + "." + a[1]
            },
            159: function(a) {
                return "Invalid value encountered when calling setConfig: " + a[0] + "." + a[1] + ": " + a[2]
            },
            160: function(a) {
                return "slot.setConfig key " + a[0] + " is not valid for this slot."
            }
        },
        vK = {
            26: function(a) {
                return "Div ID passed to googletag.display() does not match any defined slots: " + a[0] + "."
            },
            28: function(a) {
                return "Error in googletag.defineSlot: Cannot create slot " + a[1] + '. Div element "' + a[0] + '" is already associated with another slot: ' + a[2] + "."
            },
            149: function(a) {
                return "Error in googletag.defineSlot: Invalid ad unit path provided " + a[0] + ", see https://support.google.com/admanager/answer/10477476 for more information."
            },
            92: function(a) {
                return "Exception in " + a[1] + ' event listener: "' + a[0] + '".'
            },
            30: function(a) {
                return "Exception in googletag.cmd function: " + a[0] + "."
            },
            125: function(a) {
                return "google-product-ad element is invalid: " + a[0] + "."
            },
            126: function() {
                return "Attempted to collect prebid data but window.pbjs is undefined."
            },
            153: function() {
                return "Attempted to load GPT from both standard and limited ads domains."
            },
            127: function(a) {
                return "Encountered the following error while attempting to collect prebid metadata: " + a[0] + "."
            },
            144: function() {
                return "ContentService is no longer available. Use the browser's built-in DOM APIs to directly add content to div elements instead."
            }
        };
    var wK = function(a) {
            this.context = a;
            this.m = this.j = 0;
            this.A = window;
            this.o = [];
            this.o.length = 1E3
        },
        rK = function(a) {
            return [].concat(_.ch(a.o.slice(a.j)), _.ch(a.o.slice(0, a.j))).filter(function(b) {
                return !!b
            })
        },
        sK = function(a, b) {
            return rK(a).filter(function(c) {
                return c.getSlot() === b
            })
        },
        tK = function(a, b) {
            return rK(a).filter(function(c) {
                return c.getLevel() >= b
            })
        };
    wK.prototype.log = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? !1 : d;
        var e, f, g = new pK(a, b, null != (f = null == (e = c) ? void 0 : e.j) ? f : null);
        this.o[this.j] = g;
        this.j = (this.j + 1) % 1E3;
        f = 2 === a || 3 === a;
        var h = b.getMessageArgs();
        e = b.getMessageId();
        var k = uK[e] || vK[e];
        e = void 0;
        if (k) {
            e = k(h);
            if (d) throw new ym(e);
            d = this.m < _.Uf(lB) && f && _.t.console;
            if (this.A === top && d || _.A(_.t.navigator.userAgent, "includes").call(_.t.navigator.userAgent, "Lighthouse")) {
                d = "[GPT] " + e;
                var l, m, n, p;
                2 === a ? null == (m = (l = _.t.console).warn) || m.call(l, d) : null == (p = (n = _.t.console).error) || p.call(n, d);
                this.m++
            }
        }
        a: if (m = e, l = c, l = void 0 === l ? null : l, this.context.Kl) {
            switch (a) {
                case 2:
                    n = 1;
                    break;
                case 3:
                    n = 2;
                    break;
                default:
                    break a
            }
            var r, w, u;
            a = this.context.Qa;
            c = a.Jl;
            p = new JA;
            p = _.hh(p, 1, this.context.pvsid);
            d = _.If();
            p = _.be(p, 2, d, Kc);
            p = _.ih(p, 3, this.context.Lf);
            p = _.ih(p, 4, this.context.fb);
            p = _.hh(p, 5, this.context.ul);
            n = _.H(p, 6, n);
            m = _.ih(n, 7, m);
            n = b.getMessageId();
            m = _.H(m, 8, n);
            b = b.getMessageArgs();
            b = _.Lh(m, 9, b);
            m = eh(null != (u = null == (r = l) ? void 0 : r.getAdUnitPath()) ? u : "");
            r = _.ih(b, 10, m);
            u = null == (w = l) ? void 0 : w.getAdUnitPath();
            w = _.ih(r, 11, u);
            c.call(a, w)
        }
        return g
    };
    wK.prototype.info = function(a, b) {
        return this.log(1, a, void 0 === b ? null : b)
    };
    var P = function(a, b, c) {
        return a.log(2, b, c, !1)
    };
    wK.prototype.error = function(a, b, c) {
        return this.log(3, a, b, void 0 === c ? !1 : c)
    };
    var xK = function() {
            var a = {
                    Z: Hi().j,
                    Ni: new Date(Date.now()),
                    qh: window.location.href
                },
                b = this;
            a = void 0 === a ? {} : a;
            var c = void 0 === a.Z ? Hi().j : a.Z,
                d = void 0 === a.Ni ? new Date(Date.now()) : a.Ni,
                e = void 0 === a.qh ? window.location.href : a.qh;
            this.j = "";
            this.A = this.o = null;
            this.J = this.l = !1;
            this.m = function() {
                return !1
            };
            a = {};
            var f = {},
                g = {};
            this.H = (g[3] = (a[72] = function(h, k) {
                var l = b.o;
                k = Number(k);
                h = null !== l ? _.Rf("w5uHecUBa2S:" + Number(h) + ":" + l) % k === Math.floor(d.valueOf() / 864E5) % k : void 0;
                return h
            }, a[13] = function() {
                return _.Wa.apply(0, arguments).some(function(h) {
                    return _.A(b.j, "startsWith").call(b.j, h)
                })
            }, a[12] = function() {
                return !!_.L(c, 6)
            }, a[15] = function(h) {
                return b.m(h)
            }, a[66] = function() {
                try {
                    return !!HTMLScriptElement.supports("webbundle")
                } catch (h) {
                    return !1
                }
            }, a[67] = function() {
                return b.l
            }, a[68] = function() {
                return b.J
            }, a[74] = function() {
                return _.A(_.Wa.apply(0, arguments), "includes").call(_.Wa.apply(0, arguments), String(_.Rf(e)))
            }, a), g[4] = (f[14] = function() {
                var h = Number(b.A || void 0);
                isNaN(h) ? h = void 0 : (h = new Date(1E3 * h), h = 1E4 * h.getFullYear() + 100 * (h.getMonth() + 1) + h.getDate());
                return h
            }, f), g[5] = {}, g)
        },
        yK = function(a, b) {
            if (b && !a.o) {
                b = b.split(":");
                a.o = _.A(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("ID=")
                }) || null;
                var c;
                a.A = (null == (c = _.A(b, "find").call(b, function(d) {
                    return 0 === d.indexOf("T=")
                })) ? void 0 : c.substring(2)) || null
            }
        };
    var et = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 863);
        this.v = c;
        this.fd = Number(b);
        this.l = W(this, d);
        this.G = W(this, e);
        this.K = W(this, f);
        this.C = W(this, g)
    };
    _.T(et, Z);
    et.prototype.j = function() {
        var a = this.K.value,
            b = this.l.value,
            c = this.C.value,
            d = this.G.value,
            e = this.v;
        var f = kn(e);
        var g = b.getBoundingClientRect();
        e = _.fk(e) ? fi(b, e) : {
            x: 0,
            y: 0
        };
        b = e.x;
        e = e.y;
        g = new _.Ez(e, b + g.right, e + g.bottom, b);
        b = new mF;
        b = _.Lo(b, 1, g.top);
        b = _.Lo(b, 3, g.bottom);
        b = _.Lo(b, 2, g.left);
        g = _.Lo(b, 4, g.right);
        b = new nF;
        b = _.ni(b, 1, _.Nc(this.fd));
        d = xj(b, 2, !d);
        d = _.kh(d, 3, g);
        c = _.Lo(d, 4, c);
        f = _.Lo(c, 5, f);
        f = {
            type: "asmres",
            payload: tk(f)
        };
        a.ports[0].postMessage(f)
    };
    var Qp = function(a, b, c, d) {
        Z.call(this, a, 1061);
        var e = this;
        this.output = V(this);
        this.output.Ka(new _.v.Promise(function(f) {
            var g = b.listen(c, function(h) {
                h = d(h);
                null !== h && (g(), f(h))
            });
            _.mn(e, g)
        }))
    };
    _.T(Qp, Z);
    Qp.prototype.j = function() {};
    var Gp = function(a, b, c, d) {
        d = void 0 === d ? function() {
            return !0
        } : d;
        Z.call(this, a, 1061);
        var e = this;
        this.output = $F(this);
        RF(this.output, new _.v.Promise(function(f) {
            var g = b.listen(c, function(h) {
                d(h) && (g(), f())
            });
            _.mn(e, g)
        }))
    };
    _.T(Gp, Z);
    Gp.prototype.j = function() {};
    var ct = function(a, b, c, d) {
        Qp.call(this, a, b, Hp, function(e) {
            e = e.detail;
            var f;
            return "asmreq" === (null == (f = e.data) ? void 0 : f.type) && Br(lF(e.data.payload), 1) === Number(c) ? e : null
        });
        this.v = d;
        this.l = V(this)
    };
    _.T(ct, Qp);
    ct.prototype.j = function() {
        this.l.F(kn(this.v))
    };
    var zK = /(<head(\s+[^>]*)?>)/i,
        Is = function(a, b, c, d, e) {
            Z.call(this, a, 665);
            this.output = V(this);
            this.l = W(this, b);
            this.v = X(this, c);
            this.C = W(this, d);
            this.G = W(this, e)
        };
    _.T(Is, Z);
    Is.prototype.j = function() {
        var a;
        0 !== this.l.value.kind || null == (a = this.v.value) || !_.R(a, 1) || this.G.value ? this.output.F(this.l.value) : (a = this.l.value.yb, Ka("Firefox") || Ka("FxiOS") || (a = a.replace(zK, "$1<meta http-equiv=Content-Security-Policy content=\"script-src https://cdn.ampproject.org/;object-src 'none';child-src blob:;frame-src 'none'\">")), this.C.value && (a = a.replace(zK, '$1<meta name="referrer" content="origin">')), this.output.F({
            kind: 0,
            yb: a
        }))
    };
    var AK = function(a, b, c, d) {
        Z.call(this, a, 1124);
        this.Md = $F(this);
        this.v = W(this, b);
        this.l = W(this, c);
        bG(this, d)
    };
    _.T(AK, Z);
    AK.prototype.j = function() {
        _.Lz(this.l.value, {
            "min-width": "100%",
            visibility: "hidden"
        });
        _.Lz(this.v.value, "min-width", "100%");
        this.Md.notify()
    };
    var BK = function(a, b, c, d, e) {
        Z.call(this, a, 1125);
        this.v = W(this, b);
        this.l = W(this, c);
        bG(this, d);
        bG(this, e)
    };
    _.T(BK, Z);
    BK.prototype.j = function() {
        var a = this.v.value,
            b = a.contentDocument;
        b && (a.setAttribute("height", String(b.body.offsetHeight)), a.setAttribute("width", String(b.body.offsetWidth)), _.Lz(this.l.value, "visibility", "visible"))
    };
    var ft = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 718);
        this.slotId = b;
        this.Sg = e;
        this.v = f;
        this.C = g;
        this.output = V(this);
        this.l = new Gp(this.context, this.slotId, xs);
        this.K = X(this, c);
        this.G = X(this, d);
        this.O = W(this, h)
    };
    _.T(ft, Z);
    ft.prototype.j = function() {
        var a = !this.O.value;
        if (null == this.G.value || "height" !== this.K.value || a) this.l.xa(), this.output.F(!1);
        else {
            a = new Bj;
            _.S(this, a);
            var b = new AK(this.context, this.v, this.C, this.Sg);
            M(a, b);
            M(a, this.l);
            M(a, new BK(this.context, this.v, this.C, this.l.output, b.Md));
            Kj(a);
            this.output.F(!0)
        }
    };
    var xn = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        Z.call(this, a, 699);
        this.V = b;
        this.slotId = c;
        this.l = d;
        this.dd = e;
        this.O = r;
        this.K = X(this, f);
        this.ba = W(this, g);
        this.C = W(this, h);
        this.U = W(this, k);
        this.v = X(this, l);
        this.da = W(this, m);
        this.G = W(this, n);
        p && bG(this, p)
    };
    _.T(xn, Z);
    xn.prototype.j = function() {
        var a = this.ba.value,
            b = this.C.value;
        b.style.width = "";
        b.style.height = "";
        if ("height" !== this.K.value) {
            var c, d = null != (c = this.v.value) ? c : 0;
            c = this.U.value;
            var e = this.da.value,
                f = this.G.value,
                g = !1;
            switch (d) {
                case 1:
                case 2:
                case 4:
                case 5:
                    var h = this.context;
                    g = this.V;
                    var k = this.slotId,
                        l = this.l,
                        m = this.dd,
                        n, p = a.parentElement ? null == (n = zi(a.parentElement, window)) ? void 0 : n.width : void 0;
                    n = c.width;
                    var r = c.height,
                        w = 0;
                    var u = 0;
                    var y = Zh(l);
                    y = _.z(y);
                    for (var x = y.next(); !x.done; x = y.next()) {
                        var C = x.value;
                        Array.isArray(C) && (x = C[0], C = C[1], w < x && (w = x), u < C && (u = C))
                    }
                    u = [w, u];
                    w = u[0] < n;
                    r = u[1] < r;
                    if (w || r) {
                        u = n + "px";
                        y = {
                            "max-height": "none",
                            "max-width": u,
                            padding: "0px",
                            width: u
                        };
                        r && (y.height = "auto");
                        Li(b, a, y);
                        b = {};
                        if ((_.F = [2, 5], _.A(_.F, "includes")).call(_.F, d) || w && n > Ii(e.width)) b.width = u, b["max-width"] = u;
                        r && (b.height = "auto", b["max-height"] = "none");
                        c: {
                            for (I in b)
                                if (Object.prototype.hasOwnProperty.call(b, I)) {
                                    var I = !1;
                                    break c
                                }
                            I = !0
                        }
                        I ? b = !1 : (b["padding-" + ("ltr" === e.direction ? "left" : "right")] = "0px", _.Ki(a, b), b = !0)
                    } else b = !1;
                    b: switch (u = c.width, I = g.defaultView || g.parentWindow || _.t, d) {
                        case 2:
                        case 5:
                            a = Mi(a, I, u, e, m);
                            break b;
                        case 1:
                        case 4:
                            if (e = a.parentElement)
                                if (m = li(e)) {
                                    x = m.width;
                                    m = xi(k, I.document);
                                    n = zi(m, I);
                                    r = n.position;
                                    C = Ii(n.width) || 0;
                                    w = zi(e, I);
                                    y = "rtl" === w.direction ? "Right" : "Left";
                                    m = y.toLowerCase();
                                    I = "absolute" === r ? 0 : Ii(w["padding" + y]);
                                    w = Ii(w["border" + y + "Width"]);
                                    u = Math.max(Math.round((x - Math.max(C, u)) / 2), 0);
                                    x = {};
                                    C = 0;
                                    var D = En(n);
                                    D && (C = D[4] * ("Right" === y ? -1 : 1), y = D[3] || 1, 1 !== (D[0] || 1) || 1 !== y) && (D[0] = 1, D[3] = 1, x.transform = "matrix(" + D.join(",") + ")");
                                    y = 0;
                                    switch (r) {
                                        case "fixed":
                                            var J, Q = null != (J = Number(Ai(n.getPropertyValue(m)))) ? J : 0,
                                                N;
                                            J = null != (N = e.getBoundingClientRect().left) ? N : 0;
                                            y = Q - J;
                                            break;
                                        case "relative":
                                            y = null != (Q = Number(Ai(n.getPropertyValue(m)))) ? Q : 0;
                                            break;
                                        case "absolute":
                                            x[m] = "0"
                                    }
                                    x["margin-" + m] = u - I - w - y - C + "px";
                                    _.Ki(a, x);
                                    a = !0
                                } else a = !1;
                            else a = !1;
                            break b;
                        default:
                            a = !1
                    }
                    b || a ? (_.A(VG, "includes").call(VG, d) && Oi(h, g, k, l, d, c.width, c.height, p, "gpt_slotexp", f), g = !0) : g = !1;
                    break;
                case 3:
                    d = this.context, N = this.V, g = this.slotId, k = this.l, p = this.dd, l = a.parentElement ? null == (h = zi(a.parentElement, window)) ? void 0 : h.width : void 0, h = c.width, J = c.height, Q = Ii(e.height) || 0, J >= Q || "none" === e.display || "hidden" === e.visibility || !p || -12245933 === p.width || a.getBoundingClientRect().bottom <= p.height ? g = !1 : (p = {
                        height: J + "px"
                    }, Li(b, a, p), _.Ki(a, p), Oi(d, N, g, k, 3, h, J, l, "gpt_slotred", f), g = !0)
            }!g && _.G(UA) && Oi(this.context, this.V, this.slotId, this.l, 0, c.width, c.height, void 0, "gpt_pgbrk", f)
        }
        this.O.notify()
    };
    var sn = function(a, b, c, d, e, f) {
        Z.call(this, a, 1114);
        this.K = b;
        this.ia = c;
        this.C = V(this);
        this.v = V(this);
        this.G = W(this, d);
        this.l = W(this, e);
        this.O = W(this, f)
    };
    _.T(sn, Z);
    sn.prototype.j = function() {
        if (this.K) {
            var a = this.K.split(":");
            if (2 !== a.length || "#flexibleAdSlotDebugSize" !== a[0]) CK(this);
            else {
                var b = a[1];
                a = DK(this, b);
                var c;
                (c = /(?:.*)height=(ratio|[0-9]+)(?:;.*|$)/.exec(b)) ? (c = c[1], "ratio" === c ? c = a && this.G.value && this.l.value ? Math.floor(this.l.value / this.G.value * a) : null : (c = Number(c), c = 0 <= c ? c : null)) : c = null;
                b = (b = /(?:.*)ius=(.+,?)+(?:;.*|$)/.exec(b)) ? b[1].split(",") : [];
                a || c ? (this.C.F(new _.ki(null != a ? a : this.G.value, null != c ? c : this.l.value)), this.v.F(b)) : CK(this)
            }
        } else CK(this)
    };
    var DK = function(a, b) {
            b = /(?:.*)width=(parent|viewport|[0-9]+)(?:;.*|$)/.exec(b);
            if (!b) return null;
            b = b[1];
            if ("viewport" === b) return a.ia;
            if ("parent" === b) {
                var c, d, e;
                return (b = null != (e = null == (d = li(null == (c = a.O.value) ? void 0 : c.parentElement)) ? void 0 : d.width) ? e : null) ? Math.min(b, a.ia) : null
            }
            a = Number(b);
            return 0 <= a ? a : null
        },
        CK = function(a) {
            a.C.aa();
            a.v.F([])
        };
    var tn = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Z.call(this, a, 681);
        this.adUnitPath = b;
        this.K = c;
        this.Jc = d;
        this.U = n;
        this.ba = p;
        this.O = r;
        this.fa = w;
        this.C = X(this, e);
        this.pa = X(this, f);
        this.ma = X(this, g);
        this.da = X(this, h);
        this.l = W(this, k);
        this.v = W(this, l);
        this.G = W(this, m)
    };
    _.T(tn, Z);
    tn.prototype.j = function() {
        var a = EK(this),
            b = this.da.value,
            c;
        if (c = !this.Jc && a && b) this.l.value.length ? (c = this.adUnitPath.split("/"), c = _.A(this.l.value, "includes").call(this.l.value, c[c.length - 1])) : c = !0;
        if (c) {
            c = this.G.value;
            var d, e, f = null != (e = null == (d = li(c.parentElement)) ? void 0 : d.width) ? e : 0;
            d = b.width;
            b = b.height;
            FK(this, !0, d, b, {
                kind: 0,
                yb: '<html><body style="height:' + (b - 2 + "px;width:" + (d - 2 + 'px;background-color:#ddd;color:#000;border:1px solid #f00;margin:0;"><p>Requested size:')) + (a.width + "x" + a.height + "</p><p>Rendered size:") + (d + "x" + b + "</p></body></html>")
            }, d <= f ? 1 : 2, c)
        } else if (a = this.pa.value, b = this.ma.value, this.Jc) FK(this, !1, null != a ? a : 0, null != b ? b : 0, this.v.value);
        else {
            if (null == a) throw new ym("Missing 'width'.");
            if (null == b) throw new ym("Missing 'height'.");
            FK(this, !1, a, b, this.v.value)
        }
    };
    var EK = function(a) {
            a = Zh(a.K)[0];
            return Array.isArray(a) && a.every(function(b) {
                return "number" === typeof b
            }) ? new _.ki(a[0], a[1]) : null
        },
        FK = function(a, b, c, d, e, f, g) {
            f = void 0 === f ? a.C.value : f;
            a.fa.F(b);
            a.ba.F(new _.ki(c, d));
            a.U.F(e);
            a.O.Ca(f);
            g && _.Lz(g, "opacity", .5)
        };
    var wn = function(a, b, c) {
        Z.call(this, a, 698);
        this.B = b;
        this.output = V(this);
        this.l = W(this, c)
    };
    _.T(wn, Z);
    wn.prototype.j = function() {
        this.output.Ca(zi(this.l.value, this.B))
    };
    var GK = null;
    var HK = function(a, b, c, d, e) {
        Z.call(this, a, 937, _.Uf(EB));
        this.jb = b;
        this.l = V(this);
        this.v = V(this);
        this.C = V(this);
        this.bc = c;
        this.Zb = d;
        this.Fc = e
    };
    _.T(HK, Z);
    HK.prototype.j = function() {
        var a = {},
            b;
        if (null == (b = _.Qh(this.jb, Hx, 2)) ? 0 : _.L(b, 2)) a["*"] = {
            Oe: !0
        };
        b = new _.v.Set;
        for (var c = _.z(Uh(this.jb, Gx, 1)), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            for (var e = _.z([_.R(d, 2), _.R(d, 1)].filter(function(p) {
                    return !!p
                })), f = e.next(); !f.done; f = e.next()) a[f.value] = {
                Oe: _.L(d, 3)
            };
            d = _.z(Rd(d, 4, Lc));
            for (e = d.next(); !e.done; e = d.next()) b.add(e.value)
        }
        this.bc.F(a);
        this.l.F([].concat(_.ch(b)));
        var g, h;
        a = null == (g = _.Qh(this.jb, Hx, 2)) ? void 0 : null == (h = _.Qh(g, Bx, 1)) ? void 0 : Uh(h, Ax, 1);
        this.v.Ca((null == a ? 0 : a.length) ? a : null);
        var k;
        this.Zb.F(!(null == (k = _.Qh(this.jb, Hx, 2)) || !_.L(k, 4)));
        var l;
        this.Fc.F(!(null == (l = _.Qh(this.jb, Hx, 2)) || !_.L(l, 5)));
        var m, n;
        g = null == (m = _.Qh(this.jb, Hx, 2)) ? void 0 : null == (n = _.Qh(m, Bx, 3)) ? void 0 : Uh(n, Ax, 1);
        this.C.Ca((null == g ? 0 : g.length) ? g : null)
    };
    HK.prototype.H = function(a) {
        this.m(a)
    };
    HK.prototype.m = function() {
        this.bc.F({});
        this.l.F([]);
        this.v.aa();
        this.Zb.F(!1);
        this.Fc.F(!1);
        this.C.aa()
    };
    var IK = function(a, b, c, d) {
        Z.call(this, a, 980);
        this.bb = b;
        this.output = new vn;
        this.l = W(this, c);
        this.v = W(this, d)
    };
    _.T(IK, Z);
    IK.prototype.j = function() {
        (_.F = _.A(Object, "entries").call(Object, this.l.value), _.A(_.F, "find")).call(_.F, function(c) {
            var d = _.z(c);
            c = d.next().value;
            d = d.next().value;
            return "*" !== c && (null == d ? void 0 : d.Oe)
        }) && (this.bb.J = !0);
        Kl(25, this.context);
        for (var a = _.z(this.v.value), b = a.next(); !b.done; b = a.next()) Hf(b.value);
        this.output.notify()
    };
    var JK = function(a, b, c, d) {
        Z.call(this, a, 931);
        this.l = X(this, b);
        this.yc = c;
        this.ac = d
    };
    _.T(JK, Z);
    JK.prototype.j = function() {
        var a = this.l.value,
            b = new _.v.Map;
        this.yc.F(new _.v.Map);
        if (a) {
            var c;
            a = _.z(null != (c = this.l.value) ? c : []);
            for (c = a.next(); !c.done; c = a.next()) {
                var d = c.value;
                c = Uh(d, zx, 1);
                c = 1 === _.Ak(c[0], 1, 0) ? Vw(c[0]) : Ww(c[0], Uw);
                d = _.mf(d, 2);
                var e = void 0;
                b.set(c, Math.min(null != (e = b.get(c)) ? e : Number.MAX_VALUE, d))
            }
        }
        this.ac.F(b)
    };
    JK.prototype.m = function() {
        this.yc.F(new _.v.Map);
        this.ac.F(new _.v.Map)
    };
    var KK = function(a, b, c) {
        Z.call(this, a, 981);
        this.v = V(this);
        this.C = X(this, b);
        this.l = c
    };
    _.T(KK, Z);
    KK.prototype.j = function() {
        var a = new _.v.Map,
            b, c = _.z(null != (b = this.C.value) ? b : []);
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            var d = Uh(b, zx, 1);
            d = 1 === _.Ak(d[0], 1, 0) ? Vw(d[0]) : Ww(d[0], Uw);
            a.set(d, _.mf(b, 2))
        }
        this.v.F(a);
        this.l.F(new sx)
    };
    KK.prototype.m = function() {
        this.v.F(new _.v.Map);
        var a = this.l,
            b = a.F;
        var c = new sx;
        c = _.co(c, 1, 2);
        b.call(a, c)
    };
    var LK = function(a, b, c, d, e, f) {
        Z.call(this, a, 976);
        this.nextFunction = d;
        this.l = e;
        this.requestBidsConfig = f;
        bG(this, b);
        bG(this, c)
    };
    _.T(LK, Z);
    LK.prototype.j = function() {
        var a;
        null == (a = this.nextFunction) || a.apply(this.l, [this.requestBidsConfig])
    };
    var MK = function(a, b, c, d, e, f) {
        Z.call(this, a, 975);
        this.v = b;
        this.l = c;
        this.C = d;
        this.pbjs = e;
        this.requestBidsConfig = f;
        this.output = new vn
    };
    _.T(MK, Z);
    MK.prototype.j = function() {
        Pn(this.pbjs, this.v, this.l, this.C, this.requestBidsConfig);
        this.output.notify()
    };
    MK.prototype.m = function() {
        this.output.notify()
    };
    var NK = function(a, b, c, d, e, f) {
        Z.call(this, a, 1100);
        this.pbjs = b;
        this.l = c;
        this.v = d;
        this.C = e;
        this.requestBidsConfig = f;
        this.output = new vn
    };
    _.T(NK, Z);
    NK.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.l) ? void 0 : a.get("*")) ? b : _.Uf(YA);
        if (c) this.Yb(c);
        else {
            var d, e, f, g;
            a = null != (g = null != (f = null == (d = this.requestBidsConfig) ? void 0 : d.adUnits) ? f : null == (e = this.pbjs) ? void 0 : e.adUnits) ? g : [];
            d = _.z(a);
            for (e = d.next(); !e.done; e = d.next())
                if (e = e.value.code) c = b = a = g = void 0, f = null != (g = null != (a = null == (c = this.l) ? void 0 : c.get(_.G(go) ? jg(e) : e)) ? a : null == (b = this.l) ? void 0 : b.get(_.Rf(e))) ? g : 0, this.Yb(f)
        }
        this.output.notify()
    };
    NK.prototype.Yb = function(a) {
        var b;
        null != (b = this.v) && xj(b, 2, this.C);
        if (a) {
            var c;
            null == (c = this.v) || _.co(c, 1, 1);
            if (!this.C) {
                this.requestBidsConfig.timeout = a;
                var d, e, f;
                b = null != (f = null == (e = (d = this.pbjs).getConfig) ? void 0 : e.call(d).s2sConfig) ? f : [];
                if (Array.isArray(b))
                    for (d = _.z(b), e = d.next(); !e.done; e = d.next()) e.value.timeout = a;
                else b.timeout = a;
                var g, h;
                null == (h = (g = this.pbjs).setConfig) || h.call(g, {
                    bidderTimeout: a
                })
            }
        }
    };
    NK.prototype.m = function() {
        this.output.notify()
    };
    var OK = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.j = a;
        this.A = b;
        this.m = c;
        this.l = d;
        this.I = e;
        this.H = f;
        this.M = g;
        this.pbjs = h
    };
    _.T(OK, _.U);
    OK.prototype.push = function(a) {
        var b = a.context,
            c = a.nextFunction;
        a = a.requestBidsConfig;
        if (this.pbjs) {
            var d = new Bj;
            _.S(this, d);
            var e = new NK(this.j, this.pbjs, this.I, this.H, this.M, a),
                f = new MK(this.j, this.A, this.m, this.l, this.pbjs, a);
            M(d, e);
            M(d, f);
            M(d, new LK(this.j, f.output, e.output, c, b, a));
            Kj(d)
        }
    };
    var Rn = function(a, b) {
        this.push = K(a, 932, function(c) {
            b.push(c)
        })
    };
    var PK = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 951);
        this.B = window;
        this.G = W(this, b);
        this.v = X(this, d);
        this.C = W(this, e);
        this.O = W(this, f);
        this.l = X(this, g);
        this.U = X(this, h);
        this.K = W(this, k);
        bG(this, c);
        this.bf = null != l ? l : V(this);
        this.cf = null != m ? m : V(this)
    };
    _.T(PK, Z);
    PK.prototype.j = function() {
        var a = !!Am().pbjs_hooks;
        this.cf.F(a);
        this.bf.Ca(a ? null : _.Mg());
        var b, c = null == (b = this.v.value) ? void 0 : b.size,
            d;
        b = (null == (d = this.l.value) ? void 0 : d.size) || _.Uf(YA);
        d = this.G.value;
        var e, f = null != (e = Am().pbjs_hooks) ? e : [];
        e = new OK(this.context, this.v.value, this.C.value, this.O.value, this.l.value, this.U.value, this.K.value, d);
        _.S(this, e);
        f = _.z(f);
        for (var g = f.next(); !g.done; g = f.next()) e.push(g.value);
        if (c || b || a) Am().pbjs_hooks = Sn(this.context, e);
        !c && !b || a || Qn(d, this.B)
    };
    var QK = function(a, b, c) {
        Z.call(this, a, 966);
        this.B = b;
        this.Ub = c
    };
    _.T(QK, Z);
    QK.prototype.j = function() {
        var a = this,
            b = ig(this.B);
        if (b) this.Ub.F(b);
        else if (b = Object.getOwnPropertyDescriptor(this.B, "_pbjsGlobals"), !b || b.configurable) {
            var c = null;
            Object.defineProperty(this.B, "_pbjsGlobals", {
                set: function(d) {
                    c = d;
                    (d = ig(a.B)) && a.Ub.F(d)
                },
                get: function() {
                    return c
                }
            })
        }
    };
    QK.prototype.m = function() {};
    var RK = function(a, b, c, d, e) {
        Z.call(this, a, 1146, _.Uf(EB));
        this.bb = b;
        this.B = d;
        this.l = e;
        this.v = aG(this, c)
    };
    _.T(RK, Z);
    RK.prototype.j = function() {
        var a = this.v.value,
            b = new Bj;
        _.S(this, b);
        var c = new QK(this.context, this.B, this.l.Ub);
        M(b, c);
        if (a) {
            a = new HK(this.context, a, this.l.bc, this.l.Zb, this.l.Fc);
            M(b, a);
            var d = new IK(this.context, this.bb, a.bc, a.l);
            M(b, d);
            var e = new JK(this.context, a.v, this.l.yc, this.l.ac);
            M(b, e);
            var f = new KK(this.context, a.C, this.l.zf);
            M(b, f);
            c = new PK(this.context, c.Ub, d.output, e.ac, this.l.Zb, e.yc, f.v, f.l, a.Fc, this.l.bf, this.l.cf);
            M(b, c)
        } else SK(this);
        Kj(b)
    };
    var SK = function(a) {
        a.l.bc.F({});
        a.l.ac.F(new _.v.Map);
        a.l.Zb.F(!1);
        a.l.yc.F(new _.v.Map);
        a.l.bf.aa();
        a.l.cf.F(!1);
        a.l.zf.F(new sx);
        a.l.Fc.F(!1)
    };
    RK.prototype.H = function(a) {
        this.m(a)
    };
    RK.prototype.m = function() {
        SK(this)
    };
    var TK = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
        UK = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 920);
            this.T = b;
            this.R = c;
            this.pbjs = f;
            this.C = g;
            this.G = V(this);
            this.v = V(this);
            this.K = [];
            this.l = new _.v.Map;
            this.ba = W(this, d);
            this.U = X(this, e.ac);
            this.O = W(this, e.Zb);
            this.fa = W(this, e.yc);
            this.da = X(this, e.zf)
        };
    _.T(UK, Z);
    UK.prototype.j = function() {
        var a = VK(this, this.pbjs);
        a ? (this.C.Ca(a), this.G.F(this.l), this.v.F(this.K)) : WK(this)
    };
    UK.prototype.H = function(a) {
        this.m(a)
    };
    UK.prototype.m = function(a) {
        this.T.error(sJ(a.message));
        WK(this)
    };
    var WK = function(a) {
            a.C.aa();
            a.G.aa();
            a.v.aa()
        },
        VK = function(a, b) {
            var c = (0, b.getEvents)(),
                d = c.filter(function(g) {
                    var h = g.args;
                    return "auctionEnd" === g.eventType && h.auctionId
                }),
                e = !1,
                f = a.ba.value.map(function(g) {
                    var h = new xx,
                        k = function(na) {
                            return na === g.getDomId() || na === g.getAdUnitPath()
                        },
                        l, m = null != (l = XK.get(g)) ? l : 0,
                        n;
                    l = null != (n = d.filter(function(na) {
                        var za, pa, Ta;
                        return Number(null == (za = na.args) ? void 0 : za.timestamp) > m && (null == (pa = na.args) ? void 0 : null == (Ta = pa.adUnitCodes) ? void 0 : _.A(Ta, "find").call(Ta, k))
                    })) ? n : [];
                    if (!l.length) return a.K.push(g), [g, h];
                    var p;
                    n = null == (p = l.reduce(function(na, za) {
                        return Number(za.args.timestamp) > Number(na.args.timestamp) ? za : na
                    })) ? void 0 : p.args;
                    if (!n) return [g, h];
                    var r = void 0 === n.bidderRequests ? [] : n.bidderRequests;
                    p = void 0 === n.bidsReceived ? [] : n.bidsReceived;
                    var w = n.auctionId;
                    n = n.timestamp;
                    if (!w || null == n || !r.length) return [g, h];
                    XK.has(g) || _.mn(g, function() {
                        return XK.delete(g)
                    });
                    XK.set(g, n);
                    n = yx(h);
                    Math.random() < _.Uf(XA) && b.version && TK.test(b.version) && On(n, 6, b.version);
                    var u;
                    vx(n, null == (u = a.da) ? void 0 : u.value);
                    u = yi(function() {
                        return so(c, w)
                    });
                    l = Vk(a.R[g.getDomId()]);
                    r = _.z(r);
                    for (var y = r.next(), x = {}; !y.done; x = {
                            bidderCode: x.bidderCode,
                            Mg: x.Mg
                        }, y = r.next()) {
                        var C = y.value;
                        x.bidderCode = C.bidderCode;
                        var I = C.bids;
                        y = C.timeout;
                        x.Mg = C.src;
                        C = C.auctionStart;
                        I = _.z(I);
                        for (var D = I.next(), J = {}; !D.done; J = {
                                jd: J.jd
                            }, D = I.next()) {
                            var Q = D.value;
                            J.jd = Q.bidId;
                            var N = Q.transactionId;
                            D = Q.adUnitCode;
                            var Y = Q.getFloor;
                            Q = Q.mediaTypes;
                            if (J.jd && k(D)) {
                                e = !0;
                                eo(n, g, D);
                                N && (null != _.sj(n, 4) || On(n, 4, N), a.l.has(N) || a.l.set(N, C));
                                null == Cp(n, 8) && _.A(Number, "isFinite").call(Number, y) && _.Lo(n, 8, y);
                                var ua = _.A(p, "find").call(p, function(na) {
                                    return function(za) {
                                        return za.requestId === na.jd
                                    }
                                }(J));
                                N = Un(n, function(na) {
                                    return function() {
                                        var za = Xn(new Yn, na.bidderCode);
                                        Zn(na.bidderCode, b, za);
                                        switch (na.Mg) {
                                            case "client":
                                                _.co(za, 7, 1);
                                                break;
                                            case "s2s":
                                                _.co(za, 7, 2)
                                        }
                                        return za
                                    }
                                }(x)());
                                ho(n, N, D, a.U.value, a.O.value, a.fa.value, Y);
                                ua ? (Wn(N, 1), "number" === typeof ua.timeToRespond && $n(N, ua.timeToRespond), D = Tn(ua, l, Q), Vn(N, D)) : (D = u().get(J.jd)) && !D.Sh ? $n(Wn(N, 2), Math.round(D.latency)) : (D = Wn(N, 3), _.A(Number, "isFinite").call(Number, y) && $n(D, y))
                            }
                        }
                    }
                    var ma;
                    (null == (ma = b.getConfig) ? 0 : ma.call(b).useBidCache) && ao(n, g, w, l, b);
                    return [g, h]
                });
            return e ? new _.v.Map(f) : null
        },
        XK = new _.v.Map;
    var YK = function(a, b, c, d) {
        Z.call(this, a, 1019);
        this.R = c;
        this.pbjs = d;
        this.l = X(this, b)
    };
    _.T(YK, Z);
    YK.prototype.j = function() {
        ZK(this)
    };
    var ZK = function(a) {
        if (!(Math.random() >= _.Uf(WA))) {
            var b = (a.l.value || []).filter(function(k) {
                return Vk(a.R[k.getDomId()]).some(function(l) {
                    return "hb_pb" === _.sj(l, 1)
                })
            });
            if (b.length) {
                var c, d, e, f, g, h = (null == (c = a.pbjs) ? 0 : null == (d = c.adUnits) ? 0 : d.length) ? [].concat(_.ch(new _.v.Set(null == (e = a.pbjs) ? void 0 : e.adUnits.map(function(k) {
                    return k.code
                })))) : _.A(Object, "keys").call(Object, (null == (f = a.pbjs) ? void 0 : null == (g = f.getAdserverTargeting) ? void 0 : g.call(f)) || {});
                c = new Ym("haux");
                Yi(c, "ius", b.map(function(k) {
                    return k.getAdUnitPath()
                }).join("~"));
                Yi(c, "dids", b.map(function(k) {
                    return k.getDomId()
                }).join("~"));
                Yi(c, "paucs", h.join("~"));
                Xi(c, a.context);
                $m(c)
            }
        }
    };
    var xo = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1153);
        this.T = b;
        this.R = c;
        this.hb = d;
        this.G = e;
        this.fe = f;
        this.l = h;
        this.K = W(this, f.bc);
        this.v = new QF(f.Ub);
        g && (this.C = X(this, g))
    };
    _.T(xo, Z);
    xo.prototype.j = function() {
        var a, b = null == (a = this.v) ? void 0 : a.value;
        if (a = $K(this)) null != b && b.libLoaded ? "function" !== typeof b.getEvents ? (this.T.error(rJ()), a = !1) : a = !0 : a = !1;
        if (a) {
            a = new Bj;
            var c = new UK(this.context, this.T, this.R, this.G, this.fe, b, this.l.Lg);
            M(a, c);
            M(a, new YK(this.context, c.v, this.R, b));
            Kj(a)
        } else this.l.Lg.aa()
    };
    var $K = function(a) {
        var b;
        if (null == (b = a.C) ? 0 : b.value) return !0;
        var c = a.K.value;
        if (!c) return !1;
        var d;
        return !(null == (d = c["*"]) || !d.Oe) || a.hb.split(",").some(function(e) {
            var f;
            return !(null == (f = c[e]) || !f.Oe)
        })
    };
    var aL = function(a, b, c, d, e) {
        Z.call(this, a, 982);
        this.C = d;
        this.af = e;
        this.v = W(this, b);
        this.l = W(this, c)
    };
    _.T(aL, Z);
    aL.prototype.j = function() {
        for (var a = this, b = _.z(["bidWon", "staleRender", "adRenderFailed", "adRenderSucceeded"]), c = b.next(), d = {}; !c.done; d = {
                pd: d.pd,
                Ue: d.Ue
            }, c = b.next()) d.pd = c.value, d.Ue = function(e) {
            return function(f) {
                if (a.C === f.adId) {
                    var g = new Ym("hbm_brt");
                    Xi(g, a.context);
                    Yi(g, "et", e.pd);
                    Yi(g, "sf", a.v.value);
                    Yi(g, "qqid", a.l.value);
                    var h, k, l;
                    Yi(g, "bc", String(null != (l = null != (k = f.bidderCode) ? k : null == (h = f.bid) ? void 0 : h.bidder) ? l : ""));
                    $m(g)
                }
            }
        }(d), (0, this.af.onEvent)(d.pd, d.Ue), _.mn(this, function(e) {
            return function() {
                return void Eh(a.context, a.id, function() {
                    var f, g;
                    return void(null == (g = (f = a.af).offEvent) ? void 0 : g.call(f, e.pd, e.Ue))
                }, !0)
            }
        }(d))
    };
    aL.prototype.m = function() {};
    var zo = function(a, b, c, d, e) {
        Z.call(this, a, 1134);
        this.rf = d;
        this.jc = e;
        this.v = X(this, b);
        this.l = new QF(c)
    };
    _.T(zo, Z);
    zo.prototype.j = function() {
        var a;
        if (this.v.value && null != (a = this.l.value) && a.onEvent) {
            a = new Bj;
            var b = new aL(this.context, this.rf, this.jc, this.v.value, this.l.value);
            M(a, b);
            Kj(a)
        }
    };
    var eL = function(a, b, c, d) {
            var e = this;
            this.context = a;
            this.L = c;
            this.j = new _.v.Map;
            this.o = new _.v.Map;
            this.timer = _.Ff(Ah);
            XH() && (_.ib(window, "DOMContentLoaded", yh(a, 334, function() {
                for (var f = _.z(e.j), g = f.next(); !g.done; g = f.next()) {
                    var h = _.z(g.value);
                    g = h.next().value;
                    h = h.next().value;
                    bL(e, g, h) && e.j.delete(g)
                }
            })), b.listen(jI, function(f) {
                f = f.detail;
                var g = f.R;
                return void cL(e, dL(d, f.Kg), Br(g, 20))
            }), b.listen(kI, function(f) {
                f = f.detail;
                var g = f.R;
                f = dL(d, f.Kg);
                g = Br(g, 20);
                var h = e.o.get(f);
                null != h ? ZH(h, g) : cL(e, f, g)
            }))
        },
        cL = function(a, b, c) {
            bL(a, b, c) ? a.j.delete(b) : (a.j.set(b, c), _.mn(b, function() {
                return a.j.delete(b)
            }))
        },
        bL = function(a, b, c) {
            var d = xi(b);
            if ("DIV" !== (null == d ? void 0 : d.nodeName)) return !1;
            d = new WH({
                B: window,
                timer: a.timer,
                Nb: d,
                ob: function(e) {
                    return void Ch(a.context, 336, e)
                },
                Ol: _.G(kC)
            });
            if (!d.j) return !1;
            ZH(d, c);
            a.o.set(b, d);
            rI(a.L, b, function() {
                return void a.o.delete(b)
            });
            return !0
        };
    var fL = function(a, b, c, d, e) {
        Z.call(this, a, 1058);
        this.B = b;
        this.X = c;
        this.output = $F(this);
        d && (this.l = X(this, d.Dc));
        bG(this, e)
    };
    _.T(fL, Z);
    fL.prototype.j = function() {
        var a;
        Pf(this.B.isSecureContext, this.B, this.B.document) && null != (a = this.l) && a.value && !_.G($A) && zf(this.X) && (a = this.l.value, a({
            message: "goog:spam:client_age",
            pvsid: this.context.pvsid
        }));
        this.output.notify()
    };
    var gL = function(a, b, c) {
        Z.call(this, a, 1199);
        this.l = c;
        this.v = X(this, b)
    };
    _.T(gL, Z);
    gL.prototype.j = function() {
        var a = this.v.value;
        a && (a = TG(this.l, a.getSlotElementId()), xj(a, 30, !0))
    };
    var hL = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1109);
        this.V = c;
        this.Z = d;
        this.l = e;
        this.C = f;
        this.G = g;
        this.v = h;
        this.output = V(this);
        this.K = X(this, b)
    };
    _.T(hL, Z);
    hL.prototype.j = function() {
        var a = this,
            b = this.K.value;
        b && (this.v.push(function() {
            b.addService(a.l)
        }), Az(this.V, function() {
            a.G();
            a.C(b);
            _.L(a.Z, 4) && a.l.refresh([b])
        }))
    };
    var iL = {},
        Fo = (iL[64] = uJ, iL[134217728] = vJ, iL[32768] = wJ, iL[536870912] = xJ, iL[8] = yJ, iL[512] = zJ, iL[1048576] = AJ, iL[4194304] = CJ, iL);
    var jL = function(a) {
        return "22639388115" === eh(a.getAdUnitPath())
    };
    var kL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1108);
        this.adUnitPath = b;
        this.format = c;
        this.sb = d;
        this.v = e;
        this.T = f;
        this.output = V(this);
        this.l = V(this)
    };
    _.T(kL, Z);
    kL.prototype.j = function() {
        var a = Yo(this.context, this.T, this.v, {
            vh: this.format,
            adUnitPath: this.adUnitPath,
            sb: this.sb
        });
        this.l.Ca(a);
        this.output.Ca(a ? a.j : null)
    };
    var lL = function(a, b, c, d) {
        Z.call(this, a, 1111);
        this.l = c;
        this.v = d;
        this.C = X(this, b)
    };
    _.T(lL, Z);
    lL.prototype.j = function() {
        var a = this.C.value;
        a && (a = TG(this.l, a.getSlotElementId()), yj(a, 27, Px, this.v))
    };
    var mL = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Bj.call(this);
        this.context = a;
        this.V = b;
        this.adUnitPath = c;
        this.format = d;
        this.sb = e;
        this.O = f;
        this.G = g;
        this.K = h;
        this.C = k;
        this.Z = l;
        this.I = m;
        this.U = n;
        this.T = p;
        this.da = r;
        this.M = w;
        a = M(this, new kL(this.context, this.adUnitPath, this.format, this.sb, this.U, this.T));
        this.M && M(this, new lL(this.context, a.output, this.I, this.M));
        this.da && M(this, new gL(this.context, a.output, this.I));
        M(this, new hL(this.context, a.output, this.V, this.Z, this.O, this.G, this.K, this.C));
        this.j = {
            Pn: a.l
        }
    };
    _.T(mL, Bj);
    var Zo = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1198);
        this.V = b;
        this.googletag = c;
        this.Z = d;
        this.l = e;
        this.v = f;
        this.T = g;
        this.C = W(this, h)
    };
    _.T(Zo, Z);
    Zo.prototype.j = function() {
        for (var a = this, b = _.z(this.C.value), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            c = d.getAdUnitPath();
            d = _.Ak(d, 2, 0);
            c && d && (c = new mL(this.context, this.V, c, d, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, this.Z, this.l, this.v, this.T, !0), Kj(c), _.S(this, c))
        }
    };
    var ps = function(a, b) {
        Z.call(this, a, 1110);
        this.B = b;
        this.output = V(this)
    };
    _.T(ps, Z);
    ps.prototype.j = function() {
        var a = this.B;
        a = _.G(gC) && void 0 !== a.credentialless && (_.G(hC) || a.crossOriginIsolated);
        this.output.F(a)
    };
    var nL = function(a, b, c, d, e, f) {
        Z.call(this, a, 935);
        this.L = b;
        this.P = c;
        this.V = d;
        this.output = $F(this);
        this.l = W(this, e);
        bG(this, f)
    };
    _.T(nL, Z);
    nL.prototype.j = function() {
        var a = this.P,
            b = a.Z;
        a = a.R;
        for (var c = _.z(this.l.value), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = a[d.getDomId()],
                f = this.V;
            ap(e, b) && !this.L.qc(d) && bp(d, f, e, b)
        }
        this.output.notify()
    };
    var oL = function(a, b, c, d, e) {
        Z.call(this, a, 864);
        this.L = b;
        this.P = c;
        this.V = d;
        this.l = $F(this);
        this.v = W(this, e)
    };
    _.T(oL, Z);
    oL.prototype.j = function() {
        ep({
            W: this.v.value
        }, {
            L: this.L,
            P: this.P,
            V: this.V
        });
        this.l.notify()
    };
    var ip = function(a, b, c) {
        Z.call(this, a, 1208);
        this.l = b;
        this.output = new vn;
        this.v = X(this, c)
    };
    _.T(ip, Z);
    ip.prototype.j = function() {
        var a, b = null == (a = this.v.value) ? void 0 : _.Qh(a, my, 1);
        if (b) {
            a = this.l;
            var c = new SE;
            c = xj(c, 5, !0);
            ZE(a, "__eoi", b, c)
        }
        this.output.notify()
    };
    var mp = function(a, b, c, d) {
        Z.call(this, a, 879);
        this.v = b;
        this.l = V(this);
        c && (this.C = W(this, d))
    };
    _.T(mp, Z);
    mp.prototype.j = function() {
        var a, b;
        (null != (b = null == (a = this.C) ? void 0 : a.value) ? b : IC(this.v)) ? (a = JC(this.v), this.l.Ka(a)) : this.l.aa()
    };
    var lp = function(a, b, c, d) {
        Z.call(this, a, 896);
        this.l = b;
        this.oc = d;
        this.Kc = V(this);
        c && bG(this, c)
    };
    _.T(lp, Z);
    lp.prototype.j = function() {
        this.Kc.F(IC(this.l, ".google.cn" === this.oc))
    };
    var pL = function(a, b) {
        Z.call(this, a, 1018);
        this.Ce = $F(this);
        this.l = X(this, b)
    };
    _.T(pL, Z);
    pL.prototype.j = function() {
        var a, b, c, d = _.z(null != (c = null == (a = this.l.value) ? void 0 : null == (b = _.Qh(a, AC, 5)) ? void 0 : Rd(b, 1, Lc)) ? c : []);
        for (a = d.next(); !a.done; a = d.next()) Hf(a.value);
        this.Ce.notify()
    };
    var qL = function(a, b) {
        Z.call(this, a, 1070);
        this.l = V(this);
        this.v = X(this, b)
    };
    _.T(qL, Z);
    qL.prototype.j = function() {
        var a, b = null == (a = this.v.value) ? void 0 : _.Qh(a, AC, 5);
        if (b) {
            a = [];
            for (var c = _.z(Rd(b, 2, Yc, void 0, void 0, void 0, 0)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value;
                d = new Px;
                var f = new Nx;
                e = _.ni(f, 1, Tc(e));
                d = _.kh(d, 2, e);
                null != Cp(b, 3) && (e = new Lx, e = _.co(e, 1, 1), f = _.Rw(b, 3), e = _.qk(e, 2, f), _.kh(d, 3, e));
                a.push(d)
            }
            this.l.F(a)
        } else this.l.F([])
    };
    var rL = function(a, b, c, d) {
        Z.call(this, a, 1016);
        this.output = V(this);
        this.v = X(this, b);
        this.l = X(this, c);
        this.C = dG(this, [b, d])
    };
    _.T(rL, Z);
    rL.prototype.j = function() {
        if (this.l.value) {
            var a = this.v.value || this.C.value;
            a && sL(this, a) ? this.output.F(a) : this.output.aa()
        } else this.output.aa()
    };
    rL.prototype.H = function(a) {
        this.m(a)
    };
    rL.prototype.m = function() {
        this.output.aa()
    };
    var sL = function(a, b) {
        return Uh(a.l.value, Jx, 1).some(function(c) {
            return _.R(c, 1) === b
        })
    };
    var tL = function(a, b) {
        Z.call(this, a, 1015);
        this.l = V(this);
        this.v = X(this, b)
    };
    _.T(tL, Z);
    tL.prototype.j = function() {
        if (this.v.value)
            if (Uh(this.v.value, Jx, 1).length) {
                var a = Uh(this.v.value, Jx, 1)[0];
                (_.F = [2, 3], _.A(_.F, "includes")).call(_.F, _.Ak(a, 3, 0)) ? this.l.F(_.R(a, 1)) : this.l.aa()
            } else this.l.aa();
        else this.l.aa()
    };
    tL.prototype.H = function(a) {
        this.m(a)
    };
    tL.prototype.m = function() {
        this.l.aa()
    };
    var uL = function(a, b, c) {
        Z.call(this, a, 1017);
        this.B = c;
        this.output = $F(this);
        this.l = X(this, b)
    };
    _.T(uL, Z);
    uL.prototype.j = function() {
        var a = this;
        if (this.l.value) {
            var b = WC(this.B, this.l.value, function(c) {
                if (!c) {
                    c = cf(b.j);
                    for (var d = _.z(document.getElementsByName("googlefcPresent")), e = d.next(); !e.done; e = d.next()) c.mj(e.value)
                }
                a.output.notify()
            });
            b.start()
        } else this.output.notify()
    };
    uL.prototype.H = function(a) {
        this.m(a)
    };
    uL.prototype.m = function() {
        this.output.notify()
    };
    var vL = function(a, b) {
        Z.call(this, a, 1056);
        this.output = V(this);
        this.l = W(this, b)
    };
    _.T(vL, Z);
    vL.prototype.j = function() {
        var a = eh(this.l.value.getAdUnitPath());
        this.output.F(a)
    };
    vL.prototype.H = function(a) {
        this.m(a)
    };
    vL.prototype.m = function() {
        this.output.aa()
    };
    var wL = function(a, b, c, d) {
        Z.call(this, a, 906, _.Uf(FB));
        this.l = $F(this);
        if (b === b.top) {
            var e = new Bj;
            _.S(this, e);
            var f = new tL(a, c);
            M(e, f);
            d = new Qp(a, d, jI, function(g) {
                return g.detail.R
            });
            M(e, d);
            d = new vL(a, d.output);
            M(e, d);
            a = new rL(a, f.l, c, d.output);
            M(e, a);
            b = new uL(this.context, a.output, b);
            M(e, b);
            cG(this, b.output);
            Kj(e)
        } else this.l.notify()
    };
    _.T(wL, Z);
    wL.prototype.j = function() {
        this.l.notify()
    };
    wL.prototype.H = function(a) {
        this.m(a)
    };
    wL.prototype.m = function() {
        this.l.notify()
    };
    var Ws = function(a, b, c, d, e) {
        Z.call(this, a, 934);
        this.B = b;
        this.slotId = c;
        bG(this, d);
        this.l = W(this, e)
    };
    _.T(Ws, Z);
    Ws.prototype.j = function() {
        var a = this;
        this.slotId.listen(Hp, function(b) {
            b = b.detail.data;
            try {
                var c = JSON.parse(b);
                if ("gpi-uoo" === c.googMsgType) {
                    var d = c.userOptOut,
                        e = c.clearAdsData,
                        f = a.l.value,
                        g = new my;
                    var h = On(g, 1, d ? "1" : "0");
                    var k = On(_.qk(h, 2, 2147483647), 3, "/");
                    var l = On(k, 4, a.B.location.hostname);
                    var m = new _.XE(a.B);
                    ZE(m, "__gpi_opt_out", l, f);
                    if (d || e) $E(m, "__gads", f), $E(m, "__gpi", f)
                }
            } catch (n) {}
        })
    };
    var xL = function(a, b, c) {
        Z.call(this, a, 944);
        this.B = b;
        this.l = new _.XE(this.B);
        this.v = W(this, c)
    };
    _.T(xL, Z);
    xL.prototype.j = function() {
        var a = this.v.value;
        if (YE(this.l, a)) {
            var b = _.Ll(this.l, "__gpi_opt_out", a);
            if (b) {
                var c = new my;
                b = On(c, 1, b);
                b = On(_.qk(b, 2, 2147483647), 3, "/");
                b = On(b, 4, this.B.location.hostname);
                ZE(this.l, "__gpi_opt_out", b, a)
            }
        }
    };
    var yL = function(a, b, c, d) {
        Z.call(this, a, 821);
        this.X = b;
        this.wa = c;
        this.l = W(this, d)
    };
    _.T(yL, Z);
    yL.prototype.j = function() {
        if (zf(this.X))
            for (var a = new _.v.Set, b = _.z(Uh(this.l.value, my, 14)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = void 0,
                    e = null != (d = Zw(c, 5)) ? d : 1;
                a.has(e) || (ZE(this.wa, 2 === e ? "__gpi" : "__gads", c, this.X), a.add(e))
            }
    };
    var zL = function() {
            this.o = [];
            this.hostpageLibraryTokens = [];
            this.j = {}
        },
        Yr = function(a, b) {
            var c, d;
            a = null != (d = null == (c = a.j[b]) ? void 0 : _.A(c, "values").call(c)) ? d : [];
            return [].concat(_.ch(a))
        };
    var AL = function(a, b, c, d) {
        Z.call(this, a, 822);
        this.slotId = b;
        this.Ta = c;
        this.l = W(this, d)
    };
    _.T(AL, Z);
    AL.prototype.j = function() {
        var a = Rd(this.l.value, 23, Jc);
        a = _.z(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = this.Ta;
            if (!_.A(c.o, "includes").call(c.o, b) && (_.F = [1, 2, 3], _.A(_.F, "includes")).call(_.F, b)) {
                var d = bF[b];
                if (d) {
                    var e = b + "_hostpage_library";
                    if (d = _.an(document, d)) d.id = e
                }
                c.o.push(b);
                e = new cF(b);
                c.hostpageLibraryTokens.push(e);
                c = Am();
                c.hostpageLibraryTokens || (c.hostpageLibraryTokens = {});
                c.hostpageLibraryTokens[e.j] = e.o
            }
            c = void 0;
            e = this.Ta;
            d = this.slotId;
            e.j[b] = null != (c = e.j[b]) ? c : new _.v.Set;
            e.j[b].add(d)
        }
    };
    var yp = 0;
    var gt = function(a, b, c, d, e, f) {
        Z.call(this, a, 721);
        this.B = b;
        this.G = X(this, c);
        this.v = W(this, d);
        this.l = W(this, e);
        this.C = W(this, f)
    };
    _.T(gt, Z);
    gt.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c, d = null == b ? void 0 : null == (c = _.R(b, 1)) ? void 0 : c.toUpperCase(),
            e;
        b = null == b ? void 0 : null == (e = _.R(b, 2)) ? void 0 : e.toUpperCase();
        if (d && b) {
            e = this.v.value;
            c = this.l.value;
            var f = this.C.value,
                g = f.style.height,
                h = f.style.width,
                k = f.style.display,
                l = f.style.position,
                m = Ap(e.id + "_top", d),
                n = Ap(e.id + "_bottom", b);
            _.Ki(n, {
                position: "relative",
                top: "calc(100vh - 48px)"
            });
            f.appendChild(m);
            f.appendChild(n);
            _.Ki(c, {
                position: "absolute",
                top: "24px",
                clip: "rect(0, auto, auto, 0)",
                width: "100vw",
                height: "calc(100vh - 48px)"
            });
            _.Ki(e, {
                position: "fixed",
                top: "0",
                height: "100vh"
            });
            var p;
            _.Ki(f, {
                position: "relative",
                display: (null == (p = this.B.screen.orientation) ? 0 : p.angle) ? "none" : "block",
                width: "100vw",
                height: "100vh"
            });
            on(this, 722, this.B, "orientationchange", function() {
                var r;
                (null == (r = a.B.screen.orientation) ? 0 : r.angle) ? _.Ki(f, {
                    display: "none"
                }): _.Ki(f, {
                    display: "block"
                })
            });
            _.mn(this, function() {
                _.Yy(m);
                _.Yy(n);
                f.style.position = l;
                f.style.height = g;
                f.style.width = h;
                f.style.display = k
            })
        }
    };
    var BL = _.ju(["https://td.doubleclick.net/td/kb?kbli=", ""]),
        Us = function(a, b, c, d, e) {
            Z.call(this, a, 1007);
            this.C = X(this, b);
            this.l = W(this, d);
            c && (this.v = W(this, c));
            e && bG(this, e)
        };
    _.T(Us, Z);
    Us.prototype.j = function() {
        if (zf(this.l.value)) {
            var a;
            if (null == (a = this.v) || !a.value) {
                var b = this.C.value;
                if (null != b && b.length && null === document.getElementById("koelBirdIGRegisterIframe")) {
                    a = document.createElement("iframe");
                    b = Xa(BL, encodeURIComponent(b.join()));
                    a.removeAttribute("srcdoc");
                    if (b instanceof _.av) throw new Xv("TrustedResourceUrl", 3);
                    var c = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" ");
                    a.setAttribute("sandbox", "");
                    for (var d = 0; d < c.length; d++) a.sandbox.supports && !a.sandbox.supports(c[d]) || a.sandbox.add(c[d]);
                    b = _.bb(b);
                    void 0 !== b && (a.src = b);
                    a.id = "koelBirdIGRegisterIframe";
                    document.head.appendChild(a)
                }
            }
        }
    };
    var Js = function(a, b) {
        Z.call(this, a, 1176);
        this.v = b;
        this.l = V(this)
    };
    _.T(Js, Z);
    Js.prototype.j = function() {
        var a, b = this.l,
            c = b.Ca,
            d = null != (a = this.v) ? a : new Ks;
        a = null != Cp(d, 2) ? null != Dp(d) && 0 !== (0, _.In)() ? Cp(d, 2) * Dp(d) : Cp(d, 2) : null;
        c.call(b, a)
    };
    var Ps = function(a, b, c, d, e, f) {
        f = void 0 === f ? Bp : f;
        Z.call(this, a, 666);
        this.v = f;
        this.output = $F(this);
        bG(this, b);
        e && bG(this, e);
        this.l = W(this, c);
        this.C = X(this, d)
    };
    _.T(Ps, Z);
    Ps.prototype.j = function() {
        var a = this.C.value,
            b = this.l.value;
        null == a || 0 > a || !Bi(b) ? this.output.notify() : CL(this, a, b)
    };
    var CL = function(a, b, c) {
        var d = a.v(b, yh(a.context, 291, function(e, f) {
            e = _.z(e);
            for (var g = e.next(); !g.done; g = e.next())
                if (g = g.value, !(0 >= g.intersectionRatio)) {
                    f.unobserve(g.target);
                    a.output.notify();
                    break
                }
        }));
        d ? (d.observe(c), _.mn(a, function() {
            d.disconnect()
        })) : a.output.notify()
    };
    var Os = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 664);
        this.slotId = b;
        this.dd = c;
        this.L = d;
        this.output = $F(this);
        this.v = W(this, e);
        this.l = X(this, f);
        g && bG(this, g)
    };
    _.T(Os, Z);
    Os.prototype.j = function() {
        var a = this,
            b, c = null != (b = this.l.value) ? b : 0;
        if (0 !== (0, _.In)() || 0 < c)
            if (b = oF(document), pF(document) && b && (0 < wI(this.L, this.slotId) || !DL(this)) && b) {
                var d = on(this, 324, document, b, function() {
                    pF(document) || (d && d(), a.output.notify())
                });
                if (d) return
            }
        this.output.notify()
    };
    var DL = function(a) {
        try {
            var b = top;
            if (!b) return !0;
            var c = kt(b.document, b).y,
                d = c + a.dd.height,
                e = a.v.value;
            return e.y >= c && e.y <= d
        } catch (f) {
            return !0
        }
    };
    var Ns = function(a, b) {
        Z.call(this, a, 676);
        this.output = V(this);
        this.l = W(this, b)
    };
    _.T(Ns, Z);
    Ns.prototype.j = function() {
        var a = hi(this.l.value);
        this.output.F(a)
    };
    var Ep = function(a, b, c, d, e, f) {
        f = void 0 === f ? _.v.globalThis.IntersectionObserver : f;
        Z.call(this, a, 886);
        this.W = b;
        this.L = c;
        this.v = d;
        this.l = f;
        this.output = $F(this);
        e && bG(this, e)
    };
    _.T(Ep, Z);
    Ep.prototype.j = function() {
        this.W.some(function(a) {
            return !Bi(xi(a))
        }) ? this.output.notify() : RF(this.output, EL(this, this.v))
    };
    var EL = function(a, b) {
        return new _.v.Promise(function(c) {
            if (a.l) {
                for (var d = new a.l(function(h, k) {
                        h.some(function(l) {
                            return 0 < l.intersectionRatio
                        }) && (k.disconnect(), c())
                    }, {
                        rootMargin: b + "%"
                    }), e = _.z(a.W), f = e.next(), g = {}; !f.done; g = {
                        Ud: g.Ud
                    }, f = e.next()) {
                    f = f.value;
                    g.Ud = xi(f);
                    if (!g.Ud) return;
                    d.observe(g.Ud);
                    rI(a.L, f, function(h) {
                        return function() {
                            return void d.unobserve(h.Ud)
                        }
                    }(g))
                }
                _.mn(a, function() {
                    return void d.disconnect()
                })
            } else c()
        })
    };
    var FL = [{
            name: "Interstitial",
            format: 1,
            Nd: 5
        }, {
            name: "TopAnchor",
            format: 2,
            Nd: 2
        }, {
            name: "BottomAnchor",
            format: 3,
            Nd: 3
        }, {
            name: "LeftSideRail",
            format: 4,
            Nd: 8
        }, {
            name: "RightSideRail",
            format: 5,
            Nd: 9
        }],
        GL = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 789);
            this.V = b;
            this.googletag = c;
            this.v = d;
            this.l = e;
            this.T = f;
            this.C = g;
            this.output = V(this)
        };
    _.T(GL, Z);
    GL.prototype.j = function() {
        var a = this;
        FL.filter(function(b) {
            return (new RegExp("gam" + b.name + "Demo", "i")).test(a.C)
        }).forEach(function(b) {
            var c = b.name;
            b = b.Nd;
            var d, e;
            null == (d = window.console) || null == (e = d.warn) || e.call(d, "GPT - Demo " + c + " ENABLED");
            c = new mL(a.context, a.V, "/22639388115/example/" + c.toLowerCase(), b, !1, a.googletag.pubads(), function(f) {
                return void a.googletag.display(f)
            }, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, a.googletag.cmd, a.l.j, a.l, a.v, a.T, !1);
            _.S(a, c);
            Kj(c)
        })
    };
    var HL = function(a, b, c) {
        Z.call(this, a, 1163);
        _.G(Xs);
        this.l = W(this, b);
        c && bG(this, c)
    };
    _.T(HL, Z);
    HL.prototype.j = function() {
        this.l.value.lj();
        this.l.value.za()
    };
    var Zs = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 682);
        this.L = b;
        this.format = c;
        this.slotId = d;
        this.B = e;
        this.v = V(this);
        this.l = X(this, f);
        this.C = W(this, g);
        this.O = W(this, h);
        this.G = X(this, k);
        this.K = W(this, l)
    };
    _.T(Zs, Z);
    Zs.prototype.j = function() {
        var a = this,
            b;
        if (null != (b = this.l.value) && _.L(b, 12, !1)) {
            b = this.G.value.lk;
            var c = _.cp(this.L, this.slotId),
                d = this.O.value,
                e = this.C.value;
            _.Ki(e, {
                "max-height": "30vh",
                overflow: "hidden"
            });
            if (IL) IL.jj(e, this.K.value);
            else {
                IL = new b(this.context, this.format, e, this.B, d, this.L, this.slotId);
                b = {};
                d = _.z(Uh(this.l.value, $x, 13));
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, b[_.sj(f, 1)] = _.sj(f, 2);
                IL.kj(b);
                _.G(Xs) ? (IL.gj(), this.v.F(IL)) : IL.za();
                qI(this.L, this.slotId, function() {
                    IL && (IL.xa(), IL = null);
                    c && _.uI(a.L, a.slotId)
                })
            }
            _.mn(this, function() {
                return _.Yy(e)
            })
        }
    };
    var IL = null;
    var Ys = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 1155);
        this.L = b;
        this.format = c;
        this.slotId = d;
        this.B = e;
        this.Uf = f;
        this.v = g;
        this.G = h;
        this.C = k;
        this.K = l;
        this.l = X(this, f)
    };
    _.T(Ys, Z);
    Ys.prototype.j = function() {
        var a;
        if (null != (a = this.l.value) && null != Il(a, 12)) {
            a = new Bj;
            _.S(this, a);
            var b, c = (null == (b = this.l.value) ? 0 : _.L(b, 15)) ? M(a, new Gp(this.context, this.slotId, Hp, function(d) {
                d = d.detail.data;
                try {
                    var e = JSON.parse(d);
                    return "floating" === e.type && "loaded" === e.message
                } catch (f) {}
                return !1
            })).output : void 0;
            b = new Zs(this.context, this.L, this.format, this.slotId, this.B, this.Uf, this.v, this.G, this.C, this.K);
            M(a, b);
            b = new HL(this.context, b.v, c);
            M(a, b);
            Kj(a)
        }
    };
    var Np = function(a, b, c) {
        Z.call(this, a, 1150);
        this.B = b;
        this.output = $F(this);
        bG(this, c)
    };
    _.T(Np, Z);
    Np.prototype.j = function() {
        var a = this;
        this.B.location.hash = "goog_game_inter";
        _.mn(this, function() {
            "goog_game_inter" === a.B.location.hash && (a.B.location.hash = "")
        });
        RF(this.output, new _.v.Promise(function(b) {
            return void on(a, a.id, a.B, "hashchange", function(c) {
                hv(c.oldURL, "#goog_game_inter") && b()
            })
        }))
    };
    var JL = function(a, b) {
            this.serviceName = b;
            this.slot = a.j
        },
        KL = function(a, b) {
            JL.call(this, a, b);
            this.isEmpty = !1;
            this.slotContentChanged = !0;
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.labelIds = this.creativeTemplateId = this.creativeId = this.campaignId = this.advertiserId = this.size = null;
            this.isBackfill = !1;
            this.companyIds = this.yieldGroupIds = null
        };
    _.T(KL, JL);
    var LL = function() {
        JL.apply(this, arguments)
    };
    _.T(LL, JL);
    var ML = function(a, b, c) {
        JL.call(this, a, b);
        this.inViewPercentage = c
    };
    _.T(ML, JL);
    var NL = function() {
        JL.apply(this, arguments)
    };
    _.T(NL, JL);
    var OL = function() {
        JL.apply(this, arguments)
    };
    _.T(OL, JL);
    var PL = function() {
        JL.apply(this, arguments)
    };
    _.T(PL, JL);
    var QL = function() {
        JL.apply(this, arguments)
    };
    _.T(QL, JL);
    var RL = function(a, b, c, d) {
        JL.call(this, a, b);
        this.makeRewardedVisible = c;
        this.payload = d
    };
    _.T(RL, JL);
    var SL = function(a, b, c) {
        JL.call(this, a, b);
        this.payload = c
    };
    _.T(SL, JL);
    var TL = function() {
        JL.apply(this, arguments)
    };
    _.T(TL, JL);
    var UL = function(a, b, c) {
        JL.call(this, a, b);
        this.makeGameManualInterstitialVisible = c
    };
    _.T(UL, JL);
    var VL = function() {
        JL.apply(this, arguments)
    };
    _.T(VL, JL);
    var Op = function(a, b, c, d, e, f) {
        Z.call(this, a, 1151);
        this.slotId = b;
        this.ra = c;
        bG(this, d);
        a = [e];
        f && a.push(f);
        f = new SF(a, !0);
        VF(this.A, f)
    };
    _.T(Op, Z);
    Op.prototype.j = function() {
        Cr(this.ra, "gameManualInterstitialSlotClosed", 1148, new VL(this.slotId, "publisher_ads"))
    };
    var Lp = function(a, b, c, d) {
        Z.call(this, a, 1149);
        this.slotId = b;
        this.ra = c;
        this.output = $F(this);
        bG(this, d)
    };
    _.T(Lp, Z);
    Lp.prototype.j = function() {
        var a = new _.cg,
            b = a.promise;
        Cr(this.ra, "gameManualInterstitialSlotReady", 1147, new UL(this.slotId, "publisher_ads", a.resolve));
        0 < _.Uf(CB) ? RF(this.output, b.then(function() {
            return Bz(_.Uf(CB))
        })) : RF(this.output, b)
    };
    var Kp = function(a, b, c) {
        c = void 0 === c ? WL : c;
        Z.call(this, a, 1158);
        this.l = c;
        this.v = 1E3 * _.Uf(Jp);
        this.output = $F(this);
        bG(this, b)
    };
    _.T(Kp, Z);
    Kp.prototype.j = function() {
        var a = this;
        this.l.Ze++ ? RF(this.output, Bz(this.v * (this.l.Ze - 2) + (this.v - (Date.now() - this.l.fg))).then(function() {
            a.l.fg = Date.now();
            a.l.Ze--
        })) : (this.l.fg = Date.now(), Bz(this.v).then(function() {
            return void a.l.Ze--
        }), this.output.notify())
    };
    var WL = {
        Ze: 0,
        fg: Date.now()
    };
    var XL = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        YL = {
            width: "100%",
            height: "100%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        Mp = function(a, b, c, d, e) {
            Z.call(this, a, 1150);
            this.B = b;
            this.l = W(this, c);
            this.C = W(this, d);
            bG(this, e);
            this.v = new _.nG(this.B)
        };
    _.T(Mp, Z);
    Mp.prototype.j = function() {
        var a = 0 === (0, _.In)() ? "rgba(1,1,1,0.5)" : "white";
        _.Ki(this.l.value, _.A(Object, "assign").call(Object, {
            position: "absolute"
        }, 0 === (0, _.In)() ? YL : XL));
        _.Ki(this.C.value, _.A(Object, "assign").call(Object, {
            "background-color": a,
            opacity: "1",
            position: "fixed",
            margin: "0",
            padding: "0",
            "z-index": "2147483647",
            display: "block"
        }, XL));
        _.mn(this, _.AG(this.B.document, this.B));
        a = {};
        az(this.l.value).postMessage(JSON.stringify((a.googMsgType = "sth", a.msg_type = "i-view", a)), "*");
        if (this.B === this.B.top) {
            var b = _.pG(this.v, 2147483646);
            _.tG(b);
            _.mn(this, function() {
                return void _.uG(b)
            })
        }
    };
    var ZL = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 683);
        this.slotId = b;
        this.O = c;
        this.l = d;
        this.v = V(this);
        this.C = W(this, e);
        this.U = W(this, f);
        this.G = X(this, g);
        this.K = X(this, h)
    };
    _.T(ZL, Z);
    ZL.prototype.j = function() {
        var a = this,
            b = this.U.value,
            c = this.C.value,
            d = this.K.value.Fk,
            e = new _.LG(this.context),
            f = null != Sh(this.l, 14) ? 60 * Br(this.l, 14) : 604800;
        b = new d(window, c, b, e, this.O, $L(this), new _.v.Set(Rd(this.l, 15, Jc)), jL(this.slotId), function() {
            return void a.xa()
        }, f, this.G.value);
        b.K();
        _.S(this, b);
        this.v.F(b)
    };
    var $L = function(a) {
        var b = {};
        a = _.z(Uh(a.l, $x, 13));
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[_.sj(c, 1)] = _.sj(c, 2);
        return b
    };
    var $s = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1141);
        this.slotId = b;
        this.G = c;
        this.v = e;
        this.K = f;
        this.ub = g;
        this.C = h;
        this.output = V(this);
        this.l = X(this, d)
    };
    _.T($s, Z);
    $s.prototype.j = function() {
        var a = this;
        if (this.l.value) {
            var b = new Bj;
            _.S(this, b);
            var c = M(b, new ZL(this.context, this.slotId, this.G, this.l.value, this.v, this.K, this.ub, this.C));
            _.mn(c, function() {
                return void a.xa()
            });
            this.output.Ka(c.v.promise.then(function() {
                return !0
            }));
            Kj(b)
        } else this.output.F(!1)
    };
    var aM = function(a) {
        this.module = a
    };
    aM.prototype.toString = function() {
        return String(this.module)
    };
    _.bM = new aM(2);
    _.cM = new aM(5);
    _.dM = new aM(6);
    var Ts = function(a, b, c, d, e, f) {
        Z.call(this, a, 846);
        this.C = b;
        this.format = c;
        this.output = V(this);
        this.l = X(this, d);
        this.v = X(this, e);
        f && bG(this, f)
    };
    _.T(Ts, Z);
    Ts.prototype.j = function() {
        var a, b = (2 === this.format || 3 === this.format) && !(null == (a = this.l.value) || !_.L(a, 12, !1));
        a = 5 === this.format && this.v.value;
        b || a ? this.output.Ka(this.C.load(_.bM)) : this.output.aa()
    };
    var eM = function(a, b, c, d, e) {
        Z.call(this, a, 905);
        this.P = b;
        this.l = c;
        this.output = $F(this);
        this.v = W(this, d);
        bG(this, e)
    };
    _.T(eM, Z);
    eM.prototype.j = function() {
        for (var a = _.z(this.v.value), b = a.next(); !b.done; b = a.next()) {
            var c = void 0;
            b = null == (c = this.P.R[b.value.getDomId()]) ? void 0 : Fs(c);
            if (2 === b || 3 === b || 5 === b) {
                this.l.load(_.bM);
                return
            }
        }
        this.output.notify()
    };
    var fM = function(a, b, c, d, e, f) {
        Z.call(this, a, 696);
        this.slotId = b;
        this.ra = c;
        bG(this, d);
        dG(this, [e, f])
    };
    _.T(fM, Z);
    fM.prototype.j = function() {
        Cr(this.ra, "rewardedSlotClosed", 703, new TL(this.slotId, "publisher_ads"))
    };
    var gM = function(a, b, c, d, e) {
        Z.call(this, a, 694);
        this.slotId = b;
        this.ra = c;
        bG(this, d);
        this.l = X(this, e)
    };
    _.T(gM, Z);
    gM.prototype.j = function() {
        var a, b = null == (a = this.l.value) ? void 0 : a.payload;
        Cr(this.ra, "rewardedSlotGranted", 702, new SL(this.slotId, "publisher_ads", null != b ? b : null))
    };
    var hM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        iM = function(a, b, c, d, e, f) {
            Z.call(this, a, 693);
            this.B = b;
            this.G = f;
            this.output = $F(this);
            this.v = W(this, c);
            this.C = W(this, d);
            bG(this, e);
            this.l = new _.nG(this.B)
        };
    _.T(iM, Z);
    iM.prototype.j = function() {
        var a = this;
        if (!this.G.Bb) {
            var b = 0 === (0, _.In)() ? "rgba(1,1,1,0.5)" : "white";
            _.Ki(this.C.value, _.A(Object, "assign").call(Object, {
                "background-color": b,
                opacity: "1",
                position: "fixed",
                margin: "0",
                padding: "0",
                "z-index": "2147483647",
                display: "block"
            }, hM));
            _.mn(this, _.AG(this.B.document, this.B));
            az(this.v.value).postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            if (this.B === this.B.top) {
                this.B.location.hash = "goog_rewarded";
                var c = _.pG(this.l, 2147483646);
                _.tG(c);
                _.mn(this, function() {
                    _.uG(c);
                    "goog_rewarded" === a.B.location.hash && (a.B.location.hash = "")
                })
            }
            this.output.notify()
        }
    };
    var jM = function(a, b, c, d) {
        Z.call(this, a, 695);
        this.B = b;
        this.l = W(this, c);
        bG(this, d)
    };
    _.T(jM, Z);
    jM.prototype.j = function() {
        if (this.B === this.B.top) var a = az(this.l.value),
            b = on(this, 503, this.B, "hashchange", function(c) {
                hv(c.oldURL, "#goog_rewarded") && (a.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "back_button"
                }), "*"), b())
            })
    };
    var kM = function(a, b, c, d) {
        Z.call(this, a, 692);
        this.slotId = b;
        this.ra = c;
        this.output = $F(this);
        this.l = W(this, d)
    };
    _.T(kM, Z);
    kM.prototype.j = function() {
        var a = this.l.value,
            b = new _.cg,
            c = b.promise,
            d;
        Cr(this.ra, "rewardedSlotReady", 701, new RL(this.slotId, "publisher_ads", b.resolve, null != (d = a.payload) ? d : null));
        RF(this.output, c)
    };
    var lM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        mM = {
            width: "60%",
            height: "60%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        nM = function(a, b, c, d, e) {
            Z.call(this, a, 691);
            this.C = V(this);
            this.v = $F(this);
            this.G = W(this, c);
            this.l = dG(this, [d, e])
        };
    _.T(nM, Z);
    nM.prototype.j = function() {
        if ("ha_before_make_visible" === this.l.value.message) this.v.notify();
        else {
            var a = _.G(BB) ? lM : mM;
            _.Ki(this.G.value, _.A(Object, "assign").call(Object, {
                position: "absolute"
            }, 0 === (0, _.In)() ? a : lM));
            this.C.F(this.l.value)
        }
    };
    var at = function(a, b, c, d, e, f) {
        Bj.call(this);
        var g = Rp(b, "granted", a);
        M(this, g);
        var h = Rp(b, "prefetched", a);
        M(this, h);
        var k = Rp(b, "closed", a);
        M(this, k);
        var l = Rp(b, "ha_before_make_visible", a);
        M(this, l);
        var m = new nM(a, b, e, h.output, l.output);
        M(this, m);
        h = new kM(a, b, c, m.C);
        M(this, h);
        f = new iM(a, d, e, f, h.output, m.v);
        M(this, f);
        M(this, new jM(a, d, e, f.output));
        M(this, new gM(a, b, c, h.output, g.output));
        M(this, new fM(a, b, c, h.output, k.output, l.output))
    };
    _.T(at, Bj);
    var ss = function(a, b) {
        Z.call(this, a, 1031);
        this.B = b
    };
    _.T(ss, Z);
    ss.prototype.j = function() {
        this.B === this.B.top && Dk(this.B)
    };
    var qs = function(a, b, c) {
        c = void 0 === c ? gg : c;
        Z.call(this, a, 1063);
        this.B = b;
        this.v = c;
        this.l = V(this)
    };
    _.T(qs, Z);
    qs.prototype.j = function() {
        var a = this;
        if (_.G(qB) && hg(this.B)) {
            var b = null,
                c = 0,
                d = yh(this.context, this.id, function() {
                    var f, g, h, k;
                    return _.kb(function(l) {
                        switch (l.j) {
                            case 1:
                                return f = a.v(a.B), g = "0", l.m = 2, l.yield(f, 4);
                            case 4:
                                g = null != (h = l.o) ? h : "0";
                                1E4 < g.length && (Ch(a.context, a.id, new ym("ML:" + g.length)), g = "0");
                                l.j = 3;
                                l.m = 0;
                                break;
                            case 2:
                                k = ob(l), Ch(a.context, a.id, k);
                            case 3:
                                b = g, c = _.Mg(a.B) + 3E5, l.j = 0
                        }
                    })
                });
            var e = (_.F = d(), _.A(_.F, "finally")).call(_.F, function() {
                e = void 0
            });
            this.l.F(function() {
                var f, g;
                return _.kb(function(h) {
                    if (1 == h.j) {
                        f = _.Mg(a.B) >= c;
                        g = null === b || "0" === b;
                        if (!f && !g) {
                            h.j = 2;
                            return
                        }
                        e || (e = (_.F = d(), _.A(_.F, "finally")).call(_.F, function() {
                            e = void 0
                        }));
                        return h.yield(e, 2)
                    }
                    return h.return(b)
                })
            })
        } else this.l.F(function() {
            return _.v.Promise.resolve("")
        })
    };
    qs.prototype.m = function() {
        this.l.F(function() {
            return _.v.Promise.resolve("")
        })
    };
    var oM = function(a, b) {
        Z.call(this, a, 1091);
        this.output = V(this);
        b && (this.l = X(this, b))
    };
    _.T(oM, Z);
    oM.prototype.j = function() {
        var a;
        null != (a = this.l) && a.value ? this.output.Ka(this.l.value()) : this.output.F("")
    };
    oM.prototype.m = function() {
        this.output.F("")
    };
    var ns = vf(qf({
        Gm: "disablePersonalization"
    }));
    var jq = function(a, b, c) {
        Z.call(this, a, 1122);
        this.V = b;
        this.l = c;
        $F(this, c)
    };
    _.T(jq, Z);
    jq.prototype.j = function() {
        var a = this,
            b = _.G(jB) ? vh(this.context) : void 0;
        RF(this.l, new _.v.Promise(function(c) {
            return void rF(function() {
                c();
                null == b || b()
            }, a.V)
        }))
    };
    var ts = function(a, b, c) {
        Z.call(this, a, 1107);
        this.B = b;
        this.l = c;
        V(this, c)
    };
    _.T(ts, Z);
    ts.prototype.j = function() {
        var a = Nf(this.B.isSecureContext, this.B.navigator, this.B.document),
            b = Of(this.B.isSecureContext, this.B.document),
            c = Pf(this.B.isSecureContext, this.B, this.B.document),
            d = !(!this.B.isSecureContext || !Jf("attribution-reporting", this.B.document)),
            e = 0;
        a && (e |= 1);
        b && (e |= 4);
        c && (e |= 8);
        d && (e |= 2);
        this.l.Ca(0 === e ? null : e)
    };
    ts.prototype.m = function() {
        this.l.aa()
    };
    var pM = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1118, _.Uf(IB));
        this.C = b;
        this.G = d;
        this.R = e;
        V(this, d);
        c && (this.K = X(this, c));
        f && (this.v = W(this, f));
        g && (this.l = aG(this, g))
    };
    _.T(pM, Z);
    pM.prototype.j = function() {
        var a = new EF;
        a = _.ce(a, 1, _.Nc(this.C), 0);
        if (this.l)
            if (this.l.value) {
                var b = _.ih(a, 3, this.l.value.label);
                _.H(b, 4, this.l.value.status)
            } else this.l.Bb() || _.H(a, 4, 5);
        if (this.C & 1) {
            var c, d;
            b = qM(this, null != (d = null == (c = this.K) ? void 0 : c.value) ? d : null);
            _.kh(a, 2, b)
        }
        this.G.F(a)
    };
    var qM = function(a, b) {
            switch (_.Uf(us)) {
                case 1:
                    var c = 1;
                    break;
                case 2:
                    c = 2;
                    break;
                case 3:
                    c = 3;
                    break;
                default:
                    c = 0
            }
            var d = DF(new CF, c);
            null == b || b.forEach(function(g, h) {
                var k = Zd(d, 2, BF);
                var l = k.set,
                    m = new BF;
                g = _.be(m, 1, g, Mc);
                l.call(k, h, g)
            });
            var e;
            if ((null == (e = a.v) ? 0 : e.value) && a.R) {
                var f;
                b = _.z(null == (f = a.v) ? void 0 : f.value);
                for (f = b.next(); !f.done; f = b.next()) f = f.value, (c = rM(a, a.R[f.getDomId()])) && Zd(d, 3, zF).set(f.getAdUnitPath(), c)
            }
            return d
        },
        rM = function(a, b) {
            a = Fm(a.context, b);
            if (0 !== a.length) return AF(new zF, a.map(function(c) {
                return c.seller
            }))
        };
    var lq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1165);
        this.G = c;
        this.ef = d;
        this.R = e;
        this.C = f;
        this.v = g;
        this.l = X(this, b.si)
    };
    _.T(lq, Z);
    lq.prototype.j = function() {
        if (this.l.value) {
            var a = new Bj,
                b = new pM(this.context, this.l.value, this.G, this.ef.Bg, this.R, this.C, this.v);
            M(a, b);
            Kj(a)
        } else this.ef.Bg.aa()
    };
    var sM = function(a, b, c) {
        Z.call(this, a, 1206);
        this.v = b;
        this.l = V(this);
        this.X = W(this, c)
    };
    _.T(sM, Z);
    sM.prototype.j = function() {
        var a = this;
        this.v.cookieDeprecationLabel ? zf(this.X.value) ? this.l.Ka(this.v.cookieDeprecationLabel.getValue().then(function(b) {
            return {
                status: 1,
                label: b
            }
        }).catch(function(b) {
            a.I(b);
            return {
                status: 2
            }
        })) : this.l.F({
            status: 4
        }) : this.l.F({
            status: 3
        })
    };
    var tM = function(a, b, c) {
        Z.call(this, a, 873);
        this.B = b;
        this.l = W(this, c)
    };
    _.T(tM, Z);
    tM.prototype.j = function() {
        var a = this.context,
            b = this.l.value,
            c = this.B;
        !Am()._pubconsole_disable_ && (b = Df("google_pubconsole", b, c)) && (b = b.split("|"), "1" !== b[0] && "0" !== b[0] || Vm(a, c))
    };
    var uM = function() {
        this.resources = {}
    };
    var Hq = "3rd party ad content";
    var vM = function(a, b, c) {
        _.U.call(this);
        this.context = a;
        this.lb = b;
        this.m = c;
        a = c.slotId;
        b = c.size;
        this.j = "height" === c.mk ? "fluid" : [b.width, b.height];
        this.zd = Ei(a);
        this.Bd = Hq
    };
    _.T(vM, _.U);
    vM.prototype.render = function() {
        var a = this.lb,
            b = this.m,
            c = b.slotId,
            d = b.P.R,
            e = b.size,
            f = b.Qf,
            g = b.isBackfill,
            h = b.ae;
        og(b.Li, _.Vy(b.V), null != f ? f : "", !1);
        Ar(_.Ff(Ah), "5", Br(d[c.getDomId()], 20));
        Cr(c, Dr, 801, {
            nh: 0 === a.kind ? a.yb : "",
            isBackfill: g
        });
        a = this.l();
        h && a && a.setAttribute("data-google-container-id", h);
        Cr(c, Er, 825, {
            size: e,
            isEmpty: !1
        });
        return a
    };
    vM.prototype.loaded = function(a) {
        var b = this.m,
            c = b.slotId,
            d = b.ra;
        b = b.P.R;
        Cr(c, xs, 844);
        a && a.setAttribute("data-load-complete", !0);
        Cr(d, "slotOnload", 710, new NL(c, "publisher_ads"));
        Ar(_.Ff(Ah), "6", Br(b[c.getDomId()], 20))
    };
    var wM = function(a) {
        a = a.lb;
        a = 0 === a.kind ? a.yb : "";
        var b = "";
        b = void 0 === b ? "" : b;
        if (a) {
            var c = a.toLowerCase();
            a = -1 < c.indexOf("<!doctype") || -1 < c.indexOf("<html") || _.G(nC) ? a : "<!doctype html><html><head>" + b + "</head><body>" + a + "</body></html>"
        }
        return a
    };
    vM.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.m.Li.removeAttribute("data-google-query-id")
    };
    vM.prototype.H = function(a) {
        var b = this,
            c = xM(this, function() {
                return void b.loaded(c.j)
            }, a);
        _.mn(this, function() {
            100 != c.status && (c.dg() && (rH(c.m), c.v = 0), window.clearTimeout(c.ta), c.ta = -1, c.I = 3, c.o && (c.o.xa(), c.o = null), _.of(window, "resize", c.C), _.of(window, "scroll", c.C), c.l && c.j && c.l == _.Zy(c.j) && c.l.removeChild(c.j), c.j = null, c.l = null, c.status = 100)
        });
        return c
    };
    var xM = function(a, b, c) {
        var d = a.m,
            e = d.Ei,
            f = d.isBackfill,
            g = d.Gk,
            h = d.ae,
            k = d.Ae,
            l = d.yf,
            m = d.Ta,
            n = Array.isArray(a.j) ? new _.ki(Number(a.j[0]), Number(a.j[1])) : 1;
        return new zH({
            yg: d.hh,
            zd: a.zd,
            Bd: a.Bd,
            content: wM(a),
            size: n,
            ak: !!g,
            gi: b,
            Fi: null != e ? e : void 0,
            permissions: {
                ye: null != Il(c, 1) ? !!_.L(c, 1) : !f,
                ze: null != Il(c, 2) ? !!_.L(c, 2) : !1
            },
            Cd: !!Am().fifWin,
            Dl: TJ ? TJ : TJ = yl(),
            Dj: Cl(),
            hostpageLibraryTokens: m.hostpageLibraryTokens,
            ob: function(p, r) {
                return void Ch(a.context, p, r)
            },
            uniqueId: h,
            Di: UG(),
            Ae: null != k ? k : void 0,
            pb: void 0,
            yf: null != l ? l : void 0
        })
    };
    var yM = function() {
        vM.apply(this, arguments)
    };
    _.T(yM, vM);
    yM.prototype.l = function() {
        var a = this.m,
            b = a.P,
            c = b.Z;
        a = b.R[a.slotId.getDomId()];
        b = new Dl;
        c = Jl([b, c.nc(), null == a ? void 0 : a.nc()]);
        return vM.prototype.H.call(this, c).j
    };
    yM.prototype.A = function() {
        return !1
    };
    var Ls = function(a, b, c, d, e, f) {
        Z.call(this, a, 669);
        this.Z = b;
        this.R = c;
        this.output = V(this);
        this.v = X(this, d);
        this.l = W(this, e);
        f && (this.C = W(this, f))
    };
    _.T(Ls, Z);
    Ls.prototype.j = function() {
        var a;
        if (null == (a = this.C) ? 0 : a.value) this.output.F(!0);
        else {
            var b;
            a = !(null == (b = this.v.value) || !_.R(b, 1)) && (_.L(this.R, 12) || Il(this.Z, 13)) || this.l.value;
            this.output.F(!!a)
        }
    };
    var zM = function(a, b, c, d) {
        Z.call(this, a, 833);
        this.l = b;
        this.B = c;
        this.output = $F(this);
        bG(this, d)
    };
    _.T(zM, Z);
    zM.prototype.j = function() {
        var a = this.l,
            b = this.B,
            c = UG();
        c = {
            version: TJ ? TJ : TJ = yl(),
            mf: c
        };
        c = GH.Pk(c);
        var d = mH(b);
        c = d ? Ne(c, new _.v.Map([
            ["n", String(d)]
        ])) : c;
        d = Wf(Al);
        for (var e = new _.v.Map, f = 0; f < d.length; f += 2) e.set(d[f], d[f + 1]);
        c = Ne(c, e);
        var g;
        a.resources[c.toString()] || (null == (g = Am()) ? 0 : g.fifWin) || (a.resources[c.toString()] = 1, b = b.document, a = _.af("IFRAME"), a.src = _.gb(c).toString(), a.style.visibility = "hidden", a.style.display = "none", b = b.getElementsByTagName("script"), b.length && (b = b[b.length - 1], b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)));
        this.output.notify()
    };
    var AM = function(a, b, c) {
        Z.call(this, a, 1135);
        this.v = b;
        this.C = c;
        this.l = V(this)
    };
    _.T(AM, Z);
    AM.prototype.j = function() {
        for (var a = new Ex, b = new _.v.Map, c = new _.v.Set, d = _.z(this.v), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (null != _.sj(f, 1)) {
                e = new _.v.Set;
                b.set(_.R(f, 1).toString(), e);
                f = _.z(Uh(f, Cx, 2));
                for (var g = f.next(); !g.done; g = f.next()) {
                    g = g.value;
                    var h = _.R(g, 1);
                    e.add(h);
                    c.has(h) || yj(a, 2, Cx, g);
                    c.add(h)
                }
            }
        }
        this.C.F(b);
        this.l.F(a)
    };
    var BM = function(a, b, c) {
        Z.call(this, a, 1051);
        this.v = b;
        this.l = X(this, c)
    };
    _.T(BM, Z);
    BM.prototype.j = function() {
        var a = this;
        this.l.value && Wj(this.l.value, function(b, c) {
            Ch(a.context, b, c);
            var d, e;
            null == (d = a.v) || null == (e = d.error) || e.call(d, c)
        })
    };
    var CM = function(a, b) {
        Z.call(this, a, 1040);
        this.l = V(this);
        this.v = X(this, b)
    };
    _.T(CM, Z);
    CM.prototype.j = function() {
        var a = this.v.value;
        a ? (a = Uh(a, Cx, 2), this.l.F(a.map(function(b) {
            var c = Ww(b, Dx);
            b = _.R(b, 1);
            c = c && (_.A(c, "startsWith").call(c, location.protocol) || _.A(c, "startsWith").call(c, "data:") && 80 >= c.length) ? Le(jj(c)) : void 0;
            return {
                pe: b,
                url: c
            }
        }))) : this.l.F([])
    };
    var DM = function(a, b, c, d, e) {
        Z.call(this, a, 813);
        this.C = b;
        this.l = d;
        this.ub = e;
        c && (this.G = X(this, c));
        e && (this.v = X(this, e))
    };
    _.T(DM, Z);
    DM.prototype.j = function() {
        var a = this,
            b, c, d = null != (c = this.C) ? c : null == (b = this.G) ? void 0 : b.value,
            e, f;
        b = null != (f = this.l) ? f : null == (e = this.v) ? void 0 : e.value;
        if (null != d && d.length && b)
            for (d = _.z(d), e = d.next(); !e.done; e = d.next()) f = e.value, e = f.pe, (f = f.url) && _.S(this, ak(e, f, b, this.ub, function(g, h) {
                Ch(a.context, g, h);
                var k, l;
                null == (l = (k = console).error) || l.call(k, h)
            }))
    };
    var EM = function(a, b, c) {
        Z.call(this, a, 1045);
        this.l = b;
        this.ub = c
    };
    _.T(EM, Z);
    EM.prototype.j = function() {
        var a = new Bj;
        _.S(this, a);
        var b = new CM(this.context, this.l);
        M(a, b);
        b = new DM(this.context, void 0, b.l, void 0, this.ub);
        M(a, b);
        Kj(a)
    };
    var Ds = function(a, b, c, d) {
        Z.call(this, a, 706);
        this.B = b;
        this.output = null != d ? d : V(this);
        this.l = W(this, c)
    };
    _.T(Ds, Z);
    Ds.prototype.j = function() {
        this.output.Ca(Af(this.l.value, this.B))
    };
    var FM = function(a, b, c, d) {
        Z.call(this, a, 1154);
        this.kb = c;
        this.l = d;
        this.v = X(this, b)
    };
    _.T(FM, Z);
    FM.prototype.j = function() {
        if (this.v.value) {
            var a = new Bj;
            _.S(this, a);
            var b = new Ds(this.context, window, this.kb, this.l.ub);
            M(a, b);
            b = new AM(this.context, this.v.value, this.l.rg);
            M(a, b);
            M(a, new EM(this.context, b.l, this.l.ub));
            b = new BM(this.context, console, this.l.ub);
            M(a, b);
            Kj(a)
        } else this.l.rg.aa(), this.l.ub.aa()
    };
    var GM = function(a, b, c, d, e, f) {
        Z.call(this, a, 1096);
        this.B = b;
        this.X = c;
        this.l = d;
        this.oc = e;
        this.v = X(this, f)
    };
    _.T(GM, Z);
    GM.prototype.j = function() {
        var a, b = null == (a = this.v.value) ? void 0 : a.qj;
        b && b(this.l, this.X, this.B, this.oc, this.context.Qa)
    };
    var HM = function(a, b) {
        Z.call(this, a, 1095);
        this.l = b;
        this.output = V(this)
    };
    _.T(HM, Z);
    HM.prototype.j = function() {
        this.output.Ka(this.l.load(_.cM))
    };
    var IM = function(a, b, c, d, e) {
        Z.call(this, a, 1090);
        this.l = b;
        this.oc = c;
        this.v = W(this, d);
        this.C = X(this, e)
    };
    _.T(IM, Z);
    IM.prototype.j = function() {
        var a = this.C.value,
            b;
        if (a && null != (b = _.Qh(a, _.Tx, 1)) && _.Ux(b).length) {
            b = new Bj;
            _.S(this, b);
            var c = new HM(this.context, this.l);
            M(b, c);
            a = new GM(this.context, window, this.v.value, a, this.oc, c.output);
            M(b, a);
            Kj(b)
        }
    };
    var Mq = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1205);
        this.B = b;
        this.K = c;
        this.G = W(this, d);
        this.v = W(this, e);
        this.l = W(this, f);
        this.C = W(this, g)
    };
    _.T(Mq, Z);
    Mq.prototype.j = function() {
        var a = this.G.value;
        a = new a.Pl(this.v.value, this.B, this.l.value, this.K, this.C.value, new _.LG(this.context), new a.kk(this.B));
        _.S(this, a);
        _.S(this, a.K)
    };
    var Lq = function(a, b) {
        Z.call(this, a, 1204);
        this.l = b;
        this.output = V(this)
    };
    _.T(Lq, Z);
    Lq.prototype.j = function() {
        this.output.Ka(this.l.load(_.dM))
    };
    var Ur = function(a, b) {
        var c = this,
            d = [],
            e = [];
        this.addSize = yh(a, 88, function(f, g) {
            var h;
            if (h = qm(f)) h = g, h = pm(h) || Array.isArray(h) && h.every(pm);
            if (h) {
                if (_.G(TB)) {
                    var k = Pq(g);
                    h = k.size;
                    k.Fg && (g = Mk([f, g]), g = g.substring(1, g.length - 1), P(b, new Lk(151, ["SizeMappingBuilder.addSize", g])), g = h)
                }
                d.push([f, g])
            } else e.push([f, g]), P(b, Nk("SizeMappingBuilder.addSize", [f, g]));
            return c
        });
        this.build = yh(a, 89, function() {
            if (e.length) return P(b, OI(Gl(e))), null;
            sa(d);
            return d
        })
    };
    var JM = function(a, b, c, d, e, f) {
        f = void 0 === f ? ck : f;
        Z.call(this, a, 939);
        this.v = b;
        this.B = c;
        this.X = d;
        this.l = f;
        this.output = $F(this);
        bG(this, e)
    };
    _.T(JM, Z);
    JM.prototype.j = function() {
        var a = this.l,
            b = this.B,
            c = new uq;
        var d = new tq;
        d = _.ih(d, 1, String(this.v));
        c = _.kh(c, 5, d);
        c = _.H(c, 4, 1);
        c = _.H(c, 2, 2);
        c = _.ih(c, 3, this.context.zb || this.context.fb);
        c = _.oh(c, 6, zf(this.X));
        a.call(this, b, c);
        this.output.notify()
    };
    var Rs = function(a, b, c, d, e) {
        Z.call(this, a, 807);
        this.B = b;
        this.output = $F(this);
        this.l = X(this, c);
        this.v = W(this, d);
        e && bG(this, e)
    };
    _.T(Rs, Z);
    Rs.prototype.j = function() {
        var a = this.l.value;
        if (a && !this.v.value) {
            var b = Cz(this.B);
            aI(new $H(b, a)) || this.I(new ym("Cannot create top window frame"))
        }
        this.output.notify()
    };
    var KM = function(a, b) {
        Z.call(this, a, 820);
        this.B = b;
        this.output = V(this)
    };
    _.T(KM, Z);
    KM.prototype.j = function() {
        var a = this;
        this.output.Ka(gk(this.B).then(function(b) {
            var c = b.te,
                d = b.status;
            Ri("gpt_etu", function(e) {
                Xi(e, a.context);
                Yi(e, "rsn", d)
            }, c ? void 0 : 0);
            return null != c ? c : ""
        }))
    };
    var LM = function(a, b, c, d) {
        Z.call(this, a, 979);
        this.B = b;
        this.l = X(this, d);
        this.output = c
    };
    _.T(LM, Z);
    LM.prototype.j = function() {
        var a = this;
        if (_.G(YB)) this.output.aa();
        else {
            var b;
            kk(this.B, null != (b = this.l.value) ? b : !1).then(function(c) {
                a.output.F(c)
            })
        }
    };
    LM.prototype.m = function() {
        this.output.aa()
    };
    var MM = function(a, b, c, d) {
        Z.call(this, a, 1156);
        this.B = b;
        this.qe = c;
        this.l = {
            Dc: new rn
        };
        this.v = W(this, d)
    };
    _.T(MM, Z);
    MM.prototype.j = function() {
        if (zf(this.v.value)) {
            var a = new Bj;
            _.S(this, a);
            var b = new LM(this.context, this.B, this.l.Dc, this.qe);
            M(a, b);
            Kj(a)
        } else this.l.Dc.aa()
    };
    var NM = function(a, b, c) {
        Z.call(this, a, 1123);
        this.l = b;
        this.v = c;
        V(this, b);
        V(this, c)
    };
    _.T(NM, Z);
    NM.prototype.j = function() {
        _.G(WB) ? (this.l.F(!1), this.v.aa()) : (this.l.F(!0), this.v.F(10))
    };
    var OM = function(a, b, c, d, e) {
        Z.call(this, a, 978);
        this.B = b;
        this.C = c;
        this.l = e;
        V(this, e);
        this.v = X(this, d.Dc)
    };
    _.T(OM, Z);
    OM.prototype.j = function() {
        if (_.G(XB)) this.l.aa();
        else if (this.v.value) {
            var a = uk(this.v.value, this.B, new _.LG(this.context), this.C);
            this.l.Ka(a)
        } else this.l.aa()
    };
    OM.prototype.m = function() {
        this.l.aa()
    };
    var Uq = function(a, b, c, d, e) {
        Z.call(this, a, 1164);
        this.v = b;
        this.pf = c;
        this.l = e;
        this.C = W(this, d)
    };
    _.T(Uq, Z);
    Uq.prototype.j = function() {
        var a = Of(window.isSecureContext, window.document);
        if (_.G(ZB) && !a) this.l.Zc.aa(), this.l.Xd.F(!1), this.l.Yd.aa();
        else if (this.C.value) {
            a = new Bj;
            _.S(this, a);
            M(a, new OM(this.context, window, this.v, this.pf, this.l.Zc));
            var b = new NM(this.context, this.l.Xd, this.l.Yd);
            M(a, b);
            Kj(a)
        } else this.l.Zc.F(5), this.l.Xd.F(!1), this.l.Yd.F(5)
    };
    var PM = function(a, b, c) {
        Z.call(this, a, 1101);
        this.B = b;
        this.l = c
    };
    _.T(PM, Z);
    PM.prototype.j = function() {
        if (!_.G(XB)) {
            var a = this.l,
                b = hk(this.B);
            b.setTopicsCalled ? _.v.Promise.resolve() : (b.setTopicsCalled = !0, a({
                message: "goog:topics:frame:get:topics",
                skipTopicsObservation: !1
            }))
        }
    };
    var Wq = function(a, b, c, d) {
        Z.call(this, a, 1180);
        this.B = b;
        this.v = X(this, d);
        this.l = X(this, c.Dc)
    };
    _.T(Wq, Z);
    Wq.prototype.j = function() {
        if (this.v.value && this.l.value) {
            var a = new Bj;
            _.S(this, a);
            M(a, new PM(this.context, this.B, this.l.value));
            Kj(a)
        }
    };
    var er = function(a) {
        this.D = _.B(a)
    };
    _.T(er, _.E);
    var ar = function(a, b) {
        return _.ce(a, 2, null == b ? b : Zc(b), "0")
    };
    var QM = function(a) {
        this.D = _.B(a)
    };
    _.T(QM, _.E);
    var dr = Je(QM);
    QM.ca = [1];
    var RM = function(a, b, c, d) {
        Z.call(this, a, 1186);
        this.L = b;
        this.B = c;
        this.output = V(this);
        this.X = W(this, d)
    };
    _.T(RM, Z);
    RM.prototype.j = function() {
        if (!Nf(this.B.isSecureContext, this.B.navigator, this.B.document) || _.G(Gr)) this.output.aa();
        else {
            var a = this.L.Be;
            if (null !== a) this.output.F(a);
            else {
                var b = _.Ll(new _.XE(this.B), "__gpi", this.X.value);
                a = this.output;
                var c = a.F;
                b = _.Rf(b || String(this.context.pvsid)) % 63001;
                this.L.Be = b;
                c.call(a, b)
            }
        }
    };
    var SM = function(a, b, c) {
        Z.call(this, a, 1171);
        this.l = c;
        V(this, c);
        this.Eg = W(this, b)
    };
    _.T(SM, Z);
    SM.prototype.j = function() {
        this.l.F(0 === this.Eg.value.kind)
    };
    var TM = function(a, b, c) {
        Z.call(this, a, 1160);
        this.l = c;
        V(this, c);
        this.v = W(this, b)
    };
    _.T(TM, Z);
    TM.prototype.j = function() {
        var a = this;
        if (this.v.value.requestId) {
            var b = this.v.value.request;
            Ri("td_ba", function(d) {
                Xi(d, a.context);
                Yi(d, "sz", b.byteLength)
            }, 1);
            if (32768 < b.byteLength) this.l.F({
                kind: 1,
                reason: 3
            });
            else {
                var c = zb(b, 3);
                c.length ? this.l.F({
                    kind: 0,
                    signal: c,
                    requestId: this.v.value.requestId
                }) : this.l.F({
                    kind: 1,
                    reason: 5
                })
            }
        } else this.l.F({
            kind: 1,
            reason: this.v.value
        })
    };
    TM.prototype.m = function() {
        this.l.F({
            kind: 1,
            reason: 4
        })
    };
    var UM = function(a, b) {
        Z.call(this, a, 1159);
        this.output = V(this);
        this.l = b
    };
    _.T(UM, Z);
    UM.prototype.j = function() {
        var a = this;
        this.output.Ka(this.l.getInterestGroupAdAuctionData({
            seller: "https://securepubads.g.doubleclick.net"
        }).catch(function(b) {
            a.I(b);
            return 4
        }))
    };
    UM.prototype.m = function() {
        this.output.F(4)
    };
    var ir = function(a, b, c, d, e) {
        Z.call(this, a, 1177);
        this.C = b;
        this.l = d;
        this.v = e;
        V(this, d);
        V(this, e);
        this.G = W(this, c)
    };
    _.T(ir, Z);
    ir.prototype.j = function() {
        if (this.G.value) {
            var a = new Bj;
            _.S(this, a);
            var b = new UM(this.context, this.C);
            M(a, b);
            b = new TM(this.context, b.output, this.l);
            M(a, b);
            b = new SM(this.context, this.l, this.v);
            M(a, b);
            Kj(a)
        } else this.l.F({
            kind: 1,
            reason: 2
        }), this.v.F(!1)
    };
    var VM = function(a, b, c, d) {
        Z.call(this, a, 881);
        this.Da = b;
        this.sa = c;
        this.l = d;
        this.output = V(this)
    };
    _.T(VM, Z);
    VM.prototype.j = function() {
        if (4 === _.Uf(us)) {
            var a = _.Qh(this.sa, vy, 23);
            if (a) {
                var b;
                if (0 !== (null == (b = this.l) ? void 0 : b.kind)) throw new TypeError("Received remote auction config despite " + (this.l ? "invalid" : "absent") + " remarketing input.");
                this.output.F({
                    seller: "https://securepubads.g.doubleclick.net",
                    interestGroupBuyers: _.bl(this.sa, 3),
                    requestId: this.l.requestId,
                    serverResponse: xk(yk(a, 1)),
                    resolveToConfig: !_.L(this.sa, 14)
                })
            } else this.output.aa()
        } else {
            b = this.output;
            a = b.F;
            for (var c = this.sa, d = Fm(this.context, this.Da), e = !_.L(c, 14) && !0, f = {}, g = _.z(Uh(c, ty, 7)), h = g.next(); !h.done; h = g.next()) h = h.value, f[_.R(h, 1)] = JSON.parse(_.R(h, 2));
            if (g = _.Qh(c, sy, 6)) f["https://googleads.g.doubleclick.net"] = g.toJSON(), f["https://td.doubleclick.net"] = g.toJSON();
            h = {};
            g = _.z(Uh(c, uy, 11));
            for (var k = g.next(); !k.done; k = g.next()) k = k.value, h[_.R(k, 1)] = _.Rw(k, 2);
            k = {};
            0 !== _.Rw(c, 21) && (k["*"] = _.Rw(c, 21));
            var l = {};
            Br(c, 18) && (l["https://googleads.g.doubleclick.net"] = Br(c, 18), l["https://td.doubleclick.net"] = Br(c, 18));
            g = _.z(Zd(c, 24, yy));
            for (var m = g.next(); !m.done; m = g.next()) {
                var n = m.value;
                Br(n[1], 4) && (m = n[0], n = Br(n[1], 4), l[m] = n)
            }
            g = _.R(c, 1).split("/td/")[0];
            var p;
            m = null == (p = _.Qh(c, xy, 5)) ? void 0 : _.Jd(p);
            var r;
            null != m && null != (r = _.Qh(m, wy, 5)) && _.ni(r, 2);
            p = _.A(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.R(c, 1),
                trustedScoringSignalsUrl: _.R(c, 2),
                interestGroupBuyers: _.bl(c, 3),
                sellerExperimentGroupId: Br(c, 17),
                auctionSignals: JSON.parse(_.R(c, 4) || "{}"),
                sellerSignals: (null == m ? void 0 : m.toJSON()) || [],
                sellerTimeout: _.Rw(c, 15) || 50,
                perBuyerExperimentGroupIds: l,
                perBuyerSignals: f,
                perBuyerTimeouts: h,
                perBuyerCumulativeTimeouts: k
            }, e ? {
                resolveToConfig: e
            } : {});
            if (null == c ? 0 : _.L(is(c, xy, 5), 25)) p.sellerCurrency = "USD", p.perBuyerCurrencies = _.A(Object, "fromEntries").call(Object, Yd(c, 22));
            _.R(c, 28) ? p.directFromSellerSignalsHeaderAdSlot = _.R(c, 28) : _.R(c, 19) && (r = _.R(c, 19), p.directFromSellerSignals = "" !== r ? g + r : void 0);
            r = new xy;
            "0" !== Sw(is(is(c, xy, 5), wy, 5)) && (f = new wy, h = Sw(is(is(c, xy, 5), wy, 5)), f = _.ce(f, 2, Tc(h), "0"), _.kh(r, 5, f));
            is(c, xy, 5).getEscapedQemQueryId() && (f = is(c, xy, 5).getEscapedQemQueryId(), _.ih(r, 2, f));
            d = _.A(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.R(c, 1),
                sellerExperimentGroupId: Br(c, 17),
                sellerSignals: r.toJSON(),
                sellerTimeout: _.Rw(c, 15) || 50,
                interestGroupBuyers: [],
                auctionSignals: {},
                perBuyerExperimentGroupIds: {},
                perBuyerSignals: {},
                perBuyerTimeouts: {},
                perBuyerCumulativeTimeouts: {},
                componentAuctions: [p].concat(_.ch(null != d ? d : []))
            }, e ? {
                resolveToConfig: e
            } : {});
            _.R(c, 28) ? d.directFromSellerSignalsHeaderAdSlot = _.R(c, 28) : _.R(c, 19) && (c = _.R(c, 19), d.directFromSellerSignals = "" !== c ? g + c : void 0);
            a.call(b, d)
        }
    };
    VM.prototype.m = function() {
        this.output.aa()
    };
    var WM = function(a, b, c, d) {
        Z.call(this, a, 1105);
        this.adUnitPath = b;
        this.sa = c;
        this.l = d
    };
    _.T(WM, Z);
    WM.prototype.j = function() {
        var a = _.bl(this.sa, 3),
            b = Yq(this.adUnitPath);
        if (_.L(this.sa, 20)) {
            a = mr(a);
            var c = this.l.getItem(b),
                d = c ? Uh(dr(c), er, 1) : [];
            c = new QM;
            a = br(d, a);
            a = _.gl(c, 1, a);
            this.l.setItem(b, tk(a))
        } else _.G(dC) && this.l.removeItem(b)
    };
    var XM = function(a, b, c, d) {
        Z.call(this, a, 1174);
        var e = this;
        this.V = b;
        this.directFromSellerSignals = c;
        this.l = _.Vu(function() {
            var f = (_.F = [].concat(_.ch(e.V.head.querySelectorAll("script[type=webbundle]"))), _.A(_.F, "find")).call(_.F, function(h) {
                var k;
                return null == (k = h.textContent) ? void 0 : k.match(e.directFromSellerSignals)
            });
            if (null != f && f.textContent) {
                var g = JSON.parse(f.textContent);
                g.resources = g.resources.filter(function(h) {
                    return !h.match(e.directFromSellerSignals)
                });
                f.remove();
                g.resources.length && (f = e.V.createElement("script"), f.type = "webbundle", fb(f, Qe(g)), e.V.head.appendChild(f))
            }
        });
        bG(this, d);
        _.mn(this, function() {
            return setTimeout(function() {
                return void e.l()
            }, 5E3)
        })
    };
    _.T(XM, Z);
    XM.prototype.j = function() {
        this.l()
    };
    var YM = function(a, b, c) {
        Z.call(this, a, 1175);
        this.output = $F(this);
        bG(this, b);
        bG(this, c)
    };
    _.T(YM, Z);
    YM.prototype.j = function() {
        RF(this.output, Bz(5E3))
    };
    uf({
        google_signals: uf({
            buyer_reporting_id: Kh
        })
    });
    var pr = navigator,
        qr = /(\$\{GDPR})/gi,
        rr = /(\$\{GDPR_CONSENT_[0-9]+\})/gi,
        sr = /(\$\{ADDTL_CONSENT})/gi,
        tr = /(\$\{AD_WIDTH})/gi,
        ur = /(\$\{AD_HEIGHT})/gi,
        vr = /(\$\{RENDER_DATA})/gi;
    var ZM = function() {
            var a = this;
            this.promise = new _.v.Promise(function(b, c) {
                a.reject = c;
                a.resolve = b
            })
        },
        $M = function() {
            this.auctionSignals = new ZM;
            this.topLevelSellerSignals = new ZM;
            this.j = new ZM;
            this.perBuyerSignals = new ZM;
            this.perBuyerTimeouts = new ZM;
            this.perBuyerCumulativeTimeouts = new ZM;
            this.directFromSellerSignals = new ZM;
            this.directFromSellerSignalsHeaderAdSlot = new ZM;
            this.perBuyerCurrencies = new ZM;
            this.resolveToConfig = new ZM
        },
        aN = function(a, b, c) {
            this.j = a;
            this.Hf = b;
            this.Db = c
        };
    var bN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u) {
        Z.call(this, a, 1201);
        this.da = b;
        this.X = c;
        this.sa = d;
        this.fa = e;
        this.U = k;
        this.G = l;
        this.K = m;
        this.O = n;
        this.C = p;
        this.l = r;
        this.ma = $F(this);
        this.v = V(this);
        this.za = X(this, f);
        this.Ia = W(this, g);
        this.pa = W(this, h);
        this.ba = W(this, u);
        W(this, w);
        V(this, p);
        V(this, n.Hb);
        V(this, n.Aa);
        V(this, n.La);
        V(this, this.l)
    };
    _.T(bN, Z);
    bN.prototype.j = function() {
        var a = Math.round(performance.now() - this.Ia.value),
            b = this.pa.value,
            c = this.za.value,
            d = _.Qh(this.sa, xy, 5),
            e = _.L(d, 10),
            f = _.L(d, 9),
            g = "string" === typeof c || "function" === typeof FencedFrameConfig && c instanceof FencedFrameConfig,
            h = 3 !== c && 2 !== c && 1 !== c;
        this.l.F(g && !f);
        h && yr(this.context, g, b, a, d);
        var k, l;
        h = null != (l = null == (k = this.ba.value.componentAuctions) ? void 0 : k.length) ? l : 0;
        xr(this.context, c, a, b, !!this.fa, d, h, g);
        if (g)
            if (e) this.da.deprecatedURNToURL(c, !0), this.C.F(!0), this.v.aa();
            else if (f) {
            _.L(d, 17) ? nr(0, 0, d) : this.da.deprecatedURNToURL(c, !0);
            var m;
            or(this.O, this.l, this.G, this.K, this.U, null == (m = this.sa) ? void 0 : _.R(m, 25));
            this.C.F(!0);
            this.v.aa()
        } else {
            this.v.F(c);
            this.C.F(!0);
            if (_.G(cC)) {
                b = this.ba.value;
                d = this.sa;
                var n;
                a = 1 === (null == (n = b.componentAuctions) ? void 0 : n.length) && hr(b.componentAuctions[0].seller) && b.componentAuctions[0].interestGroupBuyers.every(gr) && Bn(d, ry, 26) ? rw(tk(is(d, ry, 26)), 3) : ""
            } else a = void 0;
            n = a;
            RF(this.ma, wr(c, _.A(Object, "assign").call(Object, {}, {
                gdprApplies: null != Il(this.X, 3) ? _.L(this.X, 3) ? "1" : "0" : null,
                wk: _.sj(this.X, 2),
                sj: _.sj(this.X, 4),
                pj: this.sa.getWidth().toString(),
                nj: this.sa.getHeight().toString()
            }, n ? {
                yl: n
            } : {})))
        } else {
            nr(a, 2 === c ? b : 0, d);
            if (!e) {
                var p;
                or(this.O, this.l, this.G, this.K, this.U, null == (p = this.sa) ? void 0 : _.R(p, 25))
            }
            this.C.F(!0);
            this.v.aa()
        }
    };
    bN.prototype.m = function() {
        var a, b = null == (a = this.sa) ? void 0 : _.Qh(a, xy, 5);
        a = this.fa;
        var c = this.O,
            d = this.l,
            e = this.G,
            f = this.K,
            g = this.U;
        b && nr(0, 0, b);
        null == a || a.Db.abort();
        or(c, d, e, f, g)
    };
    var cN = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 1200);
        this.L = b;
        this.pa = c;
        this.v = d;
        this.sa = e;
        this.U = g;
        this.G = h;
        this.K = k;
        this.O = m;
        this.ba = n;
        this.C = ZF(this);
        this.ma = V(this);
        this.fa = V(this);
        this.da = V(this);
        this.l = X(this, f);
        W(this, l);
        V(this, m.Hb);
        V(this, m.Aa);
        V(this, m.La);
        V(this, n)
    };
    _.T(cN, Z);
    cN.prototype.j = function() {
        if (this.l.value) {
            var a = is(this.sa, xy, 5);
            zr(this.context, a);
            this.ma.F(performance.now());
            var b = _.Rw(this.sa, 8) || 1E3;
            this.fa.F(b);
            var c = _.Rw(a, 14) || -1,
                d = _.Rw(a, 13) || -1;
            d = 0 < d && this.L.A >= d;
            if (0 < c && this.L.m >= c || d) this.C.F(1);
            else if (++this.L.m, ++this.L.A, this.l.value.signal = AbortSignal.timeout(b), _.L(a, 15)) --this.L.m, this.C.Ka(new _.v.Promise(function(e) {
                setTimeout(function() {
                    e(1)
                }, 0)
            }));
            else {
                if (this.v && this.l.value.serverResponse) throw new TypeError("Attempted to provide a RemoteAuctionConfig in parallelized auction.");
                a = this.v ? dN(this.l.value, b, this.v) : eN(this, this.l.value);
                --this.L.m;
                this.C.Ka(a)
            }
        } else null == (a = this.v) || a.Db.abort(), or(this.O, this.ba, this.G, this.K, this.U), this.da.F(!1)
    };
    var eN = function(a, b) {
            var c, d;
            return null == (d = (c = a.pa).runAdAuction) ? void 0 : d.call(c, b).catch(function(e) {
                return e instanceof DOMException && "TimeoutError" === e.name ? 2 : 3
            })
        },
        dN = function(a, b, c) {
            lr(a, c);
            setTimeout(function() {
                c.Db.abort(new DOMException("runAdAuction", "TimeoutError"))
            }, b);
            return c.j
        };
    cN.prototype.m = function() {
        var a, b = null == (a = this.sa) ? void 0 : _.Qh(a, xy, 5);
        a = this.v;
        var c = this.O,
            d = this.ba,
            e = this.G,
            f = this.K,
            g = this.U;
        b && nr(0, 0, b);
        null == a || a.Db.abort();
        or(c, d, e, f, g)
    };
    var fN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1202);
        this.sa = b;
        this.l = c;
        this.v = X(this, e);
        this.C = W(this, d);
        bG(this, f);
        V(this, c.Hb);
        V(this, c.Aa);
        V(this, c.La)
    };
    _.T(fN, Z);
    fN.prototype.j = function() {
        this.v.value && (this.C.value.style.display = "", this.l.Aa.F({
            kind: 2,
            Wd: this.v.value
        }), this.l.La.F(new _.ki(this.sa.getWidth(), this.sa.getHeight())), this.l.Hb.F(!1))
    };
    var gN = function(a, b, c) {
        Z.call(this, a, 1054);
        this.l = b;
        this.output = $F(this);
        this.v = W(this, c)
    };
    _.T(gN, Z);
    gN.prototype.j = function() {
        this.v.value || this.l();
        this.output.notify()
    };
    var hN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1053);
        this.slotId = b;
        this.P = c;
        this.L = d;
        this.l = V(this);
        this.v = W(this, e);
        this.C = W(this, f)
    };
    _.T(hN, Z);
    hN.prototype.j = function() {
        this.C.value ? (Fr(this.slotId, this.L, this.P, this.v.value), this.l.F(!1)) : this.l.F(!0)
    };
    var iN = function(a, b, c, d) {
        Z.call(this, a, 1055);
        this.l = d;
        bG(this, c);
        this.v = W(this, b);
        $F(this, this.l)
    };
    _.T(iN, Z);
    iN.prototype.j = function() {
        this.v.value && this.l.notify()
    };
    var Hr = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y) {
        Z.call(this, a, 1179);
        this.slotId = b;
        this.R = d;
        this.L = e;
        this.X = f;
        this.v = g;
        this.O = l;
        this.C = m;
        this.P = n;
        this.ba = p;
        this.jc = r;
        this.l = u;
        this.fa = y;
        this.da = X(this, w);
        this.G = W(this, h);
        this.K = W(this, k);
        this.U = X(this, c)
    };
    _.T(Hr, Z);
    Hr.prototype.j = function() {
        var a = new Bj;
        _.S(this, a);
        var b = this.da.value,
            c = V(this);
        if (b) {
            var d = is(b, xy, 5),
                e = _.L(d, 10);
            if (b.getWidth() && b.getHeight())
                if (e)
                    if (or({
                            Hb: c,
                            Aa: this.l.Aa,
                            La: this.l.La
                        }, this.l.Lc, this.G.value, this.K.value, this.v), _.L(d, 17)) {
                        nr(0, 0, d);
                        var f;
                        null == (f = this.C) || f.Db.abort()
                    } else jN(this, a, b);
            else c = jN(this, a, b);
            else {
                or({
                    Hb: c,
                    Aa: this.l.Aa,
                    La: this.l.La
                }, this.l.Lc, this.G.value, this.K.value, this.v);
                nr(0, 0, d);
                var g;
                null == (g = this.C) || g.Db.abort()
            }
        } else or({
            Hb: c,
            Aa: this.l.Aa,
            La: this.l.La
        }, this.l.Lc, this.G.value, this.K.value, this.v), null == (d = this.C) || d.Db.abort();
        b = new hN(this.context, this.slotId, this.P, this.L, this.jc, c);
        M(a, b);
        c = new gN(this.context, this.ba, c);
        M(a, c);
        c = new iN(this.context, b.l, c.output, this.l.Rd);
        M(a, c);
        Kj(a)
    };
    var jN = function(a, b, c) {
        if (2 === _.Uf(us) && a.U.value && _.L(c, 20) && 0 !== _.bl(c, 3).length) {
            var d = new WM(a.context, a.slotId.getAdUnitPath(), c, a.U.value);
            M(b, d)
        }
        var e = new VM(a.context, a.R, c, a.fa);
        M(b, e);
        var f = navigator,
            g = {
                Aa: a.l.Aa,
                La: a.l.La,
                Hb: new rn
            };
        d = g.Hb;
        var h = new cN(a.context, a.L, f, a.C, c, e.output, a.v, a.G.value, a.K.value, a.O, g, a.l.Lc);
        M(b, h);
        var k = h.da;
        e = new bN(a.context, f, a.X, c, a.C, h.C, h.ma, h.fa, a.v, a.G.value, a.K.value, g, k, a.l.Lc, a.O, e.output);
        M(b, e);
        g = new fN(a.context, c, g, a.O, e.v, e.ma);
        M(b, g);
        g = new Gp(a.context, a.slotId, Er);
        M(b, g);
        k = new YM(a.context, k, g.output);
        M(b, k);
        c = _.R(c, 19);
        (null == c ? 0 : c.length) && M(b, new XM(a.context, window.document, c, k.output));
        return d
    };
    var kN = function() {
        vM.apply(this, arguments)
    };
    _.T(kN, vM);
    var lN = function(a, b) {
            var c = _.af(b ? "fencedframe" : "IFRAME");
            b && (c.mode = "opaque-ads");
            c.id = a.zd;
            c.name = a.zd;
            c.title = a.Bd;
            Array.isArray(a.j) ? null != a.j[0] && null != a.j[1] && (c.width = String(a.j[0]), c.height = String(a.j[1])) : (c.width = "100%", c.height = "0");
            c.allowTransparency = "true";
            c.scrolling = "no";
            c.marginWidth = "0";
            c.marginHeight = "0";
            c.frameBorder = "0";
            c.style.border = "0";
            c.style.verticalAlign = "bottom";
            c.setAttribute("role", "region");
            c.setAttribute("aria-label", "Advertisement");
            c.tabIndex = 0;
            return c
        },
        mN = function(a, b) {
            "string" !== typeof a.j && (b.width = String(a.j[0]), b.height = String(a.j[1]));
            var c = yh(a.context, 774, function() {
                a.loaded(b);
                _.of(b, "load", c)
            });
            _.ib(b, "load", c);
            _.mn(a, function() {
                return _.of(b, "load", c)
            });
            a.m.hh.appendChild(b)
        };
    var nN = function() {
        kN.apply(this, arguments)
    };
    _.T(nN, kN);
    nN.prototype.l = function() {
        var a = lN(this, !this.m.gm);
        if ("string" === typeof this.lb.Wd) {
            var b = this.lb.Wd;
            /^(uuid-in-package|urn:uuid):[0-9a-fA-F-]*$/.test(b) && (b = Le(b), a.src = _.gb(b).toString())
        } else a.config = this.lb.Wd;
        mN(this, a);
        return a
    };
    nN.prototype.A = function() {
        return !1
    };
    var oN = navigator,
        pN = function(a, b, c, d, e, f, g) {
            Z.call(this, a, 1089);
            this.Sb = b;
            this.W = c;
            this.R = d;
            this.Hc = f;
            this.l = g;
            V(this, g);
            e && (this.v = X(this, e))
        };
    _.T(pN, Z);
    pN.prototype.j = function() {
        var a = {};
        if (1 === this.Sb)
            for (var b = _.z(this.W), c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                c = this.R[d.getDomId()];
                a[d.getId()] = qN(this, c, void 0, this.Hc)
            } else if (2 === this.Sb) {
                b = null == (d = this.v) ? void 0 : d.value;
                if (!b) {
                    this.l.aa();
                    return
                }
                d = _.z(this.W);
                for (c = d.next(); !c.done; c = d.next()) {
                    c = c.value;
                    var e = b.get(c.getId()),
                        f = void 0;
                    null != (f = e) && f.length && (f = this.R[c.getDomId()], a[c.getId()] = qN(this, f, e, this.Hc))
                }
            }
        this.l.F(a)
    };
    var qN = function(a, b, c, d) {
        var e = new $M,
            f = new AbortController;
        a = kr({
            Hf: e,
            Db: f,
            gh: Fm(a.context, b),
            interestGroupBuyers: c,
            Hc: d
        });
        a = oN.runAdAuction(a).catch(function(g) {
            return g instanceof DOMException && "TimeoutError" === g.name ? 2 : 3
        });
        return new aN(a, e, f)
    };
    var rN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1106);
        this.X = b;
        this.v = c;
        this.W = d;
        this.Hc = e;
        this.C = f;
        this.l = V(this);
        V(this, f)
    };
    _.T(rN, Z);
    rN.prototype.j = function() {
        for (var a = fr(this.v, this.X, this.Hc), b = new _.v.Map, c = new _.v.Map, d = _.z(this.W), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            e = f.getAdUnitPath();
            var g = void 0,
                h = void 0,
                k = null != (h = null == (g = a.get(Yq(e))) ? void 0 : Uh(g, er, 1).map(function(l) {
                    return _.R(l, 1)
                })) ? h : [];
            b.set(f.getId(), k);
            if (!c.has(e)) {
                f = [];
                k = _.z(k.sort());
                for (g = k.next(); !g.done; g = k.next()) f.push(_.Rf(g.value));
                c.set(e, f)
            }
        }
        this.l.F(b);
        this.C.F(c)
    };
    var Jr = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1170);
        this.Sb = b;
        this.R = c;
        this.X = d;
        this.v = e;
        this.l = {
            xg: V(this)
        };
        2 !== b || _.G($B) && !this.v || (this.l.ag = V(this));
        this.K = W(this, f);
        this.G = W(this, g);
        h && (this.C = X(this, h))
    };
    _.T(Jr, Z);
    Jr.prototype.j = function() {
        var a = this.K.value;
        if (this.G.value && a.length) {
            var b = new Bj;
            _.S(this, b);
            if (2 === this.Sb && this.v) {
                var c, d;
                var e = new rN(this.context, this.X, this.v, a, null != (d = null == (c = this.C) ? void 0 : c.value) ? d : void 0, this.l.ag);
                M(b, e);
                e = e.l
            }
            var f, g;
            a = new pN(this.context, this.Sb, a, this.R, e, null != (g = null == (f = this.C) ? void 0 : f.value) ? g : void 0, this.l.xg);
            M(b, a);
            Kj(b)
        } else this.l.xg.aa(), null == (b = this.l.ag) || b.aa()
    };
    var sN = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1166);
        this.kd = b;
        this.V = c;
        this.G = d;
        this.l = ZF(this);
        this.v = V(this);
        this.C = V(this);
        this.O = W(this, e);
        this.U = W(this, f);
        bG(this, g);
        this.K = W(this, h)
    };
    _.T(sN, Z);
    sN.prototype.j = function() {
        var a = this,
            b = this.O.value;
        if (b) {
            var c = _.qb(this.U.value, {
                    uuid: this.kd
                }),
                d = this.V.createElement("script");
            b = {
                source: b,
                credentials: this.K.value ? "include" : "omit",
                resources: [c.toString()]
            };
            d.setAttribute("type", "webbundle");
            fb(d, Qe(b));
            this.V.head.appendChild(d);
            this.v.F(d);
            this.C.F(b);
            this.l.Ka(tN(c).catch(function(e) {
                e instanceof ME ? a.G(e) : (a.I(e), a.m(e));
                return null
            }))
        } else this.l.aa(), this.v.aa(), this.C.aa()
    };
    var tN = function(a) {
        var b, c;
        return _.kb(function(d) {
            if (1 == d.j) return d.yield(fetch(a.toString()).catch(function() {
                throw new ME("Failed to fetch bundle index.");
            }), 2);
            if (3 != d.j) return b = d.o, d.yield(b.text(), 3);
            c = d.o;
            return d.return(Ey(c))
        })
    };
    var uN = function(a, b, c, d, e, f, g, h, k, l, m) {
        Z.call(this, a, 1167);
        this.V = b;
        this.X = c;
        this.G = d;
        this.l = e;
        this.C = f;
        this.v = W(this, g);
        this.O = X(this, h);
        this.U = X(this, k);
        this.ba = X(this, l);
        m && (this.K = X(this, m))
    };
    _.T(uN, Z);
    uN.prototype.j = function() {
        var a = this.O.value,
            b = this.U.value,
            c = this.ba.value;
        if (a)
            if (b && c) {
                var d = _.bl(a, 1),
                    e = _.bl(a, 2);
                a = _.bl(a, 3);
                if (d.length !== e.length) this.l(new LE("Received " + d.length + " ad URLs but " + e.length + " metadatas"));
                else {
                    c.resources = [].concat(_.ch(d.filter(function(f) {
                        return f
                    })), _.ch(a.map(function(f) {
                        return "https://securepubads.g.doubleclick.net" + f
                    })));
                    c.resources.length ? (a = _.af("SCRIPT"), a.setAttribute("type", "webbundle"), fb(a, Qe(c)), this.V.head.removeChild(b), this.V.head.appendChild(a)) : this.V.head.removeChild(b);
                    for (b = 0; b < d.length; b++) c = void 0, this.G(b, e[b], {
                        kind: 1,
                        url: d[b]
                    }, this.v.value, this.X, null == (c = this.K) ? void 0 : c.value, void 0);
                    this.C(d.length - 1, this.v.value, this.X)
                }
            } else this.l(Error("Lost bundle script"))
    };
    var vN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r) {
        Bj.call(this);
        e = new sN(a, f, h, c, m, n, p, r);
        M(this, e);
        M(this, new uN(a, h, g, b, c, d, k, e.l, e.v, e.C, l));
        this.j = {
            output: e.l
        }
    };
    _.T(vN, Bj);
    var Vr = new _.v.Set,
        wN = function(a, b, c) {
            var d = 0,
                e = function() {
                    d = 0
                };
            return function(f) {
                d || (d = _.t.setTimeout(e, b), a.apply(c, arguments))
            }
        }(function() {
            throw new ym("Reached Limit for addEventListener");
        }, 3E5),
        xN = function(a, b, c) {
            _.U.call(this);
            this.context = a;
            this.T = b;
            this.m = c;
            this.j = [];
            this.enabled = !1;
            this.I = 0;
            this.l = new _.v.Map;
            Vr.add(this);
            this.T.info(PI(this.getName()))
        };
    _.T(xN, _.U);
    var Xr = function(a) {
        a.enabled || (a.enabled = !0, Kl(6, a.context), a.M())
    };
    xN.prototype.slotAdded = function(a, b) {
        this.j.push(a);
        var c = new OL(a, this.getName());
        Cr(this.m, "slotAdded", 818, c);
        this.T.info(QI(this.getName(), a.getAdUnitPath()), a);
        a = this.getName();
        $w(b, 4, a)
    };
    xN.prototype.destroySlots = function(a) {
        var b = this;
        return a.filter(function(c) {
            return fa(b.j, c)
        })
    };
    xN.prototype.addEventListener = function(a, b, c) {
        var d = this;
        c = void 0 === c ? window : c;
        if (this.I >= _.Uf(hB) && 0 < _.Uf(hB)) return wN(), !1;
        if (!c.IntersectionObserver && (_.F = ["impressionViewable", "slotVisibilityChanged"], _.A(_.F, "includes")).call(_.F, a)) return P(this.T, EJ()), !1;
        var e;
        if (null == (e = this.l.get(a)) ? 0 : e.has(b)) return !1;
        this.l.has(a) || this.l.set(a, new _.v.Map);
        c = function(f) {
            f = f.detail;
            try {
                b(f)
            } catch (k) {
                d.T.error(eJ(String(k), a));
                var g, h;
                null == (g = window.console) || null == (h = g.error) || h.call(g, k)
            }
        };
        this.l.get(a).set(b, c);
        this.m.listen(a, c);
        this.I++;
        return !0
    };
    xN.prototype.removeEventListener = function(a, b) {
        var c, d = null == (c = this.l.get(a)) ? void 0 : c.get(b);
        if (!d || !eI(this.m, a, d)) return !1;
        this.I--;
        return this.l.get(a).delete(b)
    };
    var Nr = function(a) {
        for (var b = _.z(Vr), c = b.next(); !c.done; c = b.next()) c.value.destroySlots(a)
    };
    var Rr = function(a, b, c, d) {
        xN.call(this, a, b, d);
        this.A = c;
        this.ads = new _.v.Map;
        this.zc = !1
    };
    _.T(Rr, xN);
    Rr.prototype.setRefreshUnfilledSlots = function(a) {
        "boolean" === typeof a && (this.zc = a)
    };
    var QJ = function(a, b) {
            var c;
            return a.A.enabled && !(null == (c = a.ads.get(b)) || !c.kl)
        },
        RJ = function(a, b, c, d) {
            b = new KL(b, a.getName());
            null != c && null != d && (b.size = [c, d]);
            Cr(a.m, "slotRenderEnded", 67, b)
        };
    Rr.prototype.getName = function() {
        return "companion_ads"
    };
    Rr.prototype.slotAdded = function(a, b) {
        var c = this;
        a.listen(hI, function(d) {
            Il(d.detail, 11) && (yN(c, a).kl = !0)
        });
        xN.prototype.slotAdded.call(this, a, b)
    };
    Rr.prototype.M = function() {};
    var yN = function(a, b) {
            var c = a.ads.get(b);
            c || (c = {}, a.ads.set(b, c), _.mn(b, function() {
                return a.ads.delete(b)
            }));
            return c
        },
        OJ = function(a, b) {
            var c = Hi().j,
                d = Hi().o;
            if (a.A.enabled) {
                var e = {
                    Vb: 3
                };
                a.H && (e.bd = a.H);
                a.v && (e.cd = a.v);
                b = null != b ? b : a.j;
                c = oi(c, d);
                d = e.bd;
                var f = e.cd;
                d && "number" !== typeof d || f && "number" !== typeof f || a.A.refresh(c, b, e)
            } else(null == b ? 0 : b[0]) && a.T.error(WI(b[0].getDomId()))
        },
        PJ = function(a, b) {
            return a.j.filter(function(c) {
                return _.A(b, "includes").call(b, c.toString())
            })
        };
    var Sr = function(a, b, c) {
        xN.call(this, a, b, c)
    };
    _.T(Sr, xN);
    Sr.prototype.getName = function() {
        return "content"
    };
    Sr.prototype.M = function() {};
    var zN = function() {
        this.Rj = 1E3
    };
    zN.prototype.send = function(a, b) {
        a.Hi(b)
    };
    var Zt = function(a, b) {
        var c = {};
        this.configuration = (c[576944485] = new zN, c);
        this.Ja = a;
        this.j = b
    };
    Zt.prototype.log = function(a, b, c) {
        var d, e = null != (d = c.Cb) ? d : this.configuration[a].Rj;
        1 / e < this.j || (b = b(_.A(Object, "assign").call(Object, {}, {
            Cb: e
        }, c)), this.configuration[a].send(this.Ja, b))
    };
    var AN = _.ju(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl_", "", ".js"]),
        BN = _.ju(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", "_", ".js"]),
        CN = _.ju(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl_", "", ".js"]),
        DN = _.ju(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", "_", ".js"]),
        EN = new _.v.Map([
            [2, {
                pg: "page_level_ads"
            }],
            [5, {
                pg: "shoppit"
            }],
            [6, {
                pg: "side_rails"
            }]
        ]),
        FN = function(a) {
            var b = void 0 === b ? EN : b;
            this.context = a;
            this.j = b;
            this.o = new _.v.Map;
            this.loaded = new _.v.Set
        },
        HN;
    FN.prototype.load = function(a) {
        var b = _.GN(this, a),
            c, d = (null != (c = this.j.get(a.module)) ? c : {}).pg;
        if (!d) throw Error("cannot load invalid module: " + d);
        if (!this.loaded.has(a.module)) {
            (c = _.ci(172)) && "pagead2.googlesyndication.com" === ez((c.src || "").match(_.dz)[3] || null) ? (c = "", _.G(AB) && (c = tp(_.G(zB), this.context.Ah)), d = this.context.zb ? _.Me(CN, this.context.zb, d, c) : _.Me(DN, d, this.context.fb)) : this.context.zb ? (c = "", _.G(AB) && (c = tp(_.G(zB), this.context.Ah)), d = _.Me(AN, this.context.zb, d, c)) : d = _.Me(BN, d, this.context.fb);
            c = {};
            var e = _.Uf(MB);
            e && (c.cb = e);
            d = _.A(Object, "keys").call(Object, c).length ? _.dv(d, c) : d;
            HN(this, a);
            _.an(document, d);
            this.loaded.add(a.module)
        }
        return b.promise
    };
    _.GN = function(a, b) {
        b = b.module;
        a.o.has(b) || a.o.set(b, new _.cg);
        return a.o.get(b)
    };
    HN = function(a, b) {
        var c = b.module;
        b = "_gpt_js_load_" + c + "_";
        var d = yh(a.context, 340, function(e) {
            if (a.j.has(c) && "function" === typeof e) {
                var f = a.j.get(c);
                f = (void 0 === f.Tj ? [] : f.Tj).map(function(g) {
                    return _.GN(a, g).promise
                });
                _.v.Promise.all(f).then(function() {
                    e.call(window, _, a)
                })
            }
        });
        Object.defineProperty(Am(), b, {
            value: function(e) {
                if (d) {
                    var f = d;
                    d = null;
                    f(e)
                }
            },
            writable: !1,
            enumerable: !1
        })
    };
    var IN = function(a, b) {
        Z.call(this, a, 980);
        this.output = new vn;
        this.l = [];
        this.v = W(this, b)
    };
    _.T(IN, Z);
    IN.prototype.j = function() {
        for (var a = _.z((_.F = [this.v.value, this.l.map(function(c) {
                return c.value
            })], _.A(_.F, "flat")).call(_.F)), b = a.next(); !b.done; b = a.next()) Hf(b.value);
        this.output.notify()
    };
    var JN = function(a, b) {
        Z.call(this, a, 892, _.Uf(GB));
        this.l = V(this);
        this.C = V(this);
        this.v = V(this);
        this.od = V(this);
        this.Qd = V(this);
        this.G = V(this);
        this.uf = V(this);
        this.K = aG(this, b);
        _.G(bB) && (this.nd = V(this))
    };
    _.T(JN, Z);
    JN.prototype.j = function() {
        var a = this.K.value;
        if (!a) throw Error("config timeout");
        this.l.Ca(_.Qh(a, Ix, 3));
        this.C.Ca(_.Qh(a, Kx, 2));
        this.v.F(Rd(a, 4, Lc));
        this.od.Ca(Uh(a, Ex, 6));
        this.Qd.Ca(Uh(a, Wx, 5));
        this.G.Ca(_.Qh(a, Vx, 7));
        var b;
        this.uf.F(new _.v.Set((null == (b = _.Qh(a, Fx, 1)) ? void 0 : _.bl(b, 6)) || []));
        var c;
        null == (c = this.nd) || c.Ca(_.Qh(a, Yx, 8))
    };
    JN.prototype.H = function(a) {
        this.m(a)
    };
    JN.prototype.m = function(a) {
        this.l.ib(a);
        this.C.ib(a);
        this.v.F([]);
        this.od.F([]);
        this.Qd.F([]);
        this.G.aa();
        var b;
        null == (b = this.nd) || b.aa()
    };
    var KN = function(a, b) {
        Z.call(this, a, 891);
        var c = this;
        this.l = V(this);
        this.error = void 0;
        var d = V(this);
        this.v = W(this, d);
        b(function(e, f) {
            if (f) c.error = f, d.F([]);
            else try {
                if ("string" === typeof e) {
                    var g = JSON.parse(e || "[]");
                    Array.isArray(g) && d.F(g)
                }
            } catch (h) {} finally {
                d.Bb || (c.error = Error("malformed response"), d.F([]))
            }
        })
    };
    _.T(KN, Z);
    KN.prototype.j = function() {
        if (this.error) throw this.error;
        this.l.F(je(Zx, this.v.value))
    };
    var LN = function(a, b) {
        Z.call(this, a, 1081);
        this.Pb = V(this);
        this.l = X(this, b)
    };
    _.T(LN, Z);
    LN.prototype.j = function() {
        this.l.value ? this.Pb.F(this.l.value) : this.Pb.aa()
    };
    var MN = new _.v.Map([
            [1, 5],
            [2, 2],
            [3, 3]
        ]),
        NN = function(a, b, c, d, e, f, g, h, k) {
            Z.call(this, a, 1079);
            this.V = b;
            this.googletag = c;
            this.Z = d;
            this.G = e;
            this.l = f;
            this.T = g;
            this.v = h;
            this.C = k;
            V(this)
        };
    _.T(NN, Z);
    NN.prototype.j = function() {
        var a = this,
            b = this.v.getAdUnitPath(),
            c = MN.get(_.Ak(this.v, 2, 0));
        if (b && c) {
            var d, e = null != (d = this.Z) ? d : this.l.j;
            b = new mL(this.context, this.V, b, c, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, e, this.l, this.G, this.T, !1, this.C);
            _.S(this, b);
            Kj(b)
        }
    };
    var ht = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1082);
        this.googletag = b;
        this.Z = c;
        this.G = d;
        this.v = e;
        this.T = f;
        this.C = V(this);
        this.l = new LN(this.context, this.C);
        this.Pb = this.l.Pb;
        _.S(this, this.l);
        this.K = W(this, g)
    };
    _.T(ht, Z);
    ht.prototype.j = function() {
        if (_.G(LB)) {
            for (var a = [], b = _.z(this.K.value), c = b.next(); !c.done; c = b.next()) switch (c = c.value, wk(c, Xx)) {
                case 5:
                    a.push(c);
                    break;
                case 8:
                    var d = c
            }
            this.C.Ca(null == d ? void 0 : _.Qh(d, Px, 4));
            d = new Bj;
            _.S(this, d);
            a = _.z(a);
            for (b = a.next(); !b.done; b = a.next()) b = b.value, c = void 0, M(d, new NN(this.context, document, this.googletag, null != (c = this.Z) ? c : this.v.j, this.G, this.v, this.T, _.Qh(b, Rx, zk(b, Xx, 5)), _.Qh(b, Px, 4)));
            M(d, this.l);
            Kj(d)
        } else this.Pb.aa()
    };
    var ON = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.context = a;
        this.A = b;
        this.m = c;
        this.T = d;
        this.L = e;
        this.j = f;
        this.bb = g;
        this.l = h
    };
    _.T(ON, _.U);
    var PN = function(a, b, c, d) {
        var e = new Bj;
        _.S(a, e);
        var f = a.context;
        var g = a.j;
        var h = new Bj;
        g = new KN(f, g);
        M(h, g);
        var k = new JN(f, g.l);
        M(h, k);
        Kj(h);
        var l = k.l;
        var m = k.C;
        var n = k.v;
        f = k.od;
        var p = k.Qd;
        var r = k.G;
        g = k.uf;
        k = k.nd;
        _.S(a, h);
        var w;
        h = new GL(a.context, document, Am(), a.A, a.m, a.T, null != (w = window.location.hash) ? w : "");
        M(e, h);
        w = new ht(a.context, Am(), null, a.A, a.m, a.T, p);
        M(e, w);
        h = new IN(a.context, n);
        M(e, h);
        b = new wL(a.context, window, m, b);
        M(e, b);
        n = a.context;
        p = a.bb;
        m = {
            Ub: new rn,
            bc: new rn,
            ac: new rn,
            Zb: new rn,
            Fc: new rn,
            yc: new rn,
            bf: new rn,
            cf: new rn,
            zf: new rn
        };
        var u = new Bj;
        M(u, new RK(n, p, l, window, m));
        Kj(u);
        _.S(a, u);
        l = np(a.context, a.j, b.l);
        p = l.Kc;
        u = l.Eh;
        _.S(e, l.Ga);
        l = new pL(a.context, u);
        M(e, l);
        n = new qL(a.context, u);
        M(e, n);
        u = Pm(a.context, a.T, a.L, window, p, u);
        p = u.kb;
        _.S(a, u.Ga);
        if (_.G(HB)) {
            u = new sM(a.context, window.navigator, p);
            var y = u.l;
            M(e, u)
        }
        u = void 0;
        if (_.G(aC)) {
            var x = new RM(a.context, a.L, window, p);
            u = x.output;
            M(e, x)
        }
        x = a.context;
        if (_.G(fB) || bm()) x = void 0;
        else {
            var C = {
                    rg: new rn,
                    ub: new rn
                },
                I = new Bj;
            M(I, new FM(x, f, p, C));
            Kj(I);
            x = {
                hf: C,
                Ga: I
            }
        }
        if (x) {
            var D = x.hf;
            _.S(a, x.Ga)
        }
        x = a.context;
        d = d.qe;
        C = window;
        I = !Of(C.isSecureContext, C.document);
        Pf(C.isSecureContext, C, C.document) || !I ? (I = new Bj, d = new MM(x, C, d, p), M(I, d), Kj(I), d = d.l) : d = void 0;
        C = a.context;
        I = a.l;
        x = new Bj;
        c = new IM(C, I, c, p, r);
        M(x, c);
        Kj(x);
        _.S(a, x);
        Kj(e);
        return {
            fe: m,
            hf: D,
            Yk: b.l,
            Mj: h.output,
            Pb: w.Pb,
            od: f,
            Ce: l.Ce,
            tk: n.l,
            uf: g,
            pf: d,
            Dh: u,
            Pj: y,
            nd: k
        }
    };
    var Yt = function(a) {
        gG.call(this, function(b, c) {
            Ch(a, b, c);
            var d;
            null == (d = console) || d.error(c)
        })
    };
    _.T(Yt, gG);
    var QN = function() {
        kN.apply(this, arguments)
    };
    _.T(QN, kN);
    QN.prototype.l = function() {
        var a = this,
            b = this.m,
            c = b.Ei;
        b = b.Ae;
        var d = lN(this);
        if (null == c ? 0 : c.length)
            if (_.aw) {
                c = _.z(c);
                for (var e = c.next(); !e.done; e = c.next()) d.sandbox.add(e.value)
            } else d.sandbox.add.apply(d.sandbox, _.ch(c));
        b && (d.allow = b);
        mN(this, d);
        Eh(this.context, 653, function() {
            var f;
            if (f = lj(a.lb.yb)) {
                var g = f.toString().toLowerCase();
                f = -1 < g.indexOf("<!doctype") || -1 < g.indexOf("<html") || _.G(lC) ? f : lj("<!doctype html><html><head><script>var inDapIF=true,inGptIF=true;\x3c/script></head><body>" + f + "</body></html>")
            }
            var h, k;
            g = null != (k = null == (h = d.contentWindow) ? void 0 : h.document) ? k : d.contentDocument;
            (Ka("Firefox") || Ka("FxiOS")) && g.open("text/html", "replace");
            g.write(_.Lv(f));
            var l, m, n;
            if (hv(null != (n = null == (l = d.contentWindow) ? void 0 : null == (m = l.location) ? void 0 : m.href) ? n : "", "#")) {
                var p, r;
                null == (p = d.contentWindow) || null == (r = p.history) || r.replaceState(null, "", "#" + Math.random())
            }
            g.close()
        }, !0);
        return d
    };
    QN.prototype.A = function() {
        return !0
    };
    var Vs = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y, x, C, I, D, J, Q, N, Y, ua) {
        Z.call(this, a, 680);
        this.slotId = b;
        this.L = c;
        this.P = d;
        this.ra = e;
        this.Ta = f;
        this.B = g;
        this.l = V(this);
        this.C = V(this);
        this.v = $F(this);
        this.K = W(this, h);
        this.Pa = W(this, k);
        bG(this, l);
        this.fa = W(this, m);
        this.G = W(this, n);
        this.da = W(this, p);
        bG(this, I);
        this.O = W(this, r);
        this.U = X(this, w);
        this.Xa = X(this, u);
        this.ba = W(this, y);
        this.Ia = X(this, x);
        this.Eb = X(this, C);
        bG(this, D);
        this.za = W(this, J);
        bG(this, Q);
        ua && bG(this, ua);
        this.ma = X(this, N);
        Y && (this.pa = X(this, Y))
    };
    _.T(Vs, Z);
    Vs.prototype.j = function() {
        var a = this.K.value;
        if (0 === a.kind && null == a.yb) throw new LE("invalid html");
        var b, c;
        a: {
            var d = this.context,
                e = {
                    V: document,
                    slotId: this.slotId,
                    L: this.L,
                    P: this.P,
                    ra: this.ra,
                    size: this.da.value,
                    Li: this.fa.value,
                    hh: this.G.value,
                    Qf: this.O.value,
                    mk: this.U.value,
                    Ei: this.Xa.value,
                    isBackfill: this.ba.value,
                    Gk: _.G(SB) ? !1 : this.Ia.value,
                    ae: this.Eb.value,
                    Ae: this.za.value,
                    gm: null == (b = this.ma.value) ? void 0 : _.L(b, 14),
                    yf: null == (c = this.pa) ? void 0 : c.value,
                    Ta: this.Ta
                };b = this.Pa.value;c = a.kind;
            switch (c) {
                case 0:
                    a = new(b ? yM : QN)(d, a, e);
                    break a;
                case 2:
                    a = new nN(d, a, e);
                    break a;
                default:
                    _.cb(c)
            }
            a = void 0
        }
        _.S(this, a);
        d = a.render();
        RN(this, this.B, d);
        this.B.top && this.B.top !== this.B && _.fk(this.B.top) && RN(this, this.B.top, d);
        this.v.notify();
        this.l.F(d);
        this.C.F(a.A())
    };
    var RN = function(a, b, c) {
        on(a, a.id, b, "message", function(d) {
            c.contentWindow === d.source && Cr(a.slotId, Hp, 824, d)
        })
    };
    var Es = function(a, b, c, d, e) {
        Z.call(this, a, 720);
        this.format = b;
        this.na = c;
        this.output = V(this);
        this.l = X(this, d);
        this.v = X(this, e)
    };
    _.T(Es, Z);
    Es.prototype.j = function() {
        var a = this.v.value;
        if (null == a) this.output.aa();
        else {
            var b = Math.round(.3 * this.na),
                c;
            2 !== this.format && 3 !== this.format || null == (c = this.l.value) || !_.L(c, 12, !1) || 0 >= b || a <= b ? this.output.F(a) : this.output.F(b)
        }
    };
    var Ms = function(a, b, c, d, e, f, g, h, k, l, m, n) {
        Z.call(this, a, 674);
        this.slotId = b;
        this.Z = c;
        this.v = d;
        this.V = f;
        this.L = g;
        this.output = V(this);
        this.O = 2 === e || 3 === e;
        this.l = W(this, h);
        this.K = W(this, k);
        this.G = X(this, l);
        this.C = X(this, m);
        n && bG(this, n)
    };
    _.T(Ms, Z);
    Ms.prototype.j = function() {
        var a = Co(this.Z, this.v),
            b = wi(this.slotId, this.V) || zn(this.l.value, Fi(this.slotId), a);
        this.K.value && !a && (b.style.display = "inline-block");
        this.O ? qI(this.L, this.slotId, function() {
            return void _.Yy(b)
        }) : _.mn(this, function() {
            return void _.Yy(b)
        });
        a = SN(this);
        0 < a && (b.style.paddingTop = a + "px");
        this.output.F(b)
    };
    var SN = function(a) {
        var b = a.l.value,
            c, d = null == (c = a.G.value) ? void 0 : c.height;
        if (b && !a.C.value && d) {
            var e;
            c = (null != (e = Bo(a.v, 23)) ? e : _.L(a.Z, 31)) ? Math.floor((b.offsetHeight - d) / 2) : 0
        } else c = 0;
        return c
    };
    var Cs = function(a, b) {
        Z.call(this, a, 859);
        this.B = b;
        this.output = V(this)
    };
    _.T(Cs, Z);
    Cs.prototype.j = function() {
        this.output.F(!_.fk(this.B.top))
    };
    var Ss = function(a, b, c) {
        Z.call(this, a, 840);
        this.format = b;
        this.V = c;
        this.output = V(this)
    };
    _.T(Ss, Z);
    Ss.prototype.j = function() {
        var a = [],
            b = this.V;
        b = void 0 === b ? document : b;
        var c;
        null != (c = b.featurePolicy) && (_.F = c.features(), _.A(_.F, "includes")).call(_.F, "attribution-reporting") && a.push("attribution-reporting");
        5 !== this.format && 4 !== this.format || !_.G(VA) || a.push("autoplay");
        a.length ? this.output.F(a.join(";")) : this.output.F("")
    };
    var zs = function(a, b, c, d) {
        Z.call(this, a, 1207);
        this.ra = c;
        this.slotId = d;
        bG(this, b)
    };
    _.T(zs, Z);
    zs.prototype.j = function() {
        Cr(this.ra, "impressionViewable", 715, new LL(this.slotId, "publisher_ads"))
    };
    var ys = function(a, b, c, d, e) {
        e = void 0 === e ? ws : e;
        Z.call(this, a, 1121);
        this.V = b;
        this.K = e;
        this.output = $F(this);
        this.C = !1;
        this.G = W(this, c);
        bG(this, d)
    };
    _.T(ys, Z);
    ys.prototype.j = function() {
        var a = this;
        if (this.v = this.K(yh(this.context, this.id, function(b) {
                b = _.z(b);
                for (var c = b.next(); !c.done; c = b.next()) c = 100 * c.value.intersectionRatio, _.A(Number, "isFinite").call(Number, c) && 50 <= c ? a.l || (a.C = !0, pF(a.V) || TN(a)) : (a.C = !1, UN(a))
            }))) _.mn(this, function() {
            var b;
            null == (b = a.v) || b.disconnect();
            UN(a)
        }), this.v.observe(this.G.value), this.O = on(this, this.id, this.V, "visibilitychange", function() {
            pF(a.V) ? UN(a) : a.C && !a.l && TN(a)
        })
    };
    var TN = function(a) {
            a.l = setTimeout(function() {
                a.l = void 0;
                if (!pF(a.V)) {
                    a.output.notify();
                    var b;
                    null == (b = a.v) || b.disconnect();
                    var c;
                    null == (c = a.O) || c.call(a)
                }
            }, 1E3)
        },
        UN = function(a) {
            clearTimeout(a.l);
            a.l = void 0
        };
    var bt = function(a, b, c, d, e, f) {
        f = void 0 === f ? Bs : f;
        Z.call(this, a, 783);
        var g = this;
        this.slotId = b;
        this.V = d;
        this.ra = e;
        this.C = f;
        this.l = this.v = -1;
        this.K = _.Wu(function() {
            Cr(g.ra, "slotVisibilityChanged", 716, new ML(g.slotId, "publisher_ads", g.l))
        }, 200);
        this.G = W(this, c);
        var h = new vn;
        fI(this.slotId).then(function() {
            return void h.notify()
        });
        bG(this, h)
    };
    _.T(bt, Z);
    bt.prototype.j = function() {
        var a = this,
            b = this.C(yh(this.context, this.id, function(c) {
                c = _.z(c);
                for (var d = c.next(); !d.done; d = c.next()) a.v = 100 * d.value.intersectionRatio, _.A(Number, "isFinite").call(Number, a.v) && VN(a)
            }));
        b && (b.observe(this.G.value), on(this, this.id, this.V, "visibilitychange", function() {
            VN(a)
        }), _.mn(this, function() {
            b.disconnect()
        }))
    };
    var VN = function(a) {
        var b = Math.floor(pF(a.V) ? 0 : a.v);
        if (0 > b || 100 < b || b === a.l ? 0 : -1 !== a.l || 0 !== b) a.l = b, a.K()
    };
    var Qs = function(a, b, c, d, e, f) {
        Z.call(this, a, 719);
        this.Z = b;
        this.v = c;
        this.output = V(this);
        this.l = W(this, d);
        this.C = W(this, e);
        this.G = X(this, f)
    };
    _.T(Qs, Z);
    Qs.prototype.j = function() {
        var a = this.l.value.kind;
        switch (a) {
            case 0:
                if (this.l.value.yb)
                    if (this.C.value) {
                        a = this.G.value;
                        var b = new Dl;
                        a = xj(b, 3, a);
                        _.L(Jl([a, this.Z.nc(), this.v.nc()]), 3) ? this.output.F(EH) : this.output.aa()
                    } else this.output.aa();
                else this.output.aa();
                break;
            case 2:
                this.output.aa();
                break;
            default:
                _.cb(a)
        }
    };
    var WN = function(a, b, c, d, e, f) {
        Z.call(this, a, 1119);
        this.slotId = b;
        this.v = c;
        this.documentElement = d;
        this.L = e;
        this.l = f;
        this.output = YF(this)
    };
    _.T(WN, Z);
    WN.prototype.j = function() {
        var a = _.af("INS");
        a.id = this.v;
        (_.F = [8, 9], _.A(_.F, "includes")).call(_.F, this.l) || _.Ki(a, {
            display: "none"
        });
        this.documentElement.appendChild(a);
        var b = function() {
            return void _.Yy(a)
        };
        (_.F = [2, 3], _.A(_.F, "includes")).call(_.F, this.l) ? qI(this.L, this.slotId, b) : _.mn(this, b);
        this.output.F(a)
    };
    var XN = function(a, b, c, d, e) {
        Z.call(this, a, 1120);
        this.G = b;
        this.v = c;
        this.Jc = d;
        this.l = e;
        this.output = YF(this);
        a = this.l;
        if (!_.ja(a) || !_.ja(a) || 1 !== a.nodeType || a.namespaceURI && "http://www.w3.org/1999/xhtml" !== a.namespaceURI) this.C = W(this, this.l)
    };
    _.T(XN, Z);
    XN.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.C) ? void 0 : a.value) ? b : this.l;
        if (!(_.F = [2, 3], _.A(_.F, "includes")).call(_.F, this.v)) {
            a = _.z(_.A(Array, "from").call(Array, c.childNodes));
            for (b = a.next(); !b.done; b = a.next()) b = b.value, 1 === b.nodeType && b.id !== this.G && _.Yy(b);
            this.Jc || (c.style.display = "")
        }
        this.output.F(c)
    };
    var Gs = function(a, b, c, d, e, f, g, h, k) {
        Bj.call(this);
        c ? (a = new XN(a, e, g, k, c), M(this, a), a = a.output) : 0 !== g && 1 !== g ? (a = new WN(a, b, d, f, h, g), M(this, a), a = a.output) : (b = new Qp(a, b, gI, function(l) {
            return l.detail
        }), M(this, b), a = new XN(a, e, g, k, b.output), M(this, a), a = a.output);
        this.j = {
            output: a
        }
    };
    _.T(Gs, Bj);
    var YN = function(a, b) {
            var c = Hi();
            this.context = a;
            this.L = b;
            this.j = c
        },
        ZN = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y) {
            var x = document,
                C = window;
            e || f || yI(a.L, d);
            var I = jt(a.context, b, a.j, c, d, e, f, g, h, k, l, x, m, n, p, r, w, function() {
                yI(a.L, d);
                xI(a.L, d, I)
            }, u, y);
            f || xI(a.L, d, I);
            _.mn(d, function() {
                yI(a.L, d)
            });
            C.top !== C && C.addEventListener("pagehide", function(D) {
                D.persisted || yI(a.L, d)
            });
            Kj(I)
        };
    var $N = function(a, b, c, d) {
        Z.call(this, a, 884);
        this.wa = b;
        this.bb = c;
        this.v = V(this);
        this.l = W(this, d)
    };
    _.T($N, Z);
    $N.prototype.j = function() {
        yK(this.bb, _.Ll(this.wa, "__gads", this.l.value));
        Nl(20, this.context, this.wa, this.l.value);
        Nl(2, this.context, this.wa, this.l.value);
        this.v.F(_.If())
    };
    var lt = 0,
        aO = new _.gi(-9, -9);
    var ot = new _.v.Set([function(a, b) {
        var c = a.ka.P.Z;
        b.set("pvsid", {
            value: a.ja.context.pvsid
        }).set("correlator", {
            value: c.getCorrelator()
        })
    }, function(a, b) {
        a = a.Yi;
        var c = a.kd;
        "wbn" === a.Xe && b.set("wbsu", {
            value: c
        })
    }, function(a, b) {
        var c = a.ka.P.Z,
            d = a.km;
        a = d.cd;
        d = d.bd;
        var e = _.L(c, 21);
        b = b.set("hxva", {
            value: e ? 1 : null
        }).set("cmsid", {
            value: e ? _.sj(c, 23) : null
        }).set("vid", {
            value: e ? _.sj(c, 22) : null
        }).set("pod", {
            value: d
        }).set("ppos", {
            value: a
        });
        a = b.set;
        c = Pw(c, 29);
        a.call(b, "scor", {
            value: null == c ? void 0 : c
        })
    }, function(a, b) {
        var c = a.ka,
            d = c.W,
            e = c.P.R;
        c = a.vl;
        var f = c.zk,
            g = c.uk;
        b.set("eid", {
            value: a.ja.Tf
        }).set("debug_experiment_id", {
            value: QE().split(",")
        }).set("expflags", {
            value: _.ci(253) ? _.Vf(mB) || null : null
        }).set("pied", {
            value: function() {
                var h = new kG,
                    k = !1,
                    l = !1;
                f && (k = !0, yj(h, 1, Px, f));
                var m = d.map(function(p) {
                    var r = new iG,
                        w;
                    p = null == (w = e[p.getDomId()]) ? void 0 : Uh(w, Px, 27);
                    if (null == p || !p.length) return r;
                    l = k = !0;
                    w = _.z(p);
                    for (p = w.next(); !p.done; p = w.next()) yj(r, 1, Px, p.value);
                    return r
                });
                l && _.gl(h, 2, m);
                m = _.z(null != g ? g : []);
                for (var n = m.next(); !n.done; n = m.next()) yj(h, 1, Px, n.value), k = !0;
                return k ? zb(h.j(), 3) : null
            }()
        })
    }, function(a, b) {
        var c = a.ja,
            d = c.context;
        c = c.Va;
        b.set("output", {
            value: a.Yi.Xe
        }).set("gdfp_req", {
            value: 1
        }).set("vrg", {
            value: d.wc ? String(d.wc) : d.fb
        }).set("ptt", {
            value: 17
        }).set("impl", {
            value: c ? "fifs" : "fif"
        })
    }, function(a, b) {
        var c = a.ja.X;
        a = vt(a.ka.P.Z) || new OG;
        var d = _.Ak(a, 6, 2);
        b.set("rdp", {
            value: _.L(a, 1) ? "1" : null
        }).set("ltd", {
            value: _.L(a, 9) ? "1" : null
        }).set("gdpr_consent", {
            value: Yw(c, 2)
        }).set("gdpr", {
            value: null != Il(c, 3) ? _.L(c, 3) ? "1" : "0" : null,
            options: {
                Fa: !0
            }
        }).set("addtl_consent", {
            value: Yw(c, 4)
        }).set("tcfe", {
            value: Zw(c, 7)
        }).set("us_privacy", {
            value: Yw(c, 1)
        }).set("npa", {
            value: _.L(c, 6) || _.L(a, 8) ? 1 : null
        }).set("puo", {
            value: _.G(KB) && _.L(a, 13) ? 1 : null
        }).set("tfua", {
            value: 2 !== d ? d : null,
            options: {
                Fa: !0
            }
        }).set("tfcd", {
            value: null != bo(a, 5) ? _.Ak(a, 5, 0) : null,
            options: {
                Fa: !0
            }
        }).set("trt", {
            value: null != bo(a, 10) ? _.Ak(a, 10, 0) : null,
            options: {
                Fa: !0
            }
        }).set("tad", {
            value: null != Il(c, 8) ? _.L(c, 8) ? "1" : "0" : null,
            options: {
                Fa: !0
            }
        }).set("gpp", {
            value: Yw(c, 11)
        }).set("gpp_sid", {
            value: Qw(c, 10).join(",") || void 0
        })
    }, function(a, b) {
        var c = a.ka,
            d = c.P,
            e = c.W,
            f = c.cg,
            g = a.ja.B;
        a = {
            Ba: "~"
        };
        var h = e.map(function(l) {
                return d.R[l.getDomId()]
            }),
            k = [];
        c = e.map(function(l) {
            return l.getAdUnitPath().replace(/,/g, ":").split("/").map(function(m) {
                if (!m) return "";
                var n = _.A(k, "findIndex").call(k, function(p) {
                    return p === m
                });
                return 0 <= n ? n : k.push(m) - 1
            }).join("/")
        });
        b.set("iu_parts", {
            value: k
        }).set("enc_prev_ius", {
            value: c
        }).set("prev_iu_szs", {
            value: h.map(function(l) {
                return $h(l)
            })
        }).set("fluid", {
            value: function() {
                var l = !1,
                    m = h.map(function(n) {
                        n = (_.F = Zh(n), _.A(_.F, "includes")).call(_.F, "fluid");
                        l || (l = n);
                        return n ? "height" : "0"
                    });
                return l ? m : null
            }()
        }).set("ifi", {
            value: function() {
                var l = Zi(g);
                if (!f) {
                    l += 1;
                    var m = g,
                        n = e.length;
                    n = void 0 === n ? 1 : n;
                    m = Jz(Re(m)) || m;
                    m.google_unique_id = (m.google_unique_id || 0) + n
                }
                return l
            }()
        }).set("didk", {
            value: _.G(PB) ? wo(e, function(l) {
                return _.Rf(l.getDomId())
            }, a) : null,
            options: _.A(Object, "assign").call(Object, {}, a, {
                Qb: !0
            })
        })
    }, function(a, b) {
        var c = a.ka;
        a = c.W;
        c = c.P;
        var d = c.Z,
            e = c.R;
        b.set("sfv", {
            value: TJ ? TJ : TJ = yl()
        }).set("fsfs", {
            value: wo(a, function(f) {
                f = e[f.getDomId()];
                var g;
                return Number(null != (g = null == f ? void 0 : Bo(f, 12)) ? g : Il(d, 13))
            }, {
                qd: 0
            }),
            options: {
                Ba: ",",
                ld: 0,
                Qb: !0
            }
        }).set("fsbs", {
            value: wo(a, function(f) {
                f = e[f.getDomId()].nc();
                var g = d.nc(),
                    h;
                return (null != (h = null == f ? void 0 : Bo(f, 3)) ? h : null == g ? 0 : _.L(g, 3)) ? 1 : 0
            }, {
                qd: 0
            }),
            options: {
                ld: 0,
                Qb: !0
            }
        })
    }, function(a, b) {
        var c = a.ja.L;
        a = a.ka;
        var d = a.cg;
        b.set("rcs", {
            value: wo(a.W, function(e) {
                if (!d) {
                    var f = c.j.get(e);
                    f && f.Ai++
                }
                return wI(c, e)
            }, {
                qd: 0
            }),
            options: {
                ld: 0,
                Qb: !0
            }
        })
    }, function(a, b) {
        var c = a.ka;
        a = a.ja.Va;
        c = c.P.R[c.W[0].getDomId()];
        b.set("click", {
            value: !a && c.getClickUrl() ? _.sj(c, 7) : null
        })
    }, function(a, b, c) {
        var d = a.ka,
            e = d.W,
            f = d.P.R;
        a = a.ja;
        var g = a.X,
            h = a.B;
        c = void 0 === c ? function(n, p) {
            return Af(n, p)
        } : c;
        a = e.map(function(n) {
            return f[n.getDomId()]
        });
        var k, l, m;
        b.set("ists", {
            value: to(a, function(n) {
                var p;
                if (p = 0 !== Fs(n)) n = Fs(n), p = !(8 === n || 9 === n);
                return p
            }) || null
        }).set("fas", {
            value: wo(a, function(n) {
                return So(Fs(n))
            }, {
                qd: 0
            }),
            options: {
                ld: 0,
                Qb: !0
            }
        }).set("itsi", {
            value: e.some(function(n) {
                var p;
                return !jL(n) && 5 === (null == (p = f[n.getDomId()]) ? void 0 : Fs(p))
            }) ? function() {
                var n = c(g, h);
                if (!n) return 1;
                var p;
                n = Math.max.apply(Math, _.ch(null != (p = _.Qo(n, 604800)) ? p : []));
                return isFinite(n) ? Math.floor(Math.max((Date.now() - n) / 6E4, 1)) : null
            }() : null
        }).set("fsapi", {
            value: to(a, function(n) {
                return 5 === Fs(n) && _.G(_.vB)
            }) || null
        }).set("ifs", {
            value: null != (m = null == (k = (_.F = _.A(Object, "values").call(Object, f), _.A(_.F, "find")).call(_.F, function(n) {
                return Bn(n, hK, 29)
            })) ? void 0 : null == (l = _.Qh(k, hK, 29)) ? void 0 : tk(l)) ? m : null
        })
    }, function(a, b) {
        a = a.ka;
        var c = a.P.R;
        a = a.W.map(function(d) {
            return c[d.getDomId()]
        });
        b.set("rbvs", {
            value: to(a, function(d) {
                return 4 === Fs(d)
            }) || null
        })
    }, function(a, b) {
        var c = a.ka,
            d = a.ja;
        a = d.isSecureContext;
        d = d.B;
        var e = b.set;
        var f = c.W;
        var g = c.P;
        c = c.Vb;
        var h = g.Z,
            k = g.R,
            l = new Si;
        l.set(0, 1 !== c);
        k = k[f[0].getDomId()];
        l.set(1, !!_.L(k, 17));
        l.set(2, xp(f, g));
        l.set(3, _.L(h, 27) || !1);
        l.set(4, 3 === c);
        f = Ui(l);
        e.call(b, "eri", {
            value: f
        }).set("gct", {
            value: pp("google_preview", d)
        }).set("sc", {
            value: a ? 1 : 0,
            options: {
                Fa: !0
            }
        })
    }, function(a, b) {
        var c = a.ja,
            d = c.B,
            e = c.X;
        c = c.wa;
        var f = up(a.ka.P.Z.Na()),
            g = _.Ll(c, "__gads", e);
        a = "1" === _.Ll(c, "__gpi_opt_out", e) ? "1" : null;
        b = b.set("cookie", {
            value: g,
            options: {
                Fa: !0
            }
        }).set("cookie_enabled", {
            value: !g && YE(c, e) ? "1" : null
        });
        g = d.document;
        var h = g.domain;
        d = b.set.call(b, "cdm", {
            value: (f || ei(d)) === g.URL ? "" : h
        });
        f = d.set;
        e = (e = _.Ll(c, "__gpi", e)) && !_.A(e, "includes").call(e, "&") ? e : null;
        f.call(d, "gpic", {
            value: e
        }).set("pdopt", {
            value: a
        })
    }, function(a, b) {
        a = a.ja.B;
        b.set("arp", {
            value: qn(a) ? 1 : null
        }).set("abxe", {
            value: _.fk(a.top) || qz(a.IntersectionObserver) ? 1 : null
        })
    }, function(a, b) {
        var c = a.ja.B;
        a = up(a.ka.P.Z.Na());
        b.set("dt", {
            value: (new Date).getTime()
        });
        if (!a) {
            try {
                var d = Math.round(Date.parse(c.document.lastModified) / 1E3) || null
            } catch (e) {
                d = null
            }
            b.set("lmt", {
                value: d
            })
        }
    }, function(a, b) {
        var c = a.ka,
            d = c.P;
        c = c.W;
        var e = a.ja;
        a = e.B;
        var f = e.Va;
        e = Yh(!0, a);
        for (var g = d.Z, h = a.document, k = d.R, l = [], m = [], n = _.z(c), p = n.next(); !p.done; p = n.next()) {
            p = p.value;
            var r = k[p.getDomId()];
            p = Di(p, r, h, Co(g, r));
            r = void 0;
            var w = f ? null != (r = p) ? r : aO : p;
            w && (l.push(Math.round(w.x)), m.push(Math.round(w.y)))
        }
        e && (d.dd = e);
        f = di(a) ? null : Yh(!1, a);
        try {
            var u = a.top;
            var y = kt(u.document, u)
        } catch (x) {
            y = new _.gi(-12245933, -12245933)
        }
        b.set("adxs", {
            value: l,
            options: {
                Fa: !0
            }
        }).set("adys", {
            value: m,
            options: {
                Fa: !0
            }
        }).set("biw", {
            value: e ? e.width : null
        }).set("bih", {
            value: e ? e.height : null
        }).set("isw", {
            value: e ? null == f ? void 0 : f.width : null
        }).set("ish", {
            value: e ? null == f ? void 0 : f.height : null
        }).set("scr_x", {
            value: Math.round(y.x),
            options: {
                Fa: !0
            }
        }).set("scr_y", {
            value: Math.round(y.y),
            options: {
                Fa: !0
            }
        }).set("btvi", {
            value: mt(c, a, d),
            options: {
                Fa: !0,
                Ba: "|"
            }
        })
    }, function(a, b) {
        var c = a.ja.L;
        b.set("ucis", {
            value: a.ka.W.map(function(d) {
                d = c.j.get(d);
                null != d.ae || (d.ae = window === window.top ? (++c.M).toString(36) : Ky());
                return d.ae
            }),
            options: {
                Ba: "|"
            }
        }).set("oid", {
            value: 2
        })
    }, function(a, b) {
        a = a.ka;
        var c = a.W,
            d = a.P,
            e = d.R;
        a = new _.v.Map;
        d = _.z(d.Z.Na());
        for (var f = d.next(); !f.done; f = d.next()) {
            var g = f.value;
            a.set(_.R(g, 1), [_.bl(g, 2)[0]])
        }
        for (d = 0; d < c.length; d++)
            if (g = e[c[d].getDomId()])
                for (g = _.z(g.Na()), f = g.next(); !f.done; f = g.next()) {
                    var h = f.value;
                    f = _.R(h, 1);
                    var k = a.get(f) || [];
                    h = _.bl(h, 2)[0];
                    1 === c.length ? k[0] = h : h !== k[0] && (k[d + 1] = h);
                    a.set(f, k)
                }
        c = [];
        e = _.z(_.A(a, "keys").call(a));
        for (d = e.next(); !d.done; d = e.next()) g = d.value, d = rl()[g], g = a.get(g), d && g && (1 < g.length ? (g = g.map(function(l) {
            return encodeURIComponent(l || "")
        }).join(), c.push(d + "," + g)) : 1 === g.length && "url" !== d && b.set(d, {
            value: g[0]
        }));
        c.length && b.set("sps", {
            value: c,
            options: {
                Ba: "|"
            }
        })
    }, function(a, b) {
        a = a.ja.B;
        var c, d, e, f, g, h, k;
        var l = a;
        l = void 0 === l ? Fy : l;
        try {
            var m = l.history.length
        } catch (I) {
            m = 0
        }
        b = b.set("u_his", {
            value: m
        }).set("u_h", {
            value: null == (c = a.screen) ? void 0 : c.height
        }).set("u_w", {
            value: null == (d = a.screen) ? void 0 : d.width
        }).set("u_ah", {
            value: null == (e = a.screen) ? void 0 : e.availHeight
        }).set("u_aw", {
            value: null == (f = a.screen) ? void 0 : f.availWidth
        }).set("u_cd", {
            value: null == (g = a.screen) ? void 0 : g.colorDepth
        });
        c = b.set;
        d = a;
        d = void 0 === d ? _.t : d;
        d = d.devicePixelRatio;
        c = c.call(b, "u_sd", {
            value: "number" === typeof d ? +d.toFixed(3) : null
        }).set("u_tz", {
            value: -(new Date).getTimezoneOffset()
        }).set("dmc", {
            value: null != (k = null == (h = a.navigator) ? void 0 : h.deviceMemory) ? k : null
        });
        h = c.set;
        k = a;
        k = void 0 === k ? _.t : k;
        d = new Si;
        "SVGElement" in k && "createElementNS" in k.document && d.set(0);
        e = pz();
        e["allow-top-navigation-by-user-activation"] && d.set(1);
        e["allow-popups-to-escape-sandbox"] && d.set(2);
        k.crypto && k.crypto.subtle && d.set(3);
        "TextDecoder" in k && "TextEncoder" in k && d.set(4);
        k = Ui(d);
        h = h.call(c, "bc", {
            value: k
        });
        k = h.set;
        a: {
            try {
                var n, p, r = null == (n = a.performance) ? void 0 : null == (p = n.getEntriesByType("navigation")) ? void 0 : p[0];
                if (null == r ? 0 : r.type) {
                    var w;
                    var u = null != (w = iF.get(r.type)) ? w : null;
                    break a
                }
            } catch (I) {}
            var y, x, C;u = null != (C = jF.get(null == (y = a.performance) ? void 0 : null == (x = y.navigation) ? void 0 : x.type)) ? C : null
        }
        u = k.call(h, "nvt", {
            value: u
        });
        n = u.set;
        p = _.Uf(ZA);
        p = 0 === p ? null : Dz(a, 2 === p);
        u = n.call(u, "bz", {
            value: p
        });
        n = u.set;
        _.G(RB) ? a = Ma() && Bk(a) ? a.document.documentElement.lang : void 0 : a = null;
        n.call(u, "tl", {
            value: a
        })
    }, function(a, b) {
        (a = _.ci(251)) && b.set("uach", {
            value: rw(a, 3)
        })
    }, function(a, b) {
        a = a.ja;
        if (!a.Ib) {
            var c;
            if (a = null == (c = a.B.navigator) ? void 0 : c.userActivation) {
                c = 0;
                if (null == a ? 0 : a.hasBeenActive) c |= 1;
                if (null == a ? 0 : a.isActive) c |= 2
            } else c = void 0;
            c && b.set("uas", {
                value: c
            })
        }
    }, function(a, b) {
        var c = a.ja,
            d = c.B,
            e = c.L;
        c = c.Va;
        a = a.ka;
        var f = a.W;
        a = a.P;
        var g = a.Z,
            h = a.R;
        a = qp("google_preview", d);
        var k = d.document,
            l = a ? vp(k.URL) : k.URL;
        k = a ? vp(k.referrer) : k.referrer;
        a = !1;
        if (c) c = up(g.Na());
        else {
            var m;
            c = null != (m = up(h[f[0].getDomId()].Na())) ? m : up(g.Na())
        }
        if (null != c) {
            var n = l;
            di(d) || (k = "", a = !0)
        } else c = l;
        m = wp(d);
        b.set("nhd", {
            value: m || null
        }).set("url", {
            value: c
        }).set("loc", {
            value: null !== n && n !== c ? n : null
        }).set("ref", {
            value: k
        });
        if (m) {
            n = b.set;
            var p, r;
            m = _.fk(d.top) && (null == (p = d.top) ? void 0 : null == (r = p.location) ? void 0 : r.href);
            var w;
            p = null == (w = d.location) ? void 0 : w.ancestorOrigins;
            d = Fk(d) || "";
            w = (null == p ? void 0 : p[p.length - 1]) || "";
            d = (d = m || d || w) ? a ? ez(d.match(_.dz)[3] || null) : d : null;
            n.call(b, "top", {
                value: d
            }).set("etu", {
                value: e.te
            })
        }
    }, function(a, b) {
        a = a.ja.context.pvsid;
        b.set("rumc", {
            value: _.G(kC) || _.Ff(Ah).j ? a : null
        }).set("rume", {
            value: _.G(jC) ? 1 : null
        })
    }, function(a, b) {
        b.set("vis", {
            value: _.iq(a.ja.B.document)
        })
    }, function(a, b) {
        var c = a.ka,
            d = c.W;
        c = c.P;
        a = a.ja.B;
        var e = Dn(d, c.R, c.Z),
            f = Gn(d, e, a);
        c = f.cl;
        f = f.Ql;
        var g = Jn(d, e, a),
            h = g.pk;
        g = g.bl;
        null != GK || (GK = Hk(a));
        var k = !1;
        d = d.map(function(m) {
            var n;
            m = null != (n = e.get(m)) ? n : 0;
            if (0 === m) return null;
            k = !0;
            return 2 === m ? "1" : "0"
        });
        var l;
        b.set("aee", {
            value: k ? d : null,
            options: {
                Ba: "|"
            }
        }).set("psz", {
            value: c,
            options: {
                Ba: "|"
            }
        }).set("msz", {
            value: f,
            options: {
                Ba: "|"
            }
        }).set("fws", {
            value: h,
            options: {
                Fa: !0
            }
        }).set("ohw", {
            value: g,
            options: {
                Fa: !0
            }
        }).set("ea", {
            value: GK ? null : "0",
            options: {
                Fa: !0
            }
        }).set("efat", {
            value: "#flexibleAdSlotTest" === (null == (l = a.location) ? void 0 : l.hash) ? "1" : null
        })
    }, function(a, b) {
        b.set("psts", {
            value: vI(a.ja.L, a.ka.W)
        })
    }, function(a, b) {
        var c = a.ja;
        a = c.X;
        c = c.B;
        var d;
        var e = c.document.domain,
            f = null != (d = zf(a) && Bf(c) ? c.document.cookie : null) ? d : "",
            g = c.history.length,
            h = c.screen,
            k = c.document.referrer;
        if (Re()) var l = window.gaGlobal || {};
        else {
            var m = Math.round((new Date).getTime() / 1E3),
                n = c.google_analytics_domain_name;
            e = "undefined" == typeof n ? pE("auto", e) : pE(n, e);
            var p = -1 < f.indexOf("__utma=" + e + "."),
                r = -1 < f.indexOf("__utmb=" + e);
            (d = (Jz() || window).gaGlobal) || (d = {}, (Jz() || window).gaGlobal = d);
            var w = !1;
            if (p) {
                var u = f.split("__utma=" + e + ".")[1].split(";")[0].split(".");
                r ? d.sid = u[3] : d.sid || (d.sid = m + "");
                d.vid = u[0] + "." + u[1];
                d.from_cookie = !0
            } else {
                d.sid || (d.sid = m + "");
                if (!d.vid) {
                    w = !0;
                    r = Math.round(2147483647 * Math.random());
                    p = nE.appName;
                    var y = nE.version,
                        x = nE.language ? nE.language : nE.browserLanguage,
                        C = nE.platform,
                        I = nE.userAgent;
                    try {
                        u = nE.javaEnabled()
                    } catch (D) {
                        u = !1
                    }
                    u = [p, y, x, C, I, u ? 1 : 0].join("");
                    h ? u += h.width + "x" + h.height + h.colorDepth : _.t.java && _.t.java.awt && (h = _.t.java.awt.Toolkit.getDefaultToolkit().getScreenSize(), u += h.screen.width + "x" + h.screen.height);
                    u = u + f + (k || "");
                    for (k = u.length; 0 < g;) u += g-- ^ k++;
                    d.vid = (r ^ oE(u) & 2147483647) + "." + m
                }
                d.from_cookie || (d.from_cookie = !1)
            }
            if (!d.cid) {
                b: for (m = 999, n && (n = 0 == n.indexOf(".") ? n.substr(1) : n, m = n.split(".").length), n = 999, f = f.split(";"), u = 0; u < f.length; u++)
                    if (k = qE.exec(f[u]) || rE.exec(f[u]) || sE.exec(f[u])) {
                        h = k[1] || 0;
                        if (h == m) {
                            l = k[2];
                            break b
                        }
                        h < n && (n = h, l = k[2])
                    }w && l && -1 != l.search(/^\d+\.\d+$/) ? (d.vid = l, d.from_cookie = !0) : l != d.vid && (d.cid = l)
            }
            d.dh = e;
            d.hid || (d.hid = Math.round(2147483647 * Math.random()));
            l = d
        }
        e = l.sid;
        d = l.hid;
        w = l.from_cookie;
        f = l.cid;
        w && !zf(a) || b.set("ga_vid", {
            value: l.vid
        }).set("ga_sid", {
            value: e
        }).set("ga_hid", {
            value: d
        }).set("ga_fc", {
            value: w
        }).set("ga_cid", {
            value: f
        }).set("ga_wpids", {
            value: c.google_analytics_uacct
        })
    }, function(a, b) {
        var c = a.ja.B,
            d = a.fm;
        a = d.Eg;
        d = d.Be;
        if (!_.G(mC)) {
            Nf(c.isSecureContext, c.navigator, c.document) && b.set("td", {
                value: 1
            });
            if (a) switch (a.kind) {
                case 0:
                    b.set("eig", {
                        value: a.signal
                    });
                    break;
                case 1:
                    b.set("eigir", {
                        value: a.reason,
                        options: {
                            Fa: !0
                        }
                    });
                    break;
                default:
                    _.cb(a)
            }
            void 0 !== d && b.set("egid", {
                value: d,
                options: {
                    Fa: !0
                }
            })
        }
    }, function(a, b) {
        var c = a.ja.B,
            d = a.Vl;
        a = d.Yl;
        d = d.Wl;
        Of(c.isSecureContext, c.document) && (b.set("topics", {
            value: a instanceof Uint8Array ? zb(a, 3) : a
        }), !a || a instanceof Uint8Array || b.set("tps", {
            value: a
        }), d && b.set("htps", {
            value: d
        }))
    }, function(a, b) {
        var c = a.ja,
            d = c.B,
            e = c.X,
            f = a.ka.W;
        c = a.Fl;
        a = c.af;
        var g = c.dk,
            h = c.Wk;
        if (!_.G(gB)) {
            c = b.set;
            d = Af(e, d);
            f = eh(f[0].getAdUnitPath());
            e = new ky;
            g = null != g ? g : [];
            if (f && a && g && "function" === typeof a.getUserIdsAsEidBySource) {
                if ("function" === typeof a.getUserIdsAsEids) try {
                    for (var k = _.z(a.getUserIdsAsEids()), l = k.next(); !l.done; l = k.next()) {
                        var m = l.value;
                        "string" === typeof m.source && oj(52, m.source)
                    }
                } catch (w) {
                    var n;
                    oj(45, "", null == (n = w) ? void 0 : n.message)
                }
                k = _.z(g);
                for (l = k.next(); !l.done; l = k.next())
                    if (l = l.value, String(_.R(l, 1)) === f)
                        for (l = _.z(Uh(l, Cx, 2)), m = l.next(); !m.done; m = l.next())
                            if (m = m.value, _.L(m, zk(m, Dx, 3)) && (m = _.R(m, 1), !tj(e, m))) {
                                n = null;
                                try {
                                    var p = g = void 0,
                                        r = void 0;
                                    n = null == (g = a.getUserIdsAsEidBySource(m)) ? void 0 : null == (p = g.uids) ? void 0 : null == (r = p[0]) ? void 0 : r.id
                                } catch (w) {
                                    g = void 0, oj(45, m, null == (g = w) ? void 0 : g.message)
                                }
                                n && (300 < n.length ? (g = {}, oj(12, m, null, (g.sl = String(n.length), g.fp = "1", g))) : (g = fy(m), g = On(g, 2, n), g = xj(g, 11, !0), yj(e, 2, rj, g), g = {}, oj(19, m, null, (g.fp = "1", g.hs = n ? "1" : "0", g))))
                            }
            }
            zj(e, d, f, h);
            Uh(e, rj, 2).length ? (oj(50, ""), a = zb(e.j(), 3)) : a = null;
            c.call(b, "a3p", {
                value: a
            })
        }
    }, function(a, b) {
        var c = a.jb.ge,
            d = a.ka.W;
        a = {
            Ba: "~"
        };
        var e = function() {
            return c ? d.map(function(f) {
                return c.get(f)
            }) : []
        }();
        b.set("cbidsp", {
            value: wo(e, function(f) {
                return zb(f.j(), 3)
            }, a),
            options: _.A(Object, "assign").call(Object, {}, a, {
                Qb: !0
            })
        })
    }, function(a, b) {
        a = a.ka.P.Z;
        Bn(a.Ge(), js, 1) && (a = is(a.Ge(), js, 1), b.set("cmrv", {
            value: 1
        }).set("cmrq", {
            value: _.R(a, 1)
        }).set("cmrc", {
            value: _.bl(a, 2),
            options: {
                Ba: ">"
            }
        }).set("cmrids", {
            value: _.bl(a, 3),
            options: {
                Ba: "!"
            }
        }).set("cmrf", {
            value: _.R(a, 4)
        }))
    }, function(a, b) {
        var c = [];
        a = _.z(Uh(is(a.ka.P.Z.Ge(), ls, 2), aq, 1));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, _.bl(d, 2).length && c.push(_.Ak(d, 1, 0) + 2 + "=" + _.bl(d, 2).join("|"));
        b.set("pps", {
            value: c,
            options: {
                Ba: "~"
            }
        })
    }, function(a, b) {
        b.set("scar", {
            value: a.fl.yk
        })
    }, function(a, b) {
        a = a.ja.B;
        a = !(!a.isSecureContext || !Jf("attribution-reporting", a.document));
        !_.G(iC) && a && b.set("nt", {
            value: 1
        })
    }, function(a, b) {
        if (a = a.rl.ql) a = rw(tk(a), 3), b.set("psd", {
            value: a
        })
    }, function(a, b) {
        a = _.Pg(a.ja.B);
        var c = yp;
        0 < a && c >= a && b.set("dlt", {
            value: a
        }).set("idt", {
            value: c - a
        })
    }, function(a, b) {
        a = a.ka.P.Z;
        b.set("ppid", {
            value: null != _.sj(a, 16) ? _.R(a, 16) : null,
            options: {
                Fa: !0
            }
        })
    }, function(a, b) {
        var c = b.set;
        (a = _.sj(a.ka.P.Z, 8)) ? (50 < a.length && (a = a.substring(0, 50)), a = "a " + rw('role:1 producer:12 loc:"' + a + '"')) : a = "";
        c.call(b, "uule", {
            value: a
        })
    }, function(a, b) {
        a = a.ka;
        var c = a.P.Z;
        b.set("prev_scp", {
            value: Rq(a.W, a.P),
            options: {
                Qb: !0,
                Ba: "|"
            }
        }).set("cust_params", {
            value: Tq(c),
            options: {
                Ba: "&"
            }
        })
    }, function(a, b) {
        var c = a.ka,
            d = c.P;
        a = a.ja;
        var e = a.L,
            f = a.Va;
        b.set("adks", {
            value: c.W.map(function(g) {
                if (f) {
                    var h = d.R[g.getDomId()];
                    h = jn(h);
                    if (g = e.j.get(g)) g.fd = h;
                    return h
                }
                h = d.Z;
                var k = d.R[g.getDomId()],
                    l;
                if (!(l = dt(e, g))) {
                    h = jn(k, _.L(h, 6) || _.L(k, 17) ? null : xi(g));
                    if (g = e.j.get(g)) g.fd = h;
                    l = h
                }
                return l
            })
        })
    }, function(a, b) {
        var c = b.set;
        a = a.ja.B;
        var d = Cz(a);
        var e = Gk(a, a.google_ad_width, a.google_ad_height);
        var f = d.location.href;
        if (d === d.top) f = !0;
        else {
            var g = !1,
                h = d.document;
            h && h.referrer && (f = h.referrer, d.parent === d.top && (g = !0));
            (d = d.location.ancestorOrigins) && (d = d[d.length - 1]) && -1 === f.indexOf(d) && (g = !1);
            f = g
        }
        g = a.top == a ? 0 : _.fk(a.top) ? 1 : 2;
        d = 4;
        e || 1 != g ? e || 2 != g ? e && 1 == g ? d = 7 : e && 2 == g && (d = 8) : d = 6 : d = 5;
        f && (d |= 16);
        e = "" + d;
        if (a != a.top)
            for (; a && a != a.top && _.fk(a) && !a.sf_ && !a.$sf && !a.inGptIF && !a.inDapIF; a = a.parent);
        c.call(b, "frm", {
            value: e || null
        })
    }, function(a, b) {
        b.set("ppt", {
            value: Rd(a.ka.P.Z, 35, Jc),
            options: {
                Ba: "~"
            }
        })
    }, function(a, b) {
        a = a.ja.B;
        try {
            var c, d, e = null == (c = a.external) ? void 0 : null == (d = c.getHostEnvironmentValue) ? void 0 : d.call(c, "os-mode");
            if (e) {
                var f = Number(JSON.parse(e)["os-mode"]);
                0 > f || b.set("wsm", {
                    value: f + 1
                })
            }
        } catch (g) {}
    }, function(a, b) {
        var c = a.ka;
        a = c.P.R;
        var d = [],
            e = !1;
        c = _.z(c.W);
        for (var f = c.next(); !f.done; f = c.next()) {
            var g = void 0;
            (null == (g = a[f.value.getDomId()]) ? 0 : _.L(g, 30)) ? (d.push("1"), e = !0) : d.push("")
        }
        b.set("is_cau", {
            value: e ? d : null
        })
    }, function(a, b) {
        var c = a.ka,
            d = c.P.R;
        a = a.ja.B;
        var e = [],
            f = !1;
        c = _.z(c.W);
        for (var g = c.next(); !g.done; g = c.next()) g = Fs(d[g.value.getDomId()]), (_.F = [8, 9], _.A(_.F, "includes")).call(_.F, g) ? (f = 9 === g ? "right" : "left", e.push(_.ah(a).sideRailPlasParam.get(f)), f = !0) : e.push("");
        f && b.set("plas", {
            value: e,
            options: {
                Ba: "|"
            }
        })
    }, function(a, b) {
        a = a.ja;
        var c = a.X;
        a = a.wa;
        _.G(bB) && !_.L(c, 8) && (c = new SE, c = xj(c, 5, !0), (a = _.Ll(a, "__eoi", c)) && b.set("eo_id_str", {
            value: a
        }))
    }]);
    var bO = function(a, b, c) {
        Z.call(this, a, 798);
        this.output = V(this);
        this.l = X(this, b);
        this.v = W(this, c)
    };
    _.T(bO, Z);
    bO.prototype.j = function() {
        var a = this,
            b = new _.v.Map;
        if (this.l.value) {
            var c = this.l.value,
                d = c.ja.Va,
                e = c.jb.ge;
            c = _.z(c.ka.W);
            for (var f = c.next(); !f.done; f = c.next()) {
                f = f.value;
                var g = void 0,
                    h = null == (g = e) ? void 0 : g.get(f);
                b.set(f, d ? cO(this, f, h) : function() {
                    return a.v.value
                })
            }
        }
        this.output.F(b)
    };
    var cO = function(a, b, c) {
        return yi(function() {
            var d = _.A(Object, "assign").call(Object, {}, a.l.value);
            d.ka.cg = !0;
            d.ka.W = [b];
            c && (d.jb.ge = new _.v.Map, d.jb.ge.set(b, c));
            return op(ut(d)).url
        })
    };
    var dO = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 810);
        this.v = b;
        this.Va = c;
        this.P = d;
        this.T = e;
        this.B = f;
        this.X = g;
        this.l = V(this)
    };
    _.T(dO, Z);
    dO.prototype.j = function() {
        var a = this,
            b = this.v;
        !this.Va && 1 < this.v.length && (b = [b[0]]);
        b = b.filter(function(c) {
            if (c.J) return !1;
            var d = a.P.R[c.getDomId()],
                e;
            if (e = !(Wo(Fs(d)) && (_.F = Wf(DB), _.A(_.F, "includes")).call(_.F, String(Fs(d))))) e = a.T, tg(a.B) && 4 === Fs(d) ? (P(e, iJ("googletag.enums.OutOfPageFormat.REWARDED", String(c.getAdUnitPath()))), e = !0) : e = !1, e = !e;
            if (e) {
                e = a.T;
                var f = a.B,
                    g = a.X;
                d = Fs(d);
                5 !== d ? c = !1 : (f = Ro(f, !jL(c), g), (f &= -134217729) && Go(e, f, d, c.getAdUnitPath()), c = !!f);
                e = !c
            }
            return e
        });
        30 < b.length && (P(this.T, hJ("30", String(b.length), String(b.length - 30))), b = b.slice(0, 30));
        this.l.F(b)
    };
    var eO = function(a, b, c) {
        Z.call(this, a, 919);
        this.l = b;
        this.X = c;
        this.output = V(this)
    };
    _.T(eO, Z);
    eO.prototype.j = function() {
        var a, b = !(null == (a = this.l) ? 0 : _.L(a, 9)) && !!zf(this.X);
        this.output.F(b)
    };
    var fO = function(a, b, c, d, e, f) {
        Z.call(this, a, 928);
        this.requestId = b;
        this.C = f;
        this.output = $F(this);
        this.v = W(this, c);
        e && (this.l = W(this, e));
        bG(this, d)
    };
    _.T(fO, Z);
    var gO = function(a) {
        return a.l ? a.C.split(",").some(function(b) {
            var c;
            return null == (c = a.l) ? void 0 : c.value.has(b)
        }) : !1
    };
    fO.prototype.j = function() {
        var a = this.context,
            b = this.requestId,
            c = this.v.value.length,
            d = gO(this);
        if (a.Bc) {
            var e = a.Qa,
                f = e.Ac;
            a = lh(a);
            var g = new FA;
            b = _.hh(g, 2, b);
            c = _.ph(b, 1, c);
            d = _.oh(c, 3, d);
            d = _.qh(a, 7, rh, d);
            f.call(e, d)
        }
        this.output.notify()
    };
    var hO = function(a, b, c, d) {
        Z.call(this, a, 867);
        this.ra = b;
        this.P = c;
        this.output = $F(this);
        this.l = W(this, d)
    };
    _.T(hO, Z);
    hO.prototype.j = function() {
        for (var a = _.z(this.l.value), b = a.next(); !b.done; b = a.next()) {
            var c = _.z(b.value);
            b = c.next().value;
            c = c.next().value;
            var d = Sh(this.P.R[b.getDomId()], 20);
            Cr(b, iI, 808, {
                Oj: c,
                Cl: d
            });
            Cr(this.ra, "slotRequested", 705, new PL(b, "publisher_ads"))
        }
        this.output.notify()
    };
    var iO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y, x, C, I, D, J, Q, N, Y, ua, ma, na, za, pa, Ta, ab, lb, mb) {
        Z.call(this, a, 785, _.Uf(QB));
        this.Va = b;
        this.L = c;
        this.wa = d;
        this.P = e;
        this.Xe = f;
        this.Vb = g;
        this.hb = h;
        this.cd = k;
        this.bd = l;
        this.Tf = m;
        this.kd = n;
        this.timer = p;
        this.X = r;
        this.isSecureContext = w;
        this.Ib = u;
        this.B = y;
        this.l = V(this);
        this.v = V(this);
        this.U = V(this);
        bG(this, N);
        this.Ia = aG(this, x);
        this.G = aG(this, C);
        this.K = W(this, I);
        J && (this.C = _.G(VB) ? new QF(J.Zc) : aG(this, J.Zc), J.Yd && (this.lc = X(this, J.Yd)));
        Q && (this.O = _.G(VB) ? new QF(Q.Dc) : aG(this, Q.Dc));
        bG(this, N);
        Y && (this.Xa = W(this, Y));
        ua && (this.ba = new QF(ua));
        ma && (this.Pa = X(this, ma));
        na && (this.ma = W(this, na));
        za && bG(this, za);
        pa && (this.za = W(this, pa));
        D && (this.da = X(this, D));
        Ta && (this.Eb = X(this, Ta.Bg));
        ab && (this.mc = W(this, ab));
        lb && (this.pa = X(this, lb));
        mb && (this.fa = X(this, mb))
    };
    _.T(iO, Z);
    iO.prototype.j = function() {
        if (this.K.value.length) {
            var a = null;
            if (this.C) {
                var b = this.C.value;
                a = b ? b : this.O && !this.O.Bb() ? 9 : this.C.Bb() ? null : 1
            }
            this.G.value && (this.L.te = this.G.value);
            var c, d, e, f, g, h, k, l, m, n, p, r, w;
            b = {
                ja: {
                    B: this.B,
                    context: this.context,
                    L: this.L,
                    wa: this.wa,
                    X: this.X,
                    Va: this.Va,
                    Tf: this.Tf,
                    isSecureContext: this.isSecureContext,
                    Ib: this.Ib
                },
                ka: {
                    hb: this.hb,
                    W: this.K.value,
                    P: this.P,
                    Vb: this.Vb,
                    cg: !1
                },
                km: {
                    cd: this.cd,
                    bd: this.bd
                },
                fl: {
                    yk: null != (r = this.Ia.value) ? r : "0"
                },
                Yi: {
                    Xe: this.Xe,
                    kd: this.kd
                },
                jb: {
                    ge: null == (c = this.da) ? void 0 : c.value
                },
                Vl: {
                    Yl: a,
                    Wl: null == (d = this.lc) ? void 0 : d.value
                },
                Fl: {
                    Wk: null != (w = null == (e = this.Xa) ? void 0 : e.value) ? w : void 0,
                    af: null == (f = this.ba) ? void 0 : f.value,
                    dk: null == (g = this.ma) ? void 0 : g.value
                },
                vl: {
                    zk: null == (h = this.Pa) ? void 0 : h.value,
                    uk: null == (k = this.za) ? void 0 : k.value
                },
                rl: {
                    ql: null == (l = this.Eb) ? void 0 : l.value
                },
                fm: {
                    Eg: null == (m = this.mc) ? void 0 : m.value,
                    Be: null == (n = this.pa) ? void 0 : n.value
                },
                Dn: {
                    En: null == (p = this.fa) ? void 0 : p.value
                }
            };
            this.v.F(b);
            c = op(ut(b));
            d = c.url;
            KG(this.timer, (9).toString(), 9, c.bh);
            this.l.F(d);
            this.U.F(pt(b) ? _.Tu("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : _.Tu("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}"))
        } else this.l.F(""), this.v.aa()
    };
    var jO = function(a, b, c, d, e, f) {
        Z.call(this, a, 878);
        this.l = b;
        this.V = c;
        this.P = d;
        this.B = e;
        this.output = $F(this);
        f && bG(this, f)
    };
    _.T(jO, Z);
    jO.prototype.j = function() {
        for (var a = _.z(this.l), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = xi(b, this.V);
            if (!wi(b, this.V) && c) {
                a: {
                    var d = c;
                    var e = this.P.R[b.getDomId()],
                        f = 0,
                        g = 0;e = _.z(Zh(e));
                    for (var h = e.next(); !h.done; h = e.next())
                        if (h = h.value, Array.isArray(h)) {
                            var k = _.z(h);
                            h = k.next().value;
                            k = k.next().value;
                            if (!("number" !== typeof h || "number" !== typeof k || 1 >= h || 1 >= k || (f = f || h, g = Math.min(g || Infinity, k), An(zi(d, this.B)) || !d.parentElement || An(zi(d.parentElement, this.B))))) {
                                d = [f, 0];
                                break a
                            }
                        }
                    d = f || g ? [f, g] : null
                }
                g = this.P;f = g.Z;g = g.R[b.getDomId()];zn(c, Fi(b), Co(f, g), d)
            }
        }
        this.output.notify()
    };
    var kO = function(a, b, c, d, e, f, g) {
            this.l = a;
            this.I = b;
            this.J = c;
            this.W = d;
            this.X = e;
            this.M = f;
            this.H = g;
            this.A = "";
            this.m = -1;
            this.j = 1;
            this.o = ""
        },
        mO = function(a, b) {
            if (b)
                if (1 !== a.j && 2 !== a.j) lO(a, new LE("state err: (" + ([a.j, a.o.length].join() + ")")));
                else {
                    a.o && (b = a.o + b);
                    var c = 0;
                    do {
                        var d = b.indexOf("\n", c);
                        var e = -1 !== d;
                        if (!e) break;
                        var f = a;
                        c = b.substr(c, d - c);
                        if (1 === f.j) f.A = c, ++f.m, f.j = 2;
                        else {
                            try {
                                f.l(f.m, f.A, {
                                    kind: 0,
                                    yb: yz(c)
                                }, f.W, f.X, f.M, f.H), f.A = ""
                            } catch (g) {}
                            f.j = 1
                        }
                        c = d + 1
                    } while (e && c < b.length);
                    a.o = b.substr(c)
                }
        },
        lO = function(a, b) {
            a.j = 4;
            try {
                a.I(b)
            } catch (c) {}
        },
        nO = function(a) {
            1 !== a.j || a.o ? lO(a, new LE("state err (" + ([a.j, a.o.length].join() + ")"))) : (a.j = 3, a.J(a.m, a.W, a.X))
        };
    var oO = function(a, b, c, d, e, f, g, h, k, l, m, n, p) {
        Z.call(this, a, 788);
        this.U = b;
        this.O = c;
        this.K = d;
        this.X = e;
        this.L = f;
        this.P = g;
        this.output = $F(this);
        this.G = 0;
        this.C = !1;
        this.l = null != p ? p : new XMLHttpRequest;
        this.v = W(this, h);
        k && (this.da = X(this, k));
        this.fa = W(this, l);
        bG(this, m);
        this.ba = W(this, n)
    };
    _.T(oO, Z);
    oO.prototype.j = function() {
        var a = this,
            b = this.fa.value;
        if (b) {
            var c, d = new kO(this.U, this.O, this.K, this.v.value, this.X, null == (c = this.da) ? void 0 : c.value);
            this.l.open("GET", b);
            this.l.withCredentials = this.ba.value;
            this.l.onreadystatechange = function() {
                pO(a, d, !1)
            };
            this.l.onload = function() {
                pO(a, d, !0)
            };
            this.l.onerror = function() {
                lO(d, new ME("XHR error"));
                qO(a)
            };
            this.l.send()
        }
        this.output.notify()
    };
    var pO = function(a, b, c) {
            try {
                if (3 === a.l.readyState || 4 === a.l.readyState)
                    if (300 <= a.l.status) a.C || (lO(b, new ME("xhr_err-" + a.l.status)), a.C = !0, qO(a));
                    else {
                        var d = a.l.responseText.substr(a.G);
                        d && mO(b, d);
                        a.G = a.l.responseText.length;
                        c && 4 === a.l.readyState && nO(b)
                    }
            } catch (e) {
                lO(b, e)
            }
        },
        qO = function(a) {
            _.G(iB) && a.v.value.forEach(function(b) {
                Fr(b, a.L, a.P, "")
            })
        };
    var rO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        Z.call(this, a, 1078);
        this.G = b;
        this.C = c;
        this.v = d;
        this.X = e;
        this.L = f;
        this.P = g;
        this.output = $F(this);
        this.l = W(this, h);
        k && (this.O = X(this, k));
        l && (this.U = W(this, l));
        this.ba = W(this, m);
        bG(this, n);
        this.K = W(this, p);
        if (null == r ? 0 : r.Xd) this.fa = X(this, r.Xd);
        w && (this.da = W(this, w))
    };
    _.T(rO, Z);
    rO.prototype.j = function() {
        var a = this,
            b = this.ba.value;
        if (b) {
            var c, d, e = new kO(this.G, this.C, this.v, this.l.value, this.X, null == (c = this.O) ? void 0 : c.value, null == (d = this.U) ? void 0 : d.value);
            c = this.K.value ? "include" : "omit";
            var f;
            d = null == (f = this.fa) ? void 0 : f.value;
            var g;
            f = null == (g = this.da) ? void 0 : g.value;
            g = _.A(Object, "assign").call(Object, {}, {
                credentials: c
            }, d ? {
                browsingTopics: d
            } : {}, f ? {
                adAuctionHeaders: f
            } : {});
            fetch(b, g).then(function(h) {
                sO(a, h, e)
            }).catch(function(h) {
                tO(h, e);
                uO(a)
            })
        }
        this.output.notify()
    };
    var sO = function(a, b, c) {
            if (300 <= b.status) lO(c, new ME("fetch_status-" + b.status)), uO(a);
            else {
                var d, e = null == (d = b.body) ? void 0 : d.pipeThrough(new TextDecoderStream).getReader();
                e ? e.read().then(function(f) {
                    vO(a, f, e, c)
                }).catch(function(f) {
                    tO(f, c)
                }) : lO(c, new ME("failed_reader"))
            }
        },
        vO = function(a, b, c, d) {
            var e = b.value;
            b.done ? nO(d) : (mO(d, e), c.read().then(function(f) {
                vO(a, f, c, d)
            }).catch(function(f) {
                tO(f, d)
            }))
        },
        tO = function(a, b) {
            lO(b, new ME("fetch error: " + (a instanceof Error ? a.message : void 0)))
        },
        uO = function(a) {
            _.G(iB) && a.l.value.forEach(function(b) {
                Fr(b, a.L, a.P, "")
            })
        };
    var wO = function(a, b, c, d, e) {
        Z.call(this, a, 918);
        this.P = b;
        this.timer = c;
        this.output = $F(this);
        this.l = W(this, e);
        bG(this, d)
    };
    _.T(wO, Z);
    wO.prototype.j = function() {
        var a = this.l.value;
        a.length && Ar(this.timer, "3", Br(this.P.R[a[0].getDomId()], 20));
        this.output.notify()
    };
    var yO = function(a, b, c) {
        Z.call(this, a, 804);
        this.lb = c;
        this.output = YF(this);
        this.v = [];
        this.Pc = {
            Bk: xO(this, function(d) {
                return Xw(d, 6)
            }),
            lm: xO(this, function(d) {
                return Xw(d, 7)
            }),
            Jk: xO(this, function(d) {
                return !!Il(d, 8)
            }),
            nk: xO(this, function(d) {
                return Yw(d, 10)
            }),
            jc: xO(this, function(d) {
                var e;
                return null != (e = d.getEscapedQemQueryId()) ? e : ""
            }),
            tj: xO(this, function(d) {
                return _.Qh(d, ny, 43)
            }),
            Ik: xO(this, function(d) {
                return !!Il(d, 9)
            }),
            rf: xO(this, function(d) {
                return !!Il(d, 12)
            }),
            vk: xO(this, function(d) {
                return _.Qh(d, by, zk(d, By, 48))
            }),
            Uf: xO(this, function(d) {
                return _.Qh(d, ay, zk(d, By, 39))
            }),
            he: xO(this, function(d) {
                return Zw(d, 36)
            }),
            hm: xO(this, function(d) {
                return !!Il(d, 13)
            }),
            Hk: xO(this, function(d) {
                return !!Il(d, 3)
            }),
            Sg: xO(this, function(d) {
                return Yw(d, 49)
            }),
            Ek: xO(this, function(d) {
                return _.Qh(d, qy, 51)
            }),
            bk: xO(this, function(d) {
                return Yw(d, 61)
            }),
            Aa: V(this),
            Qi: xO(this, function(d) {
                return _.Qh(d, zy, 58)
            }),
            mm: xO(this, function(d) {
                var e, f;
                return null != (f = null == (e = _.Qh(d, ly, 56)) ? void 0 : Yw(e, 1)) ? f : null
            }),
            Qd: xO(this, function(d) {
                return Uh(d, Wx, 62)
            }),
            Kj: xO(this, function(d) {
                return Uh(d, oy, 67)
            }),
            Qk: xO(this, function(d) {
                return Rd(d, 63, Yc, void 0, void 0, void 0, 0)
            }),
            Fj: xO(this, function(d) {
                return !!Il(d, 64)
            }),
            ck: xO(this, function(d) {
                return Jo(d, py, 68)
            })
        };
        this.l = W(this, b)
    };
    _.T(yO, Z);
    var xO = function(a, b) {
        var c = V(a);
        a.v.push({
            output: c,
            gk: b
        });
        return c
    };
    yO.prototype.j = function() {
        for (var a = _.z(this.v), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = b.gk,
                d = void 0;
            b.output.Ca(null != (d = c(this.l.value)) ? d : null)
        }
        0 === this.lb.kind ? this.Pc.Aa.F(this.lb) : this.Pc.Aa.F({
            kind: 0,
            yb: _.sj(this.l.value, 4) || ""
        });
        this.output.F(this.Pc)
    };
    var zO = function(a, b, c, d, e) {
        Z.call(this, a, 803);
        this.l = b;
        this.slotId = c;
        this.wa = d;
        this.X = e;
        this.output = V(this)
    };
    _.T(zO, Z);
    zO.prototype.j = function() {
        var a = JSON.parse(this.l),
            b = pn(a, Uu);
        if (!b) throw Error("missing ad unit path");
        if (null == a || !a[b]) throw Error("invalid ad unit path: " + b);
        a = a[b];
        if (!Array.isArray(a)) throw Error("dictionary not an array: " + this.l);
        a = je(Ay, a);
        b = _.z(Rd(a, 27, Lc));
        for (var c = b.next(); !c.done; c = b.next()) c = c.value, _.Ff(Gf).j(c);
        Nl(4, this.context, this.wa, this.X);
        Cr(this.slotId, hI, 800, a);
        this.output.F(a)
    };
    var AO = function(a, b, c, d) {
        Z.call(this, a, 823);
        this.slotId = b;
        this.L = c;
        this.l = W(this, d)
    };
    _.T(AO, Z);
    AO.prototype.j = function() {
        var a = this;
        Il(this.l.value, 11) && (_.tI(this.L, this.slotId), qI(this.L, this.slotId, function() {
            _.uI(a.L, a.slotId)
        }))
    };
    var BO = function(a, b, c, d) {
        Bj.call(this);
        this.context = a;
        this.slotId = b;
        a = d.L;
        var e = d.X;
        b = d.Ta;
        var f = d.wa;
        d = d.lb;
        c = new zO(this.context, c, this.slotId, f, e);
        M(this, c);
        e = new yL(this.context, e, f, c.output);
        M(this, e);
        b = new AL(this.context, this.slotId, b, c.output);
        M(this, b);
        a = new AO(this.context, this.slotId, a, c.output);
        M(this, a);
        a = new yO(this.context, c.output, d);
        M(this, a);
        d = a.Pc;
        this.j = {
            Jc: d.Jk,
            Qf: d.jc,
            sa: d.Qi,
            Pc: a.output
        }
    };
    _.T(BO, Bj);
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var CO = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""),
        DO = function() {
            for (var a = Array(36), b = 0, c, d = 0; 36 > d; d++) 8 == d || 13 == d || 18 == d || 23 == d ? a[d] = "-" : 14 == d ? a[d] = "4" : (2 >= b && (b = 33554432 + 16777216 * Math.random() | 0), c = b & 15, b >>= 4, a[d] = CO[19 == d ? c & 3 | 8 : c]);
            return a.join("")
        };
    var EO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y, x, C, I, D, J, Q, N, Y) {
        Z.call(this, a, 973);
        this.pa = b;
        this.T = c;
        this.K = d;
        this.ba = e;
        this.P = f;
        this.L = g;
        this.wa = h;
        this.fa = k;
        this.O = l;
        this.G = m;
        this.Sd = n;
        this.ma = p;
        this.hb = r;
        this.isSecureContext = w;
        this.Ib = u;
        this.Ta = y;
        this.B = x;
        this.V = C;
        this.l = Q;
        this.U = N;
        this.za = Y;
        this.C = [];
        this.v = X(this, I);
        this.da = W(this, D);
        this.Ia = W(this, J);
        this.l && bG(this, this.l.Mj)
    };
    _.T(EO, Z);
    EO.prototype.j = function() {
        var a = this,
            b = new Bj;
        _.S(this, b);
        var c = this.da.value,
            d = vt(this.P.Z);
        this.v.value && this.za.F(this.v.value);
        var e = kq(this.context, this.V);
        e && _.S(b, e.Ga);
        var f = Fp(this.context, _.Qh(this.P.Z, Ks, 5), this.L, this.K, null == e ? void 0 : e.ml.Md);
        e = f.gg;
        (f = f.Rk) && _.S(b, f);
        var g = new jO(this.context, this.K, this.V, this.P, this.B, e);
        M(b, g);
        var h = !!_.L(this.P.Z, 6);
        e = new dO(this.context, this.K, h, this.P, this.T, this.B, c);
        M(b, e);
        var k = new nK(this.context, d, c, Rd(this.P.Z, 35, Jc));
        M(b, k);
        f = this.U;
        var l = f.gl,
            m = f.tl;
        f = f.Zl;
        var n, p = null != (n = this.l) ? n : {},
            r = p.fe,
            w = p.hf,
            u = p.Pb,
            y = p.od,
            x = p.Ce,
            C = p.tk;
        n = p.uf;
        var I = p.Pj,
            D = p.nd;
        if (p = Kr(this.context, f, this.P.R, c, this.v.value, e.l, k.output, p.Dh)) {
            var J = p.bm;
            p = p.am;
            var Q = J.xg;
            J = J.ag;
            _.S(b, p)
        }
        if (p = jr(this.context, f, this.B.navigator, k.output)) {
            var N = p.Ri;
            p = p.cm;
            var Y = N.yi;
            N = N.Lh;
            p && _.S(b, p)
        }
        _.G(bC) && (N = V(this), N.F(f.Qg));
        var ua = new KM(this.context, this.B);
        M(b, ua);
        p = (null != r ? r : {}).Ub;
        var ma;
        f = null == (ma = this.l) ? void 0 : ma.pf;
        ma = new oM(this.context, l.il);
        M(b, ma);
        if (l = yo(this.context, this.T, this.P.R, this.hb, e.l, r, u)) {
            var na = l.wj;
            _.S(this, l.Ga)
        }
        if (J = mq(this.context, m, J, _.G(eC) ? this.P.R : void 0, _.G(eC) ? e.l : void 0, I)) {
            var za = J.ef;
            _.S(this, J.Ga)
        }
        if (J = Vq(this.context, this.v.value, f, k.output)) {
            var pa = J.Xl;
            _.S(this, J.Ga);
            this.C.push(pa.Zc.promise)
        }
        J = window.isSecureContext && _.G(fC) ? "wbn" : "ldjh";
        var Ta = ++this.L.H;
        k = "wbn" === J ? DO().toLowerCase() : void 0;
        m = this.Sd;
        var ab, lb;
        na = new iO(this.context, h, this.L, this.wa, this.P, J, m.Vb, this.hb, m.cd, m.bd, this.Ia.value, k, _.Ff(Ah), c, this.isSecureContext, this.Ib, this.B, ma.output, ua.output, e.l, null == (ab = na) ? void 0 : ab.Lg, pa, f, g.output, null == w ? void 0 : w.rg, p, u, y, x, C, za, Y, null == (lb = this.l) ? void 0 : lb.Dh, D);
        M(b, na);
        za = new wO(this.context, this.P, _.Ff(Ah), na.l, e.l);
        M(b, za);
        d = new eO(this.context, d, c);
        M(b, d);
        ab = yh(this.context, 646, function(mb, ac, ic, td, Gc, $d, Hc) {
            xt(function() {
                return void FO(a, Gc, mb, ac, ic, td, $d, Hc)
            }, mb, a.B)
        });
        lb = yh(this.context, 647, function(mb, ac, ic) {
            xt(function() {
                return void GO(a, Ta, ic, ac, mb)
            }, -1, a.B)
        });
        "ldjh" === J ? (g = HO(this, 289, "strm_err"), _.G(nB) && window.fetch && window.TextDecoderStream || _.G(pB) && qz(window.fetch) && qz(window.TextDecoderStream) || _.G(oB) && Ma() && qz(window.fetch) && qz(window.TextDecoderStream) ? (Q = new rO(this.context, ab, g, lb, c, this.L, this.P, e.l, Q, Y, na.l, za.output, d.output, pa, N), M(b, Q), Q = Q.output) : (Q = new oO(this.context, ab, g, lb, c, this.L, this.P, e.l, Q, na.l, za.output, d.output), M(b, Q), Q = Q.output)) : (Y = new vN(this.context, ab, HO(this, 1042, "Unknown web bundle error."), lb, J, k, c, this.V, e.l, Q, na.l, na.U, za.output, d.output), Hs(b, Y), Q = new vn, RF(Q, Kj(Y).then(function() {})));
        Y = new fO(this.context, Ta, e.l, Q, n, this.hb);
        M(b, Y);
        pa = new bO(this.context, na.v, na.l);
        M(b, pa);
        pa = new hO(this.context, this.G.ra, this.P, pa.output);
        M(b, pa);
        pa = new zM(this.context, this.fa, this.B, pa.output);
        M(b, pa);
        pa = new eM(this.context, this.P, this.O, e.l, pa.output);
        M(b, pa);
        e = new nL(this.context, this.L, this.P, this.V, e.l, pa.output);
        M(b, e);
        pa = new JM(this.context, _.Ih(this.B), this.B, c, Q);
        M(b, pa);
        1 === Ta && (c = new fL(this.context, this.B, c, f, Q), M(b, c), this.C.push(c.output.promise));
        this.C.push(Y.output.promise, e.output.promise, pa.output.promise);
        Kj(b)
    };
    var FO = function(a, b, c, d, e, f, g, h) {
            var k, l, m;
            return _.kb(function(n) {
                k = f[c];
                if (!k) return Ch(a.context, 646, Error("missing slot")), n.return();
                0 === c && (l = Br(a.P.R[k.getDomId()], 20), Ar(_.Ff(Ah), "4", l));
                return n.yield(IO(a, k, d, e, b, null == (m = g) ? void 0 : m[k.getId()], h), 0)
            })
        },
        GO = function(a, b, c, d, e) {
            var f, g, h;
            return _.kb(function(k) {
                if (1 == k.j) {
                    var l = a.context,
                        m = e + 1,
                        n = d.length;
                    if (l.Bc) {
                        var p = l.Qa,
                            r = p.Ac;
                        l = lh(l);
                        var w = new GA;
                        w = _.hh(w, 3, b);
                        m = _.ph(w, 1, m);
                        n = _.ph(m, 2, n);
                        n = _.qh(l, 8, rh, n);
                        r.call(p, n)
                    }
                    f = e + 1
                }
                if (3 != k.j) {
                    if (!(f < d.length)) return k.yield(JO(a), 0);
                    if (!d[f]) {
                        k.j = 3;
                        return
                    }
                    p = new Ay;
                    p = xj(p, 8, !0);
                    g = tk(p);
                    h = '{"empty":' + g + "}";
                    return k.yield(FO(a, c, f, h, {
                        kind: 0,
                        yb: ""
                    }, d), 3)
                }++f;
                k.j = 2
            })
        },
        IO = function(a, b, c, d, e, f, g) {
            var h, k, l, m, n, p, r, w, u, y;
            return _.kb(function(x) {
                if (1 == x.j) return h = {
                    X: e,
                    Ta: a.Ta,
                    L: a.L,
                    wa: a.wa,
                    lb: d
                }, k = new BO(a.context, b, c, h), x.yield(Kj(k), 2);
                l = x.o;
                m = l.Jc;
                n = l.Qf;
                p = l.sa;
                r = l.Pc;
                Ao(a.context, null == (w = a.l) ? void 0 : w.fe, r.mm, r.rf, r.jc);
                _.G(bB) && jp(a.context, a.wa, r.ck);
                if (b.J) return x.return();
                (u = !!p) && Ri("gpt_td_init", function(C) {
                    Xi(C, a.context);
                    Yi(C, "noFill", m ? "1" : "0");
                    Yi(C, "publisher_tag", "gpt");
                    var I = _.Qh(p, xy, 5);
                    I && (Yi(C, "winner_qid", I.getEscapedQemQueryId()), Yi(C, "xfpQid", _.R(I, 6)))
                }, 1);
                (y = qp("google_norender")) || m && !u ? Fr(b, a.L, a.P, n) : ZN(a.ma, a.pa, a.T, b, m || y, u, a.L, a.P, a.Ta, r, e, f, g, a.G.ra, a.O, a.l, a.U);
                k.xa();
                x.j = 0
            })
        },
        HO = function(a, b, c) {
            return yh(a.context, b, function(d) {
                d = d instanceof Error ? d : Error();
                d.message = d.message || c;
                Ch(a.context, b, d);
                JO(a)
            })
        },
        JO = function(a) {
            return _.kb(function(b) {
                if (1 == b.j) {
                    var c = a.L,
                        d = a.ba,
                        e = c.o.get(d) - 1;
                    0 === e ? c.o.delete(d) : c.o.set(d, e);
                    return e ? b.return() : b.yield(_.v.Promise.all(a.C), 2)
                }
                Cr(a.G.Hh, lI, 965, a.ba);
                b.j = 0
            })
        };
    var KO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y, x, C, I, D, J, Q, N) {
        Z.call(this, a, 885);
        this.da = b;
        this.T = c;
        this.P = d;
        this.L = e;
        this.wa = f;
        this.Sd = g;
        this.U = h;
        this.G = k;
        this.l = l;
        this.C = m;
        this.ba = n;
        this.isSecureContext = p;
        this.bb = r;
        this.O = w;
        this.Ib = u;
        this.Ta = y;
        this.B = x;
        this.V = C;
        this.v = J;
        this.K = Q;
        this.fa = N;
        this.ma = W(this, I);
        bG(this, D)
    };
    _.T(KO, Z);
    KO.prototype.j = function() {
        var a = this.ma.value;
        if (a.length) {
            var b = this.L,
                c = this.l,
                d = a.length;
            b.o.has(c);
            b.o.set(c, d);
            a = _.z(a);
            for (b = a.next(); !b.done; b = a.next()) {
                c = b.value;
                var e = void 0;
                b = c.hb;
                d = c.W;
                c = new Bj;
                _.S(this, c);
                var f = np(this.context, this.O, null == (e = this.v) ? void 0 : e.Yk);
                e = f.Kc;
                var g = f.Eh;
                _.S(c, f.Ga);
                e = Pm(this.context, this.T, this.L, this.B, e, g, vt(this.P.Z));
                f = e.kb;
                _.S(c, e.Ga);
                e = new tM(this.context, this.B, f);
                M(c, e);
                e = new xL(this.context, this.B, f);
                M(c, e);
                e = new Ds(this.context, this.B, f);
                M(c, e);
                g = new $N(this.context, this.wa, this.bb, f);
                M(c, g);
                b = new EO(this.context, this.da, this.T, d, this.l, this.P, this.L, this.wa, this.U, this.G, this.C, this.Sd, this.ba, b, this.isSecureContext, this.Ib, this.Ta, this.B, this.V, e.output, f, g.v, this.v, this.K, this.fa);
                M(c, b);
                Kj(c)
            }
        } else Cr(this.C.Hh, lI, 965, this.l)
    };
    var LO = new _.v.Map,
        MO = function(a, b, c, d) {
            d = void 0 === d ? LO : d;
            Z.call(this, a, 834);
            this.T = b;
            this.W = c;
            this.l = d;
            this.v = V(this);
            this.v.Ka(_.v.Promise.all(this.W.map(this.C, this)).then(function(e) {
                return e.filter(function(f) {
                    return null != f && !f.J
                })
            }))
        };
    _.T(MO, Z);
    MO.prototype.j = function() {};
    MO.prototype.C = function(a) {
        var b = this,
            c, d;
        return _.kb(function(e) {
            if (1 == e.j) {
                if (a.J) return e.return();
                b.l.has(a) || (b.l.set(a, zt(a)), _.mn(a, function() {
                    return void b.l.delete(a)
                }));
                c = b.l.get(a);
                return e.yield(c(), 2)
            }
            d = e.o;
            if (b.J) return e.return();
            if (d) return e.return(a);
            P(b.T, qJ(a.getAdUnitPath()));
            return e.return()
        })
    };
    var NO = function(a, b, c, d, e) {
        Z.call(this, a, 847);
        this.L = b;
        this.Va = c;
        this.Ie = d;
        this.l = V(this);
        this.v = W(this, e)
    };
    _.T(NO, Z);
    NO.prototype.j = function() {
        var a = Bt({
            W: this.v.value
        }, {
            L: this.L,
            Va: this.Va,
            Ie: this.Ie
        });
        this.l.F(a.Rc)
    };
    var OO = function(a, b, c) {
        Z.call(this, a, 845);
        this.R = b;
        this.l = V(this);
        this.v = V(this);
        this.C = W(this, c)
    };
    _.T(OO, Z);
    OO.prototype.j = function() {
        var a = Dt({
            W: this.C.value
        }, {
            R: this.R
        });
        this.l.F(a.Jg);
        this.v.F(a.Tg)
    };
    var PO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w, u, y, x, C) {
        _.U.call(this);
        var I = this;
        this.context = a;
        this.C = b;
        this.T = c;
        this.L = d;
        this.wa = e;
        this.ra = f;
        this.M = g;
        this.l = h;
        this.v = k;
        this.isSecureContext = l;
        this.bb = m;
        this.I = n;
        this.Ib = p;
        this.Ta = r;
        this.V = w;
        this.B = u;
        this.A = y;
        this.H = x;
        this.G = C;
        this.j = new _.v.Map;
        this.m = new dI(a);
        _.S(this, this.m);
        this.m.listen(lI, function(D) {
            D = D.detail;
            var J = I.j.get(D);
            J && (I.j.delete(D), J.xa())
        })
    };
    _.T(PO, _.U);
    var QO = function(a, b, c, d) {
        var e = ++a.L.l;
        a.j.has(e);
        var f = new Bj;
        a.j.set(e, f);
        b = new MO(a.context, a.T, b);
        M(f, b);
        if (_.G(JB)) {
            b = hG(f, 845, Dt, {
                W: b.v
            }, {
                R: d.R
            }, {
                Jg: void 0,
                Tg: void 0
            });
            var g = b.Tg;
            b = hG(f, 847, Bt, {
                W: b.Jg
            }, {
                L: a.L,
                Va: !!_.L(d.Z, 6),
                Ie: qp("google_nofetch")
            }, {
                Rc: void 0
            }).Rc;
            g = hG(f, 864, ep, {
                W: g
            }, {
                L: a.L,
                P: d,
                V: document
            }, {}).finished
        } else g = new OO(a.context, d.R, b.v), M(f, g), b = new NO(a.context, a.L, !!_.L(d.Z, 6), qp("google_nofetch"), g.l), b = M(f, b).l, g = new oL(a.context, a.L, d, document, g.v), M(f, g), g = g.l;
        a = new KO(a.context, a.C, a.T, d, a.L, a.wa, c, a.M, a.l, e, {
            Hh: a.m,
            ra: a.ra
        }, a.v, a.isSecureContext, a.bb, a.I, a.Ib, a.Ta, a.B, a.V, b, g, a.A, a.H, a.G);
        M(f, a);
        Kj(f)
    };
    var RO = function(a, b, c, d, e, f, g, h, k, l, m, n, p, r, w) {
        xN.call(this, a, c, h);
        this.context = a;
        this.L = d;
        this.A = new _.v.Set;
        this.H = {};
        this.v = new YN(a, d);
        this.C = new PO(a, b, c, d, new _.XE(window), this.m, m, e, this.v, f, g, k, l, n, document, window, p, r, w);
        _.S(this, this.C)
    };
    _.T(RO, xN);
    RO.prototype.getName = function() {
        return "publisher_ads"
    };
    RO.prototype.display = function(a, b, c, d, e) {
        d = void 0 === d ? "" : d;
        e = void 0 === e ? "" : e;
        var f = "";
        if (d)
            if (_.ja(d) && 1 == d.nodeType) {
                var g = d;
                f = g.id
            } else f = d;
        Xr(this);
        var h = gm(c, this.context, this.T, a, b, f),
            k = h.slotId;
        h = h.Da;
        if (k && h) {
            g && !f && (g.id = k.getDomId());
            this.slotAdded(k, h);
            h.setClickUrl(e);
            var l;
            Qr(this, null != (l = g) ? l : k.getDomId(), c)
        } else P(this.T, Nk("PubAdsService.display", [a, b, d]))
    };
    var Qr = function(a, b, c) {
        var d = SO(b, c);
        c = d.slotId;
        var e = d.Wj;
        d = d.Xj;
        if (c) {
            if (b = Hi(), (d = TG(b, c.getDomId())) && !_.L(d, 19))
                if (e && b.m.set(c, e), (e = xi(c)) || (e = Fs(d), e = 0 !== e && 1 !== e), e) {
                    if (xj(d, 19, !0), e = oi(b.j, b.o), a.enabled) {
                        Xr(a);
                        a.enabled && sI(a.L, c);
                        a.T.info(SI());
                        b = e.Z;
                        d = e.R;
                        var f = _.L(b, 6);
                        if (f || !a.L.qc(c)) f && (f = xi(c)) && Cr(c, gI, 778, f), _.L(b, 4) && (d = d[c.getDomId()], ap(d, b) && !a.L.qc(c) && bp(c, document, d, b)), SJ(a, e, c)
                    }
                } else P(a.T, II(String(_.sj(d, 1)), String(_.sj(d, 2))), c)
        } else d ? a.T.error(JI(d)) : a.T.error(Nk("googletag.display", [String(b)]))
    };
    RO.prototype.slotAdded = function(a, b) {
        var c = this;
        _.L(b, 17) || this.enabled && sI(this.L, a);
        Cr(this.m, jI, 724, {
            Kg: a.getDomId(),
            R: b
        });
        a.listen(Er, function(d) {
            var e = d.detail;
            d = e.size;
            var f = new KL(a, "publisher_ads");
            e.isEmpty && (f.isEmpty = !0);
            e = a.j.getResponseInformation();
            d && e && (f.size = [d.width, d.height], f.sourceAgnosticCreativeId = e.sourceAgnosticCreativeId, f.sourceAgnosticLineItemId = e.sourceAgnosticLineItemId, f.isBackfill = e.isBackfill, f.creativeId = e.creativeId, f.lineItemId = e.lineItemId, f.creativeTemplateId = e.creativeTemplateId, f.advertiserId = e.advertiserId, f.campaignId = e.campaignId, f.yieldGroupIds = e.yieldGroupIds, f.companyIds = e.companyIds);
            Cr(c.m, "slotRenderEnded", 708, f)
        });
        a.listen(hI, function() {
            Cr(c.m, "slotResponseReceived", 709, new QL(a, c.getName()))
        });
        4 === Fs(b) && TO(this, "rewardedSlotClosed", a, b);
        7 === Fs(b) && TO(this, "gameManualInterstitialSlotClosed", a, b);
        xN.prototype.slotAdded.call(this, a, b)
    };
    var TO = function(a, b, c, d) {
            _.mn(c, a.m.listen(b, function(e) {
                c.j === e.detail.slot && (e = {}, UO(a, [c], Hi().j, (e[c.getDomId()] = d, e), a.L))
            }))
        },
        SJ = function(a, b, c) {
            var d = VO(a, b, c);
            WO(a, d, b, {
                Vb: 1
            });
            b = c.getAdUnitPath();
            if (c = a.H[b]) {
                c = _.z(c);
                for (d = c.next(); !d.done; d = c.next()) d = d.value, WO(a, d.W, d.P, d.Sd);
                delete a.H[b]
            }
        },
        VO = function(a, b, c) {
            var d = b.Z;
            b = b.R;
            if (_.L(d, 4)) return [];
            var e;
            return !_.L(d, 6) || (null == (e = b[c.getDomId()]) ? 0 : _.L(e, 17)) ? (a.A.add(c), _.mn(c, function() {
                return void a.A.delete(c)
            }), [c]) : a.j.filter(function(f) {
                if (a.A.has(f)) return !1;
                a.A.add(f);
                _.mn(f, function() {
                    return void a.A.delete(f)
                });
                return !0
            })
        },
        WO = function(a, b, c, d) {
            a.T.info(ZI());
            if (XO(a, b, d, c) && 1 !== d.Vb)
                for (b = _.z(b), d = b.next(); !d.done; d = b.next()) d = d.value.getDomId(), Cr(a.m, kI, 725, {
                    Kg: d,
                    R: c.R[d]
                })
        },
        XO = function(a, b, c, d) {
            b = b.filter(function(e) {
                var f = d.R[e.getDomId()],
                    g = _.cp(a.L, e);
                !1 === g && P(a.T, HJ(String(Fs(f)), e.getAdUnitPath()));
                if (!g) return !1;
                (_.F = [5, 4, 7], _.A(_.F, "includes")).call(_.F, Fs(f)) && _.tI(a.L, e);
                return !0
            });
            if (!b.length) return null;
            QO(a.C, b, c, d);
            return b
        };
    RO.prototype.refresh = function(a, b, c) {
        c = void 0 === c ? {
            Vb: 2
        } : c;
        b = YO(this, b);
        if (!b.length) return !1;
        ZO(this, a, b, c);
        return !0
    };
    var YO = function(a, b) {
            return b.filter(function(c, d) {
                if (!c.J) return !0;
                P(a.T, bJ(String(d)));
                return !1
            })
        },
        ZO = function(a, b, c, d) {
            var e = c[0],
                f, g = null != (f = null == e ? void 0 : e.getDomId()) ? f : "";
            if (a.enabled) {
                var h = _.z(c);
                e = h.next();
                for (f = {}; !e.done; f = {
                        Vd: f.Vd
                    }, e = h.next()) f.Vd = e.value, a.A.add(f.Vd), _.mn(f.Vd, function(k) {
                    return function() {
                        return void a.A.delete(k.Vd)
                    }
                }(f));
                WO(a, c, b, d)
            } else c.length && _.L(b.Z, 6) ? (P(a.T, YI(g), e), e = e.getAdUnitPath(), f = null != (h = a.H[e]) ? h : [], f.push({
                W: c,
                P: b,
                Sd: d
            }), a.H[e] = f) : P(a.T, WI(g), e)
        };
    RO.prototype.M = function() {
        var a = Hi().j;
        if (_.L(a, 6))
            for (var b = _.z(this.j), c = b.next(); !c.done; c = b.next()) this.enabled && sI(this.L, c.value);
        XJ(this, a);
        a = Am();
        a.hasOwnProperty("pubadsReady") || (a.pubadsReady = !0)
    };
    RO.prototype.destroySlots = function(a) {
        a = xN.prototype.destroySlots.call(this, a);
        if (a.length && this.enabled) {
            var b = Hi();
            $O(this, a, b.j, b.o)
        }
        return a
    };
    var ZJ = function(a, b, c, d) {
            if (!a.enabled) return P(a.T, XI(), d[0]), !1;
            var e = YO(a, d);
            if (!e.length) return P(a.T, Nk("PubAdsService.clear", [d].filter(function(f) {
                return void 0 !== f
            }))), !1;
            a.T.info($I());
            $O(a, e, b, c);
            return !0
        },
        $O = function(a, b, c, d) {
            for (var e = _.z(b), f = e.next(); !f.done; f = e.next()) pI(a.L, f.value);
            UO(a, b, c, d, a.L)
        };
    RO.prototype.forceExperiment = function(a) {
        a = Number(a);
        0 < a && _.Ff(Gf).j(a)
    };
    var UO = function(a, b, c, d, e) {
            var f = void 0 === f ? window : f;
            b = _.z(b);
            for (var g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                yI(a.v.L, g);
                var h = d[g.getDomId()];
                ap(h, c) && bp(g, f.document, h, c);
                dp(e, g)
            }
        },
        YJ = function(a, b, c, d) {
            if ("string" !== typeof b || "string" !== typeof c) P(a.T, Nk("PubAdsService.setVideoContent", [b, c]));
            else {
                var e = xj(d, 21, !0);
                b = On(e, 22, b);
                On(b, 23, c);
                XJ(a, d)
            }
        },
        $J = function(a, b) {
            if (!a.enabled) return null;
            var c, d;
            return {
                vid: null != (c = _.R(b, 22)) ? c : "",
                cmsid: null != (d = _.R(b, 23)) ? d : ""
            }
        },
        XJ = function(a, b) {
            _.L(b, 21) && a.enabled && (a = zz(), _.ni(b, 29, null == a ? a : Zc(a)))
        },
        SO = function(a, b) {
            var c = "";
            if ("string" === typeof a) c = a, b = dL(b, c);
            else if (_.ja(a) && 1 == a.nodeType) {
                var d = a;
                c = d.id;
                b = dL(b, c)
            } else b = (_.F = [].concat(_.ch(b.W)), _.A(_.F, "find")).call(_.F, function(e) {
                return e.j === a
            });
            return {
                slotId: b,
                Wj: d,
                Xj: c
            }
        };
    var Nt = _.ju(["https://pagead2.googlesyndication.com/pagead/js/rum_debug.js"]),
        Ot = _.ju(["https://pagead2.googlesyndication.com/pagead/js/rum.js"]);
    var aP = ku(["^[-p{L}p{M}p{N}_,.!*<>():/]*$"], ["^[-\\p{L}\\p{M}\\p{N}_,\\.!*<>():/]*$"]),
        bP = _.Vu(function() {
            vz("The googletag.pubads().definePassback function has been deprecated. The function may break in certain contexts, see https://developers.google.com/publisher-tag/guides/passback-tags#construct_passback_tags for how to correctly create a passback.")
        }),
        dP = function(a, b) {
            var c = this;
            var d = void 0 === d ? _.A(String, "raw").call(String, aP) : d;
            this.L = a;
            this.o = d;
            this.j = new _.v.Map;
            this.W = new _.v.Set;
            b.m = function(e) {
                return cP(c, e)
            }
        };
    dP.prototype.defineSlot = function(a, b, c, d, e) {
        a = gm(this, a, b, c, d, e);
        var f = a.slotId;
        if (f) return f.j;
        a.we || b.error(Nk("googletag.defineSlot", [c, d, e]));
        return null
    };
    var gm = function(a, b, c, d, e, f, g) {
        return "string" === typeof d && 0 < d.length && e && (void 0 === f || "string" === typeof f) ? a.add(b, c, d, e, {
            Nb: f,
            mi: void 0 === g ? !1 : g
        }) : {}
    };
    dP.prototype.add = function(a, b, c, d, e, f) {
        var g = this,
            h = e.Nb,
            k = void 0 === e.format ? 0 : e.format,
            l = void 0 === e.mi ? !1 : e.mi;
        e = void 0 === e.sb ? !1 : e.sb;
        f = void 0 === f ? _.t : f;
        try {
            var m = new RegExp(this.o, "u");
            if (m.test("/1") && !m.test(c)) return b.error(LI(c)), {
                we: !0
            }
        } catch (p) {}
        f = Vo(k, f, e);
        null !== f && Mo(a, f, So(k));
        if (f) return Go(b, f, k, c), {};
        l && bP();
        k = this.j.get(c) || Number(l);
        b = eP(this, a, b, c, k, d, h || "gpt_unit_" + c + "_" + k);
        a = b.Da;
        var n = b.slotId;
        b = b.we;
        if (!n) return {
            we: b
        };
        this.j.set(c, k + 1);
        this.W.add(n);
        _.mn(n, function() {
            return void g.W.delete(n)
        });
        BG(c);
        return {
            slotId: n,
            Da: a
        }
    };
    var dL = function(a, b) {
            a = _.z(a.W);
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, c.getDomId() === b) return c
        },
        Or = function(a) {
            a = _.z(a);
            for (var b = a.next(); !b.done; b = a.next()) b.value.xa()
        },
        eP = function(a, b, c, d, e, f, g) {
            var h = dL(a, g);
            if (h) return c.error(KI(g, d, h.getAdUnitPath())), {
                we: !0
            };
            var k = new iK;
            jK(On(k, 1, d), g);
            kK(k, vm(f));
            SG(k);
            var l = new rf(b, d, e, g);
            UJ(l, Hm(b, c, l));
            _.mn(l, function() {
                var m = Hi(),
                    n = l.getDomId();
                delete m.o[n];
                m.m.delete(l);
                m = l.getAdUnitPath();
                m = eh(m);
                var p;
                n = (null != (p = Oh.get(m)) ? p : 0) - 1;
                0 >= n ? Oh.delete(m) : Oh.set(m, n);
                c.info(gJ(l.toString()), l);
                (p = Ik.get(l)) && Jk.delete(p);
                Ik.delete(l)
            });
            c.info(zI(l.toString()), l);
            l.listen(iI, function(m) {
                m = m.detail.Cl;
                c.info(AI(l.getAdUnitPath()), l);
                KG(_.Ff(Ah), "7", 9, wI(a.L, l), 0, m)
            });
            l.listen(hI, function(m) {
                var n = m.detail;
                c.info(BI(l.getAdUnitPath()), l);
                var p;
                m = _.Ff(Ah);
                var r = Br(k, 20);
                n = null != (p = n.getEscapedQemQueryId()) ? p : "";
                m.j && (_.t.google_timing_params = _.t.google_timing_params || {}, _.t.google_timing_params["qqid." + r] = n)
            });
            l.listen(Dr, function() {
                return void c.info(CI(l.getAdUnitPath()), l)
            });
            l.listen(Er, function() {
                return void c.info(DI(l.getAdUnitPath()), l)
            });
            return {
                Da: k,
                slotId: l
            }
        },
        cP = function(a, b) {
            var c = new RegExp("(^|,|/)" + b + "($|,|/)");
            return [].concat(_.ch(a.W)).some(function(d) {
                return c.test(eh(d.getAdUnitPath()))
            })
        };
    (function(a, b) {
        var c = null != a ? a : {
            pvsid: _.Ih(window),
            fb: "1",
            zb: "m202311090101",
            Qa: new Xt(3, "m202311090101", 0),
            Ig: !0,
            Pf: 1
        };
        try {
            rc(function(pa) {
                Ch(c, 1190, pa)
            });
            var d = Am();
            Fe(!_.Ff(ai).j);
            _.A(Object, "assign").call(Object, bi, d._vars_);
            d._vars_ = bi;
            if (d.evalScripts) d.evalScripts();
            else {
                tH();
                try {
                    bg()
                } catch (pa) {
                    Ch(c, 408, pa)
                }
                zp();
                var e = new xK;
                try {
                    Yf(e.H), Kl(13, c), Kl(3, c)
                } catch (pa) {
                    Ch(c, 408, pa)
                }
                var f = Vt(c, e),
                    g = null != a ? a : $t(f, c),
                    h = null != b ? b : new wK(g);
                sh(g);
                xh(g);
                Ri("gpt_fifwin", function(pa) {
                    Xi(pa, g)
                }, d.fifWin ? .01 : 0);
                var k = new oI,
                    l = new dP(k, e),
                    m = new FN(g),
                    n = _.ci(260),
                    p = new ON(g, l, Hi(), h, k, n, e, m),
                    r = kz(),
                    w = vs(g),
                    u = new dI(g),
                    y = new dI(g),
                    x = new dI(g),
                    C = _.ci(150),
                    I;
                n && (I = PN(p, u, C, w));
                var D = _.ci(221),
                    J = new uM,
                    Q = new zL,
                    N, Y, ua, ma = null != (ua = null == (N = I) ? void 0 : null == (Y = N.hf) ? void 0 : Y.ub) ? ua : new rn,
                    na = new RO(g, l, h, k, m, r, e, u, n, D, J, Q, I, w, ma);
                _.G(kC) && new eL(g, u, k, l);
                var za = Hi().j;
                os(g, h, na, za, l, y, x, e, Q, ma);
                Tm(g, d, h);
                window.setTimeout(function() {
                    for (var pa = window.document.scripts, Ta = 0, ab = 0, lb = 0; lb < pa.length; lb++) pa[lb].src.match("securepubads.g.doubleclick.net/tag/js/gpt.js") ? Ta++ : pa[lb].src.match("www.googletagservices.com/tag/js/gpt.js") && ab++;
                    1 < Ta && 0 === ab || 1 < ab && 0 === Ta ? P(h, FJ()) : 0 < ab && 0 < Ta && h.error(GJ())
                }, 1E3);
                Lr();
                if (_.G(kC) || _.Ff(Ah).j) Lt(), Pt();
                Gq(g, h);
                Wm(g)
            }
        } catch (pa) {
            Ch(c, 106, pa)
        }
    })();
    _.fP = _.t.requestAnimationFrame || _.t.webkitRequestAnimationFrame;
    _.gP = !!_.fP && !/'iPhone'/.test(_.t.navigator.userAgent);
    _.hP = function(a, b, c) {
        _.U.call(this);
        var d = this;
        this.A = a;
        this.j = b;
        this.m = c;
        this.U = null;
        _.mn(this, function() {
            return d.U = null
        })
    };
    _.T(_.hP, _.U);
}).call(this, {});