"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [75630, 22007, 67075, 23032, 87251, 7369, 59725, 56314, 34243, 70161, 9269, 23759, 19369], {
        94092: (e, t, n) => {
            n.r(t), n.d(t, {
                pauseAllVideos: () => i,
                resetYoutube: () => l,
                setCurrentPlayingVideo: () => o,
                setYoutubeAPIReady: () => a
            });
            var r = n(58005),
                a = () => ({
                    type: r.SET_YOUTUBE_API_READY,
                    payload: {
                        isAPIloaded: !0
                    }
                }),
                o = e => ({
                    type: r.SET_CURRENT_PLAYING_VIDEO,
                    payload: {
                        currentPlayingVideoID: e
                    }
                }),
                i = e => ({
                    type: r.PAUSE_ALL_VIDEOS,
                    payload: {
                        canPauseAllVideos: e
                    }
                }),
                l = () => ({
                    type: r.RESET_YOUTUBE
                })
        },
        67482: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => m
            });
            var r = n(67294),
                a = n(45697),
                o = n(14494),
                i = n(1497),
                l = n(20544),
                d = n(94092),
                s = n(20947),
                c = n(14796),
                u = n(32066),
                p = {
                    width: "100%",
                    height: "100%",
                    minHeight: "192px",
                    background: "transparent"
                },
                g = {
                    width: "100%",
                    height: "100%",
                    maxWidth: "720px",
                    maxHeight: "405px",
                    borderRadius: "8px",
                    overflow: "auto",
                    background: "transparent"
                },
                h = e => {
                    var t, {
                            isVisible: n,
                            handleClose: a,
                            bottomSheetContent: h,
                            isDesktop: m,
                            closeButtonPosition: f,
                            videoId: y,
                            customWrapperStyle: v,
                            showFullscreenButton: b,
                            isHandleStopVideo: C
                        } = e,
                        {
                            type: x = "",
                            url: S = ""
                        } = h || {},
                        [w] = (0, s.default)("ptm-yt-api"),
                        E = (0, o.I0)(),
                        I = S ? new URL(S) : {},
                        P = (null == I || null === (t = I.searchParams) || void 0 === t ? void 0 : t.get("v")) || y || "";
                    return (0, r.useEffect)((() => (w && n && E((0, d.setYoutubeAPIReady)()), () => {
                        n && E((0, d.resetYoutube)())
                    })), [w]), n ? r.createElement(u.YoutubeWrapper, {
                        isDesktop: m
                    }, "youtube" === x ? r.createElement(l.default, {
                        close: a,
                        position: "center",
                        modalStyle: m ? g : p
                    }, r.createElement(u.ContentWrapper, null, r.createElement(u.CloseButtonWrapper, {
                        onClick: a,
                        isDesktop: m,
                        closeButtonPosition: f
                    }, r.createElement(i.default, {
                        fileName: "common",
                        svgName: "close",
                        width: "100%",
                        height: "100%"
                    })), r.createElement(u.VideoFrameWrapper, {
                        style: v
                    }, r.createElement(c.default, {
                        isVisible: n,
                        handleClose: a,
                        videoId: P,
                        videoWidth: "100%",
                        videoHeight: "100%",
                        autoPlay: !0,
                        loadThumbnailImmediately: !0,
                        showFullscreenButton: b,
                        isHandleStopVideo: C
                    })))) : null) : null
                };
            h.defaultProps = {
                isVisible: "",
                handleClose: () => {},
                bottomSheetContent: {},
                isDesktop: !1,
                closeButtonPosition: "",
                videoId: "",
                customWrapperStyle: {},
                showFullscreenButton: !0,
                isHandleStopVideo: !0
            }, h.propTypes = {
                isVisible: a.bool,
                handleClose: a.func,
                bottomSheetContent: (0, a.shape)({}),
                isDesktop: a.bool,
                closeButtonPosition: a.string,
                videoId: a.string,
                customWrapperStyle: (0, a.shape)({}),
                showFullscreenButton: a.bool,
                isHandleStopVideo: a.bool
            };
            const m = h
        },
        32066: (e, t, n) => {
            n.r(t), n.d(t, {
                CloseButtonWrapper: () => g,
                ContentWrapper: () => h,
                LoaderWrapper: () => c,
                SVGFrame: () => s,
                VideoFrameContainer: () => d,
                VideoFrameWrapper: () => m,
                YoutubeWrapper: () => o
            });
            var r = n(93352),
                a = (0, r.keyframes)(["from{opacity:0;}to{opacity:1;}"]),
                o = r.default.div.withConfig({
                    componentId: "sc-12rvx0o-0"
                })(["width:100%;height:100%;"]),
                i = (0, r.css)(["iframe{opacity:0;}"]),
                l = (0, r.css)(["iframe{opacity:1;}"]),
                d = r.default.div.withConfig({
                    componentId: "sc-12rvx0o-1"
                })(["width:", ";height:", ";position:relative;transition:opacity 0.2s ease;", ""], (e => e.videoWidth), (e => e.videoHeight), (e => {
                    var {
                        isLoading: t
                    } = e;
                    return t ? i : l
                })),
                s = r.default.div.withConfig({
                    componentId: "sc-12rvx0o-2"
                })(["position:absolute;width:48px;height:48px;top:calc(50% - 24px);margin-left:calc(50% - 24px);z-index:2;svg{width:48px;height:48px;}"]),
                c = r.default.div.withConfig({
                    componentId: "sc-12rvx0o-3"
                })(["display:flex;height:100%;width:100%;position:absolute;top:0;"]),
                u = (0, r.css)(["margin:10px;top:0;left:auto;"]),
                p = (0, r.css)(["margin-right:0;top:0px;margin-top:0px;"]),
                g = r.default.div.withConfig({
                    componentId: "sc-12rvx0o-4"
                })(["width:48px;height:48px;position:fixed;left:0;right:0;margin-left:auto;margin-right:auto;margin-top:-100px;cursor:pointer;animation:", " 2s ease-in-out;z-index:1;", " ", ""], a, (e => {
                    var {
                        isDesktop: t
                    } = e;
                    return t && u
                }), (e => {
                    var {
                        closeButtonPosition: t
                    } = e;
                    return "topRight" === t && p
                })),
                h = r.default.div.withConfig({
                    componentId: "sc-12rvx0o-5"
                })(["width:100%;height:100%;display:flex;align-items:center;justify-content:center;background-color:black;"]),
                m = r.default.div.withConfig({
                    componentId: "sc-12rvx0o-6"
                })(["width:100%;height:30vh;min-height:192px;background:transparent;"])
        },
        14796: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => b
            });
            var r = n(67294),
                a = n(16550),
                o = n(14494),
                i = n(45697),
                l = n.n(i),
                d = n(10746),
                s = n(1497),
                c = n(54430),
                u = n(87808),
                p = n(94092),
                g = n(82424),
                h = n(79153),
                m = n(70423),
                f = n(32066),
                y = {
                    borderRadius: "0px"
                },
                v = e => {
                    var t, {
                            videoId: n,
                            videoWidth: i,
                            videoHeight: l,
                            onVideoClick: v,
                            autoPlay: b,
                            loadThumbnailImmediately: C,
                            showFullscreenButton: x,
                            isHandleStopVideo: S
                        } = e,
                        w = (0, a.k6)(),
                        [E, I] = (0, u.default)({
                            threshold: .8
                        }),
                        {
                            platform: P,
                            youtube: R
                        } = (0, o.v9)((e => {
                            var t;
                            return {
                                platform: null == e || null === (t = e.cookies) || void 0 === t ? void 0 : t.platform,
                                youtube: e.youtube
                            }
                        })),
                        {
                            isAPIloaded: T,
                            currentPlayingVideoID: W
                        } = R || {},
                        {
                            code: k = c.APP_CODE
                        } = P || {},
                        O = k === c.ANDROID_APP_CODE,
                        _ = k === c.IOS_APP_CODE,
                        F = O || _,
                        B = (0, o.I0)(),
                        [A, H] = (0, r.useState)(b),
                        [z, D] = (0, r.useState)(!1),
                        j = (0, r.useRef)(null),
                        M = (0, r.useRef)(null),
                        L = () => {
                            F && (0, g.closeWebView)(), w.goBack()
                        },
                        V = e => {
                            B((0, p.setCurrentPlayingVideo)(n)), e.target.playVideo()
                        },
                        N = () => {
                            D(!1)
                        },
                        Y = () => {
                            N()
                        };
                    A && I.intersectionRatio < .8 && !document.fullscreenElement && null != M && null !== (t = M.current) && void 0 !== t && t.stopVideo && S && M.current.stopVideo();
                    return (0, r.useEffect)((() => {
                        window.hardwareBackPressed = L
                    }), []), (0, r.useEffect)((() => {
                        W && W !== n && M.current && (M.current.getPlayerState && M.current.getPlayerState()) === YT.PlayerState.PLAYING && M.current.stopVideo && M.current.stopVideo()
                    }), [W]), (0, r.useEffect)((() => {
                        A && window.YT && (D(!0), M.current = new YT.Player(j.current, {
                            height: l,
                            width: i,
                            videoId: n,
                            playerVars: {
                                enablejsapi: 1,
                                modestbranding: 1,
                                origin: window.location.hostname,
                                playsinline: 1,
                                mute: b || (0, h.isSafari)() ? 1 : 0,
                                fs: x ? 1 : 0
                            },
                            events: {
                                onReady: V,
                                onStateChange: Y,
                                onError: N
                            }
                        }))
                    }), [A, T]), (0, r.useEffect)((() => () => {
                        var e = M.current;
                        e && e.destroy && e.destroy()
                    }), []), r.createElement(f.VideoFrameContainer, {
                        ref: E,
                        id: n,
                        onClick: () => {
                            T && !A && (H(!0), v())
                        },
                        videoHeight: l,
                        videoWidth: i,
                        isLoading: z
                    }, !A && r.createElement(r.Fragment, null, r.createElement(d.default, {
                        width: i,
                        height: l,
                        hasThumbnail: !0,
                        alt: "placeholder",
                        src: "https://img.youtube.com/vi/".concat(n, "/hqdefault.jpg"),
                        shouldLoadImmediately: C,
                        customContainerStyle: y,
                        customImageStyle: y
                    }), r.createElement(f.SVGFrame, null, r.createElement(s.default, {
                        fileName: "common",
                        svgName: "play"
                    }))), A ? r.createElement("div", {
                        ref: j
                    }) : null, A && z && r.createElement(f.LoaderWrapper, null, r.createElement(m.default, null)))
                };
            v.defaultProps = {
                onVideoClick: () => null,
                autoPlay: !1,
                loadThumbnailImmediately: !1,
                showFullscreenButton: !0,
                isHandleStopVideo: !0
            }, v.propTypes = {
                videoId: l().string.isRequired,
                videoWidth: l().string.isRequired,
                videoHeight: l().string.isRequired,
                onVideoClick: l().func,
                autoPlay: l().bool,
                loadThumbnailImmediately: l().bool,
                showFullscreenButton: l().bool,
                isHandleStopVideo: l().bool
            };
            const b = (0, r.memo)(v)
        },
        44440: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => a
            });
            var r = n(67294);
            const a = () => r.createElement("style", {
                id: "modal-style",
                dangerouslySetInnerHTML: {
                    __html: "\n\t\thtml {\n\t\t\toverflow: hidden;\n\t\t\tposition: relative;\n\t\t}\n\n\t\tbody {\n\t\t\toverflow: hidden;\n\t\t\tposition: relative;\n\t\t}\n\n\t\t.super-container {\n\t\t\theight: auto;\n\t\t}\n\t"
                }
            })
        },
        20544: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => d
            });
            var r = n(67294),
                a = n(45697),
                o = n(44440),
                i = n(91515),
                l = e => {
                    var {
                        close: t,
                        handleModalComponentClick: n,
                        position: a,
                        isFullScreen: l,
                        modalStyle: d,
                        containerStyle: s,
                        backgroundColor: c,
                        height: u,
                        children: p
                    } = e;
                    return r.createElement(r.Fragment, null, r.createElement(i.ModalOverlay, {
                        "data-testid": "modalClose",
                        onClick: e => {
                            e.stopPropagation(), t()
                        },
                        style: s
                    }, r.createElement(i.ModalComponent, {
                        position: a,
                        isFullScreen: l,
                        customHeight: u,
                        style: d,
                        backgroundColor: c,
                        onClick: e => {
                            e.stopPropagation(), n()
                        }
                    }, p)), r.createElement(o.default, null))
                };
            l.defaultProps = {
                close: () => null,
                handleModalComponentClick: () => null,
                position: "center",
                isFullScreen: !1,
                height: "auto",
                modalStyle: {},
                containerStyle: {},
                backgroundColor: "#FFFFFF"
            }, l.propTypes = {
                close: a.func,
                handleModalComponentClick: a.func,
                position: a.string,
                isFullScreen: a.bool,
                height: a.string,
                modalStyle: (0, a.shape)({}),
                containerStyle: (0, a.shape)({}),
                backgroundColor: a.string,
                children: a.node.isRequired
            };
            const d = l
        },
        91515: (e, t, n) => {
            n.r(t), n.d(t, {
                ModalComponent: () => i,
                ModalOverlay: () => o
            });
            var r = n(93352),
                a = (0, r.keyframes)(["from{transform:translate3d(0,2000px,0);visibility:visible;}to{transform:translate3d(0,0,0);}"]),
                o = r.default.div.withConfig({
                    componentId: "sc-7silkt-0"
                })(["top:0;left:0;right:0;bottom:0;display:flex;justify-content:center;align-items:center;z-index:", ";opacity:1;position:fixed;overflow-x:hidden;overflow-y:auto;background-color:", ";"], (e => e.theme.headerZ), (e => e.theme.TRANSPARENT_DARK)),
                i = r.default.div.withConfig({
                    componentId: "sc-7silkt-1"
                })(["position:", ";top:", ";bottom:", ";height:", ";max-height:", ";background-color:", ";width:100%;animation:", " 0.4s ease;", ";"], (e => "center" !== e.position ? "absolute" : "relative"), (e => "top" === e.position ? "0" : "auto"), (e => "bottom" === e.position ? "0" : "auto"), (e => e.isFullScreen ? "100%" : e.customHeight), (e => e.isFullScreen ? "100%" : e.customHeight), (e => e.backgroundColor), a, (e => e.theme.hideHorizontalScrollbar))
        },
        20947: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => o
            });
            var r = n(67294),
                a = "https://www.youtube.com/iframe_api";

            function o(e) {
                var [t, n] = (0, r.useState)({
                    loaded: !1,
                    error: !1
                });
                return (0, r.useEffect)((() => {
                    if (window.YT) return n({
                        loaded: !0,
                        error: !1
                    }), () => {
                        window.YT = void 0;
                        var t = document.getElementById(e);
                        t && t.parentNode.removeChild(t)
                    };
                    var t = document.createElement("script");
                    t.id = e, t.src = a;
                    var r = document.getElementsByTagName("script")[0];
                    r.parentNode.insertBefore(t, r);
                    window.onYouTubeIframeAPIReady = () => {
                        n({
                            loaded: !0,
                            error: !1
                        })
                    };
                    var o = () => {
                        n({
                            loaded: !1,
                            error: !0
                        })
                    };
                    return t.addEventListener("error", o), () => {
                        window.YT = void 0, t.removeEventListener("error", o);
                        var n = document.getElementById(e);
                        n && n.parentNode.removeChild(n)
                    }
                }), [e]), [t.loaded, t.error]
            }
        },
        41393: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => g
            });
            var r = n(4942);

            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function o(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach((function(t) {
                        (0, r.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var i = "375px",
                l = "425px",
                d = "768px",
                s = "1024px",
                c = "1440px",
                u = "2560px",
                p = {
                    mobileSmallMax: "(max-width: ".concat("320px", ")"),
                    mobileMediumMax: "(max-width: ".concat(i, ")"),
                    mobileLargeMax: "(max-width: ".concat(l, ")"),
                    tabletMax: "(max-width: ".concat(d, ")"),
                    tabletMin: "(min-width: ".concat(d, ")"),
                    laptopMin: "(min-width: ".concat(s, ")"),
                    laptopMax: "(max-width: ".concat(s, ")"),
                    laptopLargeMin: "(min-width: ".concat(c, ")"),
                    desktopMin: "(min-width: ".concat(u, ")")
                };
            const g = o(o(o(o(o(o(o(o({}, {
                BMS_RED_1: "#DC3558",
                BMS_RED_2: "#F84464",
                BMS_RED_3: "#ffbbc3",
                BMS_RED_5: "#AE1E31",
                BMS_PINK_2: "#EB4E62",
                BMS_BLUE_1: "#3e6eea",
                BMS_BLUE_2: "#5e8aff",
                BMS_BLUE_3: "#bfd1ff",
                BMS_BLUE_4: "#0378FF",
                BMS_BLUE_5: "#0078ff",
                NOIR_1: "#1f253a",
                NOIR_2: "#2b3148",
                BMS_BACKGROUND: "#f2f5f9",
                WHITE: "#ffffff",
                WHITE_SMOKE: "#F6F6F6",
                BLACK: "#000000",
                GREY_0: "#1A1A1A",
                GREY_1: "#333333",
                GREY_2: "#666666",
                GREY_3: "#cccccc",
                GREY_4: "#eeeeee",
                GREY_5: "#999999",
                GREY_6: "#dddddd",
                GREY_7: "#222222",
                GREY_8: "#ebebeb",
                GREY_9: "#525252",
                GREY_10: "#808080",
                GREY_11: "#E5E5E5",
                GREY_12: "#F8F8F8",
                GREY_13: "#3a3a3a",
                GREY_14: "#FCFCFC",
                GREY_15: " #d1d1d1",
                GREY_17: "#505961",
                GREY_18: "#424242",
                LIGHT_GREY_5: "#F2F2F2",
                SUCCESS_1: "#008a1e",
                SUCCESS_2: "#1ea83c",
                SUCCESS_3: "#acf4bc",
                SUCCESS_4: "#006616",
                SUCCESS_6: "#c9f8d3",
                INFO_1: "#fcc42d",
                INFO_2: "#ffd564",
                INFO_3: "#fff3d2",
                INFO_4: "#ffe49b",
                INFO_5: "#fff1cc",
                ERROR_1: "#b50000",
                ERROR_2: "#d23131",
                ERROR_3: "#ffb3b3",
                YELLOW_0: "#C99303",
                DARK_BLUE_1: "#2D3553",
                DARK_BLUE_2: "#2e3147",
                BLUE_GREY_2: "#3b4261",
                BLUE_5: "#CCDAFF",
                BLUE_6: "#EBF0FF",
                TRANSPARENT_DARK: "rgba(34 34 34 / 0.8)",
                TRANSPARENT_DARK_SOFT: "rgba(0 0 0 / 0.3)",
                SHIMMER: "linear-gradient(to right, #F2F2F2 0%, #DDDDDD 20%, #F2F2F2 40%, #F2F2F2 100%)",
                SILVER: "#c0c0c0",
                LINKGRAY: "#aaabac",
                FACEBOOK: "#3b5998",
                TWITTER: "#0b92ff",
                WHATSAPP: "#25d366",
                SIES: "#F5F5F5",
                FLUSH_ORANGE: "#FB8300",
                WHITE_RED: "#fff3f5",
                AMARANTH: "#E7364D",
                BMS_PINK_1: "#DC354B",
                BMS_PINK_2: "#EB4E62",
                BMS_GREEN_1: "#1FAD3E"
            }), p), {
                headerZ: 100,
                overlayZ: 99,
                beforeZ: 1,
                afterZ: 2
            }), {
                font_size_2: "2px",
                font_size_4: "4px",
                font_size_6: "6px",
                font_size_8: "8px",
                font_size_12: "12px",
                font_size_14: "14px",
                font_size_16: "16px",
                font_size_18: "18px",
                font_size_20: "20px",
                font_size_24: "24px",
                font_size_34: "34px",
                font_size_40: "40px"
            }), {
                "desktop-heading": "font-family: Roboto;font-size: 36px; font-weight: bold; line-height: 42px;",
                "temp-header-xlarge": "font-family: Roboto;font-size: 24px;font-weight: 700;line-height: 1.17;",
                "header-font": "font-family: Roboto;font-size: 24px;font-weight: 800;line-height: 1.17;",
                "h6-bold": "font-family: Roboto;font-size: 21px;font-weight: 700;line-height: 1.33;",
                "h5-bold": "font-family: Roboto; font-size: 24px; font-weight: 700; line-height: 28px;",
                "desktop-content-title": "font-family: Roboto;font-size: 24px;font-weight: 500;line-height: 1.33;",
                title: "font-family: Roboto;font-size: 24px;font-weight: 700;line-height: 1.17;",
                "content-title": "font-family: Roboto;font-size: 24px;font-weight: bold;line-height: 1.17;",
                "Content-body": "font-family: Roboto;font-size: 18px;font-weight: normal;line-height: 1.56;",
                "subtitle-xlarge": "font-family: Roboto;font-size: 22px;font-weight: 500;line-height: 1.27;",
                "subtitle-large": "font-family: Roboto;font-size: 18px;font-weight: 500;line-height: 1.33;",
                "subtitle-medium": "font-family: Roboto;font-size: 14px;font-weight: 500;line-height: 1.5;",
                "subtitle-regular": "font-family: Roboto;font-size: 16px;font-weight: 500;line-height: 1.25;",
                "subtitle-small": "font-family: Roboto;font-size: 12px;font-weight: 500;line-height: 1.33;",
                "body-large": "font-family: Roboto;font-size: 16px;font-weight: normal;line-height: 1.5;",
                "body-regular": "font-family: Roboto;font-size: 14px;font-weight: normal;line-height: 1.43;",
                "body-small": "font-family: Roboto;font-size: 12px;font-weight: normal;line-height: 1.33;",
                "large-bold": "font-family: Roboto; font-size: 18px; font-weight: 700; line-height: 28px;",
                "small-regular": "font-family: Roboto; font-size: 14px; font-weight: 400; line-height: 20px;",
                "small-medium": "font-family: Roboto; font-size: 14px; font-weight: 500; line-height: 22px;",
                "small-bold": "font-family: Roboto; font-size: 14px; font-weight: 700; line-height: 20px;",
                "tiny-medium": "font-family: Roboto; font-size: 12px; font-weight: 500; line-height: 16px;",
                "tiny-regular": "font-family: Roboto; font-size: 12px; font-weight: 400; line-height: 16px;",
                "extra-tiny-regular": "font-family: Roboto; font-size: 11px; font-weight: 400; line-height: 16px;",
                overline: "font-family: Roboto;font-size: 10px;font-weight: 500;line-height: 1.6;"
            }), {
                hideHorizontalScrollbar: "\n\t\t&::-webkit-scrollbar {\n\t\t\tdisplay: none;\n\t\t}\n\t\t&::-webkit-scrollbar-thumb {\n\t\t\tbackground-color: transparent;\n\t\t}\n\t\t-ms-overflow-style: none;\n\t\tscrollbar-width: none;\n\t"
            }), {
                flexCentered: "display: flex; justify-content: center; align-items: center;"
            }), {
                font_weight_400: "400",
                font_weight_500: "500",
                font_weight_700: "700"
            })
        },
        54922: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => l,
                defaultComponent: () => i
            });
            var r = n(67294),
                a = n(77100),
                o = n(16759),
                i = e => {
                    var {
                        error: t = "Component not found in hybrid text"
                    } = e;
                    return r.createElement("div", null, t)
                };
            const l = {
                text: o.default,
                image: a.default,
                default: i
            }
        },
        77100: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => p
            });
            var r = n(67294),
                a = n(14494),
                o = n(45697),
                i = n(10746),
                l = n(24223),
                d = n(931),
                s = n(5237),
                c = {
                    borderRadius: "0",
                    opacity: "0",
                    transition: "all 0.5s",
                    width: "100%",
                    minHeight: "inherit",
                    maxHeight: "inherit"
                },
                u = e => {
                    var {
                        src: t,
                        cardFallbackWidths: n,
                        width: o,
                        height: u,
                        imageContainerStyle: p,
                        altText: g,
                        shouldLoadImmediately: h,
                        hasThumbnail: m,
                        customContainerStyle: f,
                        id: y
                    } = e, {
                        isFifaFlow: v
                    } = (0, a.v9)((e => ({
                        isFifaFlow: e.appConfig.isFifaFlow
                    }))), [b, C] = (0, r.useState)(!0), [x, S] = (0, l.useDimensions)(!0, {
                        events: {
                            enableResize: !0
                        }
                    }), w = () => {
                        C(!1)
                    }, E = "PTM Transaction" === y, I = !v && m, P = r.useContext(s.default), R = h || P.includes(y), T = g ? g.replace(new RegExp("'", "g"), "\\'") : "";
                    return r.createElement(d.ImageContainer, {
                        ref: x,
                        imageContainerStyle: p,
                        containerWidth: S.width ? "".concat(S.width, "px") : "",
                        cardFallbackWidths: n,
                        width: o,
                        height: u,
                        isImageLoaded: b,
                        "data-content": T
                    }, r.createElement(d.ImageWrapper, {
                        isImageLoaded: b,
                        isPTMWidget: E
                    }, R ? r.createElement("img", {
                        src: t,
                        alt: g,
                        width: o,
                        height: u,
                        onError: w
                    }) : r.createElement(i.default, {
                        customImageStyle: c,
                        src: t,
                        width: o,
                        height: u,
                        alt: g,
                        onError: w,
                        hasThumbnail: I,
                        customContainerStyle: f,
                        rootMargin: "400px"
                    })))
                };
            u.defaultProps = {
                src: "",
                cardFallbackWidths: {
                    mobile: "125px",
                    desktop: "125px"
                },
                width: "100%",
                height: "100%",
                imageContainerStyle: {},
                altText: "",
                shouldLoadImmediately: !1,
                hasThumbnail: !0,
                customContainerStyle: {},
                id: ""
            }, u.propTypes = {
                src: o.string,
                cardFallbackWidths: (0, o.shape)({}),
                width: o.string,
                height: o.string,
                imageContainerStyle: (0, o.shape)({}),
                altText: o.string,
                shouldLoadImmediately: o.bool,
                hasThumbnail: o.bool,
                customContainerStyle: (0, o.shape)({}),
                id: o.string
            };
            const p = (0, r.memo)(u)
        },
        931: (e, t, n) => {
            n.r(t), n.d(t, {
                ImageContainer: () => i,
                ImageWrapper: () => d
            });
            var r = n(93352),
                a = n(72999),
                o = n(46381),
                i = (0, r.default)(o.VerticalFlexBox).withConfig({
                    componentId: "sc-1t5vwh0-0"
                })(["position:relative;align-items:center;overflow:hidden;transition:height 0.3s ease-in,width 0.3s ease-in;width:", ";height:", ";", " ", " ", " ", " ", " ", " ", ""], (e => {
                    var {
                        width: t
                    } = e;
                    return t
                }), (e => {
                    var {
                        height: t
                    } = e;
                    return t
                }), (e => {
                    var {
                        theme: t,
                        imageContainerStyle: n,
                        containerWidth: r,
                        cardFallbackWidths: a
                    } = e;
                    return n && n.aspectRatio ? "height: calc(".concat(r || a.mobile, " / ").concat(n.aspectRatio, ");max-height: unset;@media ").concat(t.laptopMin, " {height: calc(").concat(r || a.desktop, " / ").concat(n.aspectRatio, ");max-height: calc(").concat(r || a.maxDesktop, " / ").concat(n.aspectRatio, ");}") : ""
                }), (e => {
                    var {
                        imageContainerStyle: t
                    } = e;
                    return t && t.aspectRatio && t.width ? "height: ".concat(t.width / t.aspectRatio, "px;") : ""
                }), (e => {
                    var {
                        imageContainerStyle: t
                    } = e;
                    return t && t.width ? "width: ".concat(t.width, "px;") : ""
                }), (e => {
                    var {
                        imageContainerStyle: t
                    } = e;
                    return t && t.margin ? "margin: ".concat(t.margin, ";") : ""
                }), (e => {
                    var {
                        isImageLoaded: t,
                        theme: n
                    } = e;
                    return "\n\t\t".concat(t ? "" : (0, r.css)(["background:", ";border-radius:4px;"], n.GREY_8), "\n\t\t&:before {\n\t\t\tcontent: attr(data-content);\n\t\t\tposition: absolute;\n\t\t\tz-index: ").concat(n.beforeZ, ";\n\t\t\ttop: 0;\n    \t\tleft: 8px;\n    \t\tpadding: 24px 8px;\n    \t\tcolor: ").concat(n.GREY_4, ";\n    \t\tfont-size: 14px;\n\t\t\tline-height: 1.43em;\n\t\t\theight: calc(24px + 4.29em);\n\t\t\toverflow: hidden;\n\t\t\ttext-overflow: ellipsis;\n\t\t\tdisplay: ").concat(t ? "none" : "-webkit-box", ";\n\t\t\t-webkit-line-clamp: 3;\n\t\t\t-webkit-box-orient: vertical;\n\t\t}")
                }), (e => {
                    var {
                        imageContainerStyle: t,
                        theme: n
                    } = e;
                    return t && t.shimmer ? (0, r.css)(["&:after{content:'';position:absolute;z-index:", ";top:0;left:0;height:100%;width:100%;", "}"], n.beforeZ, o.ShimmerKeyAnimationStyle) : ""
                }), (e => {
                    var {
                        imageContainerStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasBorderRadius: !0,
                        hasMargin: !0
                    })
                })),
                l = (0, r.css)(["height:auto;width:auto;"]),
                d = (0, r.default)(o.VerticalFlexBox).withConfig({
                    componentId: "sc-1t5vwh0-1"
                })(["height:100%;width:100%;img{height:", ";width:", ";object-fit:cover;transition:visibility 0s,opacity 0.3s linear;opacity:", ";visibility:", ";}", ""], (e => {
                    var {
                        height: t
                    } = e;
                    return t
                }), (e => {
                    var {
                        width: t
                    } = e;
                    return t
                }), (e => {
                    var {
                        isImageLoaded: t
                    } = e;
                    return t ? "1" : "0"
                }), (e => {
                    var {
                        isImageLoaded: t
                    } = e;
                    return t ? "visible" : "hidden"
                }), (e => {
                    var {
                        isPTMWidget: t
                    } = e;
                    return t && l
                }))
        },
        68932: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => c
            });
            var r = n(67294),
                a = n(45697),
                o = n.n(a),
                i = n(54922),
                l = n(50468),
                d = n(72999),
                s = e => {
                    var {
                        data: t,
                        tagsHorizontalSpacing: n,
                        tagsAlignment: a,
                        styles: o
                    } = e;
                    return r.createElement(l.TagsWrapper, {
                        tagsAlignment: a
                    }, t.map((e => e.label && e.label.components ? e.label.components.map(((t, s) => {
                        var c = (0, d.getComponentStyleFromStyleId)(e.styleId, o),
                            u = (0, d.getComponentStyleFromStyleId)(e.label.styleId, o),
                            p = i.default[t.type] || i.default.default;
                        return r.createElement(l.TagWrapper, {
                            key: s,
                            tagsAlignment: a,
                            tagsHorizontalSpacing: n,
                            tagContainerStyle: c[0]
                        }, r.createElement(l.TagsContainer, {
                            tagContainerStyle: c[0]
                        }, r.createElement(p, {
                            key: s,
                            text: t.text,
                            hybridStyle: u[0]
                        })))
                    })) : null)))
                };
            s.defaultProps = {
                tagsHorizontalSpacing: 0,
                tagsAlignment: "right",
                styles: {},
                data: []
            }, s.propTypes = {
                tagsHorizontalSpacing: o().number,
                tagsAlignment: o().string,
                styles: o().object,
                data: o().array
            };
            const c = s
        },
        50468: (e, t, n) => {
            n.r(t), n.d(t, {
                TagWrapper: () => l,
                TagsContainer: () => d,
                TagsWrapper: () => i
            });
            var r = n(93352),
                a = n(72999),
                o = n(46381),
                i = (0, r.default)(o.VerticalFlexBox).withConfig({
                    componentId: "sc-5afure-0"
                })(["position:absolute;z-index:", ";top:4px;", ""], (e => e.theme.afterZ), (e => {
                    var {
                        tagsAlignment: t
                    } = e;
                    return "left" === t ? "left: 4px" : "right: 4px"
                })),
                l = (0, r.default)(o.VerticalFlexBox).withConfig({
                    componentId: "sc-5afure-1"
                })(["position:relative;overflow:hidden;", " ", ""], (e => {
                    var {
                        tagContainerStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasBorderRadius: !0
                    })
                }), (e => {
                    var {
                        tagsAlignment: t,
                        tagsHorizontalSpacing: n = 0
                    } = e;
                    return "left" === t ? "margin-right: ".concat(n, "px") : "margin-left: ".concat(n, "px")
                })),
                d = r.default.div.withConfig({
                    componentId: "sc-5afure-2"
                })(["", " ", ""], (e => {
                    var {
                        tagContainerStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasBackgroundColor: !0,
                        hasMargin: !0,
                        hasPadding: !0,
                        hasBorder: !0,
                        hasBorderRadius: !0,
                        hasShadow: !0
                    })
                }), (e => {
                    var {
                        tagContainerStyle: t,
                        theme: n
                    } = e;
                    return t && t.shimmer ? (0, r.css)(["&:before{content:'';position:absolute;z-index:", ";top:0;left:0;height:100%;width:100%;", "}"], n.beforeZ, o.ShimmerKeyAnimationStyle) : ""
                }))
        },
        16759: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => g
            });
            var r = n(87462),
                a = n(67294),
                o = n(45697),
                i = n.n(o),
                l = n(41393),
                d = n(49486),
                s = n(1497),
                c = n(25773),
                u = {
                    header: c.HeaderStyledText,
                    div: c.StyledText,
                    default: c.StyledText
                },
                p = e => {
                    var {
                        text: t,
                        maxLines: n,
                        hybridStyle: o,
                        headerText: i,
                        isPTMWidget: p,
                        isClosePtmWidget: g,
                        setClosePtmWidget: h,
                        isShowtimeWidget: m,
                        customCss: f
                    } = e, y = i ? u.header : u.div;
                    return a.createElement(y, (0, r.Z)({
                        maxLines: n,
                        fontCSS: o.font && l.default[o.font] || d.default[o.font] || "",
                        textStyle: o,
                        isPTMWidget: p,
                        isShowtimeWidget: m,
                        customCss: f
                    }, p ? {
                        onClick: () => {
                            h(!g)
                        }
                    } : {}), p && a.createElement(c.PTMWidgetIcon, null, a.createElement(s.default, {
                        fileName: "common",
                        svgName: g ? "up-chevron-black" : "cross",
                        height: 8,
                        width: 8
                    })), t.replace(/^\s+|\s+$/g, " "))
                };
            p.defaultProps = {
                text: "",
                maxLines: "",
                hybridStyle: {
                    font: ""
                },
                headerText: !1,
                isPTMWidget: !1,
                isClosePtmWidget: !1,
                setClosePtmWidget: () => {},
                isShowtimeWidget: !1,
                customCss: {}
            }, p.propTypes = {
                text: i().string,
                maxLines: i().oneOfType([i().string, i().number]),
                hybridStyle: i().shape({
                    font: i().string
                }),
                headerText: i().bool,
                isPTMWidget: i().bool,
                isClosePtmWidget: i().bool,
                setClosePtmWidget: i().func,
                isShowtimeWidget: i().bool,
                customCss: i().shape({})
            };
            const g = p
        },
        25773: (e, t, n) => {
            n.r(t), n.d(t, {
                HeaderStyledText: () => i,
                PTMWidgetIcon: () => l,
                StyledText: () => o
            });
            var r = n(93352),
                a = n(72999),
                o = r.default.div.withConfig({
                    componentId: "sc-7o7nez-0"
                })(["", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], (e => {
                    var {
                        textStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasMargin: !0,
                        hasBackgroundColor: !0
                    })
                }), (e => {
                    var {
                        textStyle: t
                    } = e;
                    return t && t.lineMargin ? "margin: ".concat(t.lineMargin.replace(/,/g, "px "), "px;") : ""
                }), (e => {
                    var {
                        textStyle: t
                    } = e;
                    return t && t.doNotWrap ? "white-space: nowrap;" : "word-break: break-word;"
                }), (e => {
                    var {
                        textStyle: t
                    } = e;
                    return t && t.fontColor ? "color: ".concat(t.fontColor, ";") : ""
                }), (e => {
                    var {
                        textStyle: t
                    } = e;
                    return t && t.margin ? "margin: ".concat(t.margin, ";") : ""
                }), (e => {
                    var {
                        textStyle: t
                    } = e;
                    return t && t.horizontalAlignment && "left" !== t.horizontalAlignment ? "flex-grow: 1; text-align: ".concat(t.horizontalAlignment, ";") : ""
                }), (e => {
                    var {
                        fontCSS: t
                    } = e;
                    return (0, r.css)(["", ""], t)
                }), (e => {
                    var {
                        maxLines: t
                    } = e;
                    return t ? "overflow: hidden;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: ".concat(t, ";-webkit-box-orient: vertical;") : ""
                }), (e => {
                    var {
                        isPTMWidget: t
                    } = e;
                    return t && (0, r.css)(["background:", ";padding:0px 8px;border-radius:8px;", " color:", ";cursor:pointer;"], (e => {
                        var {
                            theme: t
                        } = e;
                        return t.INFO_YELLOW_2
                    }), (e => {
                        var {
                            theme: t
                        } = e;
                        return t["small-medium"]
                    }), (e => {
                        var {
                            theme: t
                        } = e;
                        return t.BLACK
                    }))
                }), (e => {
                    var {
                        isShowtimeWidget: t,
                        textStyle: n,
                        customCss: a
                    } = e;
                    return t && n.font && (0, r.css)(["", ""], a)
                })),
                i = (0, r.default)(o).attrs((() => ({
                    as: "h2"
                }))).withConfig({
                    componentId: "sc-7o7nez-1"
                })([""]),
                l = r.default.button.withConfig({
                    componentId: "sc-7o7nez-2"
                })(["padding:4px 10px 4px 4px;background:none;border:none;outline:none;"])
        },
        82714: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => d
            });
            var r = n(67294),
                a = n(45697),
                o = n.n(a),
                i = n(5237),
                l = e => {
                    var {
                        approxHeight: t,
                        children: n,
                        approxWidth: a,
                        rootRef: o,
                        id: l,
                        virtualHeight: d,
                        isCrawler: s
                    } = e, [c, u] = (0, r.useState)(!1), p = r.useContext(i.default), g = (0, r.useRef)(t), h = (0, r.useRef)(null), m = (0, r.useRef)(null);
                    return (0, r.useEffect)((() => {
                        if (h.current && !p.includes(l) && !s) return m.current = new IntersectionObserver((e => {
                            e[0].isIntersecting && u(e[0].isIntersecting)
                        }), {
                            root: null,
                            rootMargin: "100px",
                            threshold: .3
                        }), m.current.observe(h.current), () => {
                            h.current && m.current.unobserve(h.current)
                        }
                    }), [h]), (0, r.useEffect)((() => {
                        h.current && c && (m.current.unobserve(h.current), g.current = h.current.offsetHeight)
                    }), [c, h]), r.createElement(r.Fragment, null, s ? r.createElement(r.Fragment, null, n) : r.createElement("div", {
                        ref: h,
                        key: "parent-key".concat(n.key)
                    }, c || p.includes(l) ? r.createElement(r.Fragment, null, n) : r.createElement("div", {
                        style: {
                            height: "".concat(d, "px"),
                            width: a
                        }
                    })))
                };
            l.defaultProps = {
                approxHeight: 200,
                approxWidth: null,
                rootRef: {},
                virtualHeight: 0,
                isCrawler: !1
            }, l.propTypes = {
                approxHeight: o().number,
                approxWidth: o().number,
                rootRef: o().shape({}),
                children: o().node.isRequired,
                virtualHeight: o().number,
                isCrawler: o().bool
            };
            const d = l
        },
        71671: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => y
            });
            var r = n(4942),
                a = n(67294),
                o = n(45697),
                i = n.n(o),
                l = n(14494),
                d = n(37674),
                s = n(77100),
                c = n(24223),
                u = n(8714),
                p = n(72999),
                g = n(32578);

            function h(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function m(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? h(Object(n), !0).forEach((function(t) {
                        (0, r.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : h(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var f = e => {
                var t, {
                        cardFallbackWidths: n,
                        styles: r,
                        cardStyle: o,
                        data: i,
                        hasStyle: h,
                        itemsPerRow: f,
                        isHeaderType: y = !1,
                        parentId: v,
                        registerDismissAction: b,
                        cardCtaRefId: C
                    } = e,
                    x = (0, l.I0)(),
                    S = (0, l.v9)((e => e.cookies)),
                    [w] = (0, c.useImpressionTracker)(null, S),
                    {
                        image: E = null,
                        text: I,
                        buttons: P = null,
                        affordance: R = null,
                        id: T = "0",
                        title: W = null,
                        action: k = null
                    } = i,
                    {
                        direction: O = "ltr",
                        imageContainer: _ = {},
                        textContainer: F = {},
                        alignVertical: B = ""
                    } = o,
                    [A, H, z] = (0, p.getModifiedStyles)([_, F, o.affordance || {}]),
                    D = !(!E || !E.url),
                    j = !!I,
                    M = !!W,
                    L = !(!R || !R.imgUrl),
                    V = null == k || null === (t = k.cta) || void 0 === t ? void 0 : t.url,
                    N = e => {
                        var t, n, r = document.getElementById(C) || {};
                        null == r || null === (t = r.parentElement) || void 0 === t || t.remove(), x((0, d.dismissDropOffCard)(null == i ? void 0 : i.id, v, null == i || null === (n = i.action) || void 0 === n ? void 0 : n.actionId)), b(), e.preventDefault(), e.stopPropagation()
                    };
                return h ? a.createElement(g.HorizontalCardContainer, {
                    ref: w,
                    cardStyle: o
                }, M ? (() => {
                    var e, t, n = (0, p.getComponentStyleFromStyleId)(null == W ? void 0 : W.styleId, r, {
                            hasCardContainerStyle: !1
                        }),
                        {
                            padding: o = ""
                        } = A;
                    return a.createElement(g.HorizontalCardTitleContainer, {
                        cardTextContainerStyle: m(m({}, n[0]), {}, {
                            padding: o
                        })
                    }, (0, u.renderCardText)(r, f, [W]), V ? (e = k.cta.label.styleId, (t = r)[e].width = "21px", t[e].height = "21px", a.createElement(g.ActionContainer, {
                        onClick: N
                    }, (0, u.renderCardText)(t, f, [k.cta.label]))) : null)
                })() : null, a.createElement(g.HorizontalCardContentContainer, {
                    alignVertical: B
                }, D ? a.createElement(g.ImageContainer, {
                    direction: O,
                    imageContainerStyle: A
                }, a.createElement(s.default, {
                    cardFallbackWidths: A.width ? {
                        mobile: "".concat(A.width - (0, p.getLeftRightPadding)(A), "px")
                    } : {
                        mobile: A.calculatedWidth ? A.calculatedWidth.replace("100%", n.mobile) : ""
                    },
                    imageContainerStyle: m(m({}, A), A.width && {
                        width: "".concat(A.width - (0, p.getLeftRightPadding)(A))
                    }),
                    src: E.url,
                    altText: E.altText,
                    id: T,
                    shouldLoadImmediately: y
                })) : null, j ? a.createElement(g.TextContainer, {
                    cardTextContainerStyle: H,
                    direction: O
                }, (0, u.renderCardText)(r, f, I)) : null, L ? a.createElement(g.AffordanceWrapper, {
                    affordanceContainerStyle: z
                }, a.createElement(g.Affordance, {
                    affordanceContainerStyle: z
                }, a.createElement(s.default, {
                    cardFallbackWidths: {
                        mobile: z.width ? "".concat(z.width - (0, p.getLeftRightPadding)(z), "px") : "100%"
                    },
                    imageContainerStyle: m(m({}, z), z.width && {
                        width: "".concat(z.width - (0, p.getLeftRightPadding)(z))
                    }),
                    src: R.imgUrl,
                    id: T,
                    shouldLoadImmediately: y
                }))) : null), P ? (0, u.renderCardButtons)(r, f, P) : null) : null
            };
            f.defaultProps = {
                styles: {},
                cardStyle: {
                    affordance: {}
                },
                data: {
                    id: ""
                },
                hasStyle: !1,
                itemsPerRow: 0,
                isHeaderType: !1,
                parentId: "",
                registerDismissAction: () => null,
                cardFallbackWidths: {}
            }, f.propTypes = {
                styles: i().shape({}),
                cardStyle: i().shape({
                    affordance: i().shape({})
                }),
                data: i().shape({
                    id: i().string
                }),
                hasStyle: i().bool,
                itemsPerRow: i().number,
                isHeaderType: i().bool,
                parentId: i().string,
                registerDismissAction: i().func,
                cardFallbackWidths: i().shape({})
            };
            const y = f
        },
        32578: (e, t, n) => {
            n.r(t), n.d(t, {
                ActionContainer: () => g,
                Affordance: () => u,
                AffordanceWrapper: () => c,
                HorizontalCardContainer: () => i,
                HorizontalCardContentContainer: () => l,
                HorizontalCardTitleContainer: () => p,
                ImageContainer: () => d,
                TextContainer: () => s
            });
            var r = n(93352),
                a = n(46381),
                o = n(72999),
                i = r.default.div.withConfig({
                    componentId: "sc-1mrya4h-0"
                })(["", ""], (e => {
                    var {
                        cardStyle: t
                    } = e;
                    return (0, o.getComponentStyle)(t, {
                        hasBackgroundColor: !0,
                        hasPadding: !0,
                        hasBorder: !0,
                        hasBorderRadius: !0,
                        hasShadow: !0
                    })
                })),
                l = (0, r.default)(a.VerticalFlexBox).withConfig({
                    componentId: "sc-1mrya4h-1"
                })(["", ""], (e => {
                    var {
                        alignVertical: t
                    } = e;
                    return t ? "align-items: center;" : ""
                })),
                d = r.default.div.withConfig({
                    componentId: "sc-1mrya4h-2"
                })(["flex:0 0 auto;", " ", ""], (e => {
                    var {
                        direction: t
                    } = e;
                    return "rtl" === t ? "order: 2;" : ""
                }), (e => {
                    var {
                        imageContainerStyle: t
                    } = e;
                    return "".concat((0, o.getComponentStyle)(t, {
                        hasCalculatedWidth: !0,
                        hasWidth: !0,
                        hasPadding: !0
                    })).concat(t.width || t.calculatedWidth ? "" : "flex-grow: 1;")
                })),
                s = (0, r.default)(a.HorizontalFlexBox).withConfig({
                    componentId: "sc-1mrya4h-3"
                })(["", " ", ""], (e => {
                    var {
                        direction: t
                    } = e;
                    return "rtl" === t ? "order: 1;" : ""
                }), (e => {
                    var {
                        cardTextContainerStyle: t
                    } = e;
                    return "".concat((0, o.getComponentStyle)(t, {
                        hasMargin: !0,
                        hasPadding: !0,
                        hasVerticalAlign: !0
                    })).concat(t.width || t.calculatedWidth ? "" : "flex-grow: 1;")
                })),
                c = r.default.div.withConfig({
                    componentId: "sc-1mrya4h-4"
                })(["flex:0 0 auto;order:3;", ""], (e => {
                    var {
                        affordanceContainerStyle: t
                    } = e;
                    return "".concat((0, o.getComponentStyle)(t, {
                        hasMargin: !0
                    })).concat(t.width || t.calculatedWidth ? "" : "flex-grow: 1;")
                })),
                u = r.default.div.withConfig({
                    componentId: "sc-1mrya4h-5"
                })(["", ""], (e => {
                    var {
                        affordanceContainerStyle: t
                    } = e;
                    return (0, o.getComponentStyle)(t, {
                        hasBackgroundColor: !0,
                        hasBorderRadius: !0,
                        hasPadding: !0,
                        hasWidth: !0
                    })
                })),
                p = (0, r.default)(s).withConfig({
                    componentId: "sc-1mrya4h-6"
                })(["padding-bottom:0;flex-direction:row;justify-content:space-between;"]),
                g = (0, r.default)(a.VerticalFlexBox).withConfig({
                    componentId: "sc-1mrya4h-7"
                })(["align-items:center;"])
        },
        73394: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => g
            });
            var r = n(67294),
                a = n(45697),
                o = n.n(a),
                i = n(14494),
                l = n(77100),
                d = n(68932),
                s = n(24223),
                c = n(8714),
                u = n(79320),
                p = e => {
                    var {
                        cardFallbackWidths: t,
                        styles: n,
                        cardStyle: a,
                        data: o,
                        hasStyle: p,
                        itemsPerRow: g,
                        overlayGradient: h,
                        shouldLoadImmediately: m,
                        overrideZindex: f
                    } = e, y = (0, i.v9)((e => e.cookies)), [v] = (0, s.useImpressionTracker)(null, y), [b, C] = (0, s.useDimensions)(!0, {
                        events: {
                            enableResize: !0
                        }
                    }), {
                        image: x,
                        text: S,
                        tags: w,
                        buttons: E = null,
                        id: I
                    } = o, {
                        imageContainer: P = {},
                        textContainer: R = {},
                        tagsAlignment: T = "right",
                        tagsHorizontalSpacing: W = 0
                    } = a, k = f ? {
                        zIndex: 0
                    } : {};
                    return p ? r.createElement(u.OverlayCardContainer, {
                        ref: v,
                        overlayGradient: h
                    }, r.createElement(u.OverlayCardImageContainer, {
                        ref: b,
                        overlayGradient: h
                    }, x && x.url && r.createElement(u.ImageContainer, {
                        imageContainerStyle: P,
                        overlayGradient: h
                    }, r.createElement(l.default, {
                        cardFallbackWidths: t,
                        imageContainerStyle: P,
                        src: x.url,
                        altText: x.altText,
                        shouldLoadImmediately: m,
                        customContainerStyle: k,
                        id: I
                    })) || null, w ? r.createElement(d.default, {
                        data: w,
                        tagsHorizontalSpacing: W,
                        tagsAlignment: T,
                        styles: n
                    }) : null, h && r.createElement(u.GradientContainer, {
                        imageContainerStyle: P,
                        width: C.width
                    }), S ? r.createElement(u.TextContainer, {
                        cardTextContainerStyle: R
                    }, (0, c.renderCardText)(n, g, S)) : null), E ? (0, c.renderCardButtons)(n, g, E) : null) : null
                };
            p.defaultProps = {
                styles: {},
                cardStyle: {},
                data: {},
                hasStyle: !1,
                itemsPerRow: 0,
                overlayGradient: !1,
                cardFallbackWidths: {},
                shouldLoadImmediately: !1,
                overrideZindex: !1
            }, p.propTypes = {
                styles: o().object,
                cardStyle: o().object,
                data: o().object,
                hasStyle: o().bool,
                itemsPerRow: o().number,
                overlayGradient: o().bool,
                shouldLoadImmediately: o().bool,
                cardFallbackWidths: o().shape({}),
                overrideZindex: o().bool
            };
            const g = p
        },
        79320: (e, t, n) => {
            n.r(t), n.d(t, {
                GradientContainer: () => d,
                ImageContainer: () => l,
                OverlayCardContainer: () => o,
                OverlayCardImageContainer: () => i,
                TextContainer: () => s
            });
            var r = n(93352),
                a = n(72999),
                o = r.default.div.withConfig({
                    componentId: "sc-1xkgphj-0"
                })(["", ""], (e => {
                    var {
                        overlayGradient: t = !1
                    } = e;
                    return t ? "height: 100%; background: black; overflow: hidden; border-radius: 16px; " : ""
                })),
                i = r.default.div.withConfig({
                    componentId: "sc-1xkgphj-1"
                })(["position:relative;", ""], (e => {
                    var {
                        overlayGradient: t = !1
                    } = e;
                    return t ? "height: 100%" : ""
                })),
                l = r.default.div.withConfig({
                    componentId: "sc-1xkgphj-2"
                })(["", ""], (e => {
                    var {
                        imageContainerStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasMargin: !0
                    })
                })),
                d = r.default.div.withConfig({
                    componentId: "sc-1xkgphj-3"
                })(["width:", ";", " position:absolute;top:0;background:linear-gradient(to bottom,rgba(0,0,0,0) 60%,rgba(0,0,0,1) 100%);"], (e => {
                    var {
                        width: t
                    } = e;
                    return "".concat(t, "px")
                }), (e => {
                    var {
                        imageContainerStyle: t,
                        width: n
                    } = e;
                    return t && t.aspectRatio ? "height: ".concat(n / t.aspectRatio, "px;") : "height:100%"
                })),
                s = r.default.div.withConfig({
                    componentId: "sc-1xkgphj-4"
                })(["position:absolute;bottom:0;left:0;width:100%;", ""], (e => {
                    var {
                        cardTextContainerStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasPadding: !0,
                        hasBackgroundColor: !0,
                        hasBorderRadius: !0
                    })
                }))
        },
        51375: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => y
            });
            var r = n(4942),
                a = n(67294),
                o = n(14494),
                i = n(45697),
                l = n(68932),
                d = n(77100),
                s = n(24223),
                c = n(8714),
                u = n(9019),
                p = n(46381),
                g = n(72999);

            function h(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }
            var m = {
                    background: "none",
                    border: "none"
                },
                f = e => {
                    var {
                        horizontalSpacing: t,
                        verticalSpacing: n,
                        cardFallbackWidths: i,
                        styles: f,
                        cardStyle: y,
                        data: v,
                        hasStyle: b,
                        itemsPerRow: C,
                        isHeaderType: x
                    } = e, S = (0, o.v9)((e => e.cookies)), [w] = (0, s.useImpressionTracker)(null, S), {
                        image: E,
                        text: I,
                        tags: P,
                        id: R,
                        seoText: T = "",
                        metaImages: W = []
                    } = v, {
                        imageContainer: k = {},
                        textContainer: O = {},
                        tagsAlignment: _ = "right",
                        tagsHorizontalSpacing: F = 0
                    } = y;
                    if (b) {
                        var B = function(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? h(Object(n), !0).forEach((function(t) {
                                    (0, r.Z)(e, t, n[t])
                                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : h(Object(n)).forEach((function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                }))
                            }
                            return e
                        }({}, (() => {
                            var e = {};
                            if (O) {
                                var {
                                    margin: t,
                                    padding: n
                                } = O;
                                t && (e.margin = "".concat(t.replace(/,/g, "px "), "px")), n && (e.padding = "".concat(n.replace(/,/g, "px "), "px"))
                            }
                            return e
                        })());
                        return a.createElement(u.VerticalCardContainer, {
                            ref: w,
                            horizontalSpacing: t,
                            verticalSpacing: n,
                            cardStyle: y
                        }, P ? a.createElement(l.default, {
                            data: P,
                            tagsHorizontalSpacing: F,
                            tagsAlignment: _,
                            styles: f
                        }) : null, E && E.url && a.createElement(d.default, {
                            cardFallbackWidths: i,
                            imageContainerStyle: k,
                            src: E.url,
                            altText: E.altText,
                            shouldLoadImmediately: x,
                            hasThumbnail: x,
                            customContainerStyle: x ? m : null,
                            id: R
                        }) || null, (null == W ? void 0 : W.length) > 0 && (null == W ? void 0 : W.map((e => {
                            var t = (0, g.getComponentStyleFromStyleId)(e.styleId, f) || [],
                                {
                                    altText: n = "",
                                    url: r = ""
                                } = e.image || {};
                            return a.createElement(d.default, {
                                key: "meta_".concat(n),
                                imageContainerStyle: t[0],
                                src: r,
                                altText: n,
                                shouldLoadImmediately: !0,
                                customContainerStyle: x ? m : null
                            })
                        }))) || null, I && a.createElement(p.HorizontalFlexBox, {
                            style: B
                        }, (0, c.renderCardText)(f, C, I), T && a.createElement(p.SeoHeaderTag, null, T)))
                    }
                    return null
                };
            f.defaultProps = {
                horizontalSpacing: 0,
                verticalSpacing: 0,
                styles: {},
                cardStyle: {},
                data: {},
                hasStyle: !1,
                itemsPerRow: 0,
                isHeaderType: !1,
                cardFallbackWidths: {}
            }, f.propTypes = {
                horizontalSpacing: i.number,
                verticalSpacing: i.number,
                styles: (0, i.shape)({}),
                cardStyle: (0, i.shape)({}),
                data: (0, i.shape)({}),
                hasStyle: i.bool,
                itemsPerRow: i.number,
                isHeaderType: i.bool,
                cardFallbackWidths: (0, i.shape)({})
            };
            const y = f
        },
        9019: (e, t, n) => {
            n.r(t), n.d(t, {
                VerticalCardContainer: () => o
            });
            var r = n(93352),
                a = n(72999),
                o = r.default.div.withConfig({
                    componentId: "sc-dv5ht7-0"
                })(["position:relative;height:100%;", " ", " ", ""], (e => {
                    var {
                        horizontalSpacing: t
                    } = e;
                    return t ? "padding-right: ".concat(t, "px;") : ""
                }), (e => {
                    var {
                        verticalSpacing: t
                    } = e;
                    return t ? "padding-bottom: ".concat(t, "px;") : ""
                }), (e => {
                    var {
                        cardStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasBackgroundColor: !0,
                        hasPadding: !0,
                        hasBorder: !0,
                        hasBorderRadius: !0,
                        hasShadow: !0
                    })
                }))
        },
        94245: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => d,
                defaultComponent: () => l
            });
            var r = n(67294),
                a = n(71671),
                o = n(51375),
                i = n(73394),
                l = e => {
                    var {
                        error: t = "Card Not Found"
                    } = e;
                    return r.createElement("div", {
                        "data-error": t
                    })
                };
            const d = {
                horizontal: a.default,
                vertical: o.default,
                overlay: i.default,
                default: l
            }
        },
        8714: (e, t, n) => {
            n.r(t), n.d(t, {
                renderCardButtons: () => p,
                renderCardText: () => u,
                renderCardTextBox: () => c
            });
            var r = n(4942),
                a = n(67294),
                o = n(54922),
                i = n(72999),
                l = n(46381);

            function d(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? d(Object(n), !0).forEach((function(t) {
                        (0, r.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : d(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var c = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                    return n ? n.components.map(((r, i) => {
                        var l = r.styleId || n.styleId,
                            d = e[l] || {},
                            c = o.default[r.type] || o.default.default;
                        return a.createElement(c, {
                            key: i,
                            src: r.imageUrl,
                            text: r.text,
                            maxLines: n.maxLines,
                            hybridStyle: t ? d : s(s({}, d), {}, {
                                doNotWrap: !0
                            }),
                            width: d.width || "14px",
                            height: d.height || "14px",
                            hasThumbnail: !1,
                            customContainerStyle: {
                                background: "none"
                            }
                        })
                    })) : null
                },
                u = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                    return n ? n.map(((n, r) => a.createElement(l.CardTextBox, {
                        key: r
                    }, c(e, t, n)))) : null
                },
                p = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                    if (n) {
                        var r = n.map((t => e[t.styleId] || {})),
                            o = (0, i.getModifiedStyles)(r);
                        return a.createElement(l.CardCTA, null, n.map(((n, r) => {
                            var i = o[r] || {};
                            return a.createElement(l.Button, {
                                key: "".concat(r + t),
                                buttonStyle: i
                            }, n.label ? c(e, t, n.label) : null)
                        })))
                    }
                    return null
                }
        },
        75630: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => E
            });
            var r = n(4942),
                a = n(67294),
                o = n(45697),
                i = n(49486),
                l = n(79153),
                d = n(16550),
                s = n(14494),
                c = n(67482),
                u = n(48169),
                p = n(94245),
                g = n(26655),
                h = n(72999),
                m = n(5237),
                f = n(82714),
                y = n(24223),
                v = n(9127),
                b = n(46381),
                C = n(99698);

            function x(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function S(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? x(Object(n), !0).forEach((function(t) {
                        (0, r.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : x(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var w = e => {
                var {
                    isHomePage: t,
                    data: n,
                    styles: r,
                    isSidebarOpen: o,
                    ctaClickHandler: x
                } = e, {
                    cookies: w,
                    deviceType: E
                } = (0, s.v9)((e => ({
                    cookies: e.cookies,
                    deviceType: e.config.deviceType
                }))), I = (0, d.k6)(), P = (0, a.useContext)(m.default), {
                    isSticky: R,
                    cards: T = [],
                    title: W,
                    subtitle: k,
                    tag: O,
                    cta: _,
                    styleId: F,
                    visibleItems: B,
                    itemsPerRow: A,
                    verticalSpacing: H,
                    horizontalSpacing: z,
                    snapping: D,
                    immersive: j,
                    fillViewport: M,
                    id: L
                } = n, V = "CUSTOM_PTM_WEB" === L || !1, [N, Y] = (0, y.useSticky)(R, t ? 63 : 55), G = (0, a.useRef)(!1), [U, K] = (0, a.useState)([!1, !1]), [Z, q] = (0, a.useState)(0), [X, $] = (0, a.useState)(!1), J = (0, h.getComponentStyleFromStyleId)(F, r, {
                    hasCardContainerStyle: !0
                }), Q = (0, h.getLeftRightSpacing)(1, J[0].padding || "0,0,0,0"), ee = (0, h.getLeftRightSpacing)(1, J[2].padding || "0,0,0,0"), te = (0, h.getVisibleCardsHorizontalSpacing)(B, z), ne = "(100% - ".concat(te, "px)"), re = "".concat(Q, "px - ").concat(ee, "px - ").concat(te, "px"), ae = A || T.length, oe = Math.ceil(T.length / ae);
                ae = Math.ceil(T.length / oe);
                var [ie] = (0, y.useImpressionTracker)(null, w), [le, de] = (0, a.useState)(0), se = (0, a.useRef)((0, l.isCrawlerAgent)() || !1), [ce, ue] = (0, a.useState)(0), pe = () => {
                    ue(ce + 1)
                }, [ge, he] = (0, a.useState)(null), me = "desktop" === E;
                (0, a.useEffect)((() => {
                    var e = (0, l.getIn)(G, ["current", "clientWidth"]) || 0,
                        t = (0, l.getIn)(G, ["current", "scrollWidth"]) || 0,
                        n = (0, l.getIn)(G, ["current", "childNodes", 0, "clientWidth"]) || 0,
                        r = 0 !== Z,
                        a = t + Z - e > n;
                    t / T.length < n && (a = t / B * T.length + Z - e > n), K([r, a])
                }), [G, Z]);
                var fe, ye, ve, be, Ce, xe = (e, t) => n => {
                        if ((0, u.handleCTAClick)(n, I, e, w), null != t && t.trailerUrl && !me) {
                            var r, a, o = document.getElementById("webVideo");
                            if (null != o && o.paused || null == o || !o.pause) {
                                if ("youtube" === (null === (r = window.BMSSDK) || void 0 === r || null === (a = r.videoAdsHandler) || void 0 === a ? void 0 : a.type)) {
                                    var i, l, d;
                                    null === (i = window.BMSSDK) || void 0 === i || null === (l = i.videoAdsHandler) || void 0 === l || null === (d = l.video) || void 0 === d || d.pauseVideo()
                                }
                            } else o.oldStatePlaying = !0, o.pause();
                            he({
                                url: null == t ? void 0 : t.trailerUrl
                            })
                        }
                    },
                    Se = (e, n, o, i, l, d, s, c) => {
                        var u = "".concat(n, "-").concat(e),
                            {
                                cardDivisions: p = []
                            } = l;
                        return a.createElement(C.CardContainer, {
                            key: e,
                            index: e,
                            horizontalSpacing: z,
                            verticalSpacing: H,
                            visibleItems: B,
                            itemsPerRow: ae,
                            totalCards: T.length,
                            lastRowElementsCount: T.length % ae,
                            cardContainerPadding: J[2].padding,
                            href: n,
                            onClick: null != p && p.length ? null : xe(o, l),
                            snapping: D,
                            lastIndex: e === T.length - 1,
                            id: u
                        }, (null == p ? void 0 : p.length) > 0 && a.createElement(C.ActionsCardOverlay, null, null == p ? void 0 : p.map((e => {
                            var {
                                heightPercentage: t,
                                cta: {
                                    url: n,
                                    analytics: r = {}
                                } = {}
                            } = e;
                            return a.createElement(C.ActionCardItem, {
                                href: n,
                                height: t,
                                onClick: xe(r, l)
                            })
                        }))), a.createElement(d, {
                            error: "Card Not Found for ".concat(i),
                            data: l,
                            cardFallbackWidths: {
                                mobile: "((100vw - ".concat(s, ") / ").concat(B, ")"),
                                desktop: "((92vw - ".concat(t ? 0 : 330, "px - ").concat(s, ") / ").concat(B, ")"),
                                maxDesktop: "((1240px - ".concat(t ? 0 : 330, "px - ").concat(s, ") / ").concat(B, ")")
                            },
                            parentId: L,
                            styles: r,
                            cardStyle: c[0],
                            hasStyle: c[3],
                            itemsPerRow: B,
                            isHeaderType: "NEW_NAV_MENU_MOBILE" === L,
                            isPTMWidget: V,
                            cardCtaRefId: u,
                            registerDismissAction: pe
                        }))
                    },
                    we = () => {
                        var e = (((0, l.getIn)(G, ["current", "childNodes", 0, "clientWidth"]) || 0) + z) * parseInt(B, 10);
                        0 !== Z && q(Z + e <= 0 ? Z + e : 0)
                    },
                    Ee = () => {
                        var e = (0, l.getIn)(G, ["current", "clientWidth"]) || 0,
                            t = (0, l.getIn)(G, ["current", "scrollWidth"]) || 0,
                            n = (((0, l.getIn)(G, ["current", "childNodes", 0, "clientWidth"]) || 0) + z) * parseInt(B, 10);
                        t + Z - e > 0 && q(t - e + Z - n < 0 ? -(t - e) : Z - n)
                    },
                    Ie = (0, l.debounce)((() => {
                        var e = (0, l.getIn)(G, ["current", "scrollLeft"]) || 0,
                            t = (0, l.getIn)(G, ["current", "clientWidth"]) || 0,
                            n = (0, l.getIn)(G, ["current", "childNodes", 0, "clientWidth"]) || 0;
                        de(parseInt((e + t / 2) / n, 10))
                    })),
                    Pe = S({}, (() => {
                        var e = {};
                        if (J && J[0]) {
                            var {
                                margin: t,
                                padding: n
                            } = J[0];
                            t && (e.margin = "".concat(t.replace(/,/g, "px "), "px")), n && (e.padding = "".concat(n.replace(/,/g, "px "), "px"))
                        }
                        return e
                    })()),
                    Re = S({}, (() => {
                        var e = {};
                        if (J && J[0]) {
                            var t = (0, l.getIn)(J, [0, "background", "color"]) || (0, l.getIn)(J, [0, "backgroundColor"]) || null;
                            t && (e.backgroundColor = t)
                        }
                        return e
                    })());
                return J[3] && T.length > 0 ? a.createElement(b.FullWidgetWrapper, {
                    isPTMWidget: V,
                    isClosePtmWidget: X,
                    ref: N,
                    isFixed: Y,
                    widgetHeight: N && N.current ? N.current.children[0].clientHeight : 0,
                    show: V && !o,
                    hide: T.length === ce
                }, a.createElement(b.WidgetWrapper, {
                    ref: ie,
                    style: Re,
                    isFixed: Y
                }, j ? a.createElement(b.ImmersiveContainer, {
                    fillViewport: M,
                    backgroundImage: (Ce = T[le] || null, Ce && (0, l.getIn)(Ce, ["image", "url"]) || null)
                }) : null, a.createElement(b.WidgetContainer, {
                    isHomePage: t,
                    style: Pe,
                    immersive: j,
                    isPTMWidget: V
                }, a.createElement(g.default, {
                    title: W,
                    subtitle: k,
                    tag: O,
                    cta: _,
                    styleId: F,
                    styles: r,
                    isPTMWidget: V,
                    isClosePtmWidget: X,
                    setClosePtmWidget: $
                }), a.createElement(C.RelativeContainer, null, a.createElement(C.WidgetContainerWrapper, null, a.createElement(C.WidgetContainerBody, {
                    ref: G,
                    containerWidth: ne,
                    theme: i.default,
                    xTransform: Z,
                    cardContainerStyle: J[2],
                    verticalSpacing: H,
                    horizontalSpacing: z,
                    itemsPerColumn: oe,
                    itemsPerRow: ae - ce,
                    visibleItems: B,
                    snapping: D,
                    onScroll: Ie
                }, T.map(((e, t) => {
                    var {
                        type: n = null,
                        analytics: o = null,
                        id: i
                    } = e, l = (0, h.getComponentStyleFromStyleId)(e.styleId, r), d = p.default[n] || p.default.default, s = e.ctaUrl ? e.ctaUrl : "";
                    e.trailerUrl && !me && (s = "");
                    var c = (0, h.getLeftRightSpacing)(A || B, l[0].padding || "0,0,0,0"),
                        u = "".concat(re, " - ").concat(c, "px");
                    return a.createElement(a.Fragment, {
                        key: i
                    }, null != P && P.includes(L) ? a.createElement(f.default, {
                        key: i,
                        id: i,
                        isCrawler: se.current
                    }, Se(t, s, o, n, e, d, u, l)) : a.createElement(a.Fragment, null, Se(t, s, o, n, e, d, u, l)))
                }))), (fe = (0, h.getComponentStyleFromStyleId)(T[0].styleId, r), ye = fe[3] ? (0, l.getIn)(fe[0], ["imageContainer", "aspectRatio"]) : "0.6", ve = (0, l.getIn)(G, ["current", "clientWidth"]) || 0, be = "(((".concat(ve, "px - ").concat(te, "px) / ").concat(B, ") / ").concat(ye, ")"), a.createElement(a.Fragment, null, U[0] ? a.createElement(C.LeftButton, {
                    cardImageHeight: be,
                    onClick: we
                }, a.createElement(C.SliderIconWrapper, null, a.createElement(v.LeftArrow, null))) : null, U[1] ? a.createElement(C.RightButton, {
                    cardImageHeight: be,
                    onClick: Ee
                }, a.createElement(C.SliderIconWrapper, null, a.createElement(v.RightArrow, null))) : null)), a.createElement(c.default, {
                    isVisible: ge && !me,
                    handleClose: () => {
                        var e, t, n = document.getElementById("webVideo");
                        if (he(null), null != n && n.paused && null != n && n.play && n.oldStatePlaying) delete n.oldStatePlaying, n.play();
                        else if ("youtube" === (null === (e = window.BMSSDK) || void 0 === e || null === (t = e.videoAdsHandler) || void 0 === t ? void 0 : t.type)) {
                            var r, a, o;
                            null === (r = window.BMSSDK) || void 0 === r || null === (a = r.videoAdsHandler) || void 0 === a || null === (o = a.video) || void 0 === o || o.playVideo()
                        }
                    },
                    bottomSheetContent: {
                        type: "youtube",
                        url: null == ge ? void 0 : ge.url
                    },
                    isDesktop: me,
                    closeButtonPosition: "topRight"
                })))))) : null
            };
            w.defaultProps = {
                isHomePage: !1,
                styles: {},
                data: {},
                isSidebarOpen: !1
            }, w.propTypes = {
                isHomePage: o.bool,
                styles: (0, o.shape)({}),
                data: (0, o.shape)({
                    isSticky: o.bool,
                    cards: (0, o.arrayOf)((0, o.shape)({})),
                    title: (0, o.shape)({}),
                    subtitle: o.string,
                    tag: o.string,
                    cta: o.string,
                    styleId: o.string,
                    visibleItems: o.number,
                    itemsPerRow: o.number,
                    verticalSpacing: o.number,
                    horizontalSpacing: o.number,
                    snapping: o.bool,
                    immersive: o.bool,
                    fillViewport: o.bool,
                    id: o.string
                }),
                isSidebarOpen: o.bool
            };
            const E = w
        },
        99698: (e, t, n) => {
            n.r(t), n.d(t, {
                ActionCardItem: () => s,
                ActionsCardOverlay: () => d,
                CardContainer: () => u,
                LeftButton: () => g,
                RelativeContainer: () => i,
                RightButton: () => h,
                SliderButton: () => p,
                SliderIconWrapper: () => m,
                WidgetContainerBody: () => c,
                WidgetContainerWrapper: () => l
            });
            var r = n(93352),
                a = n(72999),
                o = n(46381),
                i = r.default.div.withConfig({
                    componentId: "sc-lnhrs7-0"
                })(["position:relative;"]),
                l = r.default.div.withConfig({
                    componentId: "sc-lnhrs7-1"
                })(["overflow:initial;@media ", "{overflow:hidden;}"], (e => e.theme.laptopMin)),
                d = r.default.div.withConfig({
                    componentId: "sc-lnhrs7-2"
                })(["position:absolute;top:0;left:0;height:100%;width:100%;z-index:", ";"], (e => {
                    var {
                        theme: t
                    } = e;
                    return t.afterZ
                })),
                s = r.default.a.withConfig({
                    componentId: "sc-lnhrs7-3"
                })(["display:block;height:", "%;"], (e => {
                    var {
                        height: t
                    } = e;
                    return t
                })),
                c = r.default.div.withConfig({
                    componentId: "sc-lnhrs7-4"
                })(["scroll-behavior:smooth;transition:transform 1000ms ease 0s;overscroll-behavior-x:contain;", " ", " ", " ", " overflow-x:scroll;overflow-y:hidden;transform:initial;@media ", "{overflow:visible;transform:translateX(", "px);}"], (e => {
                    var {
                        theme: t
                    } = e;
                    return t.hideHorizontalScrollbar
                }), (e => {
                    var {
                        snapping: t
                    } = e;
                    return t ? "scroll-snap-type: x mandatory;" : ""
                }), (e => {
                    var {
                        cardContainerStyle: t
                    } = e;
                    return (0, a.getComponentStyle)(t, {
                        hasBackgroundColor: !0,
                        hasPadding: !0,
                        hasMargin: !0
                    })
                }), (e => {
                    var {
                        itemsPerRow: t,
                        visibleItems: n,
                        itemsPerColumn: r,
                        verticalSpacing: o = 0,
                        horizontalSpacing: i = 0,
                        containerWidth: l
                    } = e;
                    return n ? "".concat((0, a.getIEGridCSS)(t, n, r, o, i, l), "display: grid;\n\t\t\tgrid-template-columns: repeat(").concat(t, ", calc(").concat(l, " / ").concat(n, "));grid-template-rows: repeat(").concat(r, ", 1fr);grid-auto-flow: column;grid-gap: ").concat(o, "px ").concat(i, "px;") : "display: flex;"
                }), (e => e.theme.laptopMin), (e => {
                    var {
                        xTransform: t
                    } = e;
                    return t
                })),
                u = (0, r.default)(o.LinkWrapper).withConfig({
                    componentId: "sc-lnhrs7-5"
                })(["position:relative;display:block;", " ", " ", ""], (e => {
                    var {
                        snapping: t
                    } = e;
                    return t ? "scroll-snap-align: center;" : ""
                }), (e => {
                    var {
                        visibleItems: t,
                        cardContainerPadding: n,
                        lastIndex: r
                    } = e;
                    return r ? "\n\t\t\tpadding-right: ".concat(n.split(",")[1], "px;\n\t\t\t").concat(t ? "width: calc(100% + ".concat(n.split(",")[1], "px);") : "", "\n\t\t\t") : ""
                }), (e => {
                    var {
                        visibleItems: t,
                        horizontalSpacing: n = 0,
                        verticalSpacing: r = 0,
                        totalCards: a,
                        itemsPerRow: o,
                        index: i
                    } = e;
                    return t ? "" : "margin-right: ".concat(n, "px;margin-bottom: ").concat(r, "px;\n\t\t\t&:nth-child(").concat(-a + (a % o || o) + i + 1, "n) { margin-bottom: 0;}")
                })),
                p = (0, r.default)(o.DesktopOnlyContainer).withConfig({
                    componentId: "sc-lnhrs7-6"
                })(["align-items:center;justify-content:center;position:absolute;cursor:pointer;width:40px;height:40px;background-color:", ";top:calc((", " / 2) - 20px);border-radius:20px;@media ", "{display:flex;}"], (e => {
                    var {
                        theme: t
                    } = e;
                    return t.GREY_6
                }), (e => {
                    var {
                        cardImageHeight: t
                    } = e;
                    return t
                }), (e => e.theme.laptopMin)),
                g = (0, r.default)(p).withConfig({
                    componentId: "sc-lnhrs7-7"
                })(["left:-20px;"]),
                h = (0, r.default)(p).withConfig({
                    componentId: "sc-lnhrs7-8"
                })(["right:-20px;"]),
                m = r.default.div.withConfig({
                    componentId: "sc-lnhrs7-9"
                })(["width:18px;height:18px;svg{width:100%;height:100%;}"])
        },
        26655: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => y
            });
            var r = n(4942),
                a = n(67294),
                o = n(45697),
                i = n.n(o),
                l = n(16550),
                d = n(14494),
                s = n(68932),
                c = n(54922),
                u = n(48169),
                p = n(72999),
                g = n(46381),
                h = n(11459);

            function m(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }
            var f = e => {
                var t, {
                        title: n,
                        subtitle: o,
                        tag: i,
                        cta: f,
                        styleId: y,
                        styles: v,
                        dimensionref: b,
                        isPTMWidget: C,
                        isClosePtmWidget: x,
                        setClosePtmWidget: S
                    } = e,
                    w = (0, l.k6)(),
                    E = (0, d.v9)((e => e.cookies)),
                    I = (0, p.getComponentStyleFromStyleId)(y, v, {
                        hasHeaderStyle: !0
                    }),
                    P = function(e, t, n) {
                        var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                            o = (0, p.getComponentStyleFromStyleId)(t.styleId, v),
                            i = c.default[n.type] || c.default.default;
                        return a.createElement(i, {
                            key: e,
                            text: n.text,
                            headerText: r,
                            hybridStyle: o[0],
                            src: n.imageUrl,
                            width: "auto",
                            height: "100%",
                            imageContainerStyle: {
                                margin: "auto 0",
                                border: {
                                    cornerRadius: "2"
                                }
                            },
                            isPTMWidget: C,
                            isClosePtmWidget: x,
                            setClosePtmWidget: S
                        })
                    },
                    R = function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? m(Object(n), !0).forEach((function(t) {
                                (0, r.Z)(e, t, n[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : m(Object(n)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            }))
                        }
                        return e
                    }({}, (() => {
                        var e = {};
                        if (I && I[1]) {
                            var {
                                margin: t,
                                padding: n
                            } = I[1];
                            t && (e.margin = "".concat(t.replace(/,/g, "px "), "px")), n && (e.padding = "".concat(n.replace(/,/g, "px "), "px"))
                        }
                        return e
                    })());
                return a.createElement(g.HorizontalFlexBox, {
                    ref: b,
                    style: R
                }, n && a.createElement(h.WidgetHeaderTitleContainerWrapper, null, a.createElement(h.WidgetHeaderTitleWrapper, {
                    isPTMWidget: C
                }, n.components && n.components.map(((e, t) => P(t, n, e, !0)))), f && Object.keys(f).length > 0 ? a.createElement(h.WidgetHeaderTitleCTAWrapper, null, a.createElement(g.LinkWrapper, {
                    href: f.url || "",
                    onClick: (t = f.analytics || null, e => {
                        (0, u.handleCTAClick)(e, w, t, E)
                    })
                }, f.label && f.label.components.map(((e, t) => P(t, f.label, e))) || null)) : null, i && Object.keys(i).length > 0 ? a.createElement(h.WidgetHeaderTitleTagWrapper, null, a.createElement(s.default, {
                    data: [i],
                    styles: v
                })) : null), o && (o.components ? o.components.map(((e, t) => P(t, o, e))) : null))
            };
            f.defaultProps = {
                analytics: {},
                title: {},
                subtitle: {},
                tag: {},
                cta: {},
                styleId: "",
                data: {},
                isPTMWidget: !1,
                isClosePtmWidget: !1,
                setClosePtmWidget: () => {}
            }, f.propTypes = {
                analytics: i().shape({}),
                title: i().shape({}),
                subtitle: i().shape({}),
                tag: i().shape({}),
                cta: i().shape({}),
                styleId: i().string,
                data: i().shape({}),
                isPTMWidget: i().bool,
                isClosePtmWidget: i().bool,
                setClosePtmWidget: i().func
            };
            const y = f
        },
        11459: (e, t, n) => {
            n.r(t), n.d(t, {
                WidgetHeaderTitleCTAWrapper: () => d,
                WidgetHeaderTitleContainerWrapper: () => o,
                WidgetHeaderTitleTagWrapper: () => s,
                WidgetHeaderTitleWrapper: () => l
            });
            var r = n(93352),
                a = n(46381),
                o = (0, r.default)(a.VerticalFlexBox).withConfig({
                    componentId: "sc-291x3n-0"
                })(["align-items:center;"]),
                i = (0, r.css)(["margin:0 0 0 auto;"]),
                l = (0, r.default)(a.VerticalFlexBox).withConfig({
                    componentId: "sc-291x3n-1"
                })(["margin:0 auto 0 0;", ""], (e => {
                    var {
                        isPTMWidget: t
                    } = e;
                    return t && i
                })),
                d = r.default.div.withConfig({
                    componentId: "sc-291x3n-2"
                })([""]),
                s = r.default.div.withConfig({
                    componentId: "sc-291x3n-3"
                })(["position:relative;margin:-4px 0 auto 0;div{div{margin:0;}}"])
        },
        5237: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => r
            });
            const r = n(67294).createContext([])
        }
    }
]);